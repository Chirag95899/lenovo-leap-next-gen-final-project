const fs = require('fs');
let content = fs.readFileSync('src/admin/pages/AdminStateAnalyticsPage.tsx', 'utf8');

content = content.replace(
  /import \{ apiFetch \} from '\.\.\/\.\.\/shared\/utils\/api';/g,
  ""
);

content = content.replace(
  /const res = await apiFetch\('\/api\/admin\/state-analytics'\);/,
  "const res = await fetch('/api/admin/state-analytics', { headers: { 'Authorization': `Bearer ${localStorage.getItem('admin_token')}` } });"
);

content = content.replace(
  /const res = await apiFetch\('\/api\/admin\/state-analytics\/report', \{ method: 'POST' \}\);/,
  "const res = await fetch('/api/admin/state-analytics/report', { method: 'POST', headers: { 'Authorization': `Bearer ${localStorage.getItem('admin_token')}` } });"
);

fs.writeFileSync('src/admin/pages/AdminStateAnalyticsPage.tsx', content);
