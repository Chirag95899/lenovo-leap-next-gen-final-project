const fs = require('fs');
let content = fs.readFileSync('src/admin/AdminCommandCenter.tsx', 'utf8');

// The block is:
/*
      {activeView === 'qr-scanner' && (
        <AdminQrScannerPage
          onNavigateToLot={(lotId) => {
            lotsQuery.setSearch(lotId);
            setActiveView('lots');
          }}
          onNavigateToPickup={(pickupId) => {
            pickupsQuery.setSearch(pickupId);
            setActiveView('pickups');
          }}
        />
      )}
*/

content = content.replace(
  /\{activeView === 'qr-scanner' && \([\s\S]*?<AdminQrScannerPage[\s\S]*?\/>\s*\)\}/g,
  ""
);

content = content.replace(
  /import \{ AdminQrScannerPage \} from '.\/pages\/AdminQrScannerPage';/g,
  ""
);

fs.writeFileSync('src/admin/AdminCommandCenter.tsx', content);
