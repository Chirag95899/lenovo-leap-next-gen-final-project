const fs = require('fs');

const file = 'src/admin/pages/AdminDashboardPage.tsx';
let code = fs.readFileSync(file, 'utf8');

if (!code.includes("IndiaMap")) {
  code = code.replace("import { DashboardResponseData } from '../types/dashboard';", "import { DashboardResponseData } from '../types/dashboard';\nimport { IndiaMap } from '../components/IndiaMap';");
  
  const mapStr = `
      {/* MAP AND HIGHLIGHTS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col h-full">
          <div className="flex items-center justify-between mb-4">
             <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
               <MapPin className="w-5 h-5 text-emerald-600" />
               Geographic Intelligence
             </h3>
             <div className="text-xs font-semibold text-slate-500 flex items-center gap-2">
               <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500 block"></span> Active</span>
               <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-300 block"></span> Pending</span>
             </div>
          </div>
          <div className="flex-1 w-full min-h-[400px]">
             <IndiaMap 
               data={[{
                 state: 'Chhattisgarh',
                 status: 'ACTIVE',
                 totalStakeholders: (overview.totalCollectors || 0) + (overview.totalAggregators || 0) + (overview.totalRecyclers || 0),
                 wasteRecycledKg: (overview.recyclingCompletedTons || 0) * 1000,
               }]}
               selectedState={selectedState}
               onSelectState={(state) => {
                 setSelectedState(state);
                 if (state === 'Chhattisgarh') setSelectedDistrict('Durg');
                 else setSelectedDistrict('');
               }}
             />
          </div>
        </div>

        <div className="space-y-4 flex flex-col">
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 shadow-sm">
             <h3 className="text-sm font-bold text-emerald-900 mb-2">RECYSETU Impact</h3>
             <div className="flex items-end gap-2 mb-1">
               <span className="text-3xl font-black text-emerald-700">{co2Offset.toLocaleString(undefined, {maximumFractionDigits: 1})}</span>
               <span className="text-sm font-bold text-emerald-600 mb-1">Tons CO₂e</span>
             </div>
             <p className="text-xs text-emerald-700 font-medium leading-relaxed">Emissions offset through verified circular operations. Verified via traceable e-waste manifests.</p>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex-1">
            <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-500" />
              Network Activity
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                <span className="text-sm text-slate-600 font-medium">Active Collectors</span>
                <span className="text-sm font-bold text-slate-900">{overview.activeWorkersCount || 0} / {overview.totalCollectors || 0}</span>
              </div>
              <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                <span className="text-sm text-slate-600 font-medium">Aggregators</span>
                <span className="text-sm font-bold text-slate-900">{overview.totalAggregators || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600 font-medium">Recycling Facilities</span>
                <span className="text-sm font-bold text-slate-900">{overview.totalRecyclers || 0}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
  `;

  // We'll replace the static Inactive state div with our map block, and we'll keep the metric cards below it.
  code = code.replace(/\{!\isDurgActive \? \([\s\S]*?Return to Active District\n\s*<\/button>\n\s*<\/div>\n\s*\) : \(\n\s*<>/, mapStr + "\n<>");
  
  fs.writeFileSync(file, code);
}
