try {
  const map = require('@react-map/india');
  console.log(Object.keys(map));
} catch(e) {
  console.log(e);
}
