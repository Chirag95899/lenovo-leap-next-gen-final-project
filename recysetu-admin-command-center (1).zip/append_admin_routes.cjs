const fs = require('fs');
let content = fs.readFileSync('server/routes/adminRoutes.ts', 'utf8');

const routes = `
// --- TRUST & REWARDS ROUTES ---
adminRouter.get('/reviews', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const search = req.query.search as string;
    
    const result = db.queryReviews({ page, limit, search });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_REVIEWS', message: err.message });
  }
});

adminRouter.post('/reviews/:id/process', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { action, scoreImpact } = req.body;
    
    const adminUser = req.adminUser;
    if (!adminUser) return res.status(401).json({ error: 'UNAUTHORIZED' });
    
    const review = db.processReview(id, adminUser.id, action, scoreImpact);
    if (!review) return res.status(404).json({ error: 'NOT_FOUND', message: 'Review not found' });
    
    res.json(review);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_PROCESS_REVIEW', message: err.message });
  }
});

adminRouter.post('/users/:id/override-score', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { newScore, reason } = req.body;
    
    const adminUser = req.adminUser;
    if (!adminUser) return res.status(401).json({ error: 'UNAUTHORIZED' });
    
    if (!reason || reason.trim().length < 5) {
      return res.status(400).json({ error: 'BAD_REQUEST', message: 'Reason must be at least 5 characters' });
    }
    
    const user = db.overrideScore(id, newScore, reason, adminUser.id);
    if (!user) return res.status(404).json({ error: 'NOT_FOUND', message: 'User not found' });
    
    res.json(user);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_SCORE_OVERRIDE', message: err.message });
  }
});

adminRouter.get('/users/:id/score-history', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const { id } = req.params;
    const history = db.queryScoreHistory(id);
    res.json(history);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_SCORE_HISTORY', message: err.message });
  }
});
`;

content = content.replace('export const adminRouter = Router();', 'export const adminRouter = Router();\n// Keep existing routes');
content += '\n' + routes;

fs.writeFileSync('server/routes/adminRoutes.ts', content);
