const fs = require('fs');

const content = `
import React, { useState, useEffect } from 'react';
import { Menu, Shield, RefreshCw, Bell, LogOut, Search } from 'lucide-react';
import { User } from '../../shared/types/domain';

interface AdminHeaderProps {
  id?: string;
  adminUser: User | null;
  onToggleSidebar: () => void;
  onLogout: () => void;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export const AdminHeader: React.FC<AdminHeaderProps> = ({
  id = 'admin-header',
  adminUser,
  onToggleSidebar,
  onLogout,
  onRefresh,
  isRefreshing = false,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Example of debouncing visual state (architectural prep for global search)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchQuery.trim()) {
        console.log('Global search executing for:', searchQuery);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  return (
    <header
      id={id}
      className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 sm:px-6 bg-white border-b border-slate-200 shadow-[0_1px_2px_0_rgba(0,0,0,0.03)]"
    >
      <div className="flex items-center gap-3 flex-1">
        <button
          id="mobile-sidebar-toggle"
          type="button"
          onClick={onToggleSidebar}
          className="p-2 -ml-2 text-slate-500 rounded-lg lg:hidden hover:bg-slate-100 hover:text-slate-800 transition-colors"
          aria-label="Toggle navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Global Search Field */}
        <div className="hidden sm:flex relative w-full max-w-md">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="w-4 h-4 text-slate-400" />
          </div>
          <input
            type="text"
            className="bg-slate-50 border border-slate-200 text-slate-900 text-sm rounded-lg focus:ring-emerald-500 focus:border-emerald-500 block w-full pl-9 p-2 placeholder-slate-400 transition-colors"
            placeholder="Search users, lots, pickups..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-4 ml-4">
        {onRefresh && (
          <button
            id="admin-telemetry-refresh-btn"
            type="button"
            onClick={onRefresh}
            disabled={isRefreshing}
            title="Refresh dynamic telemetry"
            className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-50"
          >
            <RefreshCw className={\`w-4 h-4 \${isRefreshing ? 'animate-spin text-emerald-600' : ''}\`} />
          </button>
        )}

        <div className="relative">
          <button
            id="admin-notifications-btn"
            type="button"
            className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors relative"
            title="System alerts"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white" />
          </button>
        </div>

        <div className="h-6 w-px bg-slate-200 hidden sm:block mx-1" />

        {adminUser && (
          <div className="flex items-center gap-3">
            <div className="hidden md:flex flex-col text-right">
              <span className="text-xs font-bold text-slate-900">{adminUser.name}</span>
              <div className="flex items-center justify-end gap-1 text-[10px] font-mono text-emerald-700">
                <Shield className="w-3 h-3 text-emerald-600" />
                <span>{adminUser.adminId || 'SUPER_ADMIN'}</span>
              </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-xs font-bold ring-2 ring-white shadow-sm border border-emerald-200">
              {adminUser.name ? adminUser.name.charAt(0) : 'A'}
            </div>
            <button
              id="admin-logout-btn"
              type="button"
              onClick={onLogout}
              title="Sign out of Admin Command Center"
              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors ml-1"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
`;

fs.writeFileSync('src/admin/components/AdminHeader.tsx', content);
