const fs = require('fs');

function patchReviews() {
  let code = fs.readFileSync('src/admin/pages/AdminReviewsPage.tsx', 'utf8');
  const oldFetch = `      const res = await fetch(\`/api/admin/reviews?search=\${search}\`, {
        headers: { 'Authorization': \`Bearer \${adminApi.getToken()}\` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to fetch');`;
  const newFetch = `      const data = await adminApi.getReviews(search);`;
  
  const oldProcess = `      const res = await fetch(\`/api/admin/reviews/\${selectedReview.id}/process\`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': \`Bearer \${adminApi.getToken()}\`
        },
        body: JSON.stringify({ decision, notes })
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || 'Action failed');
      }`;
  const newProcess = `      await adminApi.processReview(selectedReview.id, decision, notes);`;
  
  code = code.replace(oldFetch, newFetch).replace(oldProcess, newProcess);
  fs.writeFileSync('src/admin/pages/AdminReviewsPage.tsx', code);
}

function patchTrust() {
  let code = fs.readFileSync('src/admin/pages/AdminTrustRewardsPage.tsx', 'utf8');
  const oldFetch = `      const res = await fetch(\`/api/admin/trust-rewards?search=\${search}\`, {
        headers: { 'Authorization': \`Bearer \${adminApi.getToken()}\` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to fetch');`;
  const newFetch = `      const data = await adminApi.getTrustRewards(search);`;
  
  const oldProcess = `      const res = await fetch(\`/api/admin/trust-rewards/\${selectedRequest.id}/process\`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': \`Bearer \${adminApi.getToken()}\`
        },
        body: JSON.stringify({ action, amountInr })
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || 'Action failed');
      }`;
  const newProcess = `      await adminApi.processTrustReward(selectedRequest.id, action, amountInr);`;
  
  code = code.replace(oldFetch, newFetch).replace(oldProcess, newProcess);
  fs.writeFileSync('src/admin/pages/AdminTrustRewardsPage.tsx', code);
}

patchReviews();
patchTrust();
