const fs = require('fs');
let content = fs.readFileSync('src/admin/pages/AdminStateAnalyticsPage.tsx', 'utf8');

const oldFetch = `
  const fetchStateAnalytics = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/admin/state-analytics', { headers: { 'Authorization': \`Bearer \${localStorage.getItem('admin_token')}\` } });
      const json = await res.json();
      setData(json);
      setError(null);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };
`.trim();

const newFetch = `
  const fetchStateAnalytics = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/admin/state-analytics', { headers: { 'Authorization': \`Bearer \${localStorage.getItem('admin_token')}\` } });
      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.message || 'Failed to fetch state analytics');
      }
      if (Array.isArray(json)) {
        setData(json);
      } else if (json.data && Array.isArray(json.data)) {
        setData(json.data);
      } else {
        throw new Error('Invalid data format received');
      }
      setError(null);
    } catch (err: any) {
      setError(err.message);
      setData(null);
    } finally {
      setIsLoading(false);
    }
  };
`.trim();

// Because spacing might be different, let's use a regex
content = content.replace(
  /const fetchStateAnalytics = async \(\) => \{[\s\S]*?finally \{\s*setIsLoading\(false\);\s*\}\s*\};/,
  newFetch
);

fs.writeFileSync('src/admin/pages/AdminStateAnalyticsPage.tsx', content);
