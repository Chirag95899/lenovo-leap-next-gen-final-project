const fs = require('fs');
let content = fs.readFileSync('server/routes/adminRoutes.ts', 'utf8');

const newRoute = `
adminRouter.get('/state-analytics', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const stats = db.getStateAnalytics();
    res.json(stats);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_STATE_ANALYTICS', message: err.message });
  }
});
`;

content = content.replace(
  /adminRouter\.get\(\['\/dashboard-stats'/,
  newRoute + "\nadminRouter.get(['/dashboard-stats'"
);

fs.writeFileSync('server/routes/adminRoutes.ts', content);
