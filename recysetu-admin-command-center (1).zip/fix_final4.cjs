const fs = require('fs');

// 1. AuditLog actorRole and targetResource
let adminRoutes = fs.readFileSync('server/routes/adminRoutes.ts', 'utf8');
adminRoutes = adminRoutes.replace(/entityId: user\.id,\n/g, "actorRole: 'ADMIN',\ntargetResource: user.id,\n");
fs.writeFileSync('server/routes/adminRoutes.ts', adminRoutes);

// 2. AdminCommandCenter.tsx autoRefresh
let adminCenter = fs.readFileSync('src/admin/AdminCommandCenter.tsx', 'utf8');
adminCenter = adminCenter.replace(/autoRefresh=\{dashboard\.autoRefresh\}\n/g, "");
adminCenter = adminCenter.replace(/onToggleAutoRefresh=\{dashboard\.onToggleAutoRefresh\}\n/g, "");
// just in case
adminCenter = adminCenter.replace(/autoRefresh=\{.*\}\n/g, "");
adminCenter = adminCenter.replace(/onToggleAutoRefresh=\{.*\}\n/g, "");
fs.writeFileSync('src/admin/AdminCommandCenter.tsx', adminCenter);

