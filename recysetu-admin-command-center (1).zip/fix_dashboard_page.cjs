const fs = require('fs');
let content = fs.readFileSync('src/admin/pages/AdminDashboardPage.tsx', 'utf8');

content = content.replace(/bg-slate-900 text-white/g, 'bg-emerald-600 text-white');
content = content.replace(/border-slate-900/g, 'border-emerald-600');
content = content.replace(/hover:bg-slate-800/g, 'hover:bg-emerald-700');
content = content.replace(/focus:ring-slate-900/g, 'focus:ring-emerald-600');

fs.writeFileSync('src/admin/pages/AdminDashboardPage.tsx', content);
