import React from 'react';
import { ComposableMap, Geographies, Geography } from 'react-simple-maps';
import { renderToString } from 'react-dom/server';
import fs from 'fs';

const geoUrl = JSON.parse(fs.readFileSync('public/india-states.geojson', 'utf8'));

const Map = () => (
  <ComposableMap projection="geoMercator" projectionConfig={{ scale: 1000, center: [80, 22] }}>
    <Geographies geography={geoUrl}>
      {({ geographies }) =>
        geographies.map((geo) => (
          <Geography key={geo.rsmKey} geography={geo} />
        ))
      }
    </Geographies>
  </ComposableMap>
);

const html = renderToString(<Map />);
console.log(html.substring(0, 500));
