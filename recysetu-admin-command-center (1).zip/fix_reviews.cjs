const fs = require('fs');

const file = 'src/admin/pages/AdminReviewsPage.tsx';
let code = fs.readFileSync(file, 'utf8');

code = code.replace(/adminApi\.getReviews\(\{ search, limit: 50 \}\)/g, "adminApi.getReviews(search)");
code = code.replace(/setReviews\(data\.data \|\| \[\]\);/g, "setReviews(data || []);");
code = code.replace(/adminApi\.processReview\(selectedReview\.id, \{ action: reviewAction, notes: reviewNotes \}\)/g, "adminApi.processReview(selectedReview.id, reviewAction, reviewNotes)");

fs.writeFileSync(file, code);

