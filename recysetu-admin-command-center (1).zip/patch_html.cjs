const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');
if (!html.includes('fonts.googleapis.com')) {
  const fontLinks = `
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
  `;
  html = html.replace('</head>', fontLinks + '</head>');
  fs.writeFileSync('index.html', html);
}
