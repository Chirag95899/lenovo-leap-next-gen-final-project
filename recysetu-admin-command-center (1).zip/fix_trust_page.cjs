const fs = require('fs');
let content = fs.readFileSync('src/admin/pages/AdminTrustRewardsPage.tsx', 'utf8');
content = content.replace('fetchReviews(); // Wait I mean fetchUsers\n        fetchUsers();', 'fetchUsers();');
fs.writeFileSync('src/admin/pages/AdminTrustRewardsPage.tsx', content);
