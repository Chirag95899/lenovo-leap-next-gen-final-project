const fs = require('fs');
let content = fs.readFileSync('server/db/database.ts', 'utf8');

// Add new imports
content = content.replace(
  'import { AppConfiguration } from \'../../src/shared/types/config\';',
  'import { AppConfiguration, TrustRewardsConfiguration } from \'../../src/shared/types/config\';\nimport { MutualReview, ScoreHistoryRecord } from \'../../src/shared/types/domain\';'
);

// Add arrays/maps to the class
content = content.replace(
  'private systemConfigs: Map<string, SystemConfig> = new Map();',
  'private systemConfigs: Map<string, SystemConfig> = new Map();\n  private reviews: Map<string, MutualReview> = new Map();\n  private scoreHistory: ScoreHistoryRecord[] = [];'
);

// Add dummy review data seed in the constructor
content = content.replace(
  'this.auditLogs = [...SEED_AUDIT_LOGS];',
  `this.auditLogs = [...SEED_AUDIT_LOGS];
    
    // Seed some reviews
    const r1: MutualReview = {
      id: 'rev-1', reviewerId: 'collector-1', reviewerName: 'Ramesh (Collector)', reviewerRole: 'COLLECTOR',
      reviewedId: 'aggregator-1', reviewedName: 'Mumbai Hub', reviewedRole: 'AGGREGATOR',
      transactionId: 'pickup-1', transactionType: 'PICKUP', rating: 4,
      criteria: { pickupCoordination: 4, paymentReliability: 5, professionalism: 4 },
      comment: 'Pickup was on time.', status: 'PROCESSED', scoreImpact: 5, createdAt: new Date(Date.now() - 86400000 * 2).toISOString(), processedAt: new Date(Date.now() - 86400000 * 1).toISOString()
    };
    this.reviews.set(r1.id, r1);
`
);

// Add method to get trust/reward config in default config
content = content.replace(
  'notificationConfig: NotificationConfig;',
  'notificationConfig: NotificationConfig;\n  trustRewardsConfig?: TrustRewardsConfiguration;'
);

// Update database to fetch config
// (we don't strictly need to update default config here if we do it in a safer way, but let's just make sure it parses ok)

fs.writeFileSync('server/db/database.ts', content);
