const fs = require('fs');

function patchFile(filepath) {
  let code = fs.readFileSync(filepath, 'utf8');
  // Replace all fetch occurrences with adminApi if they have Bearer
  
  // For AdminReviewsPage
  if (filepath.includes('AdminReviewsPage')) {
      code = code.replace(/const res = await fetch\(`\/api\/admin\/reviews\?search=\$\{search\}`[\s\S]*?if \(!res\.ok\) throw new Error\(data\.error \|\| 'Failed to fetch'\);/, "const data = await adminApi.getReviews(search);");
      
      code = code.replace(/const res = await fetch\(`\/api\/admin\/reviews\/\$\{selectedReview\.id\}\/process`[\s\S]*?throw new Error\(error\.error \|\| 'Action failed'\);\n\s*\}/, "await adminApi.processReview(selectedReview.id, decision, notes);");
  }

  // For AdminTrustRewardsPage
  if (filepath.includes('AdminTrustRewardsPage')) {
      // Actually AdminTrustRewards is using /api/admin/users
      code = code.replace(/const res = await fetch\(`\/api\/admin\/users\?search=\$\{search\}&limit=50`[\s\S]*?if \(!res\.ok\) throw new Error\(data\.error \|\| 'Failed to fetch'\);/, "const data = await adminApi.getTrustRewards(search);");
      
      code = code.replace(/const res = await fetch\(`\/api\/admin\/users\/\$\{selectedUser\.id\}\/override-score`[\s\S]*?throw new Error\(error\.error \|\| 'Action failed'\);\n\s*\}/, "await adminApi.processTrustReward(selectedUser.id, action, amountInr);");
  }

  // For useAdminDomainQueries.ts
  if (filepath.includes('useAdminDomainQueries')) {
      code = code.replace(/const res = await fetch\(`\/api\/admin\/ai-activity\?page=\$\{p\}&limit=15`[\s\S]*?if \(!res\.ok\) throw new Error\('Failed to load AI activity'\);/g, "const data = await adminApi.getAiActivity(p);");
      
      code = code.replace(/const res = await fetch\(`\/api\/admin\/ivr-activity\?page=\$\{p\}&limit=15`[\s\S]*?if \(!res\.ok\) throw new Error\('Failed to load IVR activity'\);/g, "const data = await adminApi.getIvrActivity(p);");
      
      code = code.replace(/const res = await fetch\(`\/api\/admin\/notifications\?page=\$\{p\}&limit=15`[\s\S]*?if \(!res\.ok\) throw new Error\('Failed to load notifications'\);/g, "const data = await adminApi.getNotifications(p);");
  }
  
  fs.writeFileSync(filepath, code);
}

patchFile('src/admin/pages/AdminReviewsPage.tsx');
patchFile('src/admin/pages/AdminTrustRewardsPage.tsx');
patchFile('src/admin/hooks/useAdminDomainQueries.ts');
