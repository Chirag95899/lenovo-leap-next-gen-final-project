const fs = require('fs');
let code = fs.readFileSync('src/admin/hooks/useAdminDomainQueries.ts', 'utf8');

code = code.split('\n').map(line => {
  if (line.includes('const res = await fetch(`/api/admin/ai-activity?page=${p}&limit=15`')) return '        const data = await adminApi.getAiActivity(p);';
  if (line.includes('const res = await fetch(`/api/admin/ivr-activity?page=${p}&limit=15`')) return '        const data = await adminApi.getIvrActivity(p);';
  if (line.includes('const res = await fetch(`/api/admin/notifications?page=${p}&limit=15`')) return '        const data = await adminApi.getNotifications(p);';
  if (line.includes('headers: { Authorization: `Bearer ${adminApi.getToken()}` },')) return '';
  if (line.includes('const data = await res.json();')) return '';
  if (line.includes("if (!res.ok) throw new Error('Failed to load")) return '';
  return line;
}).join('\n');

fs.writeFileSync('src/admin/hooks/useAdminDomainQueries.ts', code);
