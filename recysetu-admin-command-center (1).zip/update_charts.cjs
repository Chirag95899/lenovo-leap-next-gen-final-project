const fs = require('fs');
const path = require('path');

const dir = 'src/admin/components/charts';
const files = fs.readdirSync(dir);

for (const file of files) {
  if (file.endsWith('.tsx')) {
    let content = fs.readFileSync(path.join(dir, file), 'utf8');
    
    // Replace dark tooltip with light tooltip
    content = content.replace(
      /className="bg-slate-900 border border-slate-700\/80 p-2.5 rounded-lg shadow-xl text-xs space-y-1"/g,
      'className="bg-white border border-slate-200 p-3 rounded-lg shadow-lg text-xs space-y-1.5"'
    );
    content = content.replace(/text-slate-200/g, 'text-slate-900');
    content = content.replace(/text-slate-400/g, 'text-slate-500');
    content = content.replace(/text-emerald-400/g, 'text-emerald-700');
    
    // Change some stroke and fill colors to #16A34A (primary green)
    content = content.replace(/#10b981/g, '#16A34A');
    content = content.replace(/#8b5cf6/g, '#15803D'); // replace purple with dark green
    content = content.replace(/#3b82f6/g, '#16A34A'); // replace blue with green
    content = content.replace(/#f59e0b/g, '#047857'); // replace amber with emerald-700
    
    fs.writeFileSync(path.join(dir, file), content);
  }
}
