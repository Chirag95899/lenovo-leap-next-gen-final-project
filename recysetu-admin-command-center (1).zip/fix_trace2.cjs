const fs = require('fs');
let code = fs.readFileSync('src/admin/pages/AdminTraceabilityPage.tsx', 'utf8');

code = code.replace(/<AdminPageHeader[\s\S]*?<Camera className="w-4 h-4" \/>\n\s*Scan QR Token\n\s*<\/button>\n\s*\)\}\n\s*<\/div>/, `
      <AdminPageHeader
        title="Traceability & Digital Chain of Custody"
        description="Immutable event trail from source collection through depot weighment, lot formation, and industrial facility processing."
        badge={
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            100% Cryptographically Sealed
          </span>
        }
        actions={
          onNavigateToScanner && (
          <button
            onClick={onNavigateToScanner}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 shadow-2xs transition-colors"
          >
            <Camera className="w-4 h-4" />
            Scan QR Token
          </button>
        )}
      />
`);

fs.writeFileSync('src/admin/pages/AdminTraceabilityPage.tsx', code);
