const fs = require('fs');
let code = fs.readFileSync('src/admin/services/adminApiService.ts', 'utf8');

const newMethods = `
  public async getReviews(search: string = ''): Promise<any> {
    return this.request(\`/api/admin/reviews?search=\${search}\`);
  }

  public async processReview(id: string, decision: 'APPROVE' | 'REJECT', notes: string): Promise<any> {
    return this.request(\`/api/admin/reviews/\${id}/process\`, {
      method: 'POST',
      body: JSON.stringify({ decision, notes })
    });
  }

  public async getTrustRewards(search: string = ''): Promise<any> {
    return this.request(\`/api/admin/trust-rewards?search=\${search}\`);
  }

  public async processTrustReward(id: string, action: 'APPROVE' | 'REJECT', amountInr?: number): Promise<any> {
    return this.request(\`/api/admin/trust-rewards/\${id}/process\`, {
      method: 'POST',
      body: JSON.stringify({ action, amountInr })
    });
  }

  // --- Config ---
`;

code = code.replace('  // --- Config ---', newMethods);
fs.writeFileSync('src/admin/services/adminApiService.ts', code);
