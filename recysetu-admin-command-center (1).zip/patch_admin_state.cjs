const fs = require('fs');
let code = fs.readFileSync('src/admin/pages/AdminStateAnalyticsPage.tsx', 'utf8');

const oldFetch = `      const res = await fetch('/api/admin/state-analytics', { headers: { 'Authorization': \`Bearer \${adminApi.getToken()}\` } });
      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.message || 'Failed to fetch state analytics');
      }`;
      
const newFetch = `      const json = await adminApi.getStateAnalytics();`;

const oldReport = `      const res = await fetch('/api/admin/state-analytics/report', { method: 'POST', headers: { 'Authorization': \`Bearer \${adminApi.getToken()}\` } });
      const json = await res.json();
      setReportResult(json.report);`;

const newReport = `      const json = await adminApi.generateStateAnalyticsReport();
      setReportResult(json.report);`;

code = code.replace(oldFetch, newFetch).replace(oldReport, newReport);
fs.writeFileSync('src/admin/pages/AdminStateAnalyticsPage.tsx', code);
