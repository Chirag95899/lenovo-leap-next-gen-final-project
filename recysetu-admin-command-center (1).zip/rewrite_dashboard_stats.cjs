const fs = require('fs');

let code = fs.readFileSync('server/db/database.ts', 'utf8');

const methodStart = code.indexOf('public getDashboardStats(options: { range?: string; startDate?: string; endDate?: string } = {}) {');
if (methodStart === -1) {
  console.log("Method not found");
  process.exit(1);
}

// Find the end of the method by counting braces
let openBraces = 0;
let methodEnd = -1;
for (let i = methodStart; i < code.length; i++) {
  if (code[i] === '{') openBraces++;
  if (code[i] === '}') {
    openBraces--;
    if (openBraces === 0) {
      methodEnd = i + 1;
      break;
    }
  }
}

console.log("Method goes from", methodStart, "to", methodEnd);
