import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { authRouter } from './server/routes/authRoutes';
import { adminRouter } from './server/routes/adminRoutes';
import { sharedRouter } from './server/routes/sharedRoutes';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for JSON parsing
  app.use(express.json());

  // Request logging for operational auditability
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) {
      console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    }
    next();
  });

  // 1. API Health & Metadata
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'RECYSETU Unified Core API',
      system: 'Admin Command Center + Multi-Role Hub',
      timestamp: new Date().toISOString(),
    });
  });

  // 2. Auth Routes
  app.use('/api/auth', authRouter);

  // 3. Admin Command Center Routes (Guarded by requireAdminAuth)
  app.use('/api/admin', adminRouter);

  // 4. Shared Domain Services (Used across Collector, Aggregator, Recycler, Admin)
  app.use('/api/shared', sharedRouter);

  // 5. Frontend Vite Middleware / Production Static Delivery
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`RECYSETU Unified Server online at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server boot error:', err);
  process.exit(1);
});
