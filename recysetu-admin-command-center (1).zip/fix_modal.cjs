const fs = require('fs');
let file = fs.readFileSync('src/admin/pages/AdminAnomaliesPage.tsx', 'utf8');

file = file.replace(/title=\{\`Anomaly Investigation: \$\{selectedAnomaly\?\.title \|\| selectedAnomaly\?\.ruleKey\.replace\(\/_\/g, ' '\)\}\`\}\n\s*>\s*\{/g, "title={`Anomaly Investigation: ${selectedAnomaly?.title || selectedAnomaly?.ruleKey.replace(/_/g, ' ')}`}\n      >\n        {/* ");

// Now we need to comment out `Flagged on ...`} if it was outputting a string or just remove it
file = file.replace(/\{`Flagged on \$\{formatDateTime\(selectedAnomaly\?\.detectedAt\)\} • Status: \$\{selectedAnomaly\?\.status\}`\}\n\s*>/g, "{/* */} \n");

fs.writeFileSync('src/admin/pages/AdminAnomaliesPage.tsx', file);
