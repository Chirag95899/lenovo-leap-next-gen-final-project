import React, { useState, useEffect, Suspense, lazy } from 'react';
import { 
  Recycle, 
  ShieldCheck, 
  Truck, 
  Network,
  ChevronRight,
  Leaf,
  Globe2
} from 'lucide-react';

const AdminCommandCenter = lazy(() => import('./admin/AdminCommandCenter').then(module => ({ default: module.AdminCommandCenter })));

// Localization Dictionary
const translations = {
  en: {
    welcome: "Welcome to RECYSETU",
    subtitle: "Choose your role to enter the RECYSETU ecosystem.",
    collector: "Collector",
    collectorSub: "COLLECT & EARN",
    collectorDesc: "Connect collected e-waste with the verified ecosystem.",
    aggregator: "Aggregator",
    aggregatorSub: "CONNECT & MANAGE",
    aggregatorDesc: "Coordinate collections, lots and partner operations.",
    recycler: "Recycler",
    recyclerSub: "RECYCLE & VERIFY",
    recyclerDesc: "Receive and process e-waste through responsible recycling.",
    admin: "Authorized Admin",
    adminSub: "CONTROL & MONITOR",
    adminDesc: "Monitor platform operations, analytics and ecosystem health.",
    trust: "A connected ecosystem for responsible e-waste management.",
    footer: "People. Partnerships. A Cleaner Planet."
  },
  hi: {
    welcome: "RECYSETU में आपका स्वागत है",
    subtitle: "RECYSETU पारिस्थितिकी तंत्र में प्रवेश करने के लिए अपनी भूमिका चुनें।",
    collector: "कलेक्टर (संग्राहक)",
    collectorSub: "एकत्र करें और कमाएं",
    collectorDesc: "एकत्रित ई-कचरे को सत्यापित पारिस्थितिकी तंत्र से जोड़ें।",
    aggregator: "एग्रीगेटर",
    aggregatorSub: "जुड़ें और प्रबंधित करें",
    aggregatorDesc: "संग्रह, लॉट और भागीदार संचालन का समन्वय करें।",
    recycler: "रीसाइकलर",
    recyclerSub: "रीसायकल और सत्यापित करें",
    recyclerDesc: "जिम्मेदार रीसाइक्लिंग के माध्यम से ई-कचरा प्राप्त करें और संसाधित करें।",
    admin: "अधिकृत व्यवस्थापक",
    adminSub: "नियंत्रण और निगरानी",
    adminDesc: "प्लेटफॉर्म संचालन, एनालिटिक्स और पारिस्थितिकी तंत्र के स्वास्थ्य की निगरानी करें।",
    trust: "जिम्मेदार ई-कचरा प्रबंधन के लिए एक जुड़ा हुआ पारिस्थितिकी तंत्र।",
    footer: "लोग। साझेदारी। एक स्वच्छ ग्रह।"
  },
  mr: {
    welcome: "RECYSETU मध्ये आपले स्वागत आहे",
    subtitle: "RECYSETU इकोसिस्टममध्ये प्रवेश करण्यासाठी तुमची भूमिका निवडा.",
    collector: "कलेक्टर (संग्राहक)",
    collectorSub: "गोळा करा आणि कमवा",
    collectorDesc: "गोळा केलेला ई-कचरा सत्यापित इकोसिस्टमशी जोडा.",
    aggregator: "एग्रीगेटर",
    aggregatorSub: "कनेक्ट करा आणि व्यवस्थापित करा",
    aggregatorDesc: "संकलन, लॉट आणि भागीदार ऑपरेशन्सचे समन्वय साधा.",
    recycler: "रीसायकलर",
    recyclerSub: "रीसायकल आणि सत्यापित करा",
    recyclerDesc: "जबाबदार रीसायकलिंगद्वारे ई-कचरा प्राप्त करा आणि प्रक्रिया करा.",
    admin: "अधिकृत प्रशासक",
    adminSub: "नियंत्रण आणि निरीक्षण",
    adminDesc: "प्लॅटफॉर्म ऑपरेशन्स, ॲनालिटिक्स आणि इकोसिस्टमच्या आरोग्याचे निरीक्षण करा.",
    trust: "जबाबदार ई-कचरा व्यवस्थापनासाठी एक जोडलेली इकोसिस्टम.",
    footer: "लोक. भागीदारी. एक स्वच्छ ग्रह."
  }
};

type LangKey = 'en' | 'hi' | 'mr';

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(window.location.pathname);
  const [lang, setLang] = useState<LangKey>('en');

  useEffect(() => {
    const onLocationChange = () => {
      setCurrentPath(window.location.pathname);
    };
    window.addEventListener('popstate', onLocationChange);
    return () => window.removeEventListener('popstate', onLocationChange);
  }, []);

  const navigateTo = (path: string) => {
    window.history.pushState(null, '', path);
    setCurrentPath(path);
  };

  if (currentPath.startsWith('/admin')) {
    return (
      <Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div></div>}>
        <AdminCommandCenter />
      </Suspense>
    );
  }

  const t = translations[lang];

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#F9FBF9] font-sans antialiased selection:bg-emerald-100 selection:text-emerald-900">
      
      {/* LEFT BRAND PANEL (45%) */}
      <div className="md:w-[45%] relative bg-slate-900 overflow-hidden flex flex-col justify-between p-8 md:p-12 lg:p-16 text-white min-h-[35vh] md:min-h-screen">
        {/* Background Gradients & Abstract Eco-Tech Visual */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-br from-[#0F291E] via-[#1E5631] to-[#123521] opacity-90" />
          
          {/* Abstract SVG Eco-Tech India Environment Pattern */}
          <svg className="absolute w-full h-full opacity-10" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice">
            <path d="M 0,50 Q 25,30 50,50 T 100,50 L 100,100 L 0,100 Z" fill="#4C9A2A" />
            <path d="M 0,70 Q 25,50 50,70 T 100,70 L 100,100 L 0,100 Z" fill="#2E7D32" />
            <circle cx="20" cy="40" r="1.5" fill="#fff" className="animate-pulse" />
            <circle cx="50" cy="20" r="1" fill="#fff" className="animate-pulse" style={{ animationDelay: '1s' }} />
            <circle cx="80" cy="50" r="2" fill="#fff" className="animate-pulse" style={{ animationDelay: '2s' }} />
            <path d="M 20,40 L 50,20 L 80,50" stroke="#4C9A2A" strokeWidth="0.2" fill="none" strokeDasharray="1 1" />
          </svg>
          
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-emerald-700/20 rounded-full blur-3xl translate-y-1/3 -translate-x-1/4" />
        </div>

        <div className="relative z-10 flex flex-col items-start h-full">
          {/* Logo Section */}
          <div className="flex items-center gap-3 mb-auto">
            <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-lg">
              <Recycle className="w-7 h-7 text-[#1E5631]" strokeWidth={2.5} />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-black tracking-tight" style={{ fontFamily: '"Playfair Display", serif' }}>
                RECYSETU
              </h1>
            </div>
          </div>

          <div className="mt-12 md:mt-0">
            <h2 className="text-xl md:text-2xl lg:text-3xl font-semibold mb-4 leading-snug">
              Bridging People.<br />
              <span className="text-emerald-400">Circulating a Cleaner India.</span>
            </h2>
            <p className="text-emerald-50/80 text-sm md:text-base max-w-sm font-medium leading-relaxed">
              One ecosystem for responsible e-waste collection, aggregation and recycling.
            </p>
          </div>
        </div>
      </div>

      {/* RIGHT FUNCTIONAL PANEL (55%) */}
      <div className="md:w-[55%] flex flex-col bg-[#F9FBF9] relative min-h-[65vh] md:min-h-screen">
        
        {/* Language Selector Header */}
        <header className="flex justify-end p-6 md:p-8">
          <div className="inline-flex bg-white rounded-xl p-1 shadow-sm border border-slate-200">
            {(['en', 'hi', 'mr'] as LangKey[]).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  lang === l 
                    ? 'bg-slate-900 text-white shadow-md' 
                    : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                {l === 'en' ? 'EN' : l === 'hi' ? 'हिन्दी' : 'मराठी'}
              </button>
            ))}
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 flex flex-col justify-center px-6 md:px-12 lg:px-20 py-8">
          
          <div className="mb-10 md:mb-12">
            <h1 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight mb-3">
              {t.welcome}
            </h1>
            <p className="text-base text-slate-500 font-medium">
              {t.subtitle}
            </p>
          </div>

          {/* Role Selection Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-5 mb-8 md:mb-12">
            
            {/* Collector */}
            <button 
              onClick={() => alert("Collector authentication flow would launch here.")}
              className="group text-left p-6 bg-white rounded-2xl border border-slate-200 hover:border-emerald-500/30 hover:shadow-xl hover:shadow-emerald-900/5 transition-all duration-300 relative overflow-hidden flex flex-col justify-between min-h-[160px]"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-emerald-50 to-transparent rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div>
                <div className="w-10 h-10 rounded-xl bg-slate-50 group-hover:bg-emerald-50 text-slate-400 group-hover:text-emerald-600 flex items-center justify-center mb-4 transition-colors">
                  <Truck className="w-5 h-5" />
                </div>
                <div className="text-[10px] font-bold tracking-widest uppercase text-emerald-600 mb-1">
                  {t.collectorSub}
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-emerald-950 transition-colors">
                  {t.collector}
                </h3>
                <p className="text-xs text-slate-500 font-medium leading-relaxed">
                  {t.collectorDesc}
                </p>
              </div>
              <ChevronRight className="absolute bottom-6 right-6 w-5 h-5 text-slate-300 group-hover:text-emerald-500 group-hover:translate-x-1 transition-all" />
            </button>

            {/* Aggregator */}
            <button 
              onClick={() => alert("Aggregator authentication flow would launch here.")}
              className="group text-left p-6 bg-white rounded-2xl border border-slate-200 hover:border-blue-500/30 hover:shadow-xl hover:shadow-blue-900/5 transition-all duration-300 relative overflow-hidden flex flex-col justify-between min-h-[160px]"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-blue-50 to-transparent rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div>
                <div className="w-10 h-10 rounded-xl bg-slate-50 group-hover:bg-blue-50 text-slate-400 group-hover:text-blue-600 flex items-center justify-center mb-4 transition-colors">
                  <Network className="w-5 h-5" />
                </div>
                <div className="text-[10px] font-bold tracking-widest uppercase text-blue-600 mb-1">
                  {t.aggregatorSub}
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-blue-950 transition-colors">
                  {t.aggregator}
                </h3>
                <p className="text-xs text-slate-500 font-medium leading-relaxed">
                  {t.aggregatorDesc}
                </p>
              </div>
              <ChevronRight className="absolute bottom-6 right-6 w-5 h-5 text-slate-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
            </button>

            {/* Recycler */}
            <button 
              onClick={() => alert("Recycler authentication flow would launch here.")}
              className="group text-left p-6 bg-white rounded-2xl border border-slate-200 hover:border-teal-500/30 hover:shadow-xl hover:shadow-teal-900/5 transition-all duration-300 relative overflow-hidden flex flex-col justify-between min-h-[160px]"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-teal-50 to-transparent rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div>
                <div className="w-10 h-10 rounded-xl bg-slate-50 group-hover:bg-teal-50 text-slate-400 group-hover:text-teal-600 flex items-center justify-center mb-4 transition-colors">
                  <Recycle className="w-5 h-5" />
                </div>
                <div className="text-[10px] font-bold tracking-widest uppercase text-teal-600 mb-1">
                  {t.recyclerSub}
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-teal-950 transition-colors">
                  {t.recycler}
                </h3>
                <p className="text-xs text-slate-500 font-medium leading-relaxed">
                  {t.recyclerDesc}
                </p>
              </div>
              <ChevronRight className="absolute bottom-6 right-6 w-5 h-5 text-slate-300 group-hover:text-teal-500 group-hover:translate-x-1 transition-all" />
            </button>

            {/* Admin */}
            <button 
              onClick={() => navigateTo('/admin/dashboard')}
              className="group text-left p-6 bg-white rounded-2xl border border-slate-200 hover:border-slate-800/30 hover:shadow-xl hover:shadow-slate-900/5 transition-all duration-300 relative overflow-hidden flex flex-col justify-between min-h-[160px]"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-slate-100 to-transparent rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div>
                <div className="w-10 h-10 rounded-xl bg-slate-50 group-hover:bg-slate-900 text-slate-400 group-hover:text-white flex items-center justify-center mb-4 transition-colors">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="text-[10px] font-bold tracking-widest uppercase text-slate-500 mb-1">
                  {t.adminSub}
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-black transition-colors">
                  {t.admin}
                </h3>
                <p className="text-xs text-slate-500 font-medium leading-relaxed">
                  {t.adminDesc}
                </p>
              </div>
              <ChevronRight className="absolute bottom-6 right-6 w-5 h-5 text-slate-300 group-hover:text-slate-900 group-hover:translate-x-1 transition-all" />
            </button>

          </div>

          {/* Micro Trust Signal */}
          <div className="flex items-center gap-2 text-xs font-medium text-slate-400 justify-center sm:justify-start">
            <Globe2 className="w-4 h-4 text-emerald-500/50" />
            <span>{t.trust}</span>
          </div>
          
        </main>

        {/* Footer Brand Statement */}
        <footer className="p-6 md:p-8 flex items-center justify-center sm:justify-start opacity-70">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold tracking-wide text-slate-400 uppercase">
            <Leaf className="w-3.5 h-3.5 text-emerald-600" />
            <span>{t.footer}</span>
          </div>
        </footer>

      </div>
    </div>
  );
}
