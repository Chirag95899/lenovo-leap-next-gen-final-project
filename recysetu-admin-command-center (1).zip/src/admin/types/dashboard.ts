import {
  MaterialCategory,
  AggregatedLot,
  PaymentRecord,
  Complaint,
} from '../../shared/types/domain';
import { AdminView } from './admin';

export type DashboardDateRange = 'today' | '7d' | '30d' | '90d' | 'custom';

export interface DashboardOverviewKPIs {
  totalCollectors: number;
  totalAggregators: number;
  totalRecyclers: number;
  activeLots: number;
  pendingPickups: number;
  completedPickups: number;
  materialCollectedKg: number;
  materialCollectedTons: number;
  recyclingCompletedKg: number;
  recyclingCompletedTons: number;
  pendingPaymentsCount: number;
  pendingPaymentsAmountInr: number;
  openComplaintsCount: number;
  flaggedLotsCount: number;
  activeAnomaliesCount: number;
  criticalAnomaliesCount: number;
  totalDisbursedInr: number;
  co2OffsetTons: number;
  traceabilityIntegrityPercent: number;
  activeWorkersCount: number;
  // Aliases for backwards compatibility with Phase 1 components
  totalCollectedTons?: number;
  totalRecycledTons?: number;
  totalLotWeightTons?: number;
  informalWorkersCount?: number;
  pendingDisbursementsInr?: number;
}

export interface PickupStatusBreakdown {
  REQUESTED: number;
  ACCEPTED: number;
  SCHEDULED: number;
  COLLECTOR_READY: number;
  PICKED_UP: number;
  AGGREGATED: number;
  CANCELLED: number;
  COMPLETED: number;
  total: number;
}

export interface LotStatusBreakdown {
  activeLots: number;
  processingLots: number;
  handedOverLots: number;
  recycledLots: number;
  flaggedLots: number;
  disputedLots: number;
  totalLots: number;
  totalWeightKg: number;
  totalWeightTons: number;
  recentLots: AggregatedLot[];
}

export interface MaterialCategorySummary {
  category: MaterialCategory;
  name: string;
  collectedKg: number;
  collectedTons: number;
  processedKg: number;
  recycledKg: number;
  estimatedValueInr: number;
  co2OffsetKg: number;
  co2OffsetTons: number;
  sharePercent: number;
  ratePerKg: number;
  pickupsCount: number;
}

export interface RegionalActivitySummary {
  regionKey: string;
  city: string;
  state: string;
  wards: string[];
  totalPickups: number;
  totalVolumeKg: number;
  totalVolumeTons: number;
  activeCollectors: number;
  aggregatorsCount: number;
  recyclersCount: number;
  disbursedInr: number;
}

export interface PaymentStatusBreakdown {
  PENDING: { count: number; amountInr: number };
  PROCESSING: { count: number; amountInr: number };
  PAID: { count: number; amountInr: number };
  FAILED: { count: number; amountInr: number };
  DISPUTED: { count: number; amountInr: number };
  totalCount: number;
  totalDisbursedInr: number;
  totalPendingInr: number;
  recentPayments: PaymentRecord[];
}

export interface ComplaintStatusBreakdown {
  OPEN: number;
  IN_REVIEW: number;
  RESOLVED: number;
  REJECTED: number;
  total: number;
  categoryBreakdown: Record<string, number>;
  recentComplaints: Complaint[];
}

export interface FlaggedAttentionItem {
  id: string;
  type:
    | 'WEIGHT_DISCREPANCY'
    | 'PENDING_VERIFICATION'
    | 'DISPUTED_PAYMENT'
    | 'UNRESOLVED_COMPLAINT'
    | 'SUSPICIOUS_ANOMALY'
    | 'LOT_REJECTED';
  title: string;
  description: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  entityType: string;
  entityId: string;
  actionLabel: string;
  targetView: AdminView;
  filterPayload?: Record<string, string>;
  timestamp: string;
}

export interface UnifiedActivityEvent {
  id: string;
  type: 'REGISTRATION' | 'PICKUP' | 'LOT' | 'TRACEABILITY' | 'PAYMENT' | 'COMPLAINT' | 'ANOMALY' | 'CONFIG' | string;
  title: string;
  description: string;
  timestamp: string;
  actorName: string;
  actorRole?: string;
  location?: string;
  status?: string;
  severity?: string;
  targetView?: AdminView;
  filterPayload?: Record<string, string>;
}

export interface SystemActivityEvent {
  id: string;
  eventType: string;
  title: string;
  description: string;
  timestamp: string;
  actor: { name: string; role: string };
  entityType: 'PICKUP' | 'LOT' | 'PAYMENT' | 'USER' | 'COMPLAINT' | 'ANOMALY' | 'CONFIG' | 'TRACEABILITY';
  entityId: string;
  badgeVariant: 'emerald' | 'blue' | 'amber' | 'rose' | 'slate';
  verifiedOnChain?: boolean;
  targetView?: AdminView;
}

export interface ThroughputTimelinePoint {
  label: string;
  collectedKg: number;
  recycledKg: number;
  disbursedInr: number;
}

export interface DashboardResponseData {
  overview: DashboardOverviewKPIs;
  pickupOverview: PickupStatusBreakdown;
  lotOverview: LotStatusBreakdown;
  materialOverview: {
    categories: MaterialCategorySummary[];
    totalEstimatedValueInr: number;
    totalCo2OffsetTons: number;
    totalCollectedKg: number;
    totalRecycledKg: number;
  };
  regionalActivity: RegionalActivitySummary[];
  paymentSnapshot: PaymentStatusBreakdown;
  complaintSnapshot: ComplaintStatusBreakdown;
  flaggedAttentionItems: FlaggedAttentionItem[];
  attentionRequired?: FlaggedAttentionItem[];
  systemRecentActivity: UnifiedActivityEvent[];
  throughputTimeline: ThroughputTimelinePoint[];
  // Backwards compatibility for charts
  throughputDays?: { day: string; collectedKg: number; recycledKg: number }[];
  materialBreakdown?: Record<string, { weightKg: number; count: number }>;
  recentPickups?: any[];
  recentLots?: any[];
  recentAnomalies?: any[];
  recentComplaints?: any[];
  dateRange: {
    range: DashboardDateRange;
    startDate?: string;
    endDate?: string;
    effectiveLabel: string;
  };
  systemStatus: {
    backendService: string;
    databaseEngine: string;
    qrProtocol: string;
    version: string;
    lastSyncedAt: string;
  };
}
