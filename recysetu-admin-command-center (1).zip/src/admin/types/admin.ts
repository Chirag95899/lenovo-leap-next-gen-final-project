import React from 'react';
import { UserRole } from '../../shared/types/domain';

export type AdminView =
  | 'dashboard'
  | 'analytics'
  | 'geographic'
  | 'users'
  | 'pickups'
  | 'lots'
  | 'traceability'
  | 'qr-scanner'
  | 'payments'
  | 'complaints'
  | 'anomalies'
  | 'audit'
  | 'ai-activity'
  | 'ivr'
  | 'notifications'
  | 'reviews'
  | 'trust-rewards';

export interface AdminAuthState {
  isAuthenticated: boolean;
  token: string | null;
  adminUser: {
    id: string;
    adminId?: string;
    name: string;
    email: string;
    role: UserRole;
    phone?: string;
  } | null;
  isLoading: boolean;
  error: string | null;
}

export interface TableColumn<T> {
  key: string;
  header: string;
  render?: (item: T) => React.ReactNode;
  sortable?: boolean;
  align?: 'left' | 'center' | 'right';
  width?: string;
}

export interface FilterOption {
  label: string;
  value: string;
}

export interface FilterDefinition {
  key: string;
  label: string;
  options: FilterOption[];
  currentValue: string;
}

export interface StatMetric {
  id: string;
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  subtitle?: string;
  iconName: string;
  accentColor?: 'emerald' | 'amber' | 'blue' | 'rose' | 'slate';
}
