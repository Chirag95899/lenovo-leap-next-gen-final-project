import React from 'react';
import { FlaggedAttentionItem } from '../types/dashboard';
import { AdminView } from '../types/admin';
import { formatRelativeTime } from '../utils/formatters';
import {
  ShieldAlert,
  AlertTriangle,
  Scale,
  CreditCard,
  UserCheck,
  AlertCircle,
  ArrowUpRight,
  Boxes,
} from 'lucide-react';

interface DashboardAttentionRequiredSectionProps {
  items: FlaggedAttentionItem[];
  onNavigateToView?: (view: AdminView, filters?: Record<string, string>) => void;
}

export const DashboardAttentionRequiredSection: React.FC<
  DashboardAttentionRequiredSectionProps
> = ({ items, onNavigateToView }) => {
  if (!items || items.length === 0) {
    return (
      <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200/80 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-emerald-100 text-emerald-800">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-emerald-900">Zero Critical Attention Items</h4>
            <p className="text-2xs text-emerald-700">All weighments, payouts, and compliance gates are operating within tolerance.</p>
          </div>
        </div>
      </div>
    );
  }

  const getTypeIcon = (type: FlaggedAttentionItem['type']) => {
    switch (type) {
      case 'WEIGHT_DISCREPANCY':
        return <Scale className="w-4 h-4 text-rose-600" />;
      case 'DISPUTED_PAYMENT':
        return <CreditCard className="w-4 h-4 text-amber-600" />;
      case 'PENDING_VERIFICATION':
        return <UserCheck className="w-4 h-4 text-sky-600" />;
      case 'UNRESOLVED_COMPLAINT':
        return <AlertCircle className="w-4 h-4 text-rose-600" />;
      case 'LOT_REJECTED':
        return <Boxes className="w-4 h-4 text-rose-600" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-amber-600" />;
    }
  };

  const getSeverityBadge = (severity: FlaggedAttentionItem['severity']) => {
    switch (severity) {
      case 'CRITICAL':
        return (
          <span className="px-2 py-0.5 rounded text-2xs font-extrabold uppercase bg-rose-100 text-rose-800 border border-rose-200">
            CRITICAL
          </span>
        );
      case 'HIGH':
        return (
          <span className="px-2 py-0.5 rounded text-2xs font-bold uppercase bg-amber-100 text-amber-800 border border-amber-200">
            HIGH
          </span>
        );
      case 'MEDIUM':
        return (
          <span className="px-2 py-0.5 rounded text-2xs font-semibold uppercase bg-sky-100 text-sky-800 border border-sky-200">
            MEDIUM
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-2xs font-medium uppercase bg-slate-100 text-slate-700">
            LOW
          </span>
        );
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700">
            Flagged & Attention Required ({items.length})
          </h2>
        </div>
        <span className="text-xs text-slate-700">
          Prioritized operational interventions requiring Admin action
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {items.map((item) => (
          <div
            key={item.id}
            id={item.id}
            className="p-4 rounded-xl bg-white border border-slate-200 shadow-2xs hover:border-slate-300 hover:shadow-xs transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-slate-50 border border-slate-100">
                    {getTypeIcon(item.type)}
                  </div>
                  <div>
                    {getSeverityBadge(item.severity)}
                  </div>
                </div>
                <span className="text-2xs text-slate-700 font-mono">
                  {formatRelativeTime(item.timestamp)}
                </span>
              </div>

              <h3 className="text-xs font-bold text-slate-900 line-clamp-1 mb-1">
                {item.title}
              </h3>
              <p className="text-2xs text-slate-600 line-clamp-2 leading-relaxed mb-3">
                {item.description}
              </p>
            </div>

            <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between">
              <span className="text-2xs text-slate-700 font-mono">
                {item.entityType}: {item.entityId}
              </span>
              <button
                onClick={() => onNavigateToView?.(item.targetView, item.filterPayload)}
                className="inline-flex items-center gap-1 text-xs font-semibold text-slate-800 hover:text-emerald-700 transition-colors"
              >
                <span>{item.actionLabel}</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
