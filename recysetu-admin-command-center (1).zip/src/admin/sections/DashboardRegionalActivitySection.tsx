import React from 'react';
import { RegionalActivitySummary } from '../types/dashboard';
import { AdminView } from '../types/admin';
import { formatInr, formatWeight } from '../utils/formatters';
import { MapPin, Users, Warehouse, Factory, ArrowRight, TrendingUp } from 'lucide-react';

interface DashboardRegionalActivitySectionProps {
  regionalActivity: RegionalActivitySummary[];
  onNavigateToView?: (view: AdminView, filters?: Record<string, string>) => void;
}

export const DashboardRegionalActivitySection: React.FC<
  DashboardRegionalActivitySectionProps
> = ({ regionalActivity, onNavigateToView }) => {
  if (!regionalActivity || regionalActivity.length === 0) {
    return null;
  }

  const maxVolume = Math.max(...regionalActivity.map((r) => r.totalVolumeKg), 1);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700">
            Regional Activity & Territorial Throughput
          </h2>
          <p className="text-xs text-slate-700 mt-0.5">
            Geographic operational distribution aggregated safely across municipal clusters
          </p>
        </div>
        <span className="text-xs font-semibold text-slate-700">
          {regionalActivity.length} Active Metropolitan Hubs
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {regionalActivity.map((region, idx) => {
          const percentage = Math.round((region.totalVolumeKg / maxVolume) * 100);

          return (
            <div
              key={region.regionKey}
              id={`region-${region.city.toLowerCase().replace(/\s+/g, '-')}`}
              className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs hover:border-slate-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-100">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">{region.city}</h3>
                      <span className="text-2xs font-semibold text-slate-700 uppercase tracking-wider">
                        {region.state} Cluster • Rank #{idx + 1}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                    {region.totalPickups} Pickups
                  </span>
                </div>

                {/* Throughput volume meter */}
                <div className="mt-3 mb-4 p-3 rounded-lg bg-slate-50 border border-slate-100">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-slate-500 font-medium">Recycled Volume</span>
                    <span className="font-bold text-slate-900">
                      {formatWeight(region.totalVolumeKg)} ({region.totalVolumeTons} T)
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${percentage}%` }}
                      className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                    />
                  </div>
                </div>

                {/* Network participants */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs mb-3">
                  <button
                    onClick={() => onNavigateToView?.('users', { role: 'COLLECTOR', search: region.city })}
                    className="p-2 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors"
                  >
                    <div className="text-2xs text-slate-500 font-medium flex items-center justify-center gap-1">
                      <Users className="w-3 h-3 text-emerald-600" />
                      <span>Collectors</span>
                    </div>
                    <div className="font-bold text-slate-900 mt-0.5">{region.activeCollectors}</div>
                  </button>

                  <button
                    onClick={() => onNavigateToView?.('users', { role: 'AGGREGATOR', search: region.city })}
                    className="p-2 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors"
                  >
                    <div className="text-2xs text-slate-500 font-medium flex items-center justify-center gap-1">
                      <Warehouse className="w-3 h-3 text-blue-600" />
                      <span>Depots</span>
                    </div>
                    <div className="font-bold text-slate-900 mt-0.5">{region.aggregatorsCount}</div>
                  </button>

                  <button
                    onClick={() => onNavigateToView?.('users', { role: 'RECYCLER', search: region.city })}
                    className="p-2 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors"
                  >
                    <div className="text-2xs text-slate-500 font-medium flex items-center justify-center gap-1">
                      <Factory className="w-3 h-3 text-indigo-600" />
                      <span>Plants</span>
                    </div>
                    <div className="font-bold text-slate-900 mt-0.5">{region.recyclersCount}</div>
                  </button>
                </div>

                {/* Key Wards / Hubs */}
                {region.wards.length > 0 && (
                  <div className="mb-3">
                    <span className="text-2xs text-slate-500 font-semibold uppercase tracking-wider block mb-1">
                      Primary Service Wards
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {region.wards.map((ward) => (
                        <span
                          key={ward}
                          className="px-2 py-0.5 rounded text-2xs bg-slate-100 text-slate-700 font-medium"
                        >
                          {ward}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-2xs text-slate-500 block">Direct Disbursements</span>
                  <span className="text-xs font-bold text-emerald-700">
                    {formatInr(region.disbursedInr)}
                  </span>
                </div>

                <button
                  onClick={() => onNavigateToView?.('pickups', { search: region.city })}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-slate-700 hover:text-emerald-700 transition-colors"
                >
                  <span>Pickups</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
