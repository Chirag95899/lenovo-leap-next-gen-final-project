import React from 'react';
import { AdminStatCard } from '../components/AdminStatCard';
import { formatInr, formatWeight } from '../utils/formatters';
import {
  Users,
  Warehouse,
  Factory,
  Boxes,
  Clock,
  CheckCircle2,
  Scale,
  Recycle,
  CreditCard,
  AlertCircle,
  ShieldAlert,
} from 'lucide-react';
import { AdminView } from '../types/admin';
import { DashboardOverviewKPIs } from '../types/dashboard';

interface DashboardOverviewSectionProps {
  overview: DashboardOverviewKPIs;
  onNavigateToView?: (view: AdminView, filters?: Record<string, string>) => void;
}

export const DashboardOverviewSection: React.FC<DashboardOverviewSectionProps> = ({
  overview,
  onNavigateToView,
}) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700">
          Core Operational Key Performance Indicators
        </h2>
        <span className="text-xs text-slate-700">
          Real-time aggregated telemetry across supply network & circular operations
        </span>
      </div>

      {/* Grid of the 11 Primary KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {/* 1. Total Collectors */}
        <AdminStatCard
          id="kpi-total-collectors"
          title="Total Collectors"
          value={overview.totalCollectors}
          subtitle={`${overview.activeWorkersCount} actively verified & routing`}
          icon={Users}
          variant="emerald"
          change="Direct Onboarding"
          changeType="positive"
          onClick={() => onNavigateToView?.('users', { role: 'COLLECTOR' })}
        />

        {/* 2. Total Aggregators */}
        <AdminStatCard
          id="kpi-total-aggregators"
          title="Total Aggregators"
          value={overview.totalAggregators}
          subtitle="Regional intake & sorting hubs"
          icon={Warehouse}
          variant="blue"
          change="Baling & QR Hubs"
          changeType="neutral"
          onClick={() => onNavigateToView?.('users', { role: 'AGGREGATOR' })}
        />

        {/* 3. Total Recyclers */}
        <AdminStatCard
          id="kpi-total-recyclers"
          title="Total Recyclers"
          value={overview.totalRecyclers}
          subtitle="Industrial re-granulation & smelting"
          icon={Factory}
          variant="blue"
          change="Authorized Plants"
          changeType="positive"
          onClick={() => onNavigateToView?.('users', { role: 'RECYCLER' })}
        />

        {/* 4. Active Lots */}
        <AdminStatCard
          id="kpi-active-lots"
          title="Active Lots"
          value={overview.activeLots}
          subtitle="Batches formed, in transit & intake"
          icon={Boxes}
          variant="amber"
          change="Live In-Transit"
          changeType="neutral"
          onClick={() => onNavigateToView?.('lots', { status: 'FORMED' })}
        />

        {/* 5. Pending Pickups */}
        <AdminStatCard
          id="kpi-pending-pickups"
          title="Pending Pickups"
          value={overview.pendingPickups}
          subtitle="Requested or assigned to collectors"
          icon={Clock}
          variant="amber"
          change="Action Required"
          changeType="neutral"
          onClick={() => onNavigateToView?.('pickups', { status: 'REQUESTED' })}
        />

        {/* 6. Completed Pickups */}
        <AdminStatCard
          id="kpi-completed-pickups"
          title="Completed Pickups"
          value={overview.completedPickups}
          subtitle="Aggregated & delivered to hubs"
          icon={CheckCircle2}
          variant="emerald"
          change="100% Weighed"
          changeType="positive"
          onClick={() => onNavigateToView?.('pickups', { status: 'DELIVERED' })}
        />

        {/* 7. Material Collected */}
        <AdminStatCard
          id="kpi-material-collected"
          title="Material Collected"
          value={formatWeight(overview.materialCollectedKg || 0)}
          subtitle={`${overview.materialCollectedTons} metric tons total`}
          icon={Scale}
          variant="emerald"
          change="+16.4% MoM"
          changeType="positive"
          onClick={() => onNavigateToView?.('pickups')}
        />

        {/* 8. Recycling Completed */}
        <AdminStatCard
          id="kpi-recycling-completed"
          title="Recycling Completed"
          value={formatWeight(overview.recyclingCompletedKg || 0)}
          subtitle={`${overview.recyclingCompletedTons} metric tons processed`}
          icon={Recycle}
          variant="emerald"
          change="Zero Landfill"
          changeType="positive"
          onClick={() => onNavigateToView?.('lots', { status: 'PROCESSED' })}
        />

        {/* 9. Pending Payments */}
        <AdminStatCard
          id="kpi-pending-payments"
          title="Pending Payments"
          value={formatInr(overview.pendingPaymentsAmountInr || 0)}
          subtitle={`${overview.pendingPaymentsCount} pending / escrow transactions`}
          icon={CreditCard}
          variant={overview.pendingPaymentsCount > 0 ? 'amber' : 'slate'}
          change={overview.pendingPaymentsCount > 0 ? 'Escrow / Audit' : 'Settled'}
          changeType={overview.pendingPaymentsCount > 0 ? 'neutral' : 'positive'}
          onClick={() => onNavigateToView?.('payments', { status: 'PENDING' })}
        />

        {/* 10. Open Complaints */}
        <AdminStatCard
          id="kpi-open-complaints"
          title="Open Complaints"
          value={overview.openComplaintsCount}
          subtitle="Tickets in investigation & review"
          icon={AlertCircle}
          variant={overview.openComplaintsCount > 0 ? 'rose' : 'slate'}
          change={overview.openComplaintsCount > 0 ? 'Active Inquiry' : 'Zero Disputes'}
          changeType={overview.openComplaintsCount > 0 ? 'negative' : 'positive'}
          onClick={() => onNavigateToView?.('complaints', { status: 'OPEN' })}
        />

        {/* 11. Flagged Lots */}
        <AdminStatCard
          id="kpi-flagged-lots"
          title="Flagged Lots"
          value={overview.flaggedLotsCount}
          subtitle="Rejected batches or purity flags"
          icon={ShieldAlert}
          variant={overview.flaggedLotsCount > 0 ? 'rose' : 'slate'}
          change={overview.flaggedLotsCount > 0 ? 'QA Breach' : 'Clean Verification'}
          changeType={overview.flaggedLotsCount > 0 ? 'negative' : 'positive'}
          onClick={() => onNavigateToView?.('lots', { status: 'REJECTED' })}
        />

        {/* 12. Direct Worker Payouts (Bonus essential operational metric) */}
        <AdminStatCard
          id="kpi-total-disbursed"
          title="Direct Payouts Disbursed"
          value={formatInr(overview.totalDisbursedInr || 0)}
          subtitle="Direct bank / UPI without intermediaries"
          icon={CreditCard}
          variant="emerald"
          change="Instant Settlement"
          changeType="positive"
          onClick={() => onNavigateToView?.('payments', { status: 'COMPLETED' })}
        />
      </div>
    </div>
  );
};

