import React, { useState } from 'react';
import { AdminChartContainer } from '../components/AdminChartContainer';
import { AdminStatusBadge } from '../components/AdminStatusBadge';
import { formatWeight, formatRelativeTime, formatInr } from '../utils/formatters';
import { PickupRequest, AggregatedLot } from '../../shared/types/domain';
import { UnifiedActivityEvent } from '../types/dashboard';
import { AdminView } from '../types/admin';
import {
  Truck,
  Boxes,
  QrCode,
  UserPlus,
  CreditCard,
  AlertCircle,
  ShieldAlert,
  Activity,
  ArrowRight,
  CheckCircle2,
  Clock,
  Filter,
} from 'lucide-react';

interface DashboardRecentActivitySectionProps {
  systemRecentActivity?: UnifiedActivityEvent[];
  recentPickups?: PickupRequest[];
  recentLots?: AggregatedLot[];
  onNavigateToView: (view: AdminView, filters?: Record<string, string>) => void;
}

export const DashboardRecentActivitySection: React.FC<
  DashboardRecentActivitySectionProps
> = ({
  systemRecentActivity = [],
  recentPickups = [],
  recentLots = [],
  onNavigateToView,
}) => {
  const [activeFilter, setActiveFilter] = useState<string>('ALL');

  const filteredEvents = systemRecentActivity.filter((event) => {
    if (activeFilter === 'ALL') return true;
    if (activeFilter === 'PICKUPS') return event.type === 'PICKUP';
    if (activeFilter === 'LOTS') return event.type === 'LOT';
    if (activeFilter === 'TRACEABILITY') return event.type === 'TRACEABILITY';
    if (activeFilter === 'REGISTRATIONS') return event.type === 'REGISTRATION';
    if (activeFilter === 'PAYMENTS') return event.type === 'PAYMENT';
    if (activeFilter === 'ISSUES') return event.type === 'COMPLAINT' || event.type === 'ANOMALY';
    return true;
  });

  const getEventIcon = (event: UnifiedActivityEvent) => {
    switch (event.type) {
      case 'REGISTRATION':
        return <UserPlus className="w-4 h-4 text-emerald-600" />;
      case 'PICKUP':
        return <Truck className="w-4 h-4 text-sky-600" />;
      case 'LOT':
        return <Boxes className="w-4 h-4 text-blue-600" />;
      case 'TRACEABILITY':
        return <QrCode className="w-4 h-4 text-indigo-600" />;
      case 'PAYMENT':
        return <CreditCard className="w-4 h-4 text-amber-600" />;
      case 'COMPLAINT':
        return <AlertCircle className="w-4 h-4 text-rose-600" />;
      case 'ANOMALY':
        return <ShieldAlert className="w-4 h-4 text-rose-600" />;
      default:
        return <Activity className="w-4 h-4 text-slate-500" />;
    }
  };

  const getRoleBadge = (role?: string) => {
    if (!role) return null;
    const colors: Record<string, string> = {
      COLLECTOR: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      AGGREGATOR: 'bg-blue-50 text-blue-700 border-blue-200',
      RECYCLER: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      ADMIN: 'bg-purple-50 text-purple-700 border-purple-200',
      SYSTEM: 'bg-slate-100 text-slate-700 border-slate-200',
    };
    return (
      <span
        className={`px-1.5 py-0.2 text-2xs font-semibold rounded border ${
          colors[role] || 'bg-slate-100 text-slate-600'
        }`}
      >
        {role}
      </span>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700">
            System Health & Unified Operational Activity Stream
          </h2>
          <p className="text-xs text-slate-700 mt-0.5">
            Real-time multi-tier events synthesized across audit trails, blockchain traceability & operational handovers
          </p>
        </div>

        {/* Stream Filter Buttons */}
        <div className="flex flex-wrap items-center gap-1">
          {[
            { id: 'ALL', label: 'All Events' },
            { id: 'PICKUPS', label: 'Pickups' },
            { id: 'LOTS', label: 'Lots' },
            { id: 'TRACEABILITY', label: 'QR / Scans' },
            { id: 'REGISTRATIONS', label: 'Registrations' },
            { id: 'PAYMENTS', label: 'Payments' },
            { id: 'ISSUES', label: 'Alerts & Flags' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                activeFilter === tab.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Left 2 Cols: Unified Live Operational Stream */}
        <div className="xl:col-span-2">
          <AdminChartContainer
            id="unified-operational-stream"
            title="Unified Operational Live Stream"
            subtitle="Chronological multi-stakeholder telemetry"
            footer={
              <div className="flex items-center justify-between text-xs text-slate-700">
                <span>Showing {filteredEvents.length} Recent Verified Events</span>
                <span className="flex items-center gap-1 text-emerald-700 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  Live Sync Connected
                </span>
              </div>
            }
          >
            <div className="divide-y divide-slate-100 max-h-[520px] overflow-y-auto pr-1">
              {filteredEvents.map((event) => (
                <div
                  key={event.id}
                  className="py-3 flex items-start justify-between gap-3 text-xs hover:bg-slate-50/70 p-2 rounded-lg transition-colors"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="p-2 rounded-lg bg-slate-100 border border-slate-200 shrink-0 mt-0.5">
                      {getEventIcon(event)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-900">{event.title}</span>
                        {getRoleBadge(event.actorRole)}
                        {event.severity && event.severity !== 'LOW' && (
                          <span className="px-1.5 py-0.2 rounded text-2xs font-extrabold uppercase bg-rose-100 text-rose-800 border border-rose-200">
                            {event.severity}
                          </span>
                        )}
                      </div>
                      <p className="text-slate-600 text-2xs mt-0.5 line-clamp-1">
                        {event.description}
                      </p>
                      <div className="flex items-center gap-2 text-2xs text-slate-700 mt-1">
                        <span>Actor: <strong className="text-slate-700">{event.actorName}</strong></span>
                        {event.location && (
                          <>
                            <span>•</span>
                            <span>{event.location}</span>
                          </>
                        )}
                        <span>•</span>
                        <span className="font-mono">{formatRelativeTime(event.timestamp)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="shrink-0 flex items-center gap-2">
                    {event.status && (
                      <AdminStatusBadge status={event.status} size="sm" />
                    )}
                    {event.targetView && (
                      <button
                        onClick={() => onNavigateToView(event.targetView!, event.filterPayload)}
                        className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                        title="Navigate to entity"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}

              {filteredEvents.length === 0 && (
                <div className="py-12 text-center text-xs text-slate-700">
                  No activity events found in this category for the selected date range.
                </div>
              )}
            </div>
          </AdminChartContainer>
        </div>

        {/* Right 1 Col: Quick Recent Pickups & Lots summary */}
        <div className="space-y-6">
          {/* Quick Pickups */}
          <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-600" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Latest Pickup Arrivals
                </h3>
              </div>
              <button
                onClick={() => onNavigateToView('pickups')}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800"
              >
                View all →
              </button>
            </div>

            <div className="space-y-2">
              {recentPickups.slice(0, 3).map((p) => (
                <div
                  key={p.id}
                  onClick={() => onNavigateToView('pickups', { search: p.id })}
                  className="p-2.5 rounded-lg bg-slate-50 hover:bg-slate-100/80 cursor-pointer transition-colors flex items-center justify-between text-xs"
                >
                  <div className="min-w-0 pr-2">
                    <div className="font-semibold text-slate-900 truncate">
                      {p.collectorName}
                    </div>
                    <div className="text-2xs text-slate-700 truncate">
                      {p.materialName} • {p.location.city}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-bold text-slate-900">{formatWeight(p.quantityKg)}</div>
                    <AdminStatusBadge status={p.status} size="sm" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Consolidated Lots */}
          <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2">
                <Boxes className="w-4 h-4 text-blue-600" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Aggregator Lots Dispatched
                </h3>
              </div>
              <button
                onClick={() => onNavigateToView('lots')}
                className="text-xs font-semibold text-blue-700 hover:text-blue-800"
              >
                View all →
              </button>
            </div>

            <div className="space-y-2">
              {recentLots.slice(0, 3).map((lot) => (
                <div
                  key={lot.id}
                  onClick={() => onNavigateToView('lots', { search: lot.lotNumber })}
                  className="p-2.5 rounded-lg bg-slate-50 hover:bg-slate-100/80 cursor-pointer transition-colors flex items-center justify-between text-xs"
                >
                  <div className="min-w-0 pr-2">
                    <div className="font-semibold text-slate-900 truncate font-mono">
                      {lot.lotNumber}
                    </div>
                    <div className="text-2xs text-slate-700 truncate">
                      {lot.category} • {lot.aggregatorName}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-bold text-slate-900">{formatWeight(lot.totalWeightKg)}</div>
                    <AdminStatusBadge status={lot.status} size="sm" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
