import React from 'react';
import { AdminChartContainer } from '../components/AdminChartContainer';
import { formatWeight } from '../utils/formatters';

interface ThroughputDay {
  day: string;
  collectedKg: number;
  recycledKg: number;
}

interface DashboardThroughputChartSectionProps {
  throughputDays: ThroughputDay[];
}

export const DashboardThroughputChartSection: React.FC<DashboardThroughputChartSectionProps> = ({
  throughputDays,
}) => {
  const maxVal = Math.max(
    ...throughputDays.map((d) => Math.max(d.collectedKg, d.recycledKg)),
    1000
  );

  return (
    <AdminChartContainer
      id="dashboard-throughput-chart"
      title="Weekly Material Throughput Velocity"
      subtitle="Dynamic aggregation versus facility conversion (kg)"
      headerAction={
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-emerald-600" />
            <span className="text-slate-600 font-medium">Collected</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-blue-600" />
            <span className="text-slate-600 font-medium">Recycled</span>
          </div>
        </div>
      }
      footer={
        <div className="flex items-center justify-between">
          <span>7-Day Aggregation Efficiency: <strong className="text-slate-900">92.4%</strong></span>
          <span>Verified at certified recycling docks</span>
        </div>
      }
    >
      <div className="h-56 w-full flex items-end justify-between gap-2 sm:gap-6 pt-6 pb-2">
        {throughputDays.map((item, idx) => {
          const colHeightPercent = Math.min(100, Math.round((item.collectedKg / maxVal) * 100));
          const recHeightPercent = Math.min(100, Math.round((item.recycledKg / maxVal) * 100));

          return (
            <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
              <div className="w-full flex items-end justify-center gap-1 sm:gap-2 h-full">
                {/* Collected Bar */}
                <div
                  className="w-full max-w-[20px] bg-emerald-600 hover:bg-emerald-500 rounded-t-sm transition-all duration-300 relative cursor-pointer"
                  style={{ height: `${colHeightPercent}%` }}
                >
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] px-1.5 py-0.5 rounded pointer-events-none whitespace-nowrap z-10">
                    {formatWeight(item.collectedKg)}
                  </div>
                </div>

                {/* Recycled Bar */}
                <div
                  className="w-full max-w-[20px] bg-blue-600 hover:bg-blue-500 rounded-t-sm transition-all duration-300 relative cursor-pointer"
                  style={{ height: `${recHeightPercent}%` }}
                >
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] px-1.5 py-0.5 rounded pointer-events-none whitespace-nowrap z-10">
                    {formatWeight(item.recycledKg)}
                  </div>
                </div>
              </div>

              <span className="text-[11px] font-medium text-slate-500 truncate w-full text-center">
                {item.day}
              </span>
            </div>
          );
        })}
      </div>
    </AdminChartContainer>
  );
};
