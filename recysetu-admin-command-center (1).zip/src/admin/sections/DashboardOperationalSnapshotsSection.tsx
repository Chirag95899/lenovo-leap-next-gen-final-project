import React from 'react';
import {
  PickupStatusBreakdown,
  LotStatusBreakdown,
  PaymentStatusBreakdown,
  ComplaintStatusBreakdown,
} from '../types/dashboard';
import { AdminView } from '../types/admin';
import { formatInr, formatWeight } from '../utils/formatters';
import {
  Truck,
  Boxes,
  CreditCard,
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Clock,
  ShieldAlert,
  AlertTriangle,
  FileCheck,
} from 'lucide-react';

interface DashboardOperationalSnapshotsSectionProps {
  pickupOverview?: PickupStatusBreakdown;
  lotOverview?: LotStatusBreakdown;
  paymentSnapshot?: PaymentStatusBreakdown;
  complaintSnapshot?: ComplaintStatusBreakdown;
  onNavigateToView?: (view: AdminView, filters?: Record<string, string>) => void;
}

export const DashboardOperationalSnapshotsSection: React.FC<
  DashboardOperationalSnapshotsSectionProps
> = ({
  pickupOverview,
  lotOverview,
  paymentSnapshot,
  complaintSnapshot,
  onNavigateToView,
}) => {
  const totalPickups = pickupOverview?.total || 1;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700">
            Operational Lifecycle Snapshots
          </h2>
          <p className="text-xs text-slate-700 mt-0.5">
            Dynamic distribution across collection stages, batch aggregation, financial flows, and resolution queues
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* 1. PICKUP OVERVIEW */}
        <div
          id="snapshot-pickups"
          className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-100">
                  <Truck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Pickup Overview</h3>
                  <span className="text-xs text-slate-700">
                    {pickupOverview?.total || 0} Total Requests
                  </span>
                </div>
              </div>
              <button
                onClick={() => onNavigateToView?.('pickups')}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-0.5 transition-colors"
              >
                <span>View all</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Visual ratio bar */}
            <div className="mt-4 mb-3">
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden flex">
                <div
                  style={{
                    width: `${((pickupOverview?.COMPLETED || 0) / totalPickups) * 100}%`,
                  }}
                  className="bg-emerald-500 h-full"
                  title="Completed"
                />
                <div
                  style={{
                    width: `${((pickupOverview?.COLLECTOR_READY || 0) / totalPickups) * 100}%`,
                  }}
                  className="bg-sky-500 h-full"
                  title="Collector Ready"
                />
                <div
                  style={{
                    width: `${((pickupOverview?.SCHEDULED || 0) / totalPickups) * 100}%`,
                  }}
                  className="bg-amber-400 h-full"
                  title="Scheduled / Assigned"
                />
                <div
                  style={{
                    width: `${((pickupOverview?.REQUESTED || 0) / totalPickups) * 100}%`,
                  }}
                  className="bg-slate-300 h-full"
                  title="Requested"
                />
              </div>
            </div>

            {/* Status breakdown rows */}
            <div className="space-y-1.5 text-xs">
              <button
                onClick={() => onNavigateToView?.('pickups', { status: 'REQUESTED' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-slate-400" />
                  <span>REQUESTED</span>
                </span>
                <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-2xs">
                  {pickupOverview?.REQUESTED || 0}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('pickups', { status: 'SCHEDULED' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  <span>SCHEDULED / ACCEPTED</span>
                </span>
                <span className="font-bold text-slate-900 bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded text-2xs">
                  {pickupOverview?.SCHEDULED || 0}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('pickups', { status: 'COLLECTED' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-sky-500" />
                  <span>COLLECTED / PICKED UP</span>
                </span>
                <span className="font-bold text-slate-900 bg-sky-50 text-sky-800 border border-sky-200 px-2 py-0.5 rounded text-2xs">
                  {pickupOverview?.PICKED_UP || 0}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('pickups', { status: 'DELIVERED' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>DELIVERED & COMPLETED</span>
                </span>
                <span className="font-bold text-slate-900 bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded text-2xs">
                  {pickupOverview?.COMPLETED || 0}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('pickups', { status: 'CANCELLED' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-rose-400" />
                  <span>CANCELLED</span>
                </span>
                <span className="font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded text-2xs">
                  {pickupOverview?.CANCELLED || 0}
                </span>
              </button>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-2xs text-slate-700">
            <span>Aggregated at Depots:</span>
            <span className="font-bold text-slate-800">{pickupOverview?.AGGREGATED || 0} shipments</span>
          </div>
        </div>

        {/* 2. LOT OVERVIEW */}
        <div
          id="snapshot-lots"
          className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-blue-50 text-blue-700 border border-blue-100">
                  <Boxes className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Lot Overview</h3>
                  <span className="text-xs text-slate-700">
                    {lotOverview?.totalLots || 0} Aggregated Batches
                  </span>
                </div>
              </div>
              <button
                onClick={() => onNavigateToView?.('lots')}
                className="text-xs font-semibold text-blue-700 hover:text-blue-800 flex items-center gap-0.5 transition-colors"
              >
                <span>View all</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-3 p-2.5 rounded-lg bg-slate-50 border border-slate-200/60 mb-3 flex items-center justify-between">
              <div>
                <span className="text-2xs uppercase tracking-wider text-slate-700 font-semibold">Total Batch Weight</span>
                <div className="text-sm font-bold text-slate-900">
                  {formatWeight(lotOverview?.totalWeightKg || 0)}
                </div>
              </div>
              <span className="text-xs font-bold text-blue-800 bg-blue-100/80 px-2 py-0.5 rounded">
                {lotOverview?.totalWeightTons || 0} Tons
              </span>
            </div>

            <div className="space-y-1.5 text-xs">
              <button
                onClick={() => onNavigateToView?.('lots', { status: 'FORMED' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  <span>Active Batches (Formed)</span>
                </span>
                <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-2xs">
                  {lotOverview?.activeLots || 0}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('lots', { status: 'IN_TRANSIT' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-sky-500" />
                  <span>In Processing / Transit</span>
                </span>
                <span className="font-bold text-sky-800 bg-sky-50 border border-sky-200 px-2 py-0.5 rounded text-2xs">
                  {lotOverview?.processingLots || 0}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('lots', { status: 'RECEIVED' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-indigo-500" />
                  <span>Handed Over (At Recycler)</span>
                </span>
                <span className="font-bold text-indigo-800 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded text-2xs">
                  {lotOverview?.handedOverLots || 0}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('lots', { status: 'PROCESSED' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>Recycled / Processed</span>
                </span>
                <span className="font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded text-2xs">
                  {lotOverview?.recycledLots || 0}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('lots', { status: 'REJECTED' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left"
              >
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-rose-500" />
                  <span>Flagged / QA Rejected</span>
                </span>
                <span className="font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded text-2xs">
                  {lotOverview?.flaggedLots || 0}
                </span>
              </button>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-2xs text-slate-700">
            <span>Disputed Batches:</span>
            <span className="font-bold text-amber-700">{lotOverview?.disputedLots || 0} on hold</span>
          </div>
        </div>

        {/* 3. PAYMENT SNAPSHOT */}
        <div
          id="snapshot-payments"
          className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-100">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Payment Snapshot</h3>
                  <span className="text-xs text-slate-700">
                    {formatInr(paymentSnapshot?.totalDisbursedInr || 0)} Disbursed
                  </span>
                </div>
              </div>
              <button
                onClick={() => onNavigateToView?.('payments')}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-0.5 transition-colors"
              >
                <span>View all</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2 mt-4 text-xs">
              <button
                onClick={() => onNavigateToView?.('payments', { status: 'COMPLETED' })}
                className="w-full flex items-center justify-between p-2 rounded-lg bg-emerald-50/60 border border-emerald-100/80 hover:bg-emerald-50 transition-colors text-left"
              >
                <div>
                  <div className="font-semibold text-slate-800">PAID / SETTLED</div>
                  <div className="text-2xs text-slate-700">{paymentSnapshot?.PAID.count || 0} direct transactions</div>
                </div>
                <span className="font-bold text-emerald-800">
                  {formatInr(paymentSnapshot?.PAID.amountInr || 0)}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('payments', { status: 'PENDING' })}
                className="w-full flex items-center justify-between p-2 rounded-lg bg-amber-50/60 border border-amber-100/80 hover:bg-amber-50 transition-colors text-left"
              >
                <div>
                  <div className="font-semibold text-slate-800">PENDING APPROVAL</div>
                  <div className="text-2xs text-slate-700">{paymentSnapshot?.PENDING.count || 0} awaiting clearance</div>
                </div>
                <span className="font-bold text-amber-800">
                  {formatInr(paymentSnapshot?.PENDING.amountInr || 0)}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('payments', { status: 'PENDING' })}
                className="w-full flex items-center justify-between p-2 rounded-lg bg-sky-50/60 border border-sky-100/80 hover:bg-sky-50 transition-colors text-left"
              >
                <div>
                  <div className="font-semibold text-slate-800">PROCESSING (ESCROW)</div>
                  <div className="text-2xs text-slate-700">{paymentSnapshot?.PROCESSING.count || 0} locked until QA</div>
                </div>
                <span className="font-bold text-sky-800">
                  {formatInr(paymentSnapshot?.PROCESSING.amountInr || 0)}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('payments', { status: 'FLAGGED' })}
                className="w-full flex items-center justify-between p-2 rounded-lg bg-rose-50/60 border border-rose-100/80 hover:bg-rose-50 transition-colors text-left"
              >
                <div>
                  <div className="font-semibold text-slate-800">DISPUTED / FLAGGED</div>
                  <div className="text-2xs text-slate-700">{paymentSnapshot?.DISPUTED.count || 0} security hold</div>
                </div>
                <span className="font-bold text-rose-700">
                  {formatInr(paymentSnapshot?.DISPUTED.amountInr || 0)}
                </span>
              </button>

              <button
                onClick={() => onNavigateToView?.('payments', { status: 'FAILED' })}
                className="w-full flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 transition-colors text-left text-2xs text-slate-600"
              >
                <span>FAILED / NPCI TIMEOUT</span>
                <span className="font-semibold text-rose-700">
                  {paymentSnapshot?.FAILED.count || 0} ({formatInr(paymentSnapshot?.FAILED.amountInr || 0)})
                </span>
              </button>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-2xs text-slate-700">
            <span>Pending Total:</span>
            <span className="font-bold text-slate-800">
              {formatInr(paymentSnapshot?.totalPendingInr || 0)}
            </span>
          </div>
        </div>

        {/* 4. COMPLAINT SNAPSHOT */}
        <div
          id="snapshot-complaints"
          className="p-5 rounded-xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-rose-50 text-rose-700 border border-rose-100">
                  <AlertCircle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Complaint Snapshot</h3>
                  <span className="text-xs text-slate-700">
                    {complaintSnapshot?.total || 0} Filed Grievances
                  </span>
                </div>
              </div>
              <button
                onClick={() => onNavigateToView?.('complaints')}
                className="text-xs font-semibold text-rose-700 hover:text-rose-800 flex items-center gap-0.5 transition-colors"
              >
                <span>View all</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Status indicators */}
            <div className="grid grid-cols-2 gap-2 mt-4 mb-3">
              <button
                onClick={() => onNavigateToView?.('complaints', { status: 'OPEN' })}
                className="p-2 rounded-lg bg-rose-50/80 border border-rose-200/80 text-left hover:bg-rose-100/70 transition-colors"
              >
                <div className="text-2xs font-semibold text-rose-700 uppercase">OPEN</div>
                <div className="text-lg font-bold text-rose-900">{complaintSnapshot?.OPEN || 0}</div>
              </button>

              <button
                onClick={() => onNavigateToView?.('complaints', { status: 'IN_INVESTIGATION' })}
                className="p-2 rounded-lg bg-amber-50/80 border border-amber-200/80 text-left hover:bg-amber-100/70 transition-colors"
              >
                <div className="text-2xs font-semibold text-amber-700 uppercase">IN REVIEW</div>
                <div className="text-lg font-bold text-amber-900">{complaintSnapshot?.IN_REVIEW || 0}</div>
              </button>

              <button
                onClick={() => onNavigateToView?.('complaints', { status: 'RESOLVED' })}
                className="p-2 rounded-lg bg-emerald-50/80 border border-emerald-200/80 text-left hover:bg-emerald-100/70 transition-colors"
              >
                <div className="text-2xs font-semibold text-emerald-700 uppercase">RESOLVED</div>
                <div className="text-lg font-bold text-emerald-900">{complaintSnapshot?.RESOLVED || 0}</div>
              </button>

              <button
                onClick={() => onNavigateToView?.('complaints', { status: 'DISMISSED' })}
                className="p-2 rounded-lg bg-slate-50 border border-slate-200 text-left hover:bg-slate-100 transition-colors"
              >
                <div className="text-2xs font-semibold text-slate-700 uppercase">DISMISSED</div>
                <div className="text-lg font-bold text-slate-800">{complaintSnapshot?.REJECTED || 0}</div>
              </button>
            </div>

            {/* Category breakdown tags */}
            <div className="mt-3">
              <span className="text-2xs uppercase tracking-wider font-semibold text-slate-700 block mb-1.5">
                Issue Category Distribution
              </span>
              <div className="flex flex-wrap gap-1">
                {Object.entries(complaintSnapshot?.categoryBreakdown || {}).map(([cat, count]) => (
                  <button
                    key={cat}
                    onClick={() => onNavigateToView?.('complaints', { search: cat })}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-2xs bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                  >
                    <span>{cat.replace(/_/g, ' ')}</span>
                    <span className="font-bold text-slate-900">({count})</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-2xs text-slate-700">
            <span>Target Resolution:</span>
            <span className="font-semibold text-slate-700">&lt; 24h SLA Compliance</span>
          </div>
        </div>
      </div>
    </div>
  );
};
