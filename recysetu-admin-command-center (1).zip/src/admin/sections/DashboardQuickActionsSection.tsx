import React from 'react';
import { ShieldAlert, AlertCircle, UserCheck, Sliders, ExternalLink } from 'lucide-react';
import { AdminView } from '../types/admin';

interface DashboardQuickActionsSectionProps {
  onNavigateToView: (view: AdminView) => void;
  openComplaintsCount: number;
  criticalAnomaliesCount: number;
}

export const DashboardQuickActionsSection: React.FC<DashboardQuickActionsSectionProps> = ({
  onNavigateToView,
  openComplaintsCount,
  criticalAnomaliesCount,
}) => {
  const actions = [
    {
      title: 'Review System Anomalies',
      description: 'Audit automated flags regarding weight deviation and price ceiling breaches.',
      icon: ShieldAlert,
      view: 'anomalies' as AdminView,
      count: criticalAnomaliesCount,
      color: 'rose',
    },
    {
      title: 'Resolve Field Complaints',
      description: 'Inspect ticketed discrepancies from informal collectors and aggregation hubs.',
      icon: AlertCircle,
      view: 'complaints' as AdminView,
      count: openComplaintsCount,
      color: 'amber',
    },
    {
      title: 'Verify Collector KYC',
      description: 'Approve pending safai sathis and informal workers for direct UPI disbursement.',
      icon: UserCheck,
      view: 'users' as AdminView,
      count: null,
      color: 'blue',
    },
    {
      title: 'Configure Pricing Rules',
      description: 'Update base floor/ceiling rates and adjust dynamic government incentive bonus.',
      icon: Sliders,
      view: 'config' as AdminView,
      count: null,
      color: 'emerald',
    },
  ];

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
      <div className="flex items-center justify-between pb-4 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Operational Directives & Escalations</h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Immediate attention items for central command oversight
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
        {actions.map((act) => {
          const Icon = act.icon;
          return (
            <button
              key={act.title}
              onClick={() => onNavigateToView(act.view)}
              className="p-4 rounded-lg border border-slate-200 hover:border-emerald-500/50 hover:bg-slate-50/70 text-left transition-all group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div
                    className={`p-2 rounded-md ${
                      act.color === 'rose'
                        ? 'bg-rose-50 text-rose-700'
                        : act.color === 'amber'
                        ? 'bg-amber-50 text-amber-700'
                        : act.color === 'blue'
                        ? 'bg-blue-50 text-blue-700'
                        : 'bg-emerald-50 text-emerald-700'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>

                  {act.count !== null && act.count > 0 && (
                    <span className="text-[11px] font-bold px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-700">
                      {act.count} alert{act.count > 1 ? 's' : ''}
                    </span>
                  )}
                </div>

                <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                  {act.title}
                </h4>
                <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{act.description}</p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-semibold text-slate-600 group-hover:text-emerald-700">
                <span>Manage</span>
                <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-emerald-600" />
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
