import React from 'react';
import { AdminChartContainer } from '../components/AdminChartContainer';
import { formatInr, formatWeight } from '../utils/formatters';
import { AdminView } from '../types/admin';
import { Leaf, Coins, ArrowRight } from 'lucide-react';

interface MaterialItem {
  category?: string;
  totalWeightKg?: number;
  weightKg?: number;
  totalTons?: number;
  recycledKg?: number;
  estimatedValueInr?: number;
  co2OffsetTons?: number;
  count?: number;
  sharePercent?: number;
}

interface MaterialBreakdownProps {
  breakdown: Record<string, MaterialItem>;
  onNavigateToView?: (view: AdminView, filters?: Record<string, string>) => void;
}

export const DashboardMaterialBreakdownSection: React.FC<MaterialBreakdownProps> = ({
  breakdown,
  onNavigateToView,
}) => {
  const entries: [string, MaterialItem][] = Object.entries(breakdown || {});
  const totalKg = entries.reduce(
    (acc, [, val]) => acc + (val.totalWeightKg ?? val.weightKg ?? 0),
    0
  ) || 1;

  const colorVariants: Record<string, { bar: string; badge: string }> = {
    PLASTIC: { bar: 'bg-emerald-500', badge: 'bg-emerald-50 text-emerald-800' },
    METAL: { bar: 'bg-blue-500', badge: 'bg-blue-50 text-blue-800' },
    PAPER: { bar: 'bg-amber-500', badge: 'bg-amber-50 text-amber-800' },
    E_WASTE: { bar: 'bg-purple-500', badge: 'bg-purple-50 text-purple-800' },
    GLASS: { bar: 'bg-teal-500', badge: 'bg-teal-50 text-teal-800' },
    ORGANIC: { bar: 'bg-lime-500', badge: 'bg-lime-50 text-lime-800' },
  };

  return (
    <AdminChartContainer
      id="dashboard-material-breakdown"
      title="Material Category Overview"
      subtitle="Config-driven streams, economic valuation & environmental offsets"
      footer={
        <div className="flex items-center justify-between text-xs text-slate-700">
          <span>{entries.length} Certified Circular Fractions</span>
          <button
            onClick={() => onNavigateToView?.('lots')}
            className="font-semibold text-emerald-700 hover:text-emerald-800 inline-flex items-center gap-1"
          >
            <span>Batch Details</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      }
    >
      <div className="space-y-4 pt-1">
        {entries.map(([category, data]) => {
          const weight = data.totalWeightKg ?? data.weightKg ?? 0;
          const percent = data.sharePercent ?? Math.round((weight / totalKg) * 100);
          const styling = colorVariants[category] || {
            bar: 'bg-slate-400',
            badge: 'bg-slate-100 text-slate-700',
          };

          return (
            <div
              key={category}
              className="p-3 rounded-xl bg-slate-50/70 border border-slate-200/70 hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center justify-between text-xs mb-1.5">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900">{category.replace(/_/g, ' ')}</span>
                  <span className={`text-2xs font-semibold px-1.5 py-0.2 rounded ${styling.badge}`}>
                    {percent}% Share
                  </span>
                </div>
                <span className="font-mono font-bold text-slate-900">
                  {formatWeight(weight)}
                </span>
              </div>

              {/* Progress bar */}
              <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden mb-2">
                <div
                  className={`h-full ${styling.bar} rounded-full transition-all duration-500`}
                  style={{ width: `${Math.max(4, percent)}%` }}
                />
              </div>

              {/* Metric Sub-values */}
              <div className="flex items-center justify-between text-2xs text-slate-700 pt-1 border-t border-slate-200/50">
                <div className="flex items-center gap-1">
                  <Coins className="w-3 h-3 text-amber-500" />
                  <span>Est: {formatInr(data.estimatedValueInr || weight * 20)}</span>
                </div>

                <div className="flex items-center gap-1">
                  <Leaf className="w-3 h-3 text-emerald-600" />
                  <span>{data.co2OffsetTons || Math.round((weight * 2.1) / 1000)} T CO2</span>
                </div>

                <button
                  onClick={() => onNavigateToView?.('lots', { category })}
                  className="font-semibold text-slate-700 hover:text-emerald-700 transition-colors"
                >
                  View Lots
                </button>
              </div>
            </div>
          );
        })}
        {entries.length === 0 && (
          <div className="py-6 text-center text-xs text-slate-700">
            No material pickups recorded in this date range.
          </div>
        )}
      </div>
    </AdminChartContainer>
  );
};
