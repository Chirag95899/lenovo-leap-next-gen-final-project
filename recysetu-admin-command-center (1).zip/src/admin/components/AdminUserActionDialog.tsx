import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  XCircle,
  RotateCcw,
  ShieldCheck,
  UserCheck,
  Info,
  Building2,
  Lock,
} from 'lucide-react';
import { AdminModal } from './AdminModal';
import { User, UserRole } from '../../shared/types/domain';

export type UserActionType =
  | 'VERIFY_RECYCLER'
  | 'REJECT_RECYCLER'
  | 'SUSPEND'
  | 'REACTIVATE'
  | 'VERIFY_KYC'
  | 'CHANGE_ROLE';

interface AdminUserActionDialogProps {
  id?: string;
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  actionType: UserActionType | null;
  onConfirm: (reason: string, targetRole?: UserRole) => Promise<void>;
  isLoading?: boolean;
}

export const AdminUserActionDialog: React.FC<AdminUserActionDialogProps> = ({
  id = 'admin-user-action-dialog',
  isOpen,
  onClose,
  user,
  actionType,
  onConfirm,
  isLoading = false,
}) => {
  const [reason, setReason] = useState('');
  const [targetRole, setTargetRole] = useState<UserRole>('COLLECTOR');
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setReason('');
      setValidationError(null);
      if (user) {
        setTargetRole(user.role === 'COLLECTOR' ? 'AGGREGATOR' : 'COLLECTOR');
      }
    }
  }, [isOpen, user]);

  if (!user || !actionType) return null;

  const isReasonMandatory =
    actionType === 'SUSPEND' ||
    actionType === 'REJECT_RECYCLER' ||
    actionType === 'CHANGE_ROLE';

  const getActionConfig = () => {
    switch (actionType) {
      case 'VERIFY_RECYCLER':
        return {
          title: 'Verify Industrial Recycler',
          description:
            'Authorize this industrial recycling facility for formal waste batch intake and circular credits.',
          confirmText: 'Verify Recycler',
          variant: 'emerald' as const,
          icon: <ShieldCheck className="w-5 h-5 text-emerald-600" />,
          placeholder: 'e.g., CPCB license verified, capacity confirmed via site inspection...',
        };
      case 'REJECT_RECYCLER':
        return {
          title: 'Reject Recycler Application',
          description:
            'Decline this recycler onboarding. The applicant will be marked as REJECTED with the provided justification.',
          confirmText: 'Reject Recycler',
          variant: 'rose' as const,
          icon: <XCircle className="w-5 h-5 text-rose-600" />,
          placeholder: 'Mandatory reason: e.g., Invalid CPCB air emissions permit, non-compliant slag disposal...',
        };
      case 'SUSPEND':
        return {
          title: `Suspend ${user.role} Account`,
          description:
            'Temporarily deactivate this account and pause material dispatching, batch handovers, and platform disbursements.',
          confirmText: 'Suspend User',
          variant: 'rose' as const,
          icon: <AlertTriangle className="w-5 h-5 text-rose-600" />,
          placeholder: 'Mandatory reason: e.g., Repeated weight discrepancy telemetry, pending complaint investigation...',
        };
      case 'REACTIVATE':
        return {
          title: `Reactivate ${user.role} Account`,
          description:
            'Reinstate platform privileges, lot allocations, and dispatch permissions for this stakeholder.',
          confirmText: 'Reactivate Account',
          variant: 'emerald' as const,
          icon: <RotateCcw className="w-5 h-5 text-emerald-600" />,
          placeholder: 'Reactivation notes: e.g., Discrepancy rectified, penalty resolved, clearance re-verified...',
        };
      case 'VERIFY_KYC':
        return {
          title: 'Clear KYC Verification',
          description:
            'Confirm government identity documents, bank payout details, and address proof for this stakeholder.',
          confirmText: 'Approve KYC',
          variant: 'emerald' as const,
          icon: <UserCheck className="w-5 h-5 text-emerald-600" />,
          placeholder: 'KYC notes: e.g., Aadhaar/PAN verified against national database...',
        };
      case 'CHANGE_ROLE':
        return {
          title: 'Change Stakeholder System Role',
          description:
            'Alter the operational access role for this user across RECYSETU domains.',
          confirmText: 'Apply Role Change',
          variant: 'amber' as const,
          icon: <Building2 className="w-5 h-5 text-amber-600" />,
          placeholder: 'Mandatory operational reason: e.g., Upgraded to aggregation hub after scaling warehouse operations...',
        };
    }
  };

  const config = getActionConfig();

  const handleConfirm = async () => {
    if (isReasonMandatory && (!reason || reason.trim().length < 5)) {
      setValidationError('A specific reason with at least 5 characters is required for this action.');
      return;
    }
    setValidationError(null);
    await onConfirm(reason.trim(), actionType === 'CHANGE_ROLE' ? targetRole : undefined);
  };

  return (
    <AdminModal
      id={id}
      isOpen={isOpen}
      onClose={onClose}
      title={config.title}
      maxWidth="md"
    >
      <div className="space-y-4">
        {/* Stakeholder Target Summary Card */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center shadow-2xs">
                {config.icon}
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900 leading-tight">
                  {user.organizationName || user.name}
                </p>
                <p className="text-xs text-slate-500 font-mono">
                  ID: {user.id} {user.adminId ? `(${user.adminId})` : ''}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 uppercase">
                {user.role}
              </span>
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                  user.status === 'ACTIVE'
                    ? 'bg-emerald-100 text-emerald-800'
                    : user.status === 'SUSPENDED'
                    ? 'bg-rose-100 text-rose-800'
                    : user.status === 'REJECTED'
                    ? 'bg-red-100 text-red-900'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {user.status.replace(/_/g, ' ')}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 pt-1 border-t border-slate-200/60">
            <div>
              <span className="text-slate-400">Location:</span> {user.location.city}, {user.location.state}
            </div>
            <div>
              <span className="text-slate-400">KYC Status:</span>{' '}
              {user.kycVerified ? (
                <span className="text-emerald-700 font-medium">Verified</span>
              ) : (
                <span className="text-amber-700 font-medium">Pending</span>
              )}
            </div>
          </div>
        </div>

        {/* Action description */}
        <p className="text-xs text-slate-600 leading-relaxed">
          {config.description}
        </p>

        {/* Role Selector if CHANGE_ROLE */}
        {actionType === 'CHANGE_ROLE' && (
          <div className="space-y-1.5 bg-amber-50/60 border border-amber-200/80 rounded-lg p-3">
            <label className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-amber-600" />
              Target Operational Role
            </label>
            <select
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value as UserRole)}
              className="w-full text-xs font-semibold px-3 py-2 bg-white border border-amber-300 rounded-lg text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
            >
              <option value="COLLECTOR">COLLECTOR (Safai Sathi / Kabaadi Mitra)</option>
              <option value="AGGREGATOR">AGGREGATOR (Hub / Sorting Depot)</option>
              <option value="RECYCLER">RECYCLER (Industrial Processing Plant)</option>
              <option value="ADMIN">ADMIN (System Administrator)</option>
            </select>
          </div>
        )}

        {/* Reason / Notes Field */}
        <div className="space-y-1.5">
          <label
            htmlFor="action-reason-input"
            className="text-xs font-bold text-slate-700 flex items-center justify-between"
          >
            <span>
              {isReasonMandatory ? 'Administrative Reason (Required) *' : 'Reason / Reference Notes (Optional)'}
            </span>
            {isReasonMandatory && (
              <span className="text-[10px] text-rose-500 font-medium">Min 5 chars</span>
            )}
          </label>
          <textarea
            id="action-reason-input"
            rows={3}
            value={reason}
            onChange={(e) => {
              setReason(e.target.value);
              if (validationError) setValidationError(null);
            }}
            placeholder={config.placeholder}
            className="w-full p-2.5 text-xs text-slate-900 bg-white border border-slate-200 rounded-lg placeholder:text-slate-400 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 focus:outline-hidden resize-none"
          />
          {validationError && (
            <p className="text-xs text-rose-600 font-medium">{validationError}</p>
          )}
        </div>

        {/* Immutable Audit Log Compliance Banner */}
        <div className="flex items-start gap-2 p-2.5 bg-slate-100 rounded-lg border border-slate-200 text-slate-600 text-[11px] leading-tight">
          <Info className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
          <span>
            <strong>Immutable Audit Trail:</strong> This action will be permanently recorded with your admin user ID, timestamp, target resource state, and reason in compliance with platform governance regulations.
          </span>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
          <button
            type="button"
            id={`${id}-cancel-btn`}
            onClick={onClose}
            disabled={isLoading}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 disabled:opacity-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            id={`${id}-confirm-btn`}
            onClick={handleConfirm}
            disabled={isLoading || (isReasonMandatory && reason.trim().length < 5)}
            className={`px-4 py-2 text-xs font-semibold text-white rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs disabled:opacity-50 disabled:cursor-not-allowed ${
              config.variant === 'rose'
                ? 'bg-rose-600 hover:bg-rose-700'
                : config.variant === 'amber'
                ? 'bg-amber-600 hover:bg-amber-700'
                : 'bg-emerald-600 hover:bg-emerald-700'
            }`}
          >
            {isLoading && (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            )}
            <span>{config.confirmText}</span>
          </button>
        </div>
      </div>
    </AdminModal>
  );
};
