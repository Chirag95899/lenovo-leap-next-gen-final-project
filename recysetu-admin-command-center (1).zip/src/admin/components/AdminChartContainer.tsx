import React from 'react';

interface AdminChartContainerProps {
  id?: string;
  title: string;
  subtitle?: string;
  headerAction?: React.ReactNode;
  children: React.ReactNode;
  footer?: React.ReactNode;
}

export const AdminChartContainer: React.FC<AdminChartContainerProps> = ({
  id,
  title,
  subtitle,
  headerAction,
  children,
  footer,
}) => {
  return (
    <div id={id} className="bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-5 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-bold text-slate-900">{title}</h3>
          {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
        </div>
        {headerAction && <div>{headerAction}</div>}
      </div>

      <div className="p-5 flex-1">{children}</div>

      {footer && (
        <div className="px-5 py-3 bg-slate-50/70 border-t border-slate-100 text-xs text-slate-600 rounded-b-xl">
          {footer}
        </div>
      )}
    </div>
  );
};
