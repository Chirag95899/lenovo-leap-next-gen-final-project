import React from 'react';
import { formatDateTime, formatRelativeTime } from '../utils/formatters';
import { CheckCircle2, Clock, ShieldCheck, Truck, Scale, AlertCircle } from 'lucide-react';
import { TraceabilityEvent } from '../../shared/types/domain';

interface AdminTimelineProps {
  id?: string;
  events: TraceabilityEvent[];
  onSelectEvent?: (event: TraceabilityEvent) => void;
}

export const AdminTimeline: React.FC<AdminTimelineProps> = ({
  id = 'admin-timeline',
  events,
  onSelectEvent,
}) => {
  const getEventIcon = (type: string) => {
    if (type.includes('PICKUP') || type.includes('WEIGHED')) {
      return <Scale className="w-3.5 h-3.5 text-emerald-600" />;
    }
    if (type.includes('LOT') || type.includes('DISPATCHED')) {
      return <Truck className="w-3.5 h-3.5 text-emerald-600" />;
    }
    if (type.includes('PROCESSED') || type.includes('RECEIVED')) {
      return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />;
    }
    if (type.includes('FLAG') || type.includes('ANOMALY')) {
      return <AlertCircle className="w-3.5 h-3.5 text-amber-600" />;
    }
    return <Clock className="w-3.5 h-3.5 text-slate-500" />;
  };

  return (
    <div id={id} className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
      {events.map((event, idx) => (
        <div
          key={event.id || idx}
          onClick={() => onSelectEvent && onSelectEvent(event)}
          className={`relative group ${onSelectEvent ? 'cursor-pointer' : ''}`}
        >
          {/* Timeline node */}
          <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-white border border-slate-300 shadow-[0_1px_4px_0_rgba(0,0,0,0.02)] flex items-center justify-center group-hover:border-emerald-500 transition-colors">
            {getEventIcon(event.eventType)}
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-[0_1px_4px_0_rgba(0,0,0,0.02)] group-hover:border-slate-300 transition-all">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-bold text-slate-900">
                {event.eventType.replace(/_/g, ' ')}
              </span>
              <span className="text-xs text-slate-500 font-mono" title={formatDateTime(event.timestamp)}>
                {formatRelativeTime(event.timestamp)}
              </span>
            </div>

            <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
              <div>
                <span className="text-slate-400">Actor:</span>{' '}
                <span className="font-medium text-slate-800">{event.actorName}</span>{' '}
                <span className="text-[10px] uppercase font-semibold text-slate-500 px-1 py-0.5 bg-slate-100 rounded">
                  {event.actorRole}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Location:</span>{' '}
                <span className="font-medium text-slate-800">{event.location}</span>
              </div>
              <div>
                <span className="text-slate-400">Tracking:</span>{' '}
                <span className="font-mono text-emerald-700 font-semibold">{event.trackingCode}</span>
              </div>
            </div>

            {event.verifiedOnChain && (
              <div className="mt-2.5 flex items-center gap-1.5 text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-1 rounded border border-emerald-100">
                <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">Hash: {event.verificationHash}</span>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};
