
import React from 'react';
import {
  LayoutDashboard,
  MapPin,
  BarChart3,
  Users,
  Truck,
  Boxes,
  
  Camera,
  QrCode,
  CreditCard,
  AlertCircle,
  ShieldAlert,
  Sliders,
  History,
  Recycle,
  Star,
  Award,
  X,
  Bot,
  PhoneCall,
  Bell,
} from 'lucide-react';
import { AdminView } from '../types/admin';

interface AdminSidebarProps {
  id?: string;
  activeView: AdminView;
  onNavigate: (view: AdminView) => void;
  isOpen: boolean;
  onClose: () => void;
  anomaliesCount?: number;
  complaintsCount?: number;
}

export const AdminSidebar: React.FC<AdminSidebarProps> = ({
  id = 'admin-sidebar',
  activeView,
  onNavigate,
  isOpen,
  onClose,
  anomaliesCount = 0,
  complaintsCount = 0,
}) => {
  const navigationItems: {
    view: AdminView;
    label: string;
    icon: React.ElementType;
    badge?: number;
    badgeVariant?: 'danger' | 'warning' | 'neutral';
  }[] = [
    { view: 'dashboard', label: 'Command Center', icon: LayoutDashboard },
    { view: 'geographic', label: 'Geographic Data', icon: MapPin },
    { view: 'analytics', label: 'Platform Analytics', icon: BarChart3 },
    { view: 'users', label: 'User Directory', icon: Users },
    { view: 'pickups', label: 'Pickup Ledger', icon: Truck },
    { view: 'lots', label: 'Aggregated Lots', icon: Boxes },
    { view: 'traceability', label: 'Traceability & Chain', icon: QrCode },
    { view: 'payments', label: 'Payments & Escrow', icon: CreditCard },
    {
      view: 'complaints',
      label: 'Complaints',
      icon: AlertCircle,
      badge: complaintsCount > 0 ? complaintsCount : undefined,
      badgeVariant: 'warning',
    },
    {
      view: 'anomalies',
      label: 'Anomaly Engine',
      icon: ShieldAlert,
      badge: anomaliesCount > 0 ? anomaliesCount : undefined,
      badgeVariant: 'danger',
    },
    { view: 'ai-activity', label: 'AI Activity Logs', icon: Bot },
    { view: 'ivr', label: 'IVR Voice Logs', icon: PhoneCall },
    { view: 'notifications', label: 'System Notifications', icon: Bell },
    { view: 'audit', label: 'Audit Trail', icon: History },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar container */}
      <aside
        id={id}
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-white text-slate-600 border-r border-slate-200 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="flex items-center justify-between h-16 px-5 border-b border-slate-100 bg-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white shadow-xs">
              <Recycle className="w-5 h-5" />
            </div>
            <div>
              <span className="text-base font-bold tracking-tight text-slate-900 flex items-center gap-1.5">
                RECYSETU
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 bg-emerald-50 text-emerald-700 rounded border border-emerald-200">
                  Admin
                </span>
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 lg:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tagline */}
        <div className="px-5 py-3 border-b border-slate-100 bg-slate-50/50">
          <p className="text-[11px] text-slate-500 italic leading-tight font-medium">
            "Empowering Informal Recycling, Building a Cleaner Future"
          </p>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Operations & Oversight
          </div>
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.view;

            return (
              <button
                key={item.view}
                id={`admin-nav-${item.view}`}
                onClick={() => {
                  onNavigate(item.view);
                  onClose();
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-700'
                    : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                      isActive
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.badgeVariant === 'danger'
                        ? 'bg-rose-50 text-rose-600 border border-rose-200'
                        : 'bg-amber-50 text-amber-600 border border-amber-200'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/80 text-[11px] text-slate-500">
          <div className="flex items-center justify-between">
            <span>Security Layer:</span>
            <span className="text-emerald-700 font-mono font-medium bg-emerald-50 px-1 rounded">RBAC V2</span>
          </div>
          <div className="flex items-center justify-between mt-2 text-[10px] text-slate-400">
            <span>Unified Hub:</span>
            <span className="truncate">Collector • Aggregator • Recycler</span>
          </div>
        </div>
      </aside>
    </>
  );
};
