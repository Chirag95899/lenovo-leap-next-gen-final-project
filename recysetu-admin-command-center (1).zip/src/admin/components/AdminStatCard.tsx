
import React from 'react';
import { ArrowUpRight, ArrowDownRight, Minus, LucideIcon } from 'lucide-react';

interface AdminStatCardProps {
  id?: string;
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  subtitle?: string;
  icon: LucideIcon;
  variant?: 'emerald' | 'amber' | 'blue' | 'rose' | 'slate';
  onClick?: () => void;
}

export const AdminStatCard: React.FC<AdminStatCardProps> = ({
  id,
  title,
  value,
  change,
  changeType = 'neutral',
  subtitle,
  icon: Icon,
  variant = 'emerald',
  onClick,
}) => {
  const colorMap = {
    emerald: {
      bg: 'bg-emerald-50 text-emerald-600',
    },
    blue: {
      bg: 'bg-blue-50 text-blue-600',
    },
    amber: {
      bg: 'bg-amber-50 text-amber-600',
    },
    rose: {
      bg: 'bg-rose-50 text-rose-600',
    },
    slate: {
      bg: 'bg-slate-50 text-slate-600',
    },
  };

  const scheme = colorMap[variant] || colorMap.emerald;

  return (
    <div
      id={id}
      onClick={onClick}
      className={`relative p-5 rounded-[16px] bg-white border border-slate-200 shadow-[0_2px_10px_-3px_rgba(0,0,0,0.02)] transition-all overflow-hidden group ${
        onClick ? 'cursor-pointer hover:shadow-[0_4px_12px_-3px_rgba(0,0,0,0.05)] hover:border-emerald-200' : ''
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex flex-col">
          <div className="flex items-center gap-2 mb-2">
            <span className={`p-1.5 rounded-lg ${scheme.bg}`}>
              <Icon className="w-4 h-4" strokeWidth={2.5} />
            </span>
            <span className="text-xs font-semibold text-slate-500 truncate">
              {title}
            </span>
          </div>
          <div className="text-[28px] font-bold tracking-tight text-slate-900 leading-none">
            {value}
          </div>
        </div>
      </div>

      {(change || subtitle) && (
        <div className="mt-4 flex items-center gap-2 text-xs">
          {change && (
            <span
              className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded font-bold ${
                changeType === 'positive'
                  ? 'text-emerald-700 bg-emerald-50'
                  : changeType === 'negative'
                  ? 'text-rose-700 bg-rose-50'
                  : 'text-slate-600 bg-slate-100'
              }`}
            >
              {changeType === 'positive' && <ArrowUpRight className="w-3.5 h-3.5" />}
              {changeType === 'negative' && <ArrowDownRight className="w-3.5 h-3.5" />}
              {changeType === 'neutral' && <Minus className="w-3.5 h-3.5" />}
              {change}
            </span>
          )}
          {subtitle && <span className="text-slate-400 font-medium truncate">{subtitle}</span>}
        </div>
      )}
    </div>
  );
};
