import React, { memo, useState, useEffect } from 'react';
import { ComposableMap, Geographies, Geography } from 'react-simple-maps';
import { Tooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css';

// Using the geojson we fetched
const geoUrl = '/india-states.geojson';

interface MapProps {
  data: any[];
  selectedState: string | null;
  onSelectState: (stateName: string) => void;
}

const IndiaMapComponent: React.FC<MapProps> = ({ data, selectedState, onSelectState }) => {
  const [tooltipContent, setTooltipContent] = useState("");

  return (
    <div className="relative w-full h-[500px] flex items-center justify-center bg-slate-50 border border-slate-200 rounded-xl overflow-hidden shadow-inner">
      <ComposableMap
        projection="geoMercator"
        projectionConfig={{
          scale: 850,
          center: [80, 22] // Center of India
        }}
        width={800}
        height={600}
        style={{ width: "100%", height: "100%" }}
      >
        <Geographies geography={geoUrl}>
          {({ geographies }) =>
            geographies.map((geo) => {
              const stateName = geo.properties.NAME_1;
              const sData = data.find(d => d.state === stateName || (stateName === 'Chhattisgarh' && d.state === 'Chhattisgarh')); // Match exactly if possible
              
              // Exact matches or mapping:
              let mappedName = stateName;
              if (stateName === 'Andaman and Nicobar') mappedName = 'Andaman and Nicobar';
              // ... we can refine later
              
              const isSelected = selectedState === stateName;
              const isActive = sData?.status === 'ACTIVE';
              
              let fill = "#E2E8F0"; // slate-200 for default inactive
              if (isActive) {
                fill = isSelected ? "#10B981" : "#34D399"; // emerald-500 : emerald-400
              } else if (isSelected) {
                fill = "#94A3B8"; // slate-400 for selected inactive
              }

              return (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill={fill}
                  stroke="#FFFFFF"
                  strokeWidth={0.5}
                  onMouseEnter={() => {
                    const status = sData?.status === 'ACTIVE' ? 'ACTIVE' : 'COMING SOON';
                    let tip = `<b>${stateName}</b><br/>Status: <span style="color: ${isActive ? '#34D399' : '#94A3B8'}">${status}</span>`;
                    if (isActive && sData) {
                      tip += `<br/>Stakeholders: ${sData.totalStakeholders}`;
                      tip += `<br/>Recycled: ${(sData.wasteRecycledKg / 1000).toFixed(1)} T`;
                    }
                    setTooltipContent(tip);
                  }}
                  onMouseLeave={() => {
                    setTooltipContent("");
                  }}
                  onClick={() => {
                    onSelectState(stateName);
                  }}
                  style={{
                    
                    
                    
                  }}
                  data-tooltip-id="my-tooltip"
                  data-tooltip-html={tooltipContent}
                />
              );
            })
          }
        </Geographies>
      </ComposableMap>
      <Tooltip id="my-tooltip" place="top" style={{ backgroundColor: '#0f172a', borderRadius: '8px', zIndex: 50, fontSize: '12px' }} />
    </div>
  );
};

export const IndiaMap = memo(IndiaMapComponent);
