import React, { useState } from 'react';
import { PickupRequest, PickupStatus } from '../../shared/types/domain';
import { AdminDrawer } from './AdminDrawer';
import { AdminStatusBadge } from './AdminStatusBadge';
import { AdminQrCodeView } from './AdminQrCodeView';
import { AdminTraceabilityTimelineView } from './AdminTraceabilityTimelineView';
import { formatDateTime, formatWeight, formatInr } from '../utils/formatters';
import { usePickupDetailQuery } from '../hooks/useAdminDomainQueries';
import {
  Truck,
  UserCheck,
  Building2,
  Calendar,
  Clock,
  MapPin,
  Scale,
  CreditCard,
  Boxes,
  ShieldCheck,
  AlertTriangle,
  FileCheck,
  Image,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';

interface AdminPickupDetailDrawerProps {
  pickupId: string | null;
  onClose: () => void;
  onNavigateToLot?: (lotId: string) => void;
}

export const AdminPickupDetailDrawer: React.FC<AdminPickupDetailDrawerProps> = ({
  pickupId,
  onClose,
  onNavigateToLot,
}) => {
  const { data, isLoading, error, refetch, addAuditEvent, updateStatus } = usePickupDetailQuery(pickupId);
  const [newStatus, setNewStatus] = useState<PickupStatus | ''>('');
  const [statusReason, setStatusReason] = useState('');
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [statusError, setStatusError] = useState<string | null>(null);

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStatus || !statusReason.trim()) return;
    setIsUpdatingStatus(true);
    setStatusError(null);
    try {
      await updateStatus(newStatus, statusReason.trim());
      setNewStatus('');
      setStatusReason('');
    } catch (err: any) {
      setStatusError(err.message || 'Failed to update pickup status');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const pickup = data?.pickup;

  return (
    <AdminDrawer
      isOpen={!!pickupId}
      onClose={onClose}
      title={pickup ? `Pickup Request: ${pickup.trackingCode}` : 'Pickup Details'}
      subtitle={pickup ? `ID: ${pickup.id} • Registered ${formatDateTime(pickup.createdAt)}` : 'Loading details...'}
      width="2xl"
    >
      {isLoading && (
        <div className="py-16 text-center space-y-3">
          <div className="w-8 h-8 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-500 font-medium">Fetching authentic pickup & custody records...</p>
        </div>
      )}

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
          <div className="font-bold mb-1">Failed to load pickup records</div>
          <p>{error}</p>
          <button
            onClick={() => refetch()}
            className="mt-2 text-rose-800 underline font-semibold hover:text-rose-900"
          >
            Retry
          </button>
        </div>
      )}

      {pickup && (
        <div className="space-y-6">
          {/* Header Status & Key Metrics */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-2xs text-emerald-700">
                <Truck className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] text-slate-400 block font-mono">TRACKING CODE</span>
                <span className="text-base font-mono font-bold text-slate-900">{pickup.trackingCode}</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-[11px] text-slate-400 block">CURRENT STATUS</span>
                <AdminStatusBadge status={pickup.status} size="md" />
              </div>
            </div>
          </div>

          {/* Primary Waste Specifications */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
              Waste & Weighment Specifications
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Material</span>
                <span className="text-xs font-bold text-slate-900 mt-1 block truncate">
                  {pickup.materialName}
                </span>
                <span className="text-[10px] text-slate-500 font-medium">{pickup.category}</span>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Declared Quantity</span>
                <span className="text-xs font-bold text-slate-900 mt-1 block">
                  {pickup.quantityKg} {pickup.unit || 'kg'}
                </span>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Confirmed Weight</span>
                <span className="text-xs font-bold text-emerald-700 mt-1 block">
                  {pickup.actualWeightKg != null ? formatWeight(pickup.actualWeightKg) : 'Pending Intake'}
                </span>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Valuation Payout</span>
                <span className="text-xs font-mono font-bold text-slate-900 mt-1 block">
                  {formatInr(pickup.totalPrice)}
                </span>
                <span className="text-[10px] text-slate-400">Rate: ₹{pickup.pricePerKg}/kg</span>
              </div>
            </div>
          </div>

          {/* Stakeholders & Chain of Custody Parties */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
              Custodial Parties & Location
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-1">
                <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-semibold uppercase">
                  <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                  Collector
                </div>
                <div className="font-bold text-slate-900">{pickup.collectorName}</div>
                <div className="text-[11px] text-slate-500 font-mono">ID: {pickup.collectorId}</div>
              </div>

              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-1">
                <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-semibold uppercase">
                  <Building2 className="w-3.5 h-3.5 text-blue-600" />
                  Aggregation Depot
                </div>
                <div className="font-bold text-slate-900">{pickup.aggregatorName}</div>
                <div className="text-[11px] text-slate-500 font-mono">ID: {pickup.aggregatorId}</div>
              </div>

              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-1">
                <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-semibold uppercase">
                  <Boxes className="w-3.5 h-3.5 text-purple-600" />
                  Recycler / Processor
                </div>
                <div className="font-bold text-slate-900">{pickup.recyclerName || 'Not yet assigned'}</div>
                {pickup.recyclerId && (
                  <div className="text-[11px] text-slate-500 font-mono">ID: {pickup.recyclerId}</div>
                )}
              </div>
            </div>

            {/* Privacy-Conscious Geo & Timing */}
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Pickup Location (Privacy Filtered)</span>
                  <span className="font-medium text-slate-800 text-xs mt-0.5 block">
                    {pickup.location.address}, Ward {pickup.location.ward}, {pickup.location.city}
                  </span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    Coordinates: {0?.toFixed(4)}, {0?.toFixed(4)}
                  </span>
                </div>
              </div>

              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-start gap-2.5">
                <Calendar className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Schedule & Source</span>
                  <span className="font-medium text-slate-800 text-xs mt-0.5 block">
                    {pickup.preferredDate ? pickup.preferredDate : 'Immediate On-Demand'} • {pickup.preferredTime || 'Standard Hours'}
                  </span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">
                    Origin Source: <strong>{pickup.source || 'Standard Collection'}</strong>
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Associated Lot (if aggregated) */}
          {data?.associatedLot && (
            <div className="p-4 bg-purple-50/60 rounded-xl border border-purple-200 shadow-2xs">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Boxes className="w-5 h-5 text-purple-700" />
                  <div>
                    <h5 className="text-xs font-bold text-purple-950">Aggregated into Industrial Lot</h5>
                    <p className="text-[11px] text-purple-800">
                      Lot Number: <span className="font-mono font-bold">{data.associatedLot.lotNumber}</span> • Material: {data.associatedLot.materialName}
                    </p>
                  </div>
                </div>
                {onNavigateToLot && (
                  <button
                    type="button"
                    onClick={() => onNavigateToLot(data.associatedLot!.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-purple-700 text-white hover:bg-purple-800 transition-colors shadow-2xs"
                  >
                    <span>Inspect Lot</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Associated Payments */}
          {data?.associatedPayments && data.associatedPayments.length > 0 && (
            <div>
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-emerald-600" />
                Associated Payout Records
              </h4>
              <div className="space-y-2">
                {data.associatedPayments.map((p) => (
                  <div
                    key={p.id}
                    className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-2 text-xs"
                  >
                    <div>
                      <div className="font-mono font-bold text-slate-900">{p.id}</div>
                      <div className="text-[11px] text-slate-500">
                        {p.paymentMethod} • {formatDateTime(p.timestamp)}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-slate-900 text-sm">
                        {formatInr(p.amount)}
                      </span>
                      <AdminStatusBadge status={p.status} size="sm" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Physical QR Verification Code */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              Physical Batch Verification Tag
            </h4>
            <AdminQrCodeView
              value={pickup.qrCode || `RECYSETU:PK:${pickup.id}:${pickup.trackingCode}`}
              title={`Batch Seal: ${pickup.trackingCode}`}
              subtitle="Tamper-evident verification tag scannable by Aggregators and Recyclers"
              metadata={{
                entityType: 'PICKUP',
                identifier: pickup.trackingCode,
                material: pickup.materialName,
                weightKg: pickup.quantityKg,
                status: pickup.status,
              }}
              size={180}
            />
          </div>

          {/* Traceability Timeline & Chain of Custody */}
          <AdminTraceabilityTimelineView
            events={data?.traceabilityEvents || []}
            title="Chain of Custody & Traceability Timeline"
            subtitle="Chronological log of verified custodial transfers. Historical entries are immutable."
            allowAddCorrection={true}
            onAddCorrection={async (correctionData) => {
              await addAuditEvent(correctionData);
            }}
          />

          {/* Authorized Admin Status Override */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Authorized Status Transition
            </h4>
            <p className="text-[11px] text-slate-500">
              Admin transitions adhere strictly to platform business rules and automatically generate an immutable audit log entry.
            </p>

            {statusError && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg">
                {statusError}
              </div>
            )}

            <form onSubmit={handleUpdateStatus} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Target Status</label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as PickupStatus)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="">Select Target Status...</option>
                    <option value="REQUESTED">REQUESTED</option>
                    <option value="ACCEPTED">ACCEPTED</option>
                    <option value="SCHEDULED">SCHEDULED</option>
                    <option value="COLLECTOR_READY">COLLECTOR_READY</option>
                    <option value="PICKED_UP">PICKED_UP</option>
                    <option value="COLLECTED">COLLECTED</option>
                    <option value="AGGREGATED">AGGREGATED</option>
                    <option value="COMPLETED">COMPLETED</option>
                    <option value="CANCELLED">CANCELLED</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Authorization Reason / Justification <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={statusReason}
                    onChange={(e) => setStatusReason(e.target.value)}
                    placeholder="e.g. Weighment verified at hub scale #2"
                    required
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isUpdatingStatus || !newStatus || !statusReason.trim()}
                  className="px-4 py-2 rounded-lg bg-emerald-600 text-white font-semibold text-xs hover:bg-emerald-700 shadow-2xs disabled:opacity-50 transition-colors flex items-center gap-1.5"
                >
                  {isUpdatingStatus ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      Updating Status...
                    </>
                  ) : (
                    'Execute Status Transition'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminDrawer>
  );
};
