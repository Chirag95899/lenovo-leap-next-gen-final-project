import React from 'react';
import { formatRelativeTime } from '../utils/formatters';
import { Shield, FileEdit, AlertTriangle, CheckCircle, Lock } from 'lucide-react';
import { AuditLog } from '../../shared/types/domain';

interface AdminActivityFeedProps {
  id?: string;
  logs: AuditLog[];
  maxItems?: number;
}

export const AdminActivityFeed: React.FC<AdminActivityFeedProps> = ({
  id = 'admin-activity-feed',
  logs,
  maxItems = 8,
}) => {
  const displayLogs = logs.slice(0, maxItems);

  const getActionIcon = (action: string) => {
    if (action.includes('LOGIN') || action.includes('AUTH')) {
      return <Lock className="w-3.5 h-3.5 text-slate-500" />;
    }
    if (action.includes('CONFIG') || action.includes('UPDATE')) {
      return <FileEdit className="w-3.5 h-3.5 text-emerald-700" />;
    }
    if (action.includes('HOLD') || action.includes('FLAG')) {
      return <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />;
    }
    if (action.includes('RESOLVE')) {
      return <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />;
    }
    return <Shield className="w-3.5 h-3.5 text-emerald-600" />;
  };

  if (!displayLogs.length) {
    return <div className="text-xs text-slate-500 py-4 text-center">No recent audit activity.</div>;
  }

  return (
    <div id={id} className="divide-y divide-slate-100">
      {displayLogs.map((log) => (
        <div key={log.id} className="py-3 flex items-start gap-3 text-xs">
          <div className="p-1.5 rounded-md bg-slate-100 mt-0.5 shrink-0">
            {getActionIcon(log.action)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2">
              <span className="font-semibold text-slate-800 truncate">
                {log.action.replace(/_/g, ' ')}
              </span>
              <span className="text-[11px] text-slate-400 shrink-0 font-mono">
                {formatRelativeTime(log.timestamp)}
              </span>
            </div>
            <p className="text-slate-500 mt-0.5 line-clamp-2">{log.details}</p>
            <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-400">
              <span className="font-medium text-slate-500">{log.actorName}</span>
              <span>•</span>
              <span className="font-mono">{log.targetResource}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
