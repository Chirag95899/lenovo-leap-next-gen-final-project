import React from 'react';
import { Loader2 } from 'lucide-react';

interface AdminLoadingStateProps {
  id?: string;
  message?: string;
  rows?: number;
}

export const AdminLoadingState: React.FC<AdminLoadingStateProps> = ({
  id,
  message = 'Loading operational telemetry...',
  rows,
}) => {
  if (rows && rows > 0) {
    return (
      <div id={id} className="p-4 space-y-3 bg-white rounded-xl border border-slate-200 animate-pulse">
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="h-9 bg-slate-100 rounded-md w-full" />
        ))}
      </div>
    );
  }

  return (
    <div
      id={id}
      className="flex flex-col items-center justify-center py-16 px-4 text-center bg-white rounded-xl border border-slate-200"
    >
      <Loader2 className="w-8 h-8 text-emerald-600 animate-spin mb-3" />
      <p className="text-sm font-medium text-slate-600">{message}</p>
    </div>
  );
};
