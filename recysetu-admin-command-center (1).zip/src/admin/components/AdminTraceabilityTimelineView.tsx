import React, { useState } from 'react';
import { TraceabilityEvent } from '../../shared/types/domain';
import { formatDateTime, formatRelativeTime } from '../utils/formatters';
import {
  ShieldCheck,
  Clock,
  Truck,
  Scale,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  FileText,
  UserCheck,
  Boxes,
  MapPin,
} from 'lucide-react';
import { AdminModal } from './AdminModal';

interface AdminTraceabilityTimelineViewProps {
  id?: string;
  events: TraceabilityEvent[];
  title?: string;
  subtitle?: string;
  allowAddCorrection?: boolean;
  onAddCorrection?: (data: {
    eventType: string;
    notes: string;
    weightKg?: number;
    location: string;
    details?: Record<string, any>;
  }) => Promise<void>;
  isLoading?: boolean;
}

export const AdminTraceabilityTimelineView: React.FC<AdminTraceabilityTimelineViewProps> = ({
  id = 'traceability-timeline-view',
  events,
  title = 'Chain of Custody & Traceability Timeline',
  subtitle = 'Immutable verifiable audit log of physical waste movements and custodial handovers',
  allowAddCorrection = true,
  onAddCorrection,
  isLoading = false,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [eventType, setEventType] = useState('AUDIT_CORRECTION_RECORDED');
  const [notes, setNotes] = useState('');
  const [location, setLocation] = useState('Central Admin Verification Station');
  const [weightKg, setWeightKg] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<TraceabilityEvent | null>(null);

  const getEventBadge = (type: string) => {
    const t = type.toUpperCase();
    if (t.includes('PICKUP') || t.includes('REQUEST')) {
      return {
        icon: <Clock className="w-3.5 h-3.5 text-amber-600" />,
        bg: 'bg-amber-50 text-amber-800 border-amber-200',
      };
    }
    if (t.includes('ASSIGN') || t.includes('ACCEPT')) {
      return {
        icon: <UserCheck className="w-3.5 h-3.5 text-blue-600" />,
        bg: 'bg-blue-50 text-blue-800 border-blue-200',
      };
    }
    if (t.includes('WEIGH') || t.includes('MEASURE')) {
      return {
        icon: <Scale className="w-3.5 h-3.5 text-emerald-600" />,
        bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      };
    }
    if (t.includes('LOT') || t.includes('AGGREGAT')) {
      return {
        icon: <Boxes className="w-3.5 h-3.5 text-purple-600" />,
        bg: 'bg-purple-50 text-purple-800 border-purple-200',
      };
    }
    if (t.includes('DISPATCH') || t.includes('TRANSIT')) {
      return {
        icon: <Truck className="w-3.5 h-3.5 text-indigo-600" />,
        bg: 'bg-indigo-50 text-indigo-800 border-indigo-200',
      };
    }
    if (t.includes('PROCESS') || t.includes('RECYCLE') || t.includes('DELIVER') || t.includes('RECEIVE')) {
      return {
        icon: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />,
        bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      };
    }
    if (t.includes('CORRECTION') || t.includes('AUDIT')) {
      return {
        icon: <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />,
        bg: 'bg-emerald-50 text-emerald-900 border-emerald-300',
      };
    }
    return {
      icon: <FileText className="w-3.5 h-3.5 text-slate-600" />,
      bg: 'bg-slate-50 text-slate-700 border-slate-200',
    };
  };

  const handleSubmitCorrection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onAddCorrection || !notes.trim()) return;
    setIsSubmitting(true);
    try {
      await onAddCorrection({
        eventType,
        notes: notes.trim(),
        weightKg: weightKg ? parseFloat(weightKg) : undefined,
        location: location.trim(),
        details: {
          recordedByAdminRole: true,
          recordedAt: new Date().toISOString(),
        },
      });
      setNotes('');
      setWeightKg('');
      setIsModalOpen(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div id={id} className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-slate-200">
        <div>
          <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            {title}
          </h4>
          <p className="text-xs text-slate-500">{subtitle}</p>
        </div>

        {allowAddCorrection && onAddCorrection && (
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 text-white hover:bg-emerald-700 shadow-2xs transition-colors"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            Add Audit / Correction Event
          </button>
        )}
      </div>

      {events.length === 0 ? (
        <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-xs">
          No traceability events recorded yet for this entity.
        </div>
      ) : (
        <div className="relative pl-6 space-y-4 before:absolute before:left-3 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-200">
          {events.map((event, idx) => {
            const badge = getEventBadge(event.eventType);
            return (
              <div
                key={event.id || idx}
                className="relative group cursor-pointer"
                onClick={() => setSelectedEvent(event)}
              >
                {/* Visual node */}
                <div className="absolute -left-6 top-1.5 w-6 h-6 rounded-full bg-white border border-slate-300 shadow-2xs flex items-center justify-center group-hover:scale-110 group-hover:border-emerald-500 transition-all">
                  {badge.icon}
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs hover:border-slate-300 hover:shadow-xs transition-all">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${badge.bg}`}>
                        {event.eventType.replace(/_/g, ' ')}
                      </span>
                      {event.weightKg !== undefined && (
                        <span className="text-xs font-semibold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                          {event.weightKg} kg
                        </span>
                      )}
                    </div>
                    <span
                      className="text-[11px] text-slate-500 font-mono"
                      title={formatDateTime(event.timestamp)}
                    >
                      {formatDateTime(event.timestamp)} ({formatRelativeTime(event.timestamp)})
                    </span>
                  </div>

                  <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-slate-600">
                    <div>
                      <span className="text-slate-400 block text-[10px]">Actor:</span>
                      <span className="font-semibold text-slate-800">{event.actorName}</span>{' '}
                      <span className="text-[10px] uppercase font-semibold text-slate-500 px-1 py-0.2 bg-slate-100 rounded">
                        {event.actorRole}
                      </span>
                    </div>

                    <div>
                      <span className="text-slate-400 block text-[10px]">Location:</span>
                      <span className="font-medium text-slate-800 truncate flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        {event.location}
                      </span>
                    </div>

                    <div>
                      <span className="text-slate-400 block text-[10px]">Tracking Reference:</span>
                      <span className="font-mono text-emerald-700 font-semibold truncate block">
                        {event.trackingCode}
                      </span>
                    </div>
                  </div>

                  {event.notes && (
                    <div className="mt-2 text-xs text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <span className="font-semibold text-slate-500 text-[10px] block">Audit Notes:</span>
                      {event.notes}
                    </div>
                  )}

                  {event.verifiedOnChain && (
                    <div className="mt-2.5 flex items-center gap-1.5 text-[10px] font-mono text-emerald-800 bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="truncate">Cryptographic Proof: {event.verificationHash}</span>
                      {event.verificationMethod && (
                        <span className="text-[9px] uppercase px-1 py-0.5 bg-emerald-100 text-emerald-800 rounded ml-auto">
                          {event.verificationMethod}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Detail Inspector Modal for an event */}
      <AdminModal
        isOpen={!!selectedEvent}
        onClose={() => setSelectedEvent(null)}
        title="Traceability Event Cryptographic Record"
        subtitle={`Audit ID: ${selectedEvent?.id || ''}`}
        maxWidth="md"
      >
        {selectedEvent && (
          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block text-[11px]">Event Type:</span>
                <span className="font-bold text-slate-900">{selectedEvent.eventType}</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block text-[11px]">Timestamp:</span>
                <span className="font-medium text-slate-800">{formatDateTime(selectedEvent.timestamp)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block text-[11px]">Actor:</span>
                <span className="font-bold text-slate-900">{selectedEvent.actorName} ({selectedEvent.actorRole})</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block text-[11px]">Facility / Geo:</span>
                <span className="font-medium text-slate-800">{selectedEvent.location}</span>
              </div>
            </div>

            {selectedEvent.weightKg !== undefined && (
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block text-[11px]">Recorded Weight:</span>
                <span className="font-bold text-emerald-700 text-sm">{selectedEvent.weightKg} kg</span>
              </div>
            )}

            {selectedEvent.notes && (
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block text-[11px]">Notes:</span>
                <p className="text-slate-800 mt-1">{selectedEvent.notes}</p>
              </div>
            )}

            {selectedEvent.details && Object.keys(selectedEvent.details).length > 0 && (
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block text-[11px] mb-1">Payload Metadata:</span>
                <pre className="p-2 bg-slate-900 text-slate-100 rounded text-[11px] font-mono overflow-x-auto max-h-40">
                  {JSON.stringify(selectedEvent.details, null, 2)}
                </pre>
              </div>
            )}

            <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-emerald-900">
              <div className="flex items-center gap-1.5 font-bold text-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>On-Chain Cryptographic Integrity Verified</span>
              </div>
              <div className="font-mono text-[11px] break-all mt-1 text-emerald-800">
                Hash: {selectedEvent.verificationHash}
              </div>
            </div>
          </div>
        )}
      </AdminModal>

      {/* Non-Destructive Audit / Correction Event Modal */}
      <AdminModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Record Non-Destructive Audit / Correction Event"
        subtitle="Appends an immutable audit event to the chain of custody. Past events are strictly preserved."
        maxWidth="md"
      >
        <form onSubmit={handleSubmitCorrection} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-700 font-semibold mb-1">Event Type</label>
            <select
              value={eventType}
              onChange={(e) => setEventType(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            >
              <option value="AUDIT_CORRECTION_RECORDED">AUDIT_CORRECTION_RECORDED (General Audit Record)</option>
              <option value="WEIGHT_VERIFIED">WEIGHT_VERIFIED (Intake Weighment Reconciliation)</option>
              <option value="QUALITY_INSPECTION_PASSED">QUALITY_INSPECTION_PASSED (Quality & Purity Recheck)</option>
              <option value="HANDOVER_VERIFIED">HANDOVER_VERIFIED (Custodial Transfer Reconciliation)</option>
              <option value="EXCEPTION_RESOLVED">EXCEPTION_RESOLVED (Administrative Anomaly Resolution)</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Location / Station</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Weight in kg (optional)</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={weightKg}
                onChange={(e) => setWeightKg(e.target.value)}
                placeholder="e.g. 2450.00"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Audit Findings & Reason for Entry <span className="text-rose-500">*</span>
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              required
              rows={3}
              placeholder="State the verified fact, discrepancy reconciliation note, or reason for correction..."
              className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-amber-800 text-[11px] flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong>Audit Guarantee:</strong> Historical records are never overwritten or deleted. This event is cryptographically timestamped and linked to your authorized administrator ID.
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-3 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !notes.trim()}
              className="px-4 py-2 rounded-lg bg-emerald-600 text-white font-semibold hover:bg-emerald-700 shadow-2xs disabled:opacity-50"
            >
              {isSubmitting ? 'Recording Event...' : 'Record Audit Event'}
            </button>
          </div>
        </form>
      </AdminModal>
    </div>
  );
};
