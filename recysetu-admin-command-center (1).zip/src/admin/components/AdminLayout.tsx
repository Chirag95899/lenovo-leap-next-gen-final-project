import React, { useState } from 'react';
import { AdminSidebar } from './AdminSidebar';
import { AdminHeader } from './AdminHeader';
import { AdminView } from '../types/admin';
import { User } from '../../shared/types/domain';

interface AdminLayoutProps {
  id?: string;
  adminUser: User | null;
  activeView: AdminView;
  onNavigate: (view: AdminView) => void;
  onLogout: () => void;
  onRefresh?: () => void;
  isRefreshing?: boolean;
  anomaliesCount?: number;
  complaintsCount?: number;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  id = 'admin-layout-root',
  adminUser,
  activeView,
  onNavigate,
  onLogout,
  onRefresh,
  isRefreshing = false,
  anomaliesCount = 0,
  complaintsCount = 0,
  children,
}) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div id={id} className="min-h-screen bg-slate-50 text-slate-900 flex flex-col antialiased">
      {/* Sidebar Navigation */}
      <AdminSidebar
        activeView={activeView}
        onNavigate={onNavigate}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        anomaliesCount={anomaliesCount}
        complaintsCount={complaintsCount}
      />

      {/* Main Content Viewport */}
      <div className="lg:pl-64 flex flex-col flex-1 min-w-0">
        <AdminHeader
          adminUser={adminUser}
          onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
          onLogout={onLogout}
          onRefresh={onRefresh}
          isRefreshing={isRefreshing}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
};
