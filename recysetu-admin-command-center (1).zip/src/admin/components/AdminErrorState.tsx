import React from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface AdminErrorStateProps {
  id?: string;
  title?: string;
  message: string;
  onRetry?: () => void;
}

export const AdminErrorState: React.FC<AdminErrorStateProps> = ({
  id,
  title = 'An error occurred',
  message,
  onRetry,
}) => {
  return (
    <div
      id={id}
      className="p-6 rounded-xl border border-rose-200 bg-rose-50/50 text-rose-900 flex flex-col items-center text-center my-4"
    >
      <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center text-rose-600 mb-3">
        <AlertCircle className="w-5 h-5" />
      </div>
      <h4 className="text-sm font-bold">{title}</h4>
      <p className="text-xs text-rose-700 mt-1 max-w-md">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold shadow-2xs transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Retry Request</span>
        </button>
      )}
    </div>
  );
};
