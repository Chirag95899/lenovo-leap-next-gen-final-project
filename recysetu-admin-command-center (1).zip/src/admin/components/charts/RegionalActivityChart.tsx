import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { RegionalActivityPoint } from '../../../shared/types/analytics';

interface RegionalActivityChartProps {
  data: RegionalActivityPoint[];
}

export const RegionalActivityChart: React.FC<RegionalActivityChartProps> = ({ data }) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-slate-500 text-sm">
        No regional activity data recorded.
      </div>
    );
  }

  const customTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const item: RegionalActivityPoint = payload[0].payload;
      return (
        <div className="bg-slate-900 border border-slate-700/80 p-3 rounded-lg shadow-xl text-xs space-y-1.5 min-w-44">
          <p className="font-semibold text-slate-900 border-b border-slate-800 pb-1">{item.region}</p>
          <div className="flex items-center justify-between text-emerald-700">
            <span>Collected Volume:</span>
            <span className="font-mono font-medium">{item.volumeKg.toLocaleString()} kg</span>
          </div>
          <div className="flex items-center justify-between text-teal-400">
            <span>Recycled Volume:</span>
            <span className="font-mono font-medium">{item.recycledKg.toLocaleString()} kg</span>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span>Pickups Handled:</span>
            <span className="font-mono font-medium">{item.pickupsCount}</span>
          </div>
          <div className="flex items-center justify-between text-slate-500 pt-1 border-t border-slate-800">
            <span>Active Collectors:</span>
            <span className="font-mono font-medium">{item.collectorsCount}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          layout="vertical"
          margin={{ top: 10, right: 20, left: 40, bottom: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
          <XAxis
            type="number"
            stroke="#94a3b8"
            tick={{ fontSize: 11 }}
            tickLine={false}
            tickFormatter={(val) => `${val >= 1000 ? `${(val / 1000).toFixed(0)}t` : `${val}kg`}`}
          />
          <YAxis
            type="category"
            dataKey="city"
            stroke="#94a3b8"
            tick={{ fontSize: 11 }}
            tickLine={false}
          />
          <Tooltip content={customTooltip} />
          <Bar
            dataKey="volumeKg"
            name="Volume (kg)"
            fill="#0ea5e9"
            radius={[0, 4, 4, 0]}
            maxBarSize={28}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
