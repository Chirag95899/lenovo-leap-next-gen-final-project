import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { PaymentStats } from '../../../shared/types/analytics';

interface PaymentAnalyticsChartProps {
  data: PaymentStats;
}

export const PaymentAnalyticsChart: React.FC<PaymentAnalyticsChartProps> = ({ data }) => {
  if (!data) {
    return (
      <div className="h-64 flex items-center justify-center text-slate-500 text-sm">
        No payment transactions available.
      </div>
    );
  }

  const customTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border border-slate-200 p-3 rounded-lg shadow-lg text-xs space-y-1.5">
          <p className="font-semibold text-slate-900">{label}</p>
          <div className="flex items-center justify-between gap-4 text-emerald-700">
            <span>Disbursed:</span>
            <span className="font-mono font-medium">₹{payload[0]?.value?.toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between gap-4 text-slate-500">
            <span>Transactions:</span>
            <span className="font-mono font-medium">{payload[0]?.payload?.count}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full space-y-3">
      <div className="grid grid-cols-3 gap-2 px-1 text-center text-xs">
        <div className="bg-emerald-50 text-emerald-800 p-2 rounded-lg border border-emerald-100">
          <span className="text-[11px] text-emerald-600 block">Total Disbursed</span>
          <span className="font-semibold font-mono text-sm">₹{data.totalDisbursed.toLocaleString()}</span>
        </div>
        <div className="bg-amber-50 text-amber-800 p-2 rounded-lg border border-amber-100">
          <span className="text-[11px] text-amber-600 block">Pending Payouts</span>
          <span className="font-semibold font-mono text-sm">₹{data.totalPending.toLocaleString()}</span>
        </div>
        <div className="bg-purple-50 text-purple-800 p-2 rounded-lg border border-purple-100">
          <span className="text-[11px] text-purple-600 block">Disputed / On Hold</span>
          <span className="font-semibold font-mono text-sm">₹{data.totalDisputed.toLocaleString()}</span>
        </div>
      </div>

      <div className="w-full h-56">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data.history} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
            <XAxis dataKey="label" stroke="#94a3b8" tick={{ fontSize: 11 }} tickLine={false} />
            <YAxis
              stroke="#94a3b8"
              tick={{ fontSize: 11 }}
              tickLine={false}
              tickFormatter={(val) => `₹${val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val}`}
            />
            <Tooltip content={customTooltip} />
            <Bar
              dataKey="disbursedAmount"
              name="Disbursed (₹)"
              fill="#16A34A"
              radius={[4, 4, 0, 0]}
              maxBarSize={36}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
