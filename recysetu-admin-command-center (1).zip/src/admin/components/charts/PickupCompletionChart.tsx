import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { PickupCompletionStats } from '../../../shared/types/analytics';

interface PickupCompletionChartProps {
  data: PickupCompletionStats;
}

export const PickupCompletionChart: React.FC<PickupCompletionChartProps> = ({ data }) => {
  if (!data || !data.history || data.history.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-slate-500 text-sm">
        No pickup completion timeline available.
      </div>
    );
  }

  const customTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900 border border-slate-700/80 p-3 rounded-lg shadow-xl text-xs space-y-1.5 min-w-44">
          <p className="font-semibold text-slate-900 border-b border-slate-800 pb-1">{label}</p>
          <div className="flex items-center justify-between text-emerald-700">
            <span>Completed:</span>
            <span className="font-mono font-medium">{payload[0]?.value}</span>
          </div>
          <div className="flex items-center justify-between text-amber-400">
            <span>Pending/In-Transit:</span>
            <span className="font-mono font-medium">{payload[1]?.value}</span>
          </div>
          <div className="flex items-center justify-between text-rose-400">
            <span>Cancelled:</span>
            <span className="font-mono font-medium">{payload[2]?.value}</span>
          </div>
          <div className="flex items-center justify-between text-indigo-300 pt-1 border-t border-slate-800 font-semibold">
            <span>Completion Rate:</span>
            <span className="font-mono">{payload[3]?.value}%</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full space-y-3">
      <div className="grid grid-cols-3 gap-2 px-1 text-center text-xs">
        <div className="bg-emerald-50 text-emerald-800 p-2 rounded-lg border border-emerald-100">
          <span className="text-[11px] text-emerald-600 block">Completed</span>
          <span className="font-semibold font-mono text-sm">{data.completed}</span>
        </div>
        <div className="bg-amber-50 text-amber-800 p-2 rounded-lg border border-amber-100">
          <span className="text-[11px] text-amber-600 block">In Progress</span>
          <span className="font-semibold font-mono text-sm">{data.pending}</span>
        </div>
        <div className="bg-indigo-50 text-indigo-800 p-2 rounded-lg border border-indigo-100">
          <span className="text-[11px] text-indigo-600 block">Completion Rate</span>
          <span className="font-semibold font-mono text-sm">{data.completionRate}%</span>
        </div>
      </div>

      <div className="w-full h-64">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data.history} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis dataKey="label" stroke="#94a3b8" tick={{ fontSize: 11 }} tickLine={false} />
            <YAxis yAxisId="left" stroke="#94a3b8" tick={{ fontSize: 11 }} tickLine={false} />
            <YAxis
              yAxisId="right"
              orientation="right"
              domain={[0, 100]}
              stroke="#818cf8"
              tick={{ fontSize: 10 }}
              tickLine={false}
              tickFormatter={(v) => `${v}%`}
            />
            <Tooltip content={customTooltip} />
            <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: '8px', fontSize: '11px' }} />
            <Bar yAxisId="left" dataKey="completed" name="Completed" stackId="a" fill="#16A34A" />
            <Bar yAxisId="left" dataKey="pending" name="Pending" stackId="a" fill="#047857" />
            <Bar yAxisId="left" dataKey="cancelled" name="Cancelled" stackId="a" fill="#f43f5e" />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="completionRate"
              name="Rate %"
              stroke="#6366f1"
              strokeWidth={2.5}
              dot={{ r: 3, fill: '#6366f1' }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
