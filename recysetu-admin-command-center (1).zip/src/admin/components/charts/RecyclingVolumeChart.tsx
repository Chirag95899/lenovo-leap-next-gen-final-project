import React from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { RecyclingVolumePoint } from '../../../shared/types/analytics';

interface RecyclingVolumeChartProps {
  data: RecyclingVolumePoint[];
}

export const RecyclingVolumeChart: React.FC<RecyclingVolumeChartProps> = ({ data }) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-56 flex items-center justify-center text-slate-500 text-sm">
        No recycling volume recorded.
      </div>
    );
  }

  const customTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border border-slate-200 p-3 rounded-lg shadow-lg text-xs space-y-1.5">
          <p className="font-semibold text-slate-900">{label}</p>
          <div className="flex items-center justify-between gap-4 text-teal-400">
            <span>Processed Mass:</span>
            <span className="font-mono font-medium">{payload[0]?.value?.toLocaleString()} kg</span>
          </div>
          <div className="flex items-center justify-between gap-4 text-slate-500">
            <span>Processed Lots:</span>
            <span className="font-mono font-medium">{payload[0]?.payload?.lotsCount}</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-56">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="recycledAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.35} />
              <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
          <XAxis dataKey="label" stroke="#94a3b8" tick={{ fontSize: 11 }} tickLine={false} />
          <YAxis
            stroke="#94a3b8"
            tick={{ fontSize: 11 }}
            tickLine={false}
            tickFormatter={(val) => `${val >= 1000 ? `${(val / 1000).toFixed(0)}t` : `${val}kg`}`}
          />
          <Tooltip content={customTooltip} />
          <Area
            type="monotone"
            dataKey="volumeKg"
            name="Recycled (kg)"
            stroke="#06b6d4"
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#recycledAreaGrad)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
