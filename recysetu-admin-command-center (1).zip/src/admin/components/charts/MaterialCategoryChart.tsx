import React, { useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from 'recharts';
import { MaterialCategoryPoint } from '../../../shared/types/analytics';

interface MaterialCategoryChartProps {
  data: MaterialCategoryPoint[];
}

const MATERIAL_COLORS: Record<string, string> = {
  'PET-01': '#22c55e', // Blue
  'HDPE-01': '#86efac', // Emerald
  'ALU-01': '#15803d', // Amber
  'GLAS-01': '#16a34a', // Purple
  'CARD-01': '#14532d', // Lime
};

const DEFAULT_COLOR = '#64748b';

export const MaterialCategoryChart: React.FC<MaterialCategoryChartProps> = ({ data }) => {
  const [metric, setMetric] = useState<'volume' | 'value'>('volume');

  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-slate-500 text-sm">
        No material category data available.
      </div>
    );
  }

  const sortedData = [...data].sort((a, b) =>
    metric === 'volume'
      ? b.collectedKg - a.collectedKg
      : (b.totalValueInr || b.valueInr || 0) - (a.totalValueInr || a.valueInr || 0)
  );

  const customTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const item: MaterialCategoryPoint = payload[0].payload;
      const codeKey = item.code || item.categoryId || '';
      const name = item.materialName || item.categoryName || '';
      const val = item.totalValueInr ?? item.valueInr ?? 0;
      return (
        <div className="bg-white border border-slate-200 p-3 rounded-lg shadow-lg text-xs space-y-1.5 min-w-48">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-1.5">
            <span
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: MATERIAL_COLORS[codeKey] || DEFAULT_COLOR }}
            />
            <span className="font-semibold text-slate-900">
              {name} {codeKey ? `(${codeKey})` : ''}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-600">
            <span>Collected Volume:</span>
            <span className="font-mono font-medium text-emerald-700">{item.collectedKg.toLocaleString()} kg</span>
          </div>
          <div className="flex items-center justify-between text-slate-600">
            <span>Recycled Volume:</span>
            <span className="font-mono font-medium text-emerald-600">{item.recycledKg.toLocaleString()} kg</span>
          </div>
          <div className="flex items-center justify-between text-slate-600">
            <span>Economic Valuation:</span>
            <span className="font-mono font-medium text-emerald-800">₹{val.toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between text-slate-400 pt-1 border-t border-slate-100">
            <span>Volume Share:</span>
            <span className="font-mono font-medium">{item.percentage}%</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full space-y-3">
      <div className="flex items-center justify-end gap-1.5 text-xs">
        <span className="text-slate-500 font-medium mr-1">View By:</span>
        <button
          type="button"
          onClick={() => setMetric('volume')}
          className={`px-2.5 py-1 rounded font-medium transition-colors ${
            metric === 'volume'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Volume (kg)
        </button>
        <button
          type="button"
          onClick={() => setMetric('value')}
          className={`px-2.5 py-1 rounded font-medium transition-colors ${
            metric === 'value'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Value (₹)
        </button>
      </div>

      <div className="w-full h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={sortedData} margin={{ top: 10, right: 10, left: -10, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis
              dataKey="code"
              stroke="#94a3b8"
              tick={{ fontSize: 11 }}
              tickLine={false}
              interval={0}
            />
            <YAxis
              stroke="#94a3b8"
              tick={{ fontSize: 11 }}
              tickLine={false}
              tickFormatter={(val) =>
                metric === 'volume'
                  ? `${val >= 1000 ? `${(val / 1000).toFixed(0)}t` : `${val}k`}`
                  : `₹${val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val}`
              }
            />
            <Tooltip content={customTooltip} />
            <Bar
              dataKey={metric === 'volume' ? 'collectedKg' : 'valueInr'}
              radius={[4, 4, 0, 0]}
              maxBarSize={48}
            >
              {sortedData.map((entry) => (
                <Cell
                  key={`cell-${entry.materialId}`}
                  fill={MATERIAL_COLORS[entry.code] || DEFAULT_COLOR}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
