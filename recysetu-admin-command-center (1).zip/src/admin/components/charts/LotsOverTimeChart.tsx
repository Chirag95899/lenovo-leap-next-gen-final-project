import React from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { LotsOverTimePoint } from '../../../shared/types/analytics';

interface LotsOverTimeChartProps {
  data: LotsOverTimePoint[];
}

export const LotsOverTimeChart: React.FC<LotsOverTimeChartProps> = ({ data }) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-slate-500 text-sm">
        No lot creation data available for selected period.
      </div>
    );
  }

  const customTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900 border border-slate-700/80 p-3 rounded-lg shadow-xl text-xs space-y-1.5 min-w-44">
          <p className="font-semibold text-slate-900 border-b border-slate-800 pb-1">{label}</p>
          <div className="flex items-center justify-between text-emerald-700">
            <span>Aggregated:</span>
            <span className="font-mono font-medium">{payload[0]?.value?.toLocaleString()} kg</span>
          </div>
          <div className="flex items-center justify-between text-teal-400">
            <span>Recycled:</span>
            <span className="font-mono font-medium">{payload[1]?.value?.toLocaleString()} kg</span>
          </div>
          <div className="flex items-center justify-between text-slate-500 pt-1 border-t border-slate-800">
            <span>Lots Count:</span>
            <span className="font-mono font-medium">{payload[0]?.payload?.count} lots</span>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-72">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="aggregatedGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#16A34A" stopOpacity={0.4} />
              <stop offset="95%" stopColor="#16A34A" stopOpacity={0.0} />
            </linearGradient>
            <linearGradient id="recycledGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
              <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
          <XAxis
            dataKey="label"
            stroke="#94a3b8"
            tick={{ fontSize: 11 }}
            tickLine={false}
          />
          <YAxis
            stroke="#94a3b8"
            tick={{ fontSize: 11 }}
            tickLine={false}
            tickFormatter={(val) => `${val >= 1000 ? `${(val / 1000).toFixed(0)}t` : `${val}kg`}`}
          />
          <Tooltip content={customTooltip} />
          <Legend
            verticalAlign="top"
            align="right"
            iconType="circle"
            wrapperStyle={{ paddingBottom: '12px', fontSize: '12px' }}
          />
          <Area
            type="monotone"
            dataKey="aggregatedKg"
            name="Aggregated Mass (kg)"
            stroke="#16A34A"
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#aggregatedGrad)"
          />
          <Area
            type="monotone"
            dataKey="recycledKg"
            name="Processed Mass (kg)"
            stroke="#06b6d4"
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#recycledGrad)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
