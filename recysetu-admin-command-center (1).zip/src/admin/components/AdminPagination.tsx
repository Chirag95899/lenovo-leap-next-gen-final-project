import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface AdminPaginationProps {
  id?: string;
  currentPage: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
  onPageChange: (page: number) => void;
  onItemsPerPageChange?: (limit: number) => void;
  pageSizeOptions?: number[];
}

export const AdminPagination: React.FC<AdminPaginationProps> = ({
  id = 'admin-pagination',
  currentPage,
  totalPages,
  totalItems,
  itemsPerPage,
  onPageChange,
  onItemsPerPageChange,
  pageSizeOptions = [25, 50, 100],
}) => {
  if (totalItems === 0) return null;

  const startIdx = (currentPage - 1) * itemsPerPage + 1;
  const endIdx = Math.min(currentPage * itemsPerPage, totalItems);

  return (
    <div
      id={id}
      className="flex flex-col sm:flex-row items-center justify-between gap-4 px-4 py-3 bg-white border-t border-slate-200 text-sm text-slate-600"
    >
      <div className="flex items-center gap-4">
        <div>
          Showing <span className="font-medium text-slate-900">{startIdx}</span> to{' '}
          <span className="font-medium text-slate-900">{endIdx}</span> of{' '}
          <span className="font-medium text-slate-900">{totalItems}</span> results
        </div>

        {onItemsPerPageChange && (
          <div className="flex items-center gap-1.5 text-xs text-slate-500 border-l border-slate-200 pl-4">
            <span>Show:</span>
            <select
              id={`${id}-pagesize-select`}
              value={itemsPerPage}
              onChange={(e) => onItemsPerPageChange(Number(e.target.value))}
              aria-label="Records per page"
              className="px-2 py-1 bg-slate-50 border border-slate-200 rounded text-slate-800 font-medium text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-hidden"
            >
              {pageSizeOptions.map((size) => (
                <option key={size} value={size}>
                  {size} / page
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      <div className="flex items-center gap-2">
        <button
          id={`${id}-prev-btn`}
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage <= 1}
          className="inline-flex items-center gap-1 px-3 py-1.5 border border-slate-200 rounded-lg text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Previous</span>
        </button>

        <div className="px-3 py-1 text-xs font-semibold text-slate-700 bg-slate-100 rounded-md">
          Page {currentPage} of {Math.max(1, totalPages)}
        </div>

        <button
          id={`${id}-next-btn`}
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage >= totalPages}
          className="inline-flex items-center gap-1 px-3 py-1.5 border border-slate-200 rounded-lg text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
        >
          <span>Next</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
