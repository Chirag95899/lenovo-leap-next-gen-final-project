import React from 'react';
import { Filter, RotateCcw } from 'lucide-react';
import { FilterDefinition } from '../types/admin';

interface AdminFilterBarProps {
  id?: string;
  filters: FilterDefinition[];
  onFilterChange: (key: string, value: string) => void;
  onReset?: () => void;
  children?: React.ReactNode;
}

export const AdminFilterBar: React.FC<AdminFilterBarProps> = ({
  id = 'admin-filter-bar',
  filters,
  onFilterChange,
  onReset,
  children,
}) => {
  const hasActiveFilters = filters.some((f) => f.currentValue !== '');

  return (
    <div
      id={id}
      className="flex flex-wrap items-center gap-3 py-3 px-4 bg-slate-50/70 border-b border-slate-200"
    >
      <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 uppercase tracking-wider">
        <Filter className="w-3.5 h-3.5" />
        <span>Filters:</span>
      </div>

      {filters.map((filter) => (
        <div key={filter.key} className="flex items-center gap-1.5">
          <label htmlFor={`filter-${filter.key}`} className="text-xs font-medium text-slate-600">
            {filter.label}
          </label>
          <select
            id={`filter-${filter.key}`}
            value={filter.currentValue}
            onChange={(e) => onFilterChange(filter.key, e.target.value)}
            className="text-xs font-medium bg-white border border-slate-200 rounded-md px-2.5 py-1.5 text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 shadow-2xs"
          >
            {filter.options.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>
      ))}

      {hasActiveFilters && onReset && (
        <button
          type="button"
          onClick={onReset}
          className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors ml-auto"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset filters</span>
        </button>
      )}

      {children && <div className="ml-auto flex items-center gap-2">{children}</div>}
    </div>
  );
};
