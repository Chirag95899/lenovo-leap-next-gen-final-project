import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Copy, Check, Download, ShieldCheck, QrCode } from 'lucide-react';

interface AdminQrCodeViewProps {
  id?: string;
  value: string;
  title?: string;
  subtitle?: string;
  metadata?: {
    entityType: 'PICKUP' | 'LOT';
    identifier: string;
    material?: string;
    weightKg?: number;
    status?: string;
    createdAt?: string;
  };
  size?: number;
}

export const AdminQrCodeView: React.FC<AdminQrCodeViewProps> = ({
  id = 'admin-qr-code-view',
  value,
  title,
  subtitle,
  metadata,
  size = 200,
}) => {
  const [dataUrl, setDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    if (!value) return;

    QRCode.toDataURL(value, {
      width: size,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url) => {
        if (isMounted) {
          setDataUrl(url);
          setError(null);
        }
      })
      .catch((err) => {
        if (isMounted) {
          setError(err.message || 'Failed to render QR Code');
        }
      });

    return () => {
      isMounted = false;
    };
  }, [value, size]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
    }
  };

  const handleDownload = () => {
    if (!dataUrl) return;
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `RECYSETU_QR_${metadata?.identifier || 'CODE'}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div id={id} className="flex flex-col items-center text-center p-4 bg-white rounded-xl border border-slate-200 shadow-xs">
      {title && <h4 className="text-sm font-bold text-slate-900">{title}</h4>}
      {subtitle && <p className="text-xs text-slate-500 mb-3">{subtitle}</p>}

      <div className="relative p-3 bg-white rounded-xl border-2 border-slate-200 shadow-xs flex items-center justify-center">
        {dataUrl ? (
          <img
            src={dataUrl}
            alt={`QR Code for ${value}`}
            className="rounded"
            style={{ width: `${size}px`, height: `${size}px` }}
          />
        ) : error ? (
          <div className="w-48 h-48 flex items-center justify-center text-xs text-rose-500 p-4">
            {error}
          </div>
        ) : (
          <div className="w-48 h-48 flex items-center justify-center text-slate-400">
            <QrCode className="w-12 h-12 animate-pulse" />
          </div>
        )}
      </div>

      {/* Value Token Badge */}
      <div className="mt-3 flex items-center gap-2 max-w-full">
        <span className="font-mono text-xs font-semibold text-slate-800 bg-slate-100 px-3 py-1 rounded-md truncate border border-slate-200 max-w-[240px]">
          {value}
        </span>
        <button
          onClick={handleCopy}
          className="p-1.5 rounded-md hover:bg-slate-100 text-slate-600 transition-colors"
          title="Copy QR token to clipboard"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
        </button>
        {dataUrl && (
          <button
            onClick={handleDownload}
            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-600 transition-colors"
            title="Download QR code image"
          >
            <Download className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Cryptographic Trust Seal */}
      <div className="mt-3 flex items-center gap-1.5 text-[11px] text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-100">
        <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
        <span>Authentic RECYSETU Traceability Token • Read-Only Safe</span>
      </div>

      {metadata && (
        <div className="mt-3 w-full grid grid-cols-2 gap-2 text-[11px] text-left border-t border-slate-100 pt-2 text-slate-600">
          <div>
            <span className="text-slate-400 block">Type / ID:</span>
            <span className="font-semibold text-slate-900">{metadata.entityType}: {metadata.identifier}</span>
          </div>
          {metadata.material && (
            <div>
              <span className="text-slate-400 block">Material:</span>
              <span className="font-semibold text-slate-900">{metadata.material}</span>
            </div>
          )}
          {metadata.weightKg !== undefined && (
            <div>
              <span className="text-slate-400 block">Total Weight:</span>
              <span className="font-semibold text-slate-900">{metadata.weightKg} kg</span>
            </div>
          )}
          {metadata.status && (
            <div>
              <span className="text-slate-400 block">Status:</span>
              <span className="font-semibold text-emerald-700">{metadata.status}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
