import React, { useState } from 'react';
import { AggregatedLot, LotStatus } from '../../shared/types/domain';
import { AdminDrawer } from './AdminDrawer';
import { AdminStatusBadge } from './AdminStatusBadge';
import { AdminQrCodeView } from './AdminQrCodeView';
import { AdminTraceabilityTimelineView } from './AdminTraceabilityTimelineView';
import { formatDateTime, formatWeight, formatInr } from '../utils/formatters';
import { useLotDetailQuery } from '../hooks/useAdminDomainQueries';
import {
  Boxes,
  Building2,
  Factory,
  Scale,
  AlertTriangle,
  CheckCircle2,
  Users,
  Truck,
  Calendar,
  ShieldCheck,
  CreditCard,
  ExternalLink,
  RefreshCw,
  PlusCircle,
  FileCheck,
} from 'lucide-react';

interface AdminLotDetailDrawerProps {
  lotId: string | null;
  onClose: () => void;
  onNavigateToPickup?: (pickupId: string) => void;
}

export const AdminLotDetailDrawer: React.FC<AdminLotDetailDrawerProps> = ({
  lotId,
  onClose,
  onNavigateToPickup,
}) => {
  const {
    data,
    isLoading,
    error,
    refetch,
    reconcileWeight,
    addAuditEvent,
    updateStatus,
  } = useLotDetailQuery(lotId);

  const [actualWeightInput, setActualWeightInput] = useState<string>('');
  const [reconcileNotes, setReconcileNotes] = useState<string>('');
  const [isReconciling, setIsReconciling] = useState(false);
  const [reconcileSuccess, setReconcileSuccess] = useState<string | null>(null);
  const [reconcileError, setReconcileError] = useState<string | null>(null);

  const [newStatus, setNewStatus] = useState<LotStatus | ''>('');
  const [statusReason, setStatusReason] = useState('');
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [statusError, setStatusError] = useState<string | null>(null);

  const lot = data?.lot;
  const analysis = data?.weightAnalysis;

  const handleReconcileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!actualWeightInput) return;
    const weightNum = parseFloat(actualWeightInput);
    if (isNaN(weightNum) || weightNum <= 0) return;

    setIsReconciling(true);
    setReconcileError(null);
    setReconcileSuccess(null);
    try {
      await reconcileWeight(weightNum, reconcileNotes.trim() || undefined);
      setReconcileSuccess(`Intake weight successfully reconciled to ${weightNum} kg with cryptographic audit record created.`);
      setActualWeightInput('');
      setReconcileNotes('');
    } catch (err: any) {
      setReconcileError(err.message || 'Failed to reconcile lot weight');
    } finally {
      setIsReconciling(false);
    }
  };

  const handleStatusSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStatus || !statusReason.trim()) return;
    setIsUpdatingStatus(true);
    setStatusError(null);
    try {
      await updateStatus(newStatus, statusReason.trim());
      setNewStatus('');
      setStatusReason('');
    } catch (err: any) {
      setStatusError(err.message || 'Failed to update lot status');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  return (
    <AdminDrawer
      isOpen={!!lotId}
      onClose={onClose}
      title={lot ? `Aggregated Lot: ${lot.lotNumber}` : 'Lot Details'}
      subtitle={lot ? `ID: ${lot.id} • Formed ${formatDateTime(lot.createdAt)}` : 'Loading lot details...'}
      width="2xl"
    >
      {isLoading && (
        <div className="py-16 text-center space-y-3">
          <div className="w-8 h-8 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-500 font-medium">Fetching consolidated lot & intake data...</p>
        </div>
      )}

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
          <div className="font-bold mb-1">Failed to load lot records</div>
          <p>{error}</p>
          <button
            onClick={() => refetch()}
            className="mt-2 text-rose-800 underline font-semibold hover:text-rose-900"
          >
            Retry
          </button>
        </div>
      )}

      {lot && (
        <div className="space-y-6">
          {/* Header Card */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-white border border-slate-200 shadow-2xs text-purple-700">
                <Boxes className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] text-slate-400 block font-mono">LOT IDENTIFIER</span>
                <span className="text-base font-mono font-bold text-slate-900">{lot.lotNumber}</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-[11px] text-slate-400 block">CURRENT STATUS</span>
                <AdminStatusBadge status={lot.status} size="md" />
              </div>
            </div>
          </div>

          {/* WEIGHT DISCREPANCY & RECONCILIATION ENGINE */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Scale className="w-4 h-4 text-emerald-600" />
                Weight Verification & Discrepancy Ledger
              </h4>
              {analysis && (
                <span
                  className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                    analysis.isThresholdExceeded
                      ? 'bg-rose-50 text-rose-800 border-rose-200'
                      : analysis.actualWeightKg != null
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      : 'bg-amber-50 text-amber-800 border-amber-200'
                  }`}
                >
                  {analysis.isThresholdExceeded
                    ? `⚠️ Discrepancy Exceeded (${analysis.discrepancyPercent.toFixed(1)}%)`
                    : analysis.actualWeightKg != null
                    ? `✓ Weight Verified (${analysis.discrepancyPercent.toFixed(1)}%)`
                    : 'Pending Weighbridge Intake'}
                </span>
              )}
            </div>

            {/* Weight Comparison Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                  Aggregator Declared Weight
                </span>
                <span className="text-sm font-mono font-bold text-slate-900 mt-1 block">
                  {formatWeight(lot.declaredWeightKg || lot.totalWeightKg)}
                </span>
                <span className="text-[10px] text-slate-500">Recorded at dispatch</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">
                  Recycler Intake Weighment
                </span>
                <span className="text-sm font-mono font-bold text-emerald-700 mt-1 block">
                  {lot.actualWeightKg != null ? formatWeight(lot.actualWeightKg) : 'Awaiting Weighbridge'}
                </span>
                <span className="text-[10px] text-slate-500">Certified scale receipt</span>
              </div>

              <div
                className={`p-3 rounded-xl border ${
                  analysis?.isThresholdExceeded
                    ? 'bg-rose-50 border-rose-300 text-rose-900'
                    : 'bg-slate-50 border-slate-200 text-slate-900'
                }`}
              >
                <span className="text-[10px] uppercase font-semibold block opacity-80">
                  Variance / Discrepancy
                </span>
                <span className="text-sm font-mono font-bold mt-1 block">
                  {analysis?.discrepancyKg != null ? `${analysis.discrepancyKg > 0 ? '+' : ''}${analysis.discrepancyKg.toFixed(1)} kg` : '0 kg'}
                  {analysis?.discrepancyPercent != null && (
                    <span className="text-xs font-normal ml-1">
                      ({analysis.discrepancyPercent.toFixed(1)}%)
                    </span>
                  )}
                </span>
                <span className="text-[10px] opacity-75">
                  Threshold limit: {analysis?.thresholdPercent || 5.0}%
                </span>
              </div>
            </div>

            {/* Threshold Exceeded Warning Banner */}
            {analysis?.isThresholdExceeded && (
              <div className="p-3 bg-rose-50 rounded-xl border border-rose-300 text-rose-900 text-xs flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <span className="font-bold block">
                    Critical Weight Discrepancy Flagged
                  </span>
                  <p className="text-[11px] leading-relaxed text-rose-800">
                    The difference between the aggregator&apos;s declared weight ({lot.declaredWeightKg} kg) and the recycler&apos;s verified weighbridge intake ({lot.actualWeightKg} kg) is {analysis.discrepancyPercent.toFixed(1)}%, which exceeds the standard {analysis.thresholdPercent}% discrepancy threshold.
                  </p>
                </div>
              </div>
            )}

            {/* Admin Weight Reconciliation Form */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-3">
              <span className="font-bold text-slate-900 block flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Audit / Reconcile Weighbridge Intake Weight
              </span>

              {reconcileSuccess && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{reconcileSuccess}</span>
                </div>
              )}

              {reconcileError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-xs">
                  {reconcileError}
                </div>
              )}

              <form onSubmit={handleReconcileSubmit} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Verified Weight (kg) <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      min="1"
                      value={actualWeightInput}
                      onChange={(e) => setActualWeightInput(e.target.value)}
                      placeholder={`Current declared: ${lot.declaredWeightKg || lot.totalWeightKg} kg`}
                      required
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-900 bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Weighbridge Receipt / Audit Justification
                    </label>
                    <input
                      type="text"
                      value={reconcileNotes}
                      onChange={(e) => setReconcileNotes(e.target.value)}
                      placeholder="e.g. Weighbridge slip #WB-9941 at plant intake"
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-900 bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isReconciling || !actualWeightInput}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-lg transition-colors shadow-2xs disabled:opacity-50 flex items-center gap-1.5"
                  >
                    {isReconciling ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        Reconciling...
                      </>
                    ) : (
                      'Save Verified Weight & Append Audit Event'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Facility & Logistics Stakeholders */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
              Aggregator & Destination Recycler
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-1">
                <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-semibold uppercase">
                  <Building2 className="w-3.5 h-3.5 text-blue-600" />
                  Origin Aggregator Depot
                </div>
                <div className="font-bold text-slate-900 text-sm">{lot.aggregatorName}</div>
                <div className="text-[11px] text-slate-500 font-mono">Depot ID: {lot.aggregatorId}</div>
                <div className="text-[11px] text-slate-400 mt-1">
                  Created: {formatDateTime(lot.createdAt)}
                </div>
              </div>

              <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-1">
                <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-semibold uppercase">
                  <Factory className="w-3.5 h-3.5 text-purple-600" />
                  Destination Processing Facility
                </div>
                <div className="font-bold text-slate-900 text-sm">{lot.recyclerName}</div>
                <div className="text-[11px] text-slate-500 font-mono">Recycler ID: {lot.recyclerId}</div>
                <div className="text-[11px] text-slate-400 mt-1">
                  Dispatched: {lot.dispatchedAt ? formatDateTime(lot.dispatchedAt) : 'Pending Dispatch'}
                </div>
              </div>
            </div>
          </div>

          {/* Contributing Collectors Breakdown */}
          {data?.contributingCollectors && data.contributingCollectors.length > 0 && (
            <div>
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-600" />
                Contributing Informal Collectors ({data.contributingCollectors.length})
              </h4>
              <p className="text-[11px] text-slate-500 mb-2">
                Fair-share attribution calculated from individual pickup records aggregated into this lot.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {data.contributingCollectors.map((c) => (
                  <div
                    key={c.collectorId}
                    className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-900 block">{c.collectorName}</span>
                      <span className="text-[11px] text-slate-400 font-mono">ID: {c.collectorId} • {c.pickupCount} pickup{c.pickupCount !== 1 ? 's' : ''}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-bold text-emerald-700 block">{c.totalKg} kg</span>
                      <span className="text-[10px] text-slate-500 font-semibold bg-slate-100 px-1.5 py-0.5 rounded">
                        {c.percentageOfLot.toFixed(1)}% of lot
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Contributing Pickups List */}
          {data?.pickups && data.pickups.length > 0 && (
            <div>
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-emerald-600" />
                Aggregated Pickups ({data.pickups.length})
              </h4>
              <div className="space-y-2">
                {data.pickups.map((p) => (
                  <div
                    key={p.id}
                    className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-2 text-xs hover:border-slate-300 transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-emerald-700">{p.trackingCode}</span>
                        <AdminStatusBadge status={p.status} size="sm" />
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Collector: <strong>{p.collectorName}</strong> • {p.materialName}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <span className="font-bold text-slate-900 block">{formatWeight(p.quantityKg)}</span>
                        <span className="font-mono text-[11px] text-slate-500">{formatInr(p.totalPrice)}</span>
                      </div>
                      {onNavigateToPickup && (
                        <button
                          type="button"
                          onClick={() => onNavigateToPickup(p.id)}
                          className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-slate-900"
                          title="View Pickup Details"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Payments & Financial Settlement */}
          {data?.payments && data.payments.length > 0 && (
            <div>
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-emerald-600" />
                Disbursement & Settlement Records
              </h4>
              <div className="space-y-2">
                {data.payments.map((pm) => (
                  <div
                    key={pm.id}
                    className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-2 text-xs"
                  >
                    <div>
                      <span className="font-mono font-bold text-slate-900 block">{pm.id}</span>
                      <span className="text-[11px] text-slate-500">
                        {pm.paymentMethod} • {formatDateTime(pm.timestamp)}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-mono font-bold text-slate-900 text-sm">
                        {formatInr(pm.amount)}
                      </span>
                      <AdminStatusBadge status={pm.status} size="sm" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Cryptographic QR Batch Tag */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              Cryptographic Batch Verification Tag
            </h4>
            <AdminQrCodeView
              value={lot.batchQrCode || `RECYSETU:LOT:${lot.id}:${lot.lotNumber}`}
              title={`Batch Tag: ${lot.lotNumber}`}
              subtitle="Tamper-evident verification tag scannable by Aggregators and Recyclers"
              metadata={{
                entityType: 'LOT',
                identifier: lot.lotNumber,
                material: `${lot.materialName} (${lot.qualityGrade})`,
                weightKg: lot.actualWeightKg != null ? lot.actualWeightKg : lot.totalWeightKg,
                status: lot.status,
              }}
              size={180}
            />
          </div>

          {/* Full Traceability Journey */}
          <AdminTraceabilityTimelineView
            events={data?.traceabilityTimeline || []}
            title="Complete Custodial Journey & Industrial Audit Log"
            subtitle="Full lifecycle history from collection to aggregator sorting, weighbridge, and recycling"
            allowAddCorrection={true}
            onAddCorrection={async (correctionData) => {
              await addAuditEvent(correctionData);
            }}
          />

          {/* Authorized Admin Status Override */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Authorized Status Transition
            </h4>
            <p className="text-[11px] text-slate-500">
              Admin transitions adhere strictly to platform business rules and automatically generate an immutable audit log entry.
            </p>

            {statusError && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg">
                {statusError}
              </div>
            )}

            <form onSubmit={handleStatusSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Target Status</label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as LotStatus)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="">Select Target Status...</option>
                    <option value="CREATED">CREATED</option>
                    <option value="READY_FOR_PICKUP">READY_FOR_PICKUP</option>
                    <option value="IN_TRANSIT">IN_TRANSIT</option>
                    <option value="DELIVERED">DELIVERED</option>
                    <option value="ACCEPTED">ACCEPTED</option>
                    <option value="REJECTED">REJECTED</option>
                    <option value="PROCESSING">PROCESSING</option>
                    <option value="COMPLETED">COMPLETED</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Authorization Reason / Justification <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={statusReason}
                    onChange={(e) => setStatusReason(e.target.value)}
                    placeholder="e.g. Weighbridge verification complete, cleared for processing"
                    required
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isUpdatingStatus || !newStatus || !statusReason.trim()}
                  className="px-4 py-2 rounded-lg bg-emerald-600 text-white font-semibold text-xs hover:bg-emerald-700 shadow-2xs disabled:opacity-50 transition-colors flex items-center gap-1.5"
                >
                  {isUpdatingStatus ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      Updating Status...
                    </>
                  ) : (
                    'Execute Status Transition'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminDrawer>
  );
};
