import React from 'react';

interface AdminStatusBadgeProps {
  id?: string;
  status: string;
  variant?: 'auto' | 'success' | 'warning' | 'danger' | 'info' | 'neutral';
  size?: 'sm' | 'md';
}

export const AdminStatusBadge: React.FC<AdminStatusBadgeProps> = ({
  id,
  status,
  variant = 'auto',
  size = 'md',
}) => {
  const normalized = status.toUpperCase();

  let resolvedVariant = variant;
  if (variant === 'auto') {
    if (
      ['ACTIVE', 'COMPLETED', 'PROCESSED', 'DELIVERED', 'RESOLVED', 'GRADE_A'].includes(
        normalized
      )
    ) {
      resolvedVariant = 'success';
    } else if (
      [
        'PENDING',
        'PENDING_VERIFICATION',
        'IN_TRANSIT',
        'UNDER_REVIEW',
        'ASSIGNED',
        'AGGREGATED',
        'GRADE_B',
        'MEDIUM',
      ].includes(normalized)
    ) {
      resolvedVariant = 'warning';
    } else if (
      [
        'SUSPENDED',
        'CANCELLED',
        'REJECTED',
        'FLAGGED',
        'FAILED',
        'CRITICAL',
        'HIGH',
      ].includes(normalized)
    ) {
      resolvedVariant = 'danger';
    } else if (['REQUESTED', 'COLLECTED', 'FORMED', 'OPEN', 'IN_INVESTIGATION', 'LOW'].includes(normalized)) {
      resolvedVariant = 'info';
    } else {
      resolvedVariant = 'neutral';
    }
  }

  const styles = {
    success: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    warning: 'bg-amber-50 text-amber-700 border-amber-200',
    danger: 'bg-rose-50 text-rose-700 border-rose-200',
    info: 'bg-sky-50 text-sky-700 border-sky-200',
    neutral: 'bg-slate-100 text-slate-700 border-slate-200',
  };

  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs';

  return (
    <span
      id={id}
      className={`inline-flex items-center font-medium border rounded-full whitespace-nowrap ${styles[resolvedVariant]} ${sizeClasses}`}
    >
      <span
        className={`w-1.5 h-1.5 rounded-full mr-1.5 ${
          resolvedVariant === 'success'
            ? 'bg-emerald-500'
            : resolvedVariant === 'warning'
            ? 'bg-amber-500'
            : resolvedVariant === 'danger'
            ? 'bg-rose-500'
            : resolvedVariant === 'info'
            ? 'bg-sky-500'
            : 'bg-slate-400'
        }`}
      />
      {status.replace(/_/g, ' ')}
    </span>
  );
};
