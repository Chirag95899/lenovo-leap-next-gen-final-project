import { useState, useEffect, useCallback } from 'react';
import { adminApi } from '../services/adminApiService';
import { User } from '../../shared/types/domain';

export function useAdminAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Verify session on mount
  const checkSession = useCallback(async () => {
    const existingToken = adminApi.getToken();
    if (!existingToken) {
      setUser(null);
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      const res = await adminApi.getMe();
      if (res.user && res.user.role === 'ADMIN') {
        setUser(res.user);
      } else {
        adminApi.setToken(null);
        setUser(null);
        setError('Unauthorized role: Account is not recognized as Admin.');
      }
    } catch (err: any) {
      adminApi.setToken(null);
      setUser(null);
      setError(err.message || 'Session verification failed');
    } finally {
      setIsLoading(false);
    }
  }, []);


  useEffect(() => {
    checkSession();
  }, [checkSession]);

  useEffect(() => {
    const handleExpired = () => {
      adminApi.setToken(null);
      setUser(null);
      setError('Admin session has expired. Please log in again.');
    };
    window.addEventListener('admin-auth-expired', handleExpired);
    return () => window.removeEventListener('admin-auth-expired', handleExpired);
  }, []);


  const login = async (adminId: string, pass: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.login(adminId, pass);
      setUser(res.user);
      return res.user;
    } catch (err: any) {
      setError(err.message || 'Failed to authenticate');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await adminApi.logout();
    } catch {
      // ignore
    } finally {
      setUser(null);
      adminApi.setToken(null);
    }
  };

  return {
    user,
    isAuthenticated: !!user && user.role === 'ADMIN',
    isLoading,
    error,
    login,
    logout,
    checkSession,
  };
}
