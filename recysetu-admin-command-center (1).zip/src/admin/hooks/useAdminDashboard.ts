import { useState, useEffect, useCallback } from 'react';
import { adminApi } from '../services/adminApiService';
import { DashboardDateRange, DashboardResponseData } from '../types/dashboard';

export function useAdminDashboard(initialRange: DashboardDateRange = '7d') {
  const [data, setData] = useState<DashboardResponseData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [dateRange, setDateRange] = useState<DashboardDateRange>(initialRange);
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');
  const [autoRefresh, setAutoRefresh] = useState<boolean>(false);

  const fetchStats = useCallback(
    async (isManualRefresh = false) => {
      try {
        if (isManualRefresh) {
          setIsRefreshing(true);
        } else if (!data) {
          setIsLoading(true);
        }
        setError(null);
        const res = await adminApi.getDashboardStats({
          range: dateRange,
          startDate: dateRange === 'custom' ? customStartDate : undefined,
          endDate: dateRange === 'custom' ? customEndDate : undefined,
        });
        setData(res);
        setLastUpdated(new Date());
      } catch (err: any) {
        setError(err.message || 'Failed to load dashboard metrics');
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    },
    [dateRange, customStartDate, customEndDate, data]
  );

  useEffect(() => {
    fetchStats(false);
  }, [dateRange, customStartDate, customEndDate]);

  // Optional auto-refresh interval
  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      fetchStats(true);
    }, 60000); // 1 minute interval
    return () => clearInterval(interval);
  }, [autoRefresh, fetchStats]);

  const refresh = useCallback(() => {
    return fetchStats(true);
  }, [fetchStats]);

  const setCustomRange = useCallback((start: string, end: string) => {
    setCustomStartDate(start);
    setCustomEndDate(end);
    setDateRange('custom');
  }, []);

  return {
    data,
    isLoading,
    isRefreshing,
    error,
    lastUpdated,
    dateRange,
    setDateRange,
    customStartDate,
    customEndDate,
    setCustomRange,
    autoRefresh,
    setAutoRefresh,
    refetch: refresh,
    refresh,
  };
}
