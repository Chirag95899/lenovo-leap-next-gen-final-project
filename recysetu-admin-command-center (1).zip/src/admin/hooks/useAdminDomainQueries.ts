import { useState, useEffect, useCallback } from 'react';
import { adminApi } from '../services/adminApiService';
import {
  User,
  PickupRequest,
  AggregatedLot,
  TraceabilityEvent,
  PaymentRecord,
  Complaint,
  AnomalyRecord,
  AuditLog,
  PaginatedResult,
} from '../../shared/types/domain';
import { AppConfiguration } from '../../shared/types/config';

// 1. Users Query
export function useUsersQuery(initialRole?: string) {
  const [limit, setLimit] = useState(25);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [role, setRole] = useState(initialRole || '');
  const [status, setStatus] = useState('');
  const [verificationStatus, setVerificationStatus] = useState('');
  const [location, setLocation] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [result, setResult] = useState<PaginatedResult<User>>({
    data: [],
    total: 0,
    page: 1,
    limit: 25,
    totalPages: 1,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchUsers = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getUsers({
        page,
        limit,
        search,
        role: role || undefined,
        status: status || undefined,
        verificationStatus: verificationStatus || undefined,
        location: location || undefined,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
      });
      setResult(res);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch users');
    } finally {
      setIsLoading(false);
    }
  }, [page, limit, search, role, status, verificationStatus, location, startDate, endDate]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  // Reset to page 1 when search or filters change
  const handleSearchChange = (val: string) => {
    setSearch(val);
    setPage(1);
  };
  const handleRoleChange = (val: string) => {
    setRole(val);
    setPage(1);
  };
  const handleStatusChange = (val: string) => {
    setStatus(val);
    setPage(1);
  };
  const handleVerificationStatusChange = (val: string) => {
    setVerificationStatus(val);
    setPage(1);
  };
  const handleLocationChange = (val: string) => {
    setLocation(val);
    setPage(1);
  };
  const handleLimitChange = (val: number) => {
    setLimit(val);
    setPage(1);
  };

  const verifyRecycler = async (id: string, reason?: string) => {
    await adminApi.verifyRecycler(id, reason);
    await fetchUsers();
  };

  const rejectRecycler = async (id: string, reason: string) => {
    await adminApi.rejectRecycler(id, reason);
    await fetchUsers();
  };

  const suspendUser = async (id: string, reason: string) => {
    await adminApi.suspendUser(id, reason);
    await fetchUsers();
  };

  const reactivateUser = async (id: string, reason?: string) => {
    await adminApi.reactivateUser(id, reason);
    await fetchUsers();
  };

  const verifyKyc = async (id: string, reason?: string) => {
    await adminApi.verifyKyc(id, reason);
    await fetchUsers();
  };

  const changeUserRole = async (id: string, newRole: User['role'], reason: string) => {
    await adminApi.changeUserRole(id, newRole, reason);
    await fetchUsers();
  };

  const updateUserStatus = async (id: string, newStatus: User['status'], kyc?: boolean) => {
    await adminApi.updateUserStatus(id, newStatus, kyc);
    await fetchUsers();
  };

  return {
    users: result.data,
    total: result.total,
    page,
    limit,
    setLimit: handleLimitChange,
    totalPages: result.totalPages,
    setPage,
    search,
    setSearch: handleSearchChange,
    role,
    setRole: handleRoleChange,
    status,
    setStatus: handleStatusChange,
    verificationStatus,
    setVerificationStatus: handleVerificationStatusChange,
    location,
    setLocation: handleLocationChange,
    startDate,
    setStartDate,
    endDate,
    setEndDate,
    isLoading,
    error,
    refetch: fetchUsers,
    verifyRecycler,
    rejectRecycler,
    suspendUser,
    reactivateUser,
    verifyKyc,
    changeUserRole,
    updateUserStatus,
  };
}

// User Detail Query hook
export function useUserDetailQuery(userId?: string | null) {
  const [data, setData] = useState<import('../services/adminApiService').UserDetailResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDetail = useCallback(async () => {
    if (!userId) {
      setData(null);
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getUserDetail(userId);
      setData(res);
    } catch (err: any) {
      setError(err.message || 'Failed to load user details');
    } finally {
      setIsLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    fetchDetail();
  }, [fetchDetail]);

  return { data, isLoading, error, refetch: fetchDetail };
}

// 2. Pickups Query
export function usePickupsQuery() {
  const [result, setResult] = useState<PaginatedResult<PickupRequest>>({
    data: [],
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 1,
  });
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [category, setCategory] = useState('');
  const [collectorId, setCollectorId] = useState('');
  const [aggregatorId, setAggregatorId] = useState('');
  const [recyclerId, setRecyclerId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPickups = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getPickups({
        page,
        limit: 10,
        search,
        status,
        category,
        collectorId: collectorId || undefined,
        aggregatorId: aggregatorId || undefined,
        recyclerId: recyclerId || undefined,
      });
      setResult(res);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch pickups');
    } finally {
      setIsLoading(false);
    }
  }, [page, search, status, category, collectorId, aggregatorId, recyclerId]);

  useEffect(() => {
    fetchPickups();
  }, [fetchPickups]);

  const updateStatus = async (id: string, newStatus: PickupRequest['status'], reason?: string) => {
    await adminApi.updatePickupStatus(id, newStatus, reason);
    await fetchPickups();
  };

  const addAuditEvent = async (
    id: string,
    data: { eventType?: string; notes?: string; weightKg?: number; location?: string; details?: Record<string, any> }
  ) => {
    await adminApi.addPickupAuditEvent(id, data);
    await fetchPickups();
  };

  return {
    pickups: result.data,
    total: result.total,
    page,
    totalPages: result.totalPages,
    setPage,
    search,
    setSearch: (s: string) => {
      setSearch(s);
      setPage(1);
    },
    status,
    setStatus: (st: string) => {
      setStatus(st);
      setPage(1);
    },
    category,
    setCategory: (c: string) => {
      setCategory(c);
      setPage(1);
    },
    collectorId,
    setCollectorId: (id: string) => {
      setCollectorId(id);
      setPage(1);
    },
    aggregatorId,
    setAggregatorId: (id: string) => {
      setAggregatorId(id);
      setPage(1);
    },
    recyclerId,
    setRecyclerId: (id: string) => {
      setRecyclerId(id);
      setPage(1);
    },
    isLoading,
    error,
    refetch: fetchPickups,
    updateStatus,
    addAuditEvent,
  };
}

// Pickup Detail Hook
export function usePickupDetailQuery(pickupId?: string | null) {
  const [data, setData] = useState<{
    pickup: PickupRequest;
    collector: Partial<User> | null;
    aggregator: Partial<User> | null;
    recycler: Partial<User> | null;
    associatedLot: AggregatedLot | null;
    associatedPayments: PaymentRecord[];
    traceabilityEvents: TraceabilityEvent[];
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDetail = useCallback(async () => {
    if (!pickupId) {
      setData(null);
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getPickupDetail(pickupId);
      setData(res);
    } catch (err: any) {
      setError(err.message || 'Failed to load pickup details');
    } finally {
      setIsLoading(false);
    }
  }, [pickupId]);

  useEffect(() => {
    fetchDetail();
  }, [fetchDetail]);

  const addAuditEvent = async (eventData: {
    eventType?: string;
    notes?: string;
    weightKg?: number;
    location?: string;
    details?: Record<string, any>;
  }) => {
    if (!pickupId) return;
    await adminApi.addPickupAuditEvent(pickupId, eventData);
    await fetchDetail();
  };

  const updateStatus = async (status: PickupRequest['status'], reason?: string) => {
    if (!pickupId) return;
    await adminApi.updatePickupStatus(pickupId, status, reason);
    await fetchDetail();
  };

  return {
    data,
    isLoading,
    error,
    refetch: fetchDetail,
    addAuditEvent,
    updateStatus,
  };
}

// 3. Lots Query
export function useLotsQuery() {
  const [result, setResult] = useState<PaginatedResult<AggregatedLot>>({
    data: [],
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 1,
  });
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [category, setCategory] = useState('');
  const [hasDiscrepancy, setHasDiscrepancy] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchLots = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getLots({
        page,
        limit: 10,
        search,
        status,
        category,
        hasDiscrepancy: hasDiscrepancy || undefined,
      });
      setResult(res);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch lots');
    } finally {
      setIsLoading(false);
    }
  }, [page, search, status, category, hasDiscrepancy]);

  useEffect(() => {
    fetchLots();
  }, [fetchLots]);

  const updateLotStatus = async (id: string, newStatus: AggregatedLot['status'], reason?: string) => {
    await adminApi.updateLotStatus(id, newStatus, reason);
    await fetchLots();
  };

  const reconcileWeight = async (id: string, actualWeightKg: number, notes?: string) => {
    const res = await adminApi.reconcileLotWeight(id, actualWeightKg, notes);
    await fetchLots();
    return res;
  };

  return {
    lots: result.data,
    total: result.total,
    page,
    totalPages: result.totalPages,
    setPage,
    search,
    setSearch: (s: string) => {
      setSearch(s);
      setPage(1);
    },
    status,
    setStatus: (st: string) => {
      setStatus(st);
      setPage(1);
    },
    category,
    setCategory: (c: string) => {
      setCategory(c);
      setPage(1);
    },
    hasDiscrepancy,
    setHasDiscrepancy: (hd: boolean) => {
      setHasDiscrepancy(hd);
      setPage(1);
    },
    isLoading,
    error,
    refetch: fetchLots,
    updateLotStatus,
    reconcileWeight,
  };
}

// Lot Detail Hook
export function useLotDetailQuery(lotId?: string | null) {
  const [data, setData] = useState<{
    lot: AggregatedLot;
    pickups: PickupRequest[];
    contributingCollectors: Array<{
      collectorId: string;
      collectorName: string;
      totalKg: number;
      percentageOfLot: number;
      pickupCount: number;
    }>;
    weightAnalysis: {
      declaredWeightKg: number;
      actualWeightKg: number | null;
      discrepancyKg: number;
      discrepancyPercent: number;
      thresholdPercent: number;
      isThresholdExceeded: boolean;
      status: 'NORMAL' | 'WITHIN_TOLERANCE' | 'THRESHOLD_EXCEEDED' | 'PENDING_WEIGHMENT';
      notes?: string;
    };
    payments: PaymentRecord[];
    traceabilityTimeline: TraceabilityEvent[];
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDetail = useCallback(async () => {
    if (!lotId) {
      setData(null);
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getLotDetail(lotId);
      setData(res);
    } catch (err: any) {
      setError(err.message || 'Failed to load lot details');
    } finally {
      setIsLoading(false);
    }
  }, [lotId]);

  useEffect(() => {
    fetchDetail();
  }, [fetchDetail]);

  const reconcileWeight = async (actualWeightKg: number, notes?: string) => {
    if (!lotId) return null;
    const res = await adminApi.reconcileLotWeight(lotId, actualWeightKg, notes);
    await fetchDetail();
    return res;
  };

  const addAuditEvent = async (eventData: {
    eventType?: string;
    notes?: string;
    weightKg?: number;
    location?: string;
    details?: Record<string, any>;
  }) => {
    if (!lotId) return;
    await adminApi.addLotAuditEvent(lotId, eventData);
    await fetchDetail();
  };

  const updateStatus = async (status: AggregatedLot['status'], reason?: string) => {
    if (!lotId) return;
    await adminApi.updateLotStatus(lotId, status, reason);
    await fetchDetail();
  };

  return {
    data,
    isLoading,
    error,
    refetch: fetchDetail,
    reconcileWeight,
    addAuditEvent,
    updateStatus,
  };
}

// 4. Traceability Query
export function useTraceabilityQuery() {
  const [result, setResult] = useState<PaginatedResult<TraceabilityEvent>>({
    data: [],
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 1,
  });
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [entityType, setEntityType] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchTraceability = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getTraceability({ page, limit: 10, search, entityType });
      setResult(res);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch traceability log');
    } finally {
      setIsLoading(false);
    }
  }, [page, search, entityType]);

  useEffect(() => {
    fetchTraceability();
  }, [fetchTraceability]);

  return {
    events: result.data,
    total: result.total,
    page,
    totalPages: result.totalPages,
    setPage,
    search,
    setSearch,
    entityType,
    setEntityType,
    isLoading,
    error,
    refetch: fetchTraceability,
  };
}

// 5. Payments Query
export function usePaymentsQuery() {
  const [result, setResult] = useState<PaginatedResult<PaymentRecord>>({
    data: [],
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 1,
  });
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [minAmount, setMinAmount] = useState<number | undefined>(undefined);
  const [maxAmount, setMaxAmount] = useState<number | undefined>(undefined);
  const [disputedOnly, setDisputedOnly] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPayments = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getPayments({
        page,
        limit: 10,
        search,
        status,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
        minAmount,
        maxAmount,
        disputedOnly: disputedOnly || undefined,
        paymentMethod: paymentMethod || undefined,
      });
      setResult(res);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch payments');
    } finally {
      setIsLoading(false);
    }
  }, [page, search, status, startDate, endDate, minAmount, maxAmount, disputedOnly, paymentMethod]);

  useEffect(() => {
    fetchPayments();
  }, [fetchPayments]);

  const flagPayment = async (id: string, flag: boolean, reason?: string) => {
    await adminApi.flagPayment(id, flag, reason);
    await fetchPayments();
  };

  const resolveDispute = async (
    id: string,
    action: 'HOLD_ESCROW' | 'RELEASE_PAYOUT' | 'REFUND_PAYER' | 'ARBITRATE' | 'CLEAR_FLAG',
    reason: string
  ) => {
    const res = await adminApi.resolvePaymentDispute(id, action, reason);
    await fetchPayments();
    return res;
  };

  return {
    payments: result.data,
    total: result.total,
    page,
    totalPages: result.totalPages,
    setPage,
    search,
    setSearch: (s: string) => {
      setSearch(s);
      setPage(1);
    },
    status,
    setStatus: (st: string) => {
      setStatus(st);
      setPage(1);
    },
    startDate,
    setStartDate: (d: string) => {
      setStartDate(d);
      setPage(1);
    },
    endDate,
    setEndDate: (d: string) => {
      setEndDate(d);
      setPage(1);
    },
    minAmount,
    setMinAmount: (n?: number) => {
      setMinAmount(n);
      setPage(1);
    },
    maxAmount,
    setMaxAmount: (n?: number) => {
      setMaxAmount(n);
      setPage(1);
    },
    disputedOnly,
    setDisputedOnly: (d: boolean) => {
      setDisputedOnly(d);
      setPage(1);
    },
    paymentMethod,
    setPaymentMethod: (m: string) => {
      setPaymentMethod(m);
      setPage(1);
    },
    isLoading,
    error,
    refetch: fetchPayments,
    flagPayment,
    resolveDispute,
  };
}

// 6. Complaints Query
export function useComplaintsQuery() {
  const [result, setResult] = useState<PaginatedResult<Complaint>>({
    data: [],
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 1,
  });
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [category, setCategory] = useState('');
  const [priority, setPriority] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchComplaints = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getComplaints({
        page,
        limit: 10,
        search,
        status,
        category: category || undefined,
        priority: priority || undefined,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
      });
      setResult(res);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch complaints');
    } finally {
      setIsLoading(false);
    }
  }, [page, search, status, category, priority, startDate, endDate]);

  useEffect(() => {
    fetchComplaints();
  }, [fetchComplaints]);

  const resolveComplaint = async (id: string, newStatus: Complaint['status'], notes?: string) => {
    await adminApi.resolveComplaint(id, newStatus, notes);
    await fetchComplaints();
  };

  const resolveComplaintAction = async (
    id: string,
    action: 'RESOLVE' | 'REJECT' | 'ESCALATE_REVIEW' | 'FLAG_INVESTIGATION',
    notes: string
  ) => {
    const res = await adminApi.resolveComplaintAction(id, action, notes);
    await fetchComplaints();
    return res;
  };

  const addComplaintResponse = async (id: string, message: string, isInternal?: boolean) => {
    const res = await adminApi.addComplaintResponse(id, message, isInternal);
    await fetchComplaints();
    return res;
  };

  return {
    complaints: result.data,
    total: result.total,
    page,
    totalPages: result.totalPages,
    setPage,
    search,
    setSearch: (s: string) => {
      setSearch(s);
      setPage(1);
    },
    status,
    setStatus: (st: string) => {
      setStatus(st);
      setPage(1);
    },
    category,
    setCategory: (c: string) => {
      setCategory(c);
      setPage(1);
    },
    priority,
    setPriority: (p: string) => {
      setPriority(p);
      setPage(1);
    },
    startDate,
    setStartDate: (d: string) => {
      setStartDate(d);
      setPage(1);
    },
    endDate,
    setEndDate: (d: string) => {
      setEndDate(d);
      setPage(1);
    },
    isLoading,
    error,
    refetch: fetchComplaints,
    resolveComplaint,
    resolveComplaintAction,
    addComplaintResponse,
  };
}

// 7. Anomalies Query
export function useAnomaliesQuery() {
  const [result, setResult] = useState<PaginatedResult<AnomalyRecord>>({
    data: [],
    total: 0,
    page: 1,
    limit: 10,
    totalPages: 1,
  });
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [severity, setSeverity] = useState('');
  const [status, setStatus] = useState('');
  const [entityType, setEntityType] = useState('');
  const [ruleKey, setRuleKey] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchAnomalies = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getAnomalies({
        page,
        limit: 10,
        search,
        severity,
        status,
        entityType,
        ruleKey,
      });
      setResult(res);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch anomalies');
    } finally {
      setIsLoading(false);
    }
  }, [page, search, severity, status, entityType, ruleKey]);

  useEffect(() => {
    fetchAnomalies();
  }, [fetchAnomalies]);

  const runRules = async () => {
    const res = await adminApi.runAnomalyRules();
    await fetchAnomalies();
    return res;
  };

  const reviewAnomaly = async (id: string) => {
    const res = await adminApi.reviewAnomaly(id);
    await fetchAnomalies();
    return res;
  };

  const resolveAnomalyWithNotes = async (id: string, resolution: string) => {
    const res = await adminApi.resolveAnomalyWithNotes(id, resolution);
    await fetchAnomalies();
    return res;
  };

  const dismissAnomaly = async (id: string, reason: string) => {
    const res = await adminApi.dismissAnomaly(id, reason);
    await fetchAnomalies();
    return res;
  };

  const investigateAnomaly = async (id: string, notes: string) => {
    const res = await adminApi.investigateAnomaly(id, notes);
    await fetchAnomalies();
    return res;
  };

  const explainAnomalyWithAi = async (id: string) => {
    const res = await adminApi.explainAnomalyWithAi(id);
    await fetchAnomalies();
    return res;
  };

  const resolveAnomaly = async (id: string, newStatus: AnomalyRecord['status']) => {
    await adminApi.resolveAnomaly(id, newStatus);
    await fetchAnomalies();
  };

  return {
    anomalies: result.data,
    total: result.total,
    page,
    totalPages: result.totalPages,
    setPage,
    search,
    setSearch: (s: string) => {
      setSearch(s);
      setPage(1);
    },
    severity,
    setSeverity: (sev: string) => {
      setSeverity(sev);
      setPage(1);
    },
    status,
    setStatus: (st: string) => {
      setStatus(st);
      setPage(1);
    },
    entityType,
    setEntityType: (et: string) => {
      setEntityType(et);
      setPage(1);
    },
    ruleKey,
    setRuleKey: (rk: string) => {
      setRuleKey(rk);
      setPage(1);
    },
    isLoading,
    error,
    refetch: fetchAnomalies,
    runRules,
    reviewAnomaly,
    resolveAnomalyWithNotes,
    dismissAnomaly,
    investigateAnomaly,
    explainAnomalyWithAi,
    resolveAnomaly,
  };
}

// 8. Audit Logs Query
export function useAuditLogsQuery() {
  const [result, setResult] = useState<PaginatedResult<AuditLog>>({
    data: [],
    total: 0,
    page: 1,
    limit: 15,
    totalPages: 1,
  });
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchLogs = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await adminApi.getAuditLogs({ page, limit: 15, search });
      setResult(res);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch audit logs');
    } finally {
      setIsLoading(false);
    }
  }, [page, search]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  return {
    logs: result.data,
    total: result.total,
    page,
    totalPages: result.totalPages,
    setPage,
    search,
    setSearch,
    isLoading,
    error,
    refetch: fetchLogs,
  };
}

// 9. Config Query & Update
export function useAdminConfig() {
  const [config, setConfig] = useState<AppConfiguration | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const fetchConfig = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await adminApi.getConfig();
      setConfig(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load configuration');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchConfig();
  }, [fetchConfig]);

  const updateSection = async (section: string, patch: any) => {
    setIsSaving(true);
    try {
      const res = await adminApi.updateConfig(section, patch);
      setConfig(res.config);
      return res.config;
    } finally {
      setIsSaving(false);
    }
  };

  return {
    config,
    isLoading,
    isSaving,
    error,
    refetch: fetchConfig,
    updateSection,
  };
}


export function useAiActivityQuery() {
  const [data, setData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const fetchAiActivity = async (p: number = page) => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await adminApi.getAiActivity(p);
      setData(data.data);
      setTotal(data.total);
      setTotalPages(data.totalPages);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAiActivity();
  }, [page]);

  return { data, isLoading, error, page, setPage, total, totalPages, refetch: fetchAiActivity };
}

export function useIvrActivityQuery() {
  const [data, setData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const fetchIvrActivity = async (p: number = page) => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await adminApi.getIvrActivity(p);
      setData(data.data);
      setTotal(data.total);
      setTotalPages(data.totalPages);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchIvrActivity();
  }, [page]);

  return { data, isLoading, error, page, setPage, total, totalPages, refetch: fetchIvrActivity };
}

export function useSystemNotificationsQuery() {
  const [data, setData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const fetchNotifications = async (p: number = page) => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await adminApi.getNotifications(p);
      setData(data.data);
      setTotal(data.total);
      setTotalPages(data.totalPages);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [page]);

  return { data, isLoading, error, page, setPage, total, totalPages, refetch: fetchNotifications };
}
