import {
  User,
  PickupRequest,
  AggregatedLot,
  TraceabilityEvent,
  PaymentRecord,
  Complaint,
  AnomalyRecord,
  AuditLog,
  PaginatedResult,
} from '../../shared/types/domain';
import { AppConfiguration } from '../../shared/types/config';
import { AnalyticsResponse, AnalyticsRange } from '../../shared/types/analytics';
import { DashboardResponseData } from '../types/dashboard';

export interface UserDetailResponse {
  user: User;
  stats: {
    pickupCount: number;
    lotCount: number;
    complaintCount: number;
    paymentCount: number;
    totalAmountInr: number;
  };
  pickups: PickupRequest[];
  lots: AggregatedLot[];
  complaints: Complaint[];
  payments: PaymentRecord[];
  auditHistory: AuditLog[];
  traceabilityEvents: TraceabilityEvent[];
}

class AdminApiService {
  private token: string | null = null;

  constructor() {
    // Restore token from session storage if present
    if (typeof window !== 'undefined') {
      this.token = sessionStorage.getItem('recysetu_admin_token') || localStorage.getItem('recysetu_admin_token');
    }
  }

  public setToken(token: string | null) {
    this.token = token;
    if (typeof window !== 'undefined') {
      if (token) {
        sessionStorage.setItem('recysetu_admin_token', token);
      } else {
        sessionStorage.removeItem('recysetu_admin_token');
        localStorage.removeItem('recysetu_admin_token');
      }
    }
  }

  public getToken(): string | null {
    return this.token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(endpoint, {
      ...options,
      headers,
    });

    if (!response.ok) {
      if (response.status === 401 && typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('admin-auth-expired'));
      }
      let errMessage = `HTTP error ${response.status}`;
      try {
        const errorBody = await response.json();
        errMessage = errorBody.message || errorBody.error || errMessage;
      } catch {
        // use default
      }
      throw new Error(errMessage);
    }

    return response.json();
  }

  // --- Auth ---
  public async login(adminId: string, password: string):Promise<{ token: string; expiresAt: string; user: User }> {
    const res = await this.request<{ token: string; expiresAt: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ adminId, password }),
    });
    this.setToken(res.token);
    return res;
  }

  public async getMe(): Promise<{ user: User }> {
    return this.request<{ user: User }>('/api/auth/me');
  }

  public async logout(): Promise<void> {
    try {
      await this.request('/api/auth/logout', { method: 'POST' });
    } finally {
      this.setToken(null);
    }
  }

  // --- Dashboard ---
  public async getDashboardStats(params?: {
    range?: string;
    startDate?: string;
    endDate?: string;
  }): Promise<DashboardResponseData> {
    const query = new URLSearchParams();
    if (params?.range) query.set('range', params.range);
    if (params?.startDate) query.set('startDate', params.startDate);
    if (params?.endDate) query.set('endDate', params.endDate);
    const queryString = query.toString();
    return this.request(`/api/admin/dashboard-stats${queryString ? `?${queryString}` : ''}`);
  }

  // --- Users ---
  public async getUsers(params: {
    page?: number;
    limit?: number;
    search?: string;
    role?: string;
    status?: string;
    verificationStatus?: string;
    location?: string;
    startDate?: string;
    endDate?: string;
  }): Promise<PaginatedResult<User>> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page.toString());
    if (params.limit) query.set('limit', params.limit.toString());
    if (params.search) query.set('search', params.search);
    if (params.role) query.set('role', params.role);
    if (params.status) query.set('status', params.status);
    if (params.verificationStatus) query.set('verificationStatus', params.verificationStatus);
    if (params.location) query.set('location', params.location);
    if (params.startDate) query.set('startDate', params.startDate);
    if (params.endDate) query.set('endDate', params.endDate);

    return this.request(`/api/admin/users?${query.toString()}`);
  }

  public async getUserDetail(userId: string): Promise<UserDetailResponse> {
    return this.request(`/api/admin/users/${userId}`);
  }

  public async verifyRecycler(userId: string, reason?: string): Promise<{ success: boolean; user: User }> {
    return this.request(`/api/admin/users/${userId}/verify-recycler`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  }

  public async rejectRecycler(userId: string, reason: string): Promise<{ success: boolean; user: User }> {
    return this.request(`/api/admin/users/${userId}/reject-recycler`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  }

  public async suspendUser(userId: string, reason: string): Promise<{ success: boolean; user: User }> {
    return this.request(`/api/admin/users/${userId}/suspend`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  }

  public async reactivateUser(userId: string, reason?: string): Promise<{ success: boolean; user: User }> {
    return this.request(`/api/admin/users/${userId}/reactivate`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  }

  public async verifyKyc(userId: string, reason?: string): Promise<{ success: boolean; user: User }> {
    return this.request(`/api/admin/users/${userId}/verify-kyc`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  }

  public async changeUserRole(
    userId: string,
    newRole: User['role'],
    reason: string
  ): Promise<{ success: boolean; user: User }> {
    return this.request(`/api/admin/users/${userId}/change-role`, {
      method: 'POST',
      body: JSON.stringify({ newRole, reason }),
    });
  }

  public async updateUserStatus(
    userId: string,
    status: User['status'],
    kycVerified?: boolean
  ): Promise<{ success: boolean; user: User }> {
    return this.request(`/api/admin/users/${userId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, kycVerified }),
    });
  }

  // --- Pickups ---
  public async getPickups(params: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    category?: string;
    collectorId?: string;
    aggregatorId?: string;
    recyclerId?: string;
  }): Promise<PaginatedResult<PickupRequest>> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page.toString());
    if (params.limit) query.set('limit', params.limit.toString());
    if (params.search) query.set('search', params.search);
    if (params.status) query.set('status', params.status);
    if (params.category) query.set('category', params.category);
    if (params.collectorId) query.set('collectorId', params.collectorId);
    if (params.aggregatorId) query.set('aggregatorId', params.aggregatorId);
    if (params.recyclerId) query.set('recyclerId', params.recyclerId);

    return this.request(`/api/admin/pickups?${query.toString()}`);
  }

  public async getPickupDetail(id: string): Promise<{
    pickup: PickupRequest;
    collector: Partial<User> | null;
    aggregator: Partial<User> | null;
    recycler: Partial<User> | null;
    associatedLot: AggregatedLot | null;
    associatedPayments: PaymentRecord[];
    traceabilityEvents: TraceabilityEvent[];
  }> {
    return this.request(`/api/admin/pickups/${encodeURIComponent(id)}`);
  }

  public async updatePickupStatus(
    id: string,
    status: PickupRequest['status'],
    reason?: string
  ): Promise<{ success: boolean; pickup: PickupRequest }> {
    return this.request(`/api/admin/pickups/${encodeURIComponent(id)}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, reason }),
    });
  }

  public async addPickupAuditEvent(
    id: string,
    data: {
      eventType?: string;
      notes?: string;
      weightKg?: number;
      location?: string;
      details?: Record<string, any>;
    }
  ): Promise<{ success: boolean; event: TraceabilityEvent }> {
    return this.request(`/api/admin/pickups/${encodeURIComponent(id)}/audit-event`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  // --- Lots ---
  public async getLots(params: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    category?: string;
    hasDiscrepancy?: boolean;
  }): Promise<PaginatedResult<AggregatedLot>> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page.toString());
    if (params.limit) query.set('limit', params.limit.toString());
    if (params.search) query.set('search', params.search);
    if (params.status) query.set('status', params.status);
    if (params.category) query.set('category', params.category);
    if (params.hasDiscrepancy) query.set('hasDiscrepancy', 'true');

    return this.request(`/api/admin/lots?${query.toString()}`);
  }

  public async getLotDetail(id: string): Promise<{
    lot: AggregatedLot;
    pickups: PickupRequest[];
    contributingCollectors: Array<{
      collectorId: string;
      collectorName: string;
      totalKg: number;
      percentageOfLot: number;
      pickupCount: number;
    }>;
    weightAnalysis: {
      declaredWeightKg: number;
      actualWeightKg: number | null;
      discrepancyKg: number;
      discrepancyPercent: number;
      thresholdPercent: number;
      isThresholdExceeded: boolean;
      status: 'NORMAL' | 'WITHIN_TOLERANCE' | 'THRESHOLD_EXCEEDED' | 'PENDING_WEIGHMENT';
      notes?: string;
    };
    payments: PaymentRecord[];
    traceabilityTimeline: TraceabilityEvent[];
  }> {
    return this.request(`/api/admin/lots/${encodeURIComponent(id)}`);
  }

  public async reconcileLotWeight(
    id: string,
    actualWeightKg: number,
    notes?: string
  ): Promise<{
    success: boolean;
    lot: AggregatedLot;
    detail: any;
  }> {
    return this.request(`/api/admin/lots/${encodeURIComponent(id)}/reconcile-weight`, {
      method: 'POST',
      body: JSON.stringify({ actualWeightKg, notes }),
    });
  }

  public async addLotAuditEvent(
    id: string,
    data: {
      eventType?: string;
      notes?: string;
      weightKg?: number;
      location?: string;
      details?: Record<string, any>;
    }
  ): Promise<{ success: boolean; event: TraceabilityEvent }> {
    return this.request(`/api/admin/lots/${encodeURIComponent(id)}/audit-event`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  public async updateLotStatus(
    id: string,
    status: AggregatedLot['status'],
    reason?: string
  ): Promise<{ success: boolean; lot: AggregatedLot }> {
    return this.request(`/api/admin/lots/${encodeURIComponent(id)}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, reason }),
    });
  }

  // --- QR Code Resolution ---
  public async resolveQrToken(token: string): Promise<{
    found: boolean;
    type: 'LOT' | 'PICKUP';
    id: string;
    code: string;
    entity: AggregatedLot | PickupRequest;
    summary: Record<string, any>;
  }> {
    return this.request('/api/admin/qr/resolve', {
      method: 'POST',
      body: JSON.stringify({ token }),
    });
  }

  // --- Traceability ---
  public async getTraceability(params: {
    page?: number;
    limit?: number;
    search?: string;
    entityType?: string;
  }): Promise<PaginatedResult<TraceabilityEvent>> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page.toString());
    if (params.limit) query.set('limit', params.limit.toString());
    if (params.search) query.set('search', params.search);
    if (params.entityType) query.set('entityType', params.entityType);

    return this.request(`/api/admin/traceability?${query.toString()}`);
  }

  // --- Payments ---
  public async getPayments(params: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
    minAmount?: number;
    maxAmount?: number;
    disputedOnly?: boolean;
    paymentMethod?: string;
  }): Promise<PaginatedResult<PaymentRecord>> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page.toString());
    if (params.limit) query.set('limit', params.limit.toString());
    if (params.search) query.set('search', params.search);
    if (params.status) query.set('status', params.status);
    if (params.startDate) query.set('startDate', params.startDate);
    if (params.endDate) query.set('endDate', params.endDate);
    if (params.minAmount != null) query.set('minAmount', params.minAmount.toString());
    if (params.maxAmount != null) query.set('maxAmount', params.maxAmount.toString());
    if (params.disputedOnly) query.set('disputedOnly', 'true');
    if (params.paymentMethod) query.set('paymentMethod', params.paymentMethod);

    return this.request(`/api/admin/payments?${query.toString()}`);
  }

  public async getPaymentDetail(id: string): Promise<{
    success: boolean;
    payment: PaymentRecord;
    payer: any;
    payee: any;
    relatedLot: any;
    relatedPickup: any;
    lifecycleEvents: TraceabilityEvent[];
    auditLogs: any[];
    notifications: any[];
  }> {
    return this.request(`/api/admin/payments/${encodeURIComponent(id)}`);
  }

  public async resolvePaymentDispute(
    id: string,
    action: 'HOLD_ESCROW' | 'RELEASE_PAYOUT' | 'REFUND_PAYER' | 'ARBITRATE' | 'CLEAR_FLAG',
    reason: string
  ): Promise<{ success: boolean; payment: PaymentRecord; detail?: any }> {
    return this.request(`/api/admin/payments/${encodeURIComponent(id)}/dispute`, {
      method: 'POST',
      body: JSON.stringify({ action, reason }),
    });
  }

  public async flagPayment(
    id: string,
    flag: boolean,
    reason?: string
  ): Promise<{ success: boolean; payment: PaymentRecord }> {
    return this.request(`/api/admin/payments/${id}/flag`, {
      method: 'PATCH',
      body: JSON.stringify({ flag, reason }),
    });
  }

  // --- Complaints ---
  public async getComplaints(params: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    category?: string;
    priority?: string;
    startDate?: string;
    endDate?: string;
  }): Promise<PaginatedResult<Complaint>> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page.toString());
    if (params.limit) query.set('limit', params.limit.toString());
    if (params.search) query.set('search', params.search);
    if (params.status) query.set('status', params.status);
    if (params.category) query.set('category', params.category);
    if (params.priority) query.set('priority', params.priority);
    if (params.startDate) query.set('startDate', params.startDate);
    if (params.endDate) query.set('endDate', params.endDate);

    return this.request(`/api/admin/complaints?${query.toString()}`);
  }

  public async getComplaintDetail(id: string): Promise<{
    success: boolean;
    complaint: Complaint;
    complainant: any;
    against: any;
    relatedLot: any;
    relatedPickup: any;
    auditLogs: any[];
    notifications: any[];
  }> {
    return this.request(`/api/admin/complaints/${encodeURIComponent(id)}`);
  }

  public async addComplaintResponse(
    id: string,
    message: string,
    isInternal?: boolean
  ): Promise<{ success: boolean; complaint: Complaint; detail?: any }> {
    return this.request(`/api/admin/complaints/${encodeURIComponent(id)}/respond`, {
      method: 'POST',
      body: JSON.stringify({ message, isInternal }),
    });
  }

  public async resolveComplaintAction(
    id: string,
    action: 'RESOLVE' | 'REJECT' | 'ESCALATE_REVIEW' | 'FLAG_INVESTIGATION',
    notes: string
  ): Promise<{ success: boolean; complaint: Complaint; detail?: any }> {
    return this.request(`/api/admin/complaints/${encodeURIComponent(id)}/resolve`, {
      method: 'POST',
      body: JSON.stringify({ action, notes }),
    });
  }

  public async resolveComplaint(
    id: string,
    status: Complaint['status'],
    resolutionNotes?: string
  ): Promise<{ success: boolean; complaint: Complaint }> {
    return this.request(`/api/admin/complaints/${id}/resolve`, {
      method: 'PATCH',
      body: JSON.stringify({ status, resolutionNotes }),
    });
  }

  // --- Analytics (Phase 6) ---
  public async getAnalytics(params: {
    range?: AnalyticsRange | string;
    startDate?: string;
    endDate?: string;
  }): Promise<AnalyticsResponse> {
    const query = new URLSearchParams();
    if (params.range) query.set('range', params.range);
    if (params.startDate) query.set('startDate', params.startDate);
    if (params.endDate) query.set('endDate', params.endDate);

    return this.request(`/api/admin/analytics?${query.toString()}`);
  }

  public async exportAnalytics(params: {
    type?: string;
    range?: string;
    startDate?: string;
    endDate?: string;
  }): Promise<{ filename: string; text: string }> {
    const query = new URLSearchParams();
    if (params.type) query.set('type', params.type);
    if (params.range) query.set('range', params.range);
    if (params.startDate) query.set('startDate', params.startDate);
    if (params.endDate) query.set('endDate', params.endDate);

    const headers: Record<string, string> = {};
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(`/api/admin/analytics/export?${query.toString()}`, { headers });
    if (!response.ok) {
      throw new Error(`Export failed with HTTP ${response.status}`);
    }

    const disposition = response.headers.get('content-disposition') || '';
    const match = disposition.match(/filename="?([^"]+)"?/);
    const filename = match ? match[1] : `recysetu-export-${Date.now()}.csv`;
    const text = await response.text();

    return { filename, text };
  }

  // --- Anomalies & Fraud Detection (Phase 6) ---
  public async getAnomalies(params: {
    page?: number;
    limit?: number;
    search?: string;
    severity?: string;
    status?: string;
    entityType?: string;
    ruleKey?: string;
  }): Promise<PaginatedResult<AnomalyRecord>> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page.toString());
    if (params.limit) query.set('limit', params.limit.toString());
    if (params.search) query.set('search', params.search);
    if (params.severity) query.set('severity', params.severity);
    if (params.status) query.set('status', params.status);
    if (params.entityType) query.set('entityType', params.entityType);
    if (params.ruleKey) query.set('ruleKey', params.ruleKey);

    return this.request(`/api/admin/anomalies?${query.toString()}`);
  }

  public async getAnomalyDetail(id: string): Promise<AnomalyRecord> {
    return this.request(`/api/admin/anomalies/${encodeURIComponent(id)}`);
  }

  public async runAnomalyRules(): Promise<{ success: boolean; detected: AnomalyRecord[]; totalActive: number }> {
    return this.request('/api/admin/anomalies/run-rules', {
      method: 'POST',
    });
  }

  public async reviewAnomaly(id: string): Promise<{ success: boolean; anomaly: AnomalyRecord }> {
    return this.request(`/api/admin/anomalies/${encodeURIComponent(id)}/review`, {
      method: 'POST',
    });
  }

  public async resolveAnomalyWithNotes(
    id: string,
    resolution: string
  ): Promise<{ success: boolean; anomaly: AnomalyRecord }> {
    return this.request(`/api/admin/anomalies/${encodeURIComponent(id)}/resolve`, {
      method: 'POST',
      body: JSON.stringify({ resolution }),
    });
  }

  public async dismissAnomaly(
    id: string,
    reason: string
  ): Promise<{ success: boolean; anomaly: AnomalyRecord }> {
    return this.request(`/api/admin/anomalies/${encodeURIComponent(id)}/dismiss`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  }

  public async investigateAnomaly(
    id: string,
    notes: string
  ): Promise<{ success: boolean; anomaly: AnomalyRecord }> {
    return this.request(`/api/admin/anomalies/${encodeURIComponent(id)}/investigate`, {
      method: 'POST',
      body: JSON.stringify({ notes }),
    });
  }

  public async explainAnomalyWithAi(
    id: string
  ): Promise<{ success: boolean; anomaly: AnomalyRecord }> {
    return this.request(`/api/admin/anomalies/${encodeURIComponent(id)}/explain-ai`, {
      method: 'POST',
    });
  }

  public async resolveAnomaly(
    id: string,
    status: AnomalyRecord['status']
  ): Promise<{ success: boolean; anomaly: AnomalyRecord }> {
    return this.request(`/api/admin/anomalies/${id}/resolve`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  }


  public async getStateAnalytics(): Promise<any> {
    return this.request('/api/admin/state-analytics');
  }

  public async generateStateAnalyticsReport(): Promise<{ report: string }> {
    return this.request('/api/admin/state-analytics/report', { method: 'POST' });
  }


  public async getReviews(search: string = ''): Promise<any> {
    return this.request(`/api/admin/reviews?search=${search}`);
  }

  public async processReview(id: string, decision: 'APPROVE' | 'REJECT', notes: string): Promise<any> {
    return this.request(`/api/admin/reviews/${id}/process`, {
      method: 'POST',
      body: JSON.stringify({ decision, notes })
    });
  }

  public async getTrustRewards(search: string = ''): Promise<any> {
    return this.request(`/api/admin/trust-rewards?search=${search}`);
  }

  public async processTrustReward(id: string, action: 'APPROVE' | 'REJECT', amountInr?: number): Promise<any> {
    return this.request(`/api/admin/trust-rewards/${id}/process`, {
      method: 'POST',
      body: JSON.stringify({ action, amountInr })
    });
  }


  public async getAiActivity(page: number): Promise<any> {
    return this.request(`/api/admin/ai-activity?page=${page}&limit=15`);
  }

  public async getIvrActivity(page: number): Promise<any> {
    return this.request(`/api/admin/ivr-activity?page=${page}&limit=15`);
  }

  public async getNotifications(page: number): Promise<any> {
    return this.request(`/api/admin/notifications?page=${page}&limit=15`);
  }

  // --- Config ---



  public async getConfig(): Promise<AppConfiguration> {
    return this.request('/api/admin/config');
  }

  public async updateConfig(
    section: string,
    data: any
  ): Promise<{ success: boolean; config: AppConfiguration }> {
    return this.request(`/api/admin/config/${section}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  // --- Audit Logs ---
  public async getAuditLogs(params: {
    page?: number;
    limit?: number;
    search?: string;
  }): Promise<PaginatedResult<AuditLog>> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page.toString());
    if (params.limit) query.set('limit', params.limit.toString());
    if (params.search) query.set('search', params.search);

    return this.request(`/api/admin/audit-logs?${query.toString()}`);
  }
}

export const adminApi = new AdminApiService();
