import React from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { AdminPagination } from '../components/AdminPagination';
import { formatDateTime } from '../utils/formatters';
import { SystemNotification } from '../../shared/types/domain';
import { TableColumn } from '../types/admin';
import { Bell } from 'lucide-react';

interface AdminNotificationsPageProps {
  data: SystemNotification[];
  total: number;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  isLoading: boolean;
}

export const AdminNotificationsPage: React.FC<AdminNotificationsPageProps> = ({
  data,
  total,
  page,
  totalPages,
  setPage,
  isLoading,
}) => {
  const columns: TableColumn<SystemNotification>[] = [
    {
      key: 'timestamp',
      header: 'Time',
      render: (a) => (
        <span className="font-mono text-xs text-slate-500 whitespace-nowrap">
          {formatDateTime(a.timestamp)}
        </span>
      ),
    },
    {
      key: 'type',
      header: 'Type',
      render: (a) => (
        <span className="font-bold text-xs text-slate-800 font-mono">
          {a.type.replace(/_/g, ' ')}
        </span>
      ),
    },
    {
      key: 'recipient',
      header: 'Recipient',
      render: (a) => <span className="text-xs font-semibold text-slate-800">{a.recipientId}</span>,
    },
    {
      key: 'channel',
      header: 'Channel',
      render: (a) => (
        <span className="text-xs text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
          {a.channel}
        </span>
      ),
    },
    {
      key: 'message',
      header: 'Content',
      render: (a) => (
        <div className="text-xs">
          <div className="font-medium text-slate-800">{a.title}</div>
          <div className="text-slate-500 truncate max-w-xs">{a.message}</div>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (a) => (
        <span className={`text-xs px-2 py-0.5 rounded border \${
          a.status === 'DELIVERED' || a.status === 'READ' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
          a.status === 'FAILED' ? 'bg-red-50 text-red-700 border-red-200' :
          'bg-amber-50 text-amber-700 border-amber-200'
        }`}>
          {a.status}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <AdminPageHeader
        title="System Notifications"
        description="Audit log of all SMS, WhatsApp, and Push notifications dispatched to users."
        badge={
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            <Bell className="w-3.5 h-3.5 text-slate-500" />
            Dispatch Log
          </span>
        }
      />
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <AdminDataTable
          columns={columns}
          data={data}
          keyExtractor={(a) => a.id}
          isLoading={isLoading}
          emptyTitle="No notifications found"
        />
        <AdminPagination
          currentPage={page}
          totalPages={totalPages}
          totalItems={total}
          itemsPerPage={15}
          onPageChange={setPage}
        />
      </div>
    </div>
  );
};
