import { adminApi } from '../services/adminApiService';
import React, { useState, useEffect } from 'react';
import { 
  MapPin, CheckCircle, Clock, AlertTriangle, 
  FileText, Download, Users, TrendingUp,
  ChevronRight, RefreshCw, BarChart2, Zap, Leaf
} from 'lucide-react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminLoadingState } from '../components/AdminLoadingState';
import { AdminErrorState } from '../components/AdminErrorState';
import { IndiaMap } from '../components/IndiaMap';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend, Cell } from 'recharts';
import ReactMarkdown from 'react-markdown';


interface StateData {
  state: string;
  status: 'ACTIVE' | 'COMING_SOON' | 'INACTIVE';
  collectors: number;
  aggregators: number;
  recyclers: number;
  totalStakeholders: number;
  wasteCollectedKg: number;
  wasteProcessedKg: number;
  wasteRecycledKg: number;
  districts?: Record<string, any>;
}

export const AdminStateAnalyticsPage: React.FC = () => {
  const [data, setData] = useState<StateData[] | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedState, setSelectedState] = useState<string | null>('Chhattisgarh');
  
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const [reportResult, setReportResult] = useState<string | null>(null);
  const [showReportModal, setShowReportModal] = useState(false);

  const fetchStateAnalytics = async () => {
    try {
      setIsLoading(true);
      const json = await adminApi.getStateAnalytics();
      if (Array.isArray(json)) {
        setData(json);
      } else if (json.data && Array.isArray(json.data)) {
        setData(json.data);
      } else {
        throw new Error('Invalid data format received');
      }
      setError(null);
    } catch (err: any) {
      setError(err.message);
      setData(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStateAnalytics();
  }, []);

  const handleGenerateReport = async () => {
    try {
      setIsGeneratingReport(true);
      setShowReportModal(true);
      const json = await adminApi.generateStateAnalyticsReport();
      setReportResult(json.report);
    } catch (err: any) {
      setReportResult('Error generating report: ' + err.message);
    } finally {
      setIsGeneratingReport(false);
    }
  };

  if (isLoading && !data) return <AdminLoadingState message="Loading geographic analytics..." />;
  if (error && !data) return <AdminErrorState title="Geographic Data Offline" message={error} onRetry={fetchStateAnalytics} />;
  if (!data) return null;

  const activeStates = data.filter(d => d.status === 'ACTIVE').length;
  const totalCollectors = data.reduce((sum, d) => sum + d.collectors, 0);
  const totalAggregators = data.reduce((sum, d) => sum + d.aggregators, 0);
  const totalRecyclers = data.reduce((sum, d) => sum + d.recyclers, 0);
  const totalWasteRecycledTons = data.reduce((sum, d) => sum + d.wasteRecycledKg, 0) / 1000;

  const selectedStateData = data.find(d => d.state === selectedState) || data[0];
  const isDurgActive = selectedStateData?.state === 'Chhattisgarh';
  
  // Custom abstract map layout of India (rough approximations of regions)
  const renderAbstractMap = () => {
    const statesMapLayout = [
      { name: 'Delhi', top: '20%', left: '40%' },
      { name: 'Gujarat', top: '45%', left: '20%' },
      { name: 'Maharashtra', top: '55%', left: '30%' },
      { name: 'Chhattisgarh', top: '45%', left: '55%' },
      { name: 'Karnataka', top: '75%', left: '35%' },
      { name: 'Tamil Nadu', top: '85%', left: '45%' },
    ];

    return (
      <div className="relative w-full h-[400px] bg-slate-50 border border-slate-200 rounded-xl overflow-hidden shadow-inner">
        {/* Abstract India Background Path (Simulated) */}
        <div className="absolute inset-0 opacity-10 flex items-center justify-center pointer-events-none">
          <svg viewBox="0 0 100 100" className="w-full h-full p-4" preserveAspectRatio="xMidYMid meet">
            <path d="M45,10 L35,25 L20,35 L15,50 L25,65 L30,85 L45,95 L55,85 L65,70 L75,55 L85,45 L70,30 L60,15 Z" fill="#94a3b8" />
          </svg>
        </div>

        {statesMapLayout.map((sLayout) => {
          const sData = data.find(d => d.state === sLayout.name);
          if (!sData) return null;
          const isActive = sData.status === 'ACTIVE';
          const isSelected = selectedState === sData.state;

          return (
            <button
              key={sLayout.name}
              onClick={() => setSelectedState(sData.state)}
              className={`absolute flex flex-col items-center justify-center transform -translate-x-1/2 -translate-y-1/2 transition-all group ${
                isSelected ? 'scale-110 z-10' : 'hover:scale-105 z-0'
              }`}
              style={{ top: sLayout.top, left: sLayout.left }}
            >
              <div className={`w-4 h-4 rounded-full border-2 mb-1 shadow-sm ${
                isSelected 
                  ? 'bg-emerald-500 border-emerald-200 ring-4 ring-emerald-500/20' 
                  : isActive 
                    ? 'bg-emerald-500 border-white' 
                    : 'bg-slate-300 border-white'
              }`} />
              <div className={`text-[10px] font-bold px-2 py-0.5 rounded shadow-sm whitespace-nowrap ${
                isSelected ? 'bg-slate-900 text-white' : 'bg-white text-slate-700 border border-slate-200 group-hover:border-slate-300'
              }`}>
                {sData.state}
              </div>
              
              {/* Tooltip on Hover */}
              {!isSelected && (
                <div className="absolute bottom-full mb-2 hidden group-hover:block w-40 bg-slate-900 text-white text-xs rounded-lg p-2.5 shadow-xl pointer-events-none z-20">
                  <div className="font-bold border-b border-slate-700 pb-1 mb-1">{sData.state}</div>
                  <div className="flex items-center justify-between text-[10px] text-slate-300">
                    <span>Status</span>
                    <span className={isActive ? 'text-emerald-400 font-bold' : 'text-slate-400'}>{sData.status}</span>
                  </div>
                  {isActive && (
                    <>
                      <div className="flex items-center justify-between text-[10px] mt-1">
                        <span>Stakeholders</span>
                        <span className="font-bold">{sData.totalStakeholders}</span>
                      </div>
                      <div className="flex items-center justify-between text-[10px]">
                        <span>Recycled</span>
                        <span className="font-bold">{(sData.wasteRecycledKg / 1000).toFixed(1)} T</span>
                      </div>
                    </>
                  )}
                  {!isActive && (
                    <div className="text-[10px] text-slate-400 mt-1 italic">Operational data not yet available</div>
                  )}
                </div>
              )}
            </button>
          );
        })}
      </div>
    );
  };

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6 pb-20">
      <AdminPageHeader
        title="State-Wise E-Waste Progress"
        description="Geographic intelligence, stakeholder network mapping, and operational analytics across India."
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={fetchStateAnalytics}
              className="p-2 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={handleGenerateReport}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 text-white text-sm font-semibold rounded-lg hover:bg-slate-800 transition-colors shadow-sm"
            >
              <FileText className="w-4 h-4" />
              Generate AI Report
            </button>
          </div>
        }
      />

      {/* KPI Header Strip */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm flex flex-wrap divide-y sm:divide-y-0 sm:divide-x divide-slate-100">
        <div className="p-4 flex-1 min-w-[120px]">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Active States</div>
          <div className="text-2xl font-black text-slate-900">{activeStates}</div>
        </div>
        <div className="p-4 flex-1 min-w-[120px]">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Total Collectors</div>
          <div className="text-2xl font-black text-slate-900">{totalCollectors}</div>
        </div>
        <div className="p-4 flex-1 min-w-[120px]">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Total Aggregators</div>
          <div className="text-2xl font-black text-slate-900">{totalAggregators}</div>
        </div>
        <div className="p-4 flex-1 min-w-[120px]">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Total Recyclers</div>
          <div className="text-2xl font-black text-slate-900">{totalRecyclers}</div>
        </div>
        <div className="p-4 flex-1 min-w-[150px]">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Waste Recycled</div>
          <div className="text-2xl font-black text-emerald-600">{totalWasteRecycledTons.toFixed(1)} <span className="text-sm">T</span></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* MAP VISUALIZATION */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-emerald-600" />
              India Geographic Map
            </h3>
            <IndiaMap data={data} selectedState={selectedState} onSelectState={setSelectedState} />
          </div>
          
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              States Requiring Attention
            </h3>
            <div className="space-y-3">
              {data.filter(d => d.status === 'ACTIVE' && d.recyclers === 0).length > 0 ? (
                data.filter(d => d.status === 'ACTIVE' && d.recyclers === 0).map(d => (
                  <div key={d.state} className="p-3 bg-amber-50 rounded-lg border border-amber-100 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-xs font-bold text-amber-900">{d.state}</div>
                      <div className="text-[11px] font-medium text-amber-700">Low Recycler availability. Network congestion risk.</div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-xs font-medium text-slate-500 text-center">
                  No critical attention signals detected in active states.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* STATE PERFORMANCE TABLE & DRILL DOWN */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">State Performance</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm whitespace-nowrap">
                <thead className="bg-slate-50 text-slate-600 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">State</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Stakeholders</th>
                    <th className="px-4 py-3 text-right">Collected</th>
                    <th className="px-4 py-3 text-right">Recycled</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {data.map((row) => (
                    <tr 
                      key={row.state} 
                      onClick={() => setSelectedState(row.state)}
                      className={`cursor-pointer transition-colors ${selectedState === row.state ? 'bg-emerald-50/50' : 'hover:bg-slate-50'}`}
                    >
                      <td className="px-4 py-3 font-semibold text-slate-900 flex items-center gap-2">
                        {selectedState === row.state && <ChevronRight className="w-4 h-4 text-emerald-600" />}
                        {row.state}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          row.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {row.status === 'COMING_SOON' ? 'Coming Soon' : row.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right font-medium text-slate-600">
                        {row.totalStakeholders > 0 ? row.totalStakeholders : '-'}
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-slate-600">
                        {row.wasteCollectedKg > 0 ? `${(row.wasteCollectedKg / 1000).toFixed(1)}T` : '-'}
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-slate-600">
                        {row.wasteRecycledKg > 0 ? `${(row.wasteRecycledKg / 1000).toFixed(1)}T` : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* DRILL DOWN: SELECTED STATE */}
          {selectedStateData && (
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-slate-50 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
              
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight">{selectedStateData.state} Analytics</h2>
                    <p className="text-sm font-medium text-slate-500 mt-1">Detailed operational breakdown</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                    selectedStateData.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {selectedStateData.status === 'COMING_SOON' ? 'Coming Soon' : selectedStateData.status}
                  </span>
                </div>

                {selectedStateData.status === 'ACTIVE' ? (
                  <>
                    <div className="grid grid-cols-3 gap-4 mb-8">
                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-center">
                        <Users className="w-5 h-5 text-slate-400 mx-auto mb-2" />
                        <div className="text-2xl font-black text-slate-900">{selectedStateData.collectors}</div>
                        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mt-1">Collectors</div>
                      </div>
                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-center">
                        <TrendingUp className="w-5 h-5 text-slate-400 mx-auto mb-2" />
                        <div className="text-2xl font-black text-slate-900">{selectedStateData.aggregators}</div>
                        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mt-1">Aggregators</div>
                      </div>
                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 text-center">
                        <Leaf className="w-5 h-5 text-slate-400 mx-auto mb-2" />
                        <div className="text-2xl font-black text-slate-900">{selectedStateData.recyclers}</div>
                        <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mt-1">Recyclers</div>
                      </div>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 mb-3">District Operations (Durg)</h4>
                    <div className="bg-emerald-50 rounded-xl p-5 border border-emerald-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                          <span className="font-bold text-emerald-900">Active Collection Zone</span>
                        </div>
                        <p className="text-xs font-medium text-emerald-700">All metrics derive from active operations within Durg.</p>
                      </div>
                      <div className="flex gap-4">
                        <div className="text-right">
                          <div className="text-xs font-bold text-emerald-600/70 uppercase">Collected</div>
                          <div className="font-mono font-bold text-emerald-900">{(selectedStateData.wasteCollectedKg / 1000).toFixed(2)} T</div>
                        </div>
                        <div className="text-right pl-4 border-l border-emerald-200">
                          <div className="text-xs font-bold text-emerald-600/70 uppercase">Recycled</div>
                          <div className="font-mono font-bold text-emerald-900">{(selectedStateData.wasteRecycledKg / 1000).toFixed(2)} T</div>
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="py-12 flex flex-col items-center justify-center text-center">
                    <Clock className="w-10 h-10 text-slate-300 mb-3" />
                    <h4 className="text-base font-bold text-slate-900">Data Unavailable</h4>
                    <p className="text-sm text-slate-500 mt-1 max-w-sm">
                      {selectedStateData.state} is scheduled for a future rollout phase. No stakeholder or operational telemetry exists yet.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* AI Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-slate-600" />
                <h3 className="text-lg font-bold text-slate-900">State-Wise Progress Report</h3>
              </div>
              <button 
                onClick={() => setShowReportModal(false)}
                className="p-2 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors"
              >
                Close
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1 bg-white">
              {isGeneratingReport ? (
                <div className="py-20 flex flex-col items-center justify-center space-y-4">
                  <div className="w-10 h-10 border-4 border-emerald-100 border-t-emerald-600 rounded-full animate-spin" />
                  <p className="text-sm font-semibold text-slate-600 animate-pulse">
                    Synthesizing geographic intelligence...
                  </p>
                </div>
              ) : (
                <div className="prose prose-sm prose-slate max-w-none">
                  {reportResult ? (
                    <ReactMarkdown>{reportResult}</ReactMarkdown>
                  ) : (
                    <p className="text-rose-600">Failed to generate report content.</p>
                  )}
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
              <button
                disabled={isGeneratingReport}
                className="px-4 py-2 bg-white border border-slate-200 text-sm font-semibold text-slate-700 rounded-lg hover:bg-slate-100 disabled:opacity-50 transition-colors"
              >
                Download PDF
              </button>
              <button
                disabled={isGeneratingReport}
                className="px-4 py-2 bg-slate-900 text-white text-sm font-semibold rounded-lg hover:bg-slate-800 disabled:opacity-50 transition-colors"
              >
                Export CSV Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
