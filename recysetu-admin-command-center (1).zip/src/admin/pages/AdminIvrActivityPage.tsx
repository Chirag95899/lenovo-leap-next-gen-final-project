import React from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { AdminPagination } from '../components/AdminPagination';
import { formatDateTime } from '../utils/formatters';
import { IvrActivity } from '../../shared/types/domain';
import { TableColumn } from '../types/admin';
import { PhoneCall } from 'lucide-react';

interface AdminIvrActivityPageProps {
  data: IvrActivity[];
  total: number;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  isLoading: boolean;
}

export const AdminIvrActivityPage: React.FC<AdminIvrActivityPageProps> = ({
  data,
  total,
  page,
  totalPages,
  setPage,
  isLoading,
}) => {
  const columns: TableColumn<IvrActivity>[] = [
    {
      key: 'timestamp',
      header: 'Time',
      render: (a) => (
        <span className="font-mono text-xs text-slate-500 whitespace-nowrap">
          {formatDateTime(a.timestamp)}
        </span>
      ),
    },
    {
      key: 'callId',
      header: 'Call Ref',
      render: (a) => (
        <span className="font-mono text-xs text-slate-600 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
          {a.callId.substring(0, 8)}...
        </span>
      ),
    },
    {
      key: 'caller',
      header: 'Caller',
      render: (a) => <span className="text-xs font-semibold text-slate-800">{a.callerId}</span>,
    },
    {
      key: 'language',
      header: 'Lang',
      render: (a) => (
        <span className="text-xs uppercase text-slate-600">{a.language}</span>
      ),
    },
    {
      key: 'intent',
      header: 'Intent',
      render: (a) => (
        <span className="font-bold text-xs text-slate-800 font-mono">
          {a.intent.replace(/_/g, ' ')}
        </span>
      ),
    },
    {
      key: 'duration',
      header: 'Duration',
      render: (a) => <span className="text-xs text-slate-600">{a.durationSeconds}s</span>,
    },
    {
      key: 'status',
      header: 'Status',
      render: (a) => (
        <span className={`text-xs px-2 py-0.5 rounded border \${
          a.status === 'COMPLETED' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
          a.status === 'FAILED' || a.status === 'DROPPED' ? 'bg-red-50 text-red-700 border-red-200' :
          'bg-amber-50 text-amber-700 border-amber-200'
        }`}>
          {a.status}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <AdminPageHeader
        title="IVR & Voice Logs"
        description="Monitor automated voice menus and caller intent resolutions."
        badge={
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            <PhoneCall className="w-3.5 h-3.5 text-slate-500" />
            Telephony
          </span>
        }
      />
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <AdminDataTable
          columns={columns}
          data={data}
          keyExtractor={(a) => a.id}
          isLoading={isLoading}
          emptyTitle="No IVR activity found"
        />
        <AdminPagination
          currentPage={page}
          totalPages={totalPages}
          totalItems={total}
          itemsPerPage={15}
          onPageChange={setPage}
        />
      </div>
    </div>
  );
};
