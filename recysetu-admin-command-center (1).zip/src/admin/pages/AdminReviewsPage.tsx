import { adminApi } from '../services/adminApiService';
import React, { useState, useEffect } from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { AdminStatusBadge } from '../components/AdminStatusBadge';
import { Star, Eye, Filter, RefreshCw, ShieldAlert, CheckCircle, Clock } from 'lucide-react';
import { MutualReview } from '../../shared/types/domain';
import { AdminModal } from '../components/AdminModal';
import { formatDateTime } from '../utils/formatters';

interface AdminReviewsPageProps {
  id?: string;
  onNavigateToView: (view: string) => void;
}

export const AdminReviewsPage: React.FC<AdminReviewsPageProps> = ({ id = 'admin-reviews-page', onNavigateToView }) => {
  const [reviews, setReviews] = useState<MutualReview[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedReview, setSelectedReview] = useState<MutualReview | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processNotes, setProcessNotes] = useState('');
  const [scoreImpact, setScoreImpact] = useState<number>(0);

  const fetchReviews = async () => {
    setIsLoading(true);
    try {
      const res = await adminApi.getReviews(search);
      if (res.ok) {
        const data = res;
        setReviews(data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchReviews();
  }, [search]);

  const handleProcess = async (action:any |any| 'FLAG') => {
    if (!selectedReview) return;
    setIsProcessing(true);
    try {
      const res = await adminApi.processReview(selectedReview.id, action, processNotes);
      if (res.ok) {
        setSelectedReview(null);
        fetchReviews();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  const columns = [
    {
      key: 'id',
      header: 'Review Ref',
      render: (item: MutualReview) => (
        <div>
          <div className="font-mono text-slate-900 font-medium">{item.id}</div>
          <div className="text-[10px] text-slate-500">{formatDateTime(item.createdAt)}</div>
        </div>
      )
    },
    {
      key: 'reviewer',
      header: 'Reviewer',
      render: (item: MutualReview) => (
        <div>
          <div className="font-semibold text-slate-800">{item.reviewerName}</div>
          <div className="text-[10px] uppercase font-bold text-slate-500 bg-slate-100 px-1 py-0.5 inline-block rounded mt-0.5">
            {item.reviewerRole}
          </div>
        </div>
      )
    },
    {
      key: 'reviewed',
      header: 'Reviewed Entity',
      render: (item: MutualReview) => (
        <div>
          <div className="font-semibold text-slate-800">{item.reviewedName}</div>
          <div className="text-[10px] uppercase font-bold text-slate-500 bg-slate-100 px-1 py-0.5 inline-block rounded mt-0.5">
            {item.reviewedRole}
          </div>
        </div>
      )
    },
    {
      key: 'transaction',
      header: 'Transaction',
      render: (item: MutualReview) => (
        <span className="font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
          {item.transactionId}
        </span>
      )
    },
    {
      key: 'rating',
      header: 'Rating',
      render: (item: MutualReview) => (
        <div className="flex items-center gap-1">
          <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
          <span className="font-bold text-slate-900">{item.rating.toFixed(1)}</span>
        </div>
      )
    },
    {
      key: 'status',
      header: 'Status',
      render: (item: MutualReview) => <AdminStatusBadge status={item.status} />
    }
  ];

  return (
    <div id={id} className="space-y-6 animate-in fade-in duration-300">
      <AdminPageHeader
        title="Tri-Party Reviews"
        description="Monitor mutual reviews between Collectors, Aggregators, and Recyclers. Process pending reviews to update Trust Scores and Contribution Points safely."
        actions={
          <div className="flex gap-2">
            <div className="relative w-64">
              <input
                type="text"
                placeholder="Search reviewers, entities..."
                className="w-full text-xs pl-3 pr-8 py-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <button onClick={fetchReviews} className="p-2 border border-slate-200 rounded-lg text-slate-500 hover:text-slate-900 bg-white shadow-sm">
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        }
      />

      <AdminDataTable
        columns={columns}
        data={reviews}
        keyExtractor={(item) => item.id}
        isLoading={isLoading}
        onRowClick={(item) => setSelectedReview(item as MutualReview)}
      />

      <AdminModal
        isOpen={!!selectedReview}
        onClose={() => setSelectedReview(null)}
        title="Review Processing Center"
        maxWidth="xl"
      >
        {selectedReview && (
          <div className="space-y-5">
            {/* Header info */}
            <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-xl">
              <div>
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">Mutual Feedback</p>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-900">{selectedReview.reviewerName}</span>
                  <span className="text-slate-400 text-xs">→</span>
                  <span className="font-semibold text-slate-900">{selectedReview.reviewedName}</span>
                </div>
              </div>
              <div className="text-right">
                <AdminStatusBadge status={selectedReview.status} size="md" />
                <div className="text-xs text-slate-500 mt-1 font-mono">{selectedReview.transactionId}</div>
              </div>
            </div>

            {/* Criteria & Rating */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 border border-slate-200 rounded-xl">
                <div className="flex items-center gap-2 mb-3">
                  <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                  <span className="text-2xl font-bold text-slate-900">{selectedReview.rating.toFixed(1)}</span>
                </div>
                {selectedReview.comment && (
                  <p className="text-sm text-slate-700 italic border-l-2 border-emerald-200 pl-3">
                    "{selectedReview.comment}"
                  </p>
                )}
              </div>
              
              <div className="p-4 border border-slate-200 rounded-xl space-y-2">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">Criteria Breakdown</h4>
                {Object.entries(selectedReview.criteria).map(([key, val]) => (
                  val !== undefined && (
                    <div key={key} className="flex items-center justify-between text-xs">
                      <span className="text-slate-600 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                      <span className="font-bold text-slate-900">{val}/5</span>
                    </div>
                  )
                ))}
              </div>
            </div>

            {/* Admin Action Area (if pending or flagged) */}
            {(selectedReview.status === 'PENDING' || selectedReview.status === 'FLAGGED' || selectedReview.status === 'UNDER_REVIEW') && (
              <div className="bg-emerald-50/50 border border-emerald-200 rounded-xl p-4">
                <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-emerald-600" /> Admin Determination
                </h4>
                
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Score Impact Calculation</label>
                    <input 
                      type="number" 
                      className="w-full sm:w-1/3 p-2 bg-white border border-slate-300 rounded text-sm text-slate-900"
                      value={scoreImpact}
                      onChange={(e) => setScoreImpact(Number(e.target.value))}
                      placeholder="e.g. 5, -2"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">Adjust Contribution Points or Trust Score based on backend rules.</p>
                  </div>
                  
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Audit Notes (Optional)</label>
                    <textarea 
                      className="w-full p-2 bg-white border border-slate-300 rounded text-sm text-slate-900 h-20 resize-none"
                      value={processNotes}
                      onChange={(e) => setProcessNotes(e.target.value)}
                      placeholder="Enter verification notes..."
                    />
                  </div>

                  <div className="flex gap-2 justify-end pt-2">
                    <button 
                      onClick={() => handleProcess('REJECT')}
                      disabled={isProcessing}
                      className="px-4 py-2 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded hover:bg-rose-100 transition-colors"
                    >
                      Reject Feedback
                    </button>
                    <button 
                      onClick={() => handleProcess('FLAG')}
                      disabled={isProcessing}
                      className="px-4 py-2 text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 rounded hover:bg-amber-100 transition-colors"
                    >
                      Flag for Investigation
                    </button>
                    <button 
                      onClick={() => handleProcess('APPROVE')}
                      disabled={isProcessing}
                      className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 rounded hover:bg-emerald-700 transition-colors shadow-sm"
                    >
                      Approve & Update Scores
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </AdminModal>
    </div>
  );
};
