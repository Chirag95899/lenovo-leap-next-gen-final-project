import React from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { AdminPagination } from '../components/AdminPagination';
import { formatDateTime } from '../utils/formatters';
import { AiActivity } from '../../shared/types/domain';
import { TableColumn } from '../types/admin';
import { Bot } from 'lucide-react';

interface AdminAiActivityPageProps {
  data: AiActivity[];
  total: number;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  isLoading: boolean;
}

export const AdminAiActivityPage: React.FC<AdminAiActivityPageProps> = ({
  data,
  total,
  page,
  totalPages,
  setPage,
  isLoading,
}) => {
  const columns: TableColumn<AiActivity>[] = [
    {
      key: 'timestamp',
      header: 'Time',
      render: (a) => (
        <span className="font-mono text-xs text-slate-500 whitespace-nowrap">
          {formatDateTime(a.timestamp)}
        </span>
      ),
    },
    {
      key: 'intent',
      header: 'Intent',
      render: (a) => (
        <span className="font-bold text-xs text-slate-800 font-mono">
          {a.intent.replace(/_/g, ' ')}
        </span>
      ),
    },
    {
      key: 'language',
      header: 'Lang',
      render: (a) => (
        <span className="text-xs uppercase bg-slate-100 px-2 py-0.5 rounded font-mono text-slate-600 border border-slate-200">
          {a.language}
        </span>
      ),
    },
    {
      key: 'user',
      header: 'User/Role',
      render: (a) => (
        <div className="text-xs">
          <span className="font-semibold text-slate-900">{a.userId}</span>
          {a.userRole && <div className="text-[11px] text-slate-400 font-mono">{a.userRole}</div>}
        </div>
      ),
    },
    {
      key: 'action',
      header: 'Action',
      render: (a) => <span className="text-xs text-slate-600">{a.action}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      render: (a) => (
        <span className={`text-xs px-2 py-0.5 rounded border \${
          a.status === 'SUCCESS' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
          a.status === 'FAILED' ? 'bg-red-50 text-red-700 border-red-200' :
          'bg-amber-50 text-amber-700 border-amber-200'
        }`}>
          {a.status}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <AdminPageHeader
        title="AI Interaction Ledger"
        description="Aggregated metadata of AI-assisted conversations and automated intent resolutions."
        badge={
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            <Bot className="w-3.5 h-3.5 text-slate-500" />
            AI Diagnostics
          </span>
        }
      />
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <AdminDataTable
          columns={columns}
          data={data}
          keyExtractor={(a) => a.id}
          isLoading={isLoading}
          emptyTitle="No AI activity found"
        />
        <AdminPagination
          currentPage={page}
          totalPages={totalPages}
          totalItems={total}
          itemsPerPage={15}
          onPageChange={setPage}
        />
      </div>
    </div>
  );
};
