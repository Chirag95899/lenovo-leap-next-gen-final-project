import React, { useState } from 'react';
import { Recycle, Shield, Lock, AlertCircle, Loader2, ArrowRight } from 'lucide-react';

interface AdminLoginPageProps {
  onLogin: (adminId: string, pass: string) => Promise<any>;
  isLoading?: boolean;
  error?: string | null;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({
  onLogin,
  isLoading = false,
  error: externalError,
}) => {
  const [adminId, setAdminId] = useState('ADMIN-RECY-01');
  const [password, setPassword] = useState('RecySetuAdmin2026!');
  const [localError, setLocalError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);

    if (!adminId.trim() || !password.trim()) {
      setLocalError('Please enter both Admin ID and Password.');
      return;
    }

    try {
      await onLogin(adminId.trim(), password);
    } catch (err: any) {
      setLocalError(err.message || 'Authentication failed. Please check credentials.');
    }
  };

  const activeError = externalError || localError;

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background visual geometric accent */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-30 pointer-events-none" />

      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10 px-4">
        <div className="flex justify-center mb-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-600 flex items-center justify-center text-white shadow-lg ring-4 ring-emerald-500/20">
            <Recycle className="w-7 h-7" />
          </div>
        </div>

        <h2 className="text-center text-2xl font-bold tracking-tight text-white">
          RECYSETU Command Center
        </h2>
        <p className="mt-1 text-center text-xs text-slate-400 italic">
          "Empowering Informal Recycling, Building a Cleaner Future"
        </p>

        <div className="mt-2 text-center">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
            <Shield className="w-3 h-3 text-emerald-400" />
            Central Administrator Portal
          </span>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md relative z-10 px-4">
        <div className="bg-white py-8 px-6 shadow-xl rounded-2xl sm:px-10 border border-slate-200">
          {activeError && (
            <div className="mb-6 p-3.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{activeError}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="admin-id-input" className="block text-xs font-semibold uppercase text-slate-700 tracking-wider">
                Admin Identification ID
              </label>
              <div className="mt-1 relative rounded-md shadow-2xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Shield className="w-4 h-4" />
                </div>
                <input
                  id="admin-id-input"
                  name="adminId"
                  type="text"
                  required
                  value={adminId}
                  onChange={(e) => setAdminId(e.target.value)}
                  placeholder="e.g. ADMIN-RECY-01"
                  className="w-full pl-9 pr-3 py-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 font-mono placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>
            </div>

            <div>
              <label htmlFor="admin-password-input" className="block text-xs font-semibold uppercase text-slate-700 tracking-wider">
                Password
              </label>
              <div className="mt-1 relative rounded-md shadow-2xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="admin-password-input"
                  name="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-9 pr-3 py-2.5 border border-slate-300 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                id="admin-submit-btn"
                type="submit"
                disabled={isLoading}
                className="w-full flex justify-center items-center gap-2 py-2.5 px-4 border border-transparent rounded-lg shadow-xs text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-hidden focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 disabled:opacity-50 transition-colors"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Verifying Authorization...</span>
                  </>
                ) : (
                  <>
                    <span>Authenticate Admin Session</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Quick Demo Credential Helper */}
          <div className="mt-6 pt-5 border-t border-slate-100 bg-slate-50/70 -mx-6 -mb-8 p-5 rounded-b-2xl">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-700 mb-2">
              <span>Demo Security Clearance:</span>
              <span className="text-emerald-700 font-mono">Role: ADMIN</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <button
                type="button"
                onClick={() => {
                  setAdminId('ADMIN-RECY-01');
                  setPassword('RecySetuAdmin2026!');
                }}
                className="p-2 rounded bg-white border border-slate-200 text-left hover:border-emerald-500 transition-colors"
              >
                <div className="font-bold text-slate-800">Admin 01 (Lead)</div>
                <div className="font-mono text-slate-500 text-[10px]">ADMIN-RECY-01</div>
              </button>
              <button
                type="button"
                onClick={() => {
                  setAdminId('ADMIN-RECY-02');
                  setPassword('RecySetuAdmin2026!');
                }}
                className="p-2 rounded bg-white border border-slate-200 text-left hover:border-emerald-500 transition-colors"
              >
                <div className="font-bold text-slate-800">Admin 02 (Ops)</div>
                <div className="font-mono text-slate-500 text-[10px]">ADMIN-RECY-02</div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
