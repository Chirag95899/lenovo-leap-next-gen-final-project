import { adminApi } from '../services/adminApiService';
import React, { useState, useEffect } from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { Award, Search, Shield, RefreshCw, Star, Edit3 } from 'lucide-react';
import { User } from '../../shared/types/domain';
import { AdminModal } from '../components/AdminModal';

interface AdminTrustRewardsPageProps {
  id?: string;
  onNavigateToView: (view: string) => void;
}

export const AdminTrustRewardsPage: React.FC<AdminTrustRewardsPageProps> = ({ id = 'admin-trust-page', onNavigateToView }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [overrideScore, setOverrideScore] = useState<number>(0);
  const [overrideReason, setOverrideReason] = useState('');
  const [isOverriding, setIsOverriding] = useState(false);

  const fetchUsers = async () => {
    setIsLoading(true);
    try {
      // Just fetching all users and filtering by roles that matter for trust
      const res = await adminApi.getUsers({ search, limit: 50 });
      if (res) {
        const data = res;
        const relevantUsers = data.data.filter((u: User) => ['COLLECTOR', 'AGGREGATOR', 'RECYCLER'].includes(u.role));
        setUsers(relevantUsers);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [search]);

  const handleOverride = async () => {
    if (!selectedUser) return;
    setIsOverriding(true);
    try {
      const res = await adminApi.getUsers({ search, limit: 50 });
      if (res) {
        setSelectedUser(null);
        fetchUsers();
      } else {
        const err: any = res;
        alert(err.message);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsOverriding(false);
    }
  };

  const openOverrideModal = (user: User) => {
    setSelectedUser(user);
    setOverrideScore(user.role === 'COLLECTOR' ? (user.contributionPoints || 0) : (user.trustScore || 0));
    setOverrideReason('');
  };

  const columns = [
    {
      key: 'name',
      header: 'Stakeholder',
      render: (item: User) => (
        <div>
          <div className="font-bold text-slate-900">{item.organizationName || item.name}</div>
          <div className="text-[10px] text-slate-500 font-mono">{item.id}</div>
        </div>
      )
    },
    {
      key: 'role',
      header: 'Ecosystem Role',
      render: (item: User) => (
        <span className="text-[10px] uppercase font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
          {item.role}
        </span>
      )
    },
    {
      key: 'score',
      header: 'Trust / Contribution Score',
      render: (item: User) => {
        if (item.role === 'COLLECTOR') {
          return (
            <div className="flex items-center gap-1.5">
              <Award className="w-4 h-4 text-emerald-600" />
              <span className="font-bold text-emerald-700">{item.contributionPoints || 0} pts</span>
            </div>
          );
        } else {
          return (
            <div className="flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-blue-600" />
              <span className="font-bold text-blue-700">{item.trustScore || 0} / 100</span>
            </div>
          );
        }
      }
    },
    {
      key: 'tier',
      header: 'Reward Tier',
      render: (item: User) => {
        if (item.role !== 'COLLECTOR') return <span className="text-slate-400 text-xs">—</span>;
        const pts = item.contributionPoints || 0;
        let tier = 'Basic';
        let color = 'bg-slate-100 text-slate-600';
        if (pts >= 900) { tier = 'Platinum'; color = 'bg-purple-100 text-purple-700'; }
        else if (pts >= 750) { tier = 'Gold'; color = 'bg-amber-100 text-amber-700'; }
        else if (pts >= 500) { tier = 'Silver'; color = 'bg-slate-200 text-slate-800'; }
        else if (pts >= 200) { tier = 'Bronze'; color = 'bg-orange-100 text-orange-800'; }
        
        return <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${color}`}>{tier}</span>;
      }
    },
    {
      key: 'actions',
      header: '',
      align: 'right' as const,
      render: (item: User) => (
        <button 
          onClick={(e) => { e.stopPropagation(); openOverrideModal(item); }}
          className="text-slate-400 hover:text-emerald-600 transition-colors p-1"
          title="Override Score"
        >
          <Edit3 className="w-4 h-4" />
        </button>
      )
    }
  ];

  return (
    <div id={id} className="space-y-6 animate-in fade-in duration-300">
      <AdminPageHeader
        title="Trust & Rewards Engine"
        description="Monitor and manage Collector Contribution Points and Aggregator/Recycler Trust Scores. Scores are calculated dynamically from Tri-Party Reviews and ecosystem participation."
        actions={
          <div className="flex gap-2">
            <div className="relative w-64">
              <input
                type="text"
                placeholder="Search users..."
                className="w-full text-xs pl-3 pr-8 py-2 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <button onClick={fetchUsers} className="p-2 border border-slate-200 rounded-lg text-slate-500 hover:text-slate-900 bg-white shadow-sm">
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        }
      />

      <AdminDataTable
        columns={columns}
        data={users}
        keyExtractor={(item) => item.id}
        isLoading={isLoading}
      />

      <AdminModal
        isOpen={!!selectedUser}
        onClose={() => setSelectedUser(null)}
        title="Manual Score Override"
        maxWidth="md"
      >
        {selectedUser && (
          <div className="space-y-4">
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800">
              <strong>Warning:</strong> Manual overrides bypass the automated Trust Engine. This action is permanently recorded in the Immutable Audit Log with your Admin ID.
            </div>
            
            <div className="flex justify-between items-center bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div>
                <div className="font-bold text-slate-900">{selectedUser.name}</div>
                <div className="text-[10px] text-slate-500">{selectedUser.role}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-500">Current Score</div>
                <div className="font-bold text-slate-900 text-lg">
                  {selectedUser.role === 'COLLECTOR' ? (selectedUser.contributionPoints || 0) : (selectedUser.trustScore || 0)}
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">New Score Value</label>
              <input 
                type="number" 
                className="w-full p-2 bg-white border border-slate-300 rounded text-sm text-slate-900"
                value={overrideScore}
                onChange={(e) => setOverrideScore(Number(e.target.value))}
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Audit Reason (Mandatory)</label>
              <textarea 
                className="w-full p-2 bg-white border border-slate-300 rounded text-sm text-slate-900 h-24 resize-none"
                value={overrideReason}
                onChange={(e) => setOverrideReason(e.target.value)}
                placeholder="Required explanation for compliance..."
              />
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <button 
                onClick={() => setSelectedUser(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded hover:bg-slate-200"
              >
                Cancel
              </button>
              <button 
                onClick={handleOverride}
                disabled={isOverriding || overrideReason.length < 5}
                className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 rounded hover:bg-emerald-700 disabled:opacity-50"
              >
                Confirm & Override
              </button>
            </div>
          </div>
        )}
      </AdminModal>
    </div>
  );
};
