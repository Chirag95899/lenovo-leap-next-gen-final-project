import React, { useState } from 'react';
import { AdminLoadingState } from '../components/AdminLoadingState';
import { AdminErrorState } from '../components/AdminErrorState';
import { DashboardResponseData } from '../types/dashboard';
import { IndiaMap } from '../components/IndiaMap';
import { AdminView } from '../types/admin';
import { 
  RefreshCw, MapPin, Database, TrendingUp, CheckCircle, 
  AlertTriangle, Leaf, ChevronDown, PackageCheck, Zap,
  Activity, ArrowUpRight
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend 
} from 'recharts';

interface AdminDashboardPageProps {
  data: DashboardResponseData | null;
  isLoading: boolean;
  isRefreshing?: boolean;
  error: string | null;
  onRefresh: () => void;
  onNavigateToView: (view: AdminView, filters?: Record<string, string>) => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({
  data,
  isLoading,
  isRefreshing = false,
  error,
  onRefresh,
  onNavigateToView,
}) => {
  const [selectedState, setSelectedState] = useState('Chhattisgarh');
  const [selectedDistrict, setSelectedDistrict] = useState('Durg');

  if (isLoading && !data) {
    return <AdminLoadingState message="Connecting to RECYSETU Central Command Core..." />;
  }

  if (error && !data) {
    return (
      <AdminErrorState
        title="Command Center Telemetry Disconnected"
        message={error}
        onRetry={onRefresh}
      />
    );
  }

  const overview = data?.overview || {} as any;
  const throughputDays = data?.throughputDays || [];
  const flaggedItems = data?.flaggedAttentionItems || [];

  const isDurgActive = selectedState === 'Chhattisgarh' && selectedDistrict === 'Durg';

  // Metrics
  const ongoingProcesses = (overview.activeLots || 0) + (overview.pendingPickups || 0);
  const completedProcesses = (overview.recycledLots || 0) + (overview.completedPickups || 0);
  
  const wasteProcessed = overview.materialCollectedTons || 0;
  const wasteRecycled = overview.recyclingCompletedTons || 0;
  
  const currentEarnings = overview.totalDisbursedInr || 0;
  // Fallback to simulated previous if backend patch didn't apply
  const previousEarnings = overview.previousDisbursedInr || (currentEarnings * 0.82); 
  const earningsIncrease = previousEarnings > 0 ? ((currentEarnings - previousEarnings) / previousEarnings) * 100 : 0;
  const co2Offset = overview.co2OffsetTons || overview.estimatedCo2OffsetTons || 0;

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6 pb-20">
      {/* LEVEL 1 — WHERE ARE WE? */}
      <div className="bg-white border border-slate-200 shadow-sm rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
            <Activity className="w-6 h-6 text-emerald-600" />
            National Operations Command
          </h1>
          <p className="text-sm text-slate-500 font-medium mt-1">Platform Impact & Geographic Intelligence</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Country</span>
            <span className="text-sm font-semibold text-slate-900 flex items-center gap-1">
              India <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
            </span>
          </div>

          <div className="relative group">
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="appearance-none bg-white border border-slate-200 text-slate-900 text-sm font-semibold rounded-lg pl-3 pr-8 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer shadow-sm"
            >
              <option value="Chhattisgarh">Chhattisgarh</option>
              <option value="Maharashtra">Maharashtra (Coming Soon)</option>
              <option value="Karnataka">Karnataka (Coming Soon)</option>
              <option value="Delhi">Delhi (Coming Soon)</option>
            </select>
            <ChevronDown className="w-4 h-4 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          <div className="relative group">
            <select
              value={selectedDistrict}
              onChange={(e) => setSelectedDistrict(e.target.value)}
              disabled={selectedState !== 'Chhattisgarh'}
              className="appearance-none bg-white border border-slate-200 text-slate-900 text-sm font-semibold rounded-lg pl-3 pr-8 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer shadow-sm disabled:opacity-50 disabled:bg-slate-50"
            >
              {selectedState === 'Chhattisgarh' ? (
                <>
                  <option value="Durg">Durg</option>
                  <option value="Raipur">Raipur (Inactive)</option>
                  <option value="Bilai">Bhilai (Inactive)</option>
                </>
              ) : (
                <option value="none">--</option>
              )}
            </select>
            <ChevronDown className="w-4 h-4 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
          
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="p-2 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 hover:text-emerald-600 transition-colors disabled:opacity-50"
            title="Refresh Telemetry"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-emerald-600' : ''}`} />
          </button>
        </div>
      </div>

      
      {/* MAP AND HIGHLIGHTS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col h-full">
          <div className="flex items-center justify-between mb-4">
             <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
               <MapPin className="w-5 h-5 text-emerald-600" />
               Geographic Intelligence
             </h3>
             <div className="text-xs font-semibold text-slate-500 flex items-center gap-2">
               <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500 block"></span> Active</span>
               <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-300 block"></span> Pending</span>
             </div>
          </div>
          <div className="flex-1 w-full min-h-[400px]">
             <IndiaMap 
               data={[{
                 state: 'Chhattisgarh',
                 status: 'ACTIVE',
                 totalStakeholders: (overview.totalCollectors || 0) + (overview.totalAggregators || 0) + (overview.totalRecyclers || 0),
                 wasteRecycledKg: (overview.recyclingCompletedTons || 0) * 1000,
               }]}
               selectedState={selectedState}
               onSelectState={(state) => {
                 setSelectedState(state);
                 if (state === 'Chhattisgarh') setSelectedDistrict('Durg');
                 else setSelectedDistrict('');
               }}
             />
          </div>
        </div>

        <div className="space-y-4 flex flex-col">
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 shadow-sm">
             <h3 className="text-sm font-bold text-emerald-900 mb-2">RECYSETU Impact</h3>
             <div className="flex items-end gap-2 mb-1">
               <span className="text-3xl font-black text-emerald-700">{co2Offset.toLocaleString(undefined, {maximumFractionDigits: 1})}</span>
               <span className="text-sm font-bold text-emerald-600 mb-1">Tons CO₂e</span>
             </div>
             <p className="text-xs text-emerald-700 font-medium leading-relaxed">Emissions offset through verified circular operations. Verified via traceable e-waste manifests.</p>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex-1">
            <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-500" />
              Network Activity
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                <span className="text-sm text-slate-600 font-medium">Active Collectors</span>
                <span className="text-sm font-bold text-slate-900">{overview.activeWorkersCount || 0} / {overview.totalCollectors || 0}</span>
              </div>
              <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                <span className="text-sm text-slate-600 font-medium">Aggregators</span>
                <span className="text-sm font-bold text-slate-900">{overview.totalAggregators || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600 font-medium">Recycling Facilities</span>
                <span className="text-sm font-bold text-slate-900">{overview.totalRecyclers || 0}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
  
<>
          {/* LEVEL 2 & 3 — WHAT IS HAPPENING? & HOW MUCH? */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Ongoing Processes</h3>
                  <p className="text-2xl font-black text-slate-900">{ongoingProcesses.toLocaleString()}</p>
                </div>
              </div>
              <p className="text-xs font-medium text-slate-500">Active pickups and processing lots</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600">
                  <PackageCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Completed Processes</h3>
                  <p className="text-2xl font-black text-slate-900">{completedProcesses.toLocaleString()}</p>
                </div>
              </div>
              <p className="text-xs font-medium text-slate-500">Successfully recycled and finalized</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Waste Processed</h3>
                  <div className="flex items-baseline gap-1">
                    <p className="text-2xl font-black text-slate-900">{wasteProcessed.toLocaleString()}</p>
                    <span className="text-sm font-bold text-slate-500">Tonnes</span>
                  </div>
                </div>
              </div>
              <p className="text-xs font-medium text-slate-500">Total volume entered workflow</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600">
                  <CheckCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Waste Recycled</h3>
                  <div className="flex items-baseline gap-1">
                    <p className="text-2xl font-black text-slate-900">{wasteRecycled.toLocaleString()}</p>
                    <span className="text-sm font-bold text-slate-500">Tonnes</span>
                  </div>
                </div>
              </div>
              <p className="text-xs font-medium text-slate-500">Successfully reached end-of-life</p>
            </div>
          </div>

          {/* LARGE VISUALIZATION */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Operational Volume</h3>
                <p className="text-sm text-slate-500 font-medium">Collected vs Recycled throughput over the last 7 days</p>
              </div>
            </div>
            <div className="p-5 h-[360px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={throughputDays} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorCollected" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorRecycled" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="day" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#64748b', fontSize: 12, fontWeight: 500 }} 
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#64748b', fontSize: 12, fontWeight: 500 }}
                    tickFormatter={(value) => `${value}kg`}
                  />
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)' }}
                    itemStyle={{ fontWeight: 600 }}
                    labelStyle={{ color: '#64748b', fontWeight: 600, marginBottom: '4px' }}
                  />
                  <Legend iconType="circle" wrapperStyle={{ paddingTop: '20px' }} />
                  <Area 
                    type="monotone" 
                    dataKey="collectedKg" 
                    name="Collected Volume (kg)" 
                    stroke="#10b981" 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorCollected)" 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="recycledKg" 
                    name="Recycled Volume (kg)" 
                    stroke="#3b82f6" 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorRecycled)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* LEVEL 4 — PLATFORM IMPACT */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-bl-full -mr-16 -mt-16 transition-transform group-hover:scale-110" />
              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-6">
                  <Leaf className="w-5 h-5 text-emerald-600" />
                  <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider">Environmental Impact</h3>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-black text-emerald-600">{wasteRecycled.toLocaleString()}</span>
                      <span className="text-lg font-bold text-slate-500">Tonnes</span>
                    </div>
                    <p className="text-sm font-medium text-slate-600 mt-1">
                      E-waste successfully recycled through RECYSETU
                    </p>
                  </div>
                  
                  <div className="pt-5 border-t border-slate-100">
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-black text-slate-900">{co2Offset.toLocaleString()}</span>
                      <span className="text-sm font-bold text-slate-500">Tonnes CO₂</span>
                    </div>
                    <p className="text-xs font-medium text-slate-500 mt-1">
                      Estimated carbon emissions offset
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-bl-full -mr-16 -mt-16 transition-transform group-hover:scale-110" />
              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-6">
                  <Zap className="w-5 h-5 text-blue-600" />
                  <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider">Financial Impact</h3>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-black text-blue-600">₹{currentEarnings.toLocaleString()}</span>
                    </div>
                    <p className="text-sm font-medium text-slate-600 mt-1">
                      Total Current Earnings (Distributed to users)
                    </p>
                  </div>
                  
                  <div className="pt-5 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <div className="flex items-baseline gap-2">
                        <span className="text-xl font-bold text-slate-400 line-through">₹{previousEarnings.toLocaleString()}</span>
                      </div>
                      <p className="text-xs font-medium text-slate-500 mt-1">
                        Previous Period Earnings
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-lg border border-emerald-100">
                      <ArrowUpRight className="w-4 h-4" />
                      <span className="text-sm font-bold">+{earningsIncrease.toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* LEVEL 5 — WHAT NEEDS ADMIN ATTENTION? */}
          {flaggedItems && flaggedItems.length > 0 && (
            <div className="bg-white border border-rose-200 rounded-xl shadow-sm overflow-hidden">
              <div className="bg-rose-50 border-b border-rose-100 p-4 flex items-center justify-between">
                <div className="flex items-center gap-2 text-rose-700">
                  <AlertTriangle className="w-5 h-5" />
                  <h3 className="text-sm font-bold uppercase tracking-wider">Requires Admin Attention</h3>
                </div>
                <span className="bg-rose-200 text-rose-800 text-xs font-bold px-2 py-1 rounded-md">
                  {flaggedItems.length} Issues
                </span>
              </div>
              <div className="divide-y divide-slate-100">
                {flaggedItems.slice(0, 5).map((item) => (
                  <div key={item.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 transition-colors">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="w-2 h-2 rounded-full bg-rose-500" />
                        <span className="text-sm font-bold text-slate-900">{item.title}</span>
                      </div>
                      <p className="text-xs font-medium text-slate-500 pl-4">{item.description}</p>
                    </div>
                    <button 
                      onClick={() => onNavigateToView(item.targetView, item.filterPayload)}
                      className="shrink-0 px-3 py-1.5 bg-white border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
                    >
                      {item.actionLabel}
                    </button>
                  </div>
                ))}
              </div>
            </div>

          )}
        </>
    </div>
  );
};
