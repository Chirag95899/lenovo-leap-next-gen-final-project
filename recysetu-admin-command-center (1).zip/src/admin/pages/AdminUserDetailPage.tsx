import React, { useState } from 'react';
import {
  ArrowLeft,
  ShieldCheck,
  AlertTriangle,
  Building2,
  Calendar,
  MapPin,
  Phone,
  Mail,
  Award,
  Package,
  Boxes,
  CreditCard,
  FileText,
  History,
  CheckCircle2,
  XCircle,
  RotateCcw,
  UserCheck,
  Scale,
  Factory,
  Copy,
  Check,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';
import { User, UserRole } from '../../shared/types/domain';
import { useUserDetailQuery } from '../hooks/useAdminDomainQueries';
import { AdminUserActionDialog, UserActionType } from '../components/AdminUserActionDialog';
import { adminApi } from '../services/adminApiService';

interface AdminUserDetailPageProps {
  userId: string;
  onBack: () => void;
  onNavigateToUser?: (userId: string) => void;
}

export const AdminUserDetailPage: React.FC<AdminUserDetailPageProps> = ({
  userId,
  onBack,
}) => {
  const { data: dossier, isLoading, error, refetch } = useUserDetailQuery(userId);
  const [activeTab, setActiveTab] = useState<'overview' | 'operations' | 'complaints' | 'payments' | 'audit'>('overview');
  const [copiedId, setCopiedId] = useState(false);

  // Dialog state for sensitive actions
  const [actionType, setActionType] = useState<UserActionType | null>(null);
  const [isActionLoading, setIsActionLoading] = useState(false);

  if (isLoading) {
    return (
      <div className="p-8 flex flex-col items-center justify-center min-h-[400px]">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm text-slate-500 font-medium">Loading stakeholder dossier from secure vault...</p>
      </div>
    );
  }

  if (error || !dossier) {
    return (
      <div className="p-8 max-w-2xl mx-auto">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Directory</span>
        </button>
        <div className="p-6 bg-rose-50 border border-rose-200 rounded-2xl text-center">
          <AlertTriangle className="w-10 h-10 text-rose-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-rose-900 mb-1">Dossier Unavailable</h3>
          <p className="text-sm text-rose-700 mb-4">{error || 'Requested user record does not exist or access is restricted.'}</p>
          <button
            onClick={onBack}
            className="px-4 py-2 bg-rose-600 text-white text-xs font-semibold rounded-lg hover:bg-rose-700"
          >
            Return to User Directory
          </button>
        </div>
      </div>
    );
  }

  const { user, stats, pickups, lots, complaints, payments, auditHistory } = dossier;

  const copyUserId = () => {
    navigator.clipboard.writeText(user.id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleExecuteAction = async (reason: string, targetRole?: UserRole) => {
    setIsActionLoading(true);
    try {
      if (actionType === 'VERIFY_RECYCLER') {
        await adminApi.verifyRecycler(user.id, reason);
      } else if (actionType === 'REJECT_RECYCLER') {
        await adminApi.rejectRecycler(user.id, reason);
      } else if (actionType === 'SUSPEND') {
        await adminApi.suspendUser(user.id, reason);
      } else if (actionType === 'REACTIVATE') {
        await adminApi.reactivateUser(user.id, reason);
      } else if (actionType === 'VERIFY_KYC') {
        await adminApi.verifyKyc(user.id, reason);
      } else if (actionType === 'CHANGE_ROLE' && targetRole) {
        await adminApi.changeUserRole(user.id, targetRole, reason);
      }
      await refetch();
      setActionType(null);
    } catch (err: any) {
      alert(err.message || 'Operation failed. Please verify admin privileges.');
    } finally {
      setIsActionLoading(false);
    }
  };

  const isRecycler = user.role === 'RECYCLER';
  const isCollector = user.role === 'COLLECTOR';
  const isAggregator = user.role === 'AGGREGATOR';

  return (
    <div id="admin-user-detail-page" className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Navigation Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button
          id="back-to-users-btn"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 px-3.5 py-2 rounded-lg shadow-2xs hover:bg-slate-50 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Directory</span>
        </button>

        {/* Action Buttons Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Recycler Specific Verification Controls */}
          {isRecycler && (
            <>
              {user.status === 'PENDING_VERIFICATION' || user.verificationStatus === 'PENDING' ? (
                <>
                  <button
                    id="verify-recycler-btn"
                    onClick={() => setActionType('VERIFY_RECYCLER')}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-2xs transition-colors"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Verify Recycler</span>
                  </button>
                  <button
                    id="reject-recycler-btn"
                    onClick={() => setActionType('REJECT_RECYCLER')}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-white border border-rose-300 text-rose-700 hover:bg-rose-50 rounded-lg text-xs font-bold transition-colors"
                  >
                    <XCircle className="w-4 h-4" />
                    <span>Reject Application</span>
                  </button>
                </>
              ) : null}

              {user.verificationStatus === 'REJECTED' && (
                <button
                  id="re-verify-recycler-btn"
                  onClick={() => setActionType('VERIFY_RECYCLER')}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-2xs transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Re-review & Verify</span>
                </button>
              )}
            </>
          )}

          {/* KYC Verification for Collectors and Aggregators */}
          {!isRecycler && !user.kycVerified && user.role !== 'ADMIN' && (
            <button
              id="verify-kyc-btn"
              onClick={() => setActionType('VERIFY_KYC')}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-2xs transition-colors"
            >
              <UserCheck className="w-4 h-4" />
              <span>Verify KYC</span>
            </button>
          )}

          {/* Suspend / Reactivate Controls */}
          {user.status === 'ACTIVE' && user.role !== 'ADMIN' && (
            <button
              id="suspend-user-btn"
              onClick={() => setActionType('SUSPEND')}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-white border border-rose-200 text-rose-700 hover:bg-rose-50 rounded-lg text-xs font-bold transition-colors"
            >
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span>Suspend Account</span>
            </button>
          )}

          {user.status === 'SUSPENDED' && (
            <button
              id="reactivate-user-btn"
              onClick={() => setActionType('REACTIVATE')}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-2xs transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reactivate User</span>
            </button>
          )}

          {/* Change Role (Security Protected) */}
          <button
            id="change-role-btn"
            onClick={() => setActionType('CHANGE_ROLE')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
          >
            <span>Change Role</span>
          </button>
        </div>
      </div>

      {/* Main Profile Header Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 shrink-0 shadow-2xs">
              {isRecycler ? (
                <Factory className="w-7 h-7 text-emerald-700" />
              ) : isAggregator ? (
                <Building2 className="w-7 h-7 text-blue-700" />
              ) : (
                <Package className="w-7 h-7 text-amber-700" />
              )}
            </div>

            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900">
                  {user.organizationName || user.name}
                </h1>
                {user.organizationName && user.name !== user.organizationName && (
                  <span className="text-xs text-slate-500 font-medium">({user.name})</span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2 text-xs">
                {/* ID with copy */}
                <button
                  onClick={copyUserId}
                  className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-700 rounded font-mono text-[11px] hover:bg-slate-200 transition-colors"
                  title="Click to copy User ID"
                >
                  <span>{user.id}</span>
                  {copiedId ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-400" />}
                </button>

                {user.adminId && (
                  <span className="px-2 py-0.5 bg-slate-800 text-white rounded font-mono text-[11px] font-bold">
                    {user.adminId}
                  </span>
                )}

                {/* Role Pill */}
                <span className="px-2.5 py-0.5 rounded-full bg-slate-200 text-slate-800 font-bold uppercase tracking-wider text-[10px]">
                  {user.role}
                </span>

                {/* Account Status Pill */}
                <span
                  className={`px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider text-[10px] ${
                    user.status === 'ACTIVE'
                      ? 'bg-emerald-100 text-emerald-800'
                      : user.status === 'SUSPENDED'
                      ? 'bg-rose-100 text-rose-800'
                      : user.status === 'REJECTED'
                      ? 'bg-red-100 text-red-900'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {user.status.replace(/_/g, ' ')}
                </span>

                {/* Verification Status */}
                {isRecycler ? (
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      user.verificationStatus === 'VERIFIED'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : user.verificationStatus === 'REJECTED'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : user.verificationStatus === 'SUSPENDED'
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}
                  >
                    <ShieldCheck className="w-3 h-3" />
                    <span>Recycler: {user.verificationStatus || 'PENDING'}</span>
                  </span>
                ) : (
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                      user.kycVerified
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}
                  >
                    {user.kycVerified ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                    <span>KYC: {user.kycVerified ? 'VERIFIED' : 'PENDING'}</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Quick Contact & Registration Meta */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5 text-xs text-slate-600 bg-slate-50 p-3.5 rounded-xl border border-slate-100 md:max-w-md">
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="truncate">{user.email}</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>{user.phone}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="truncate">{user.location.city}, {user.location.state}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>Reg: {new Date(user.createdAt).toLocaleDateString('en-IN')}</span>
            </div>
          </div>
        </div>

        {/* Rejection / Suspension Notice if applicable */}
        {user.status === 'REJECTED' && user.rejectionReason && (
          <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2 text-xs text-rose-800">
            <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <strong>Rejection Justification:</strong> {user.rejectionReason}
            </div>
          </div>
        )}

        {user.status === 'SUSPENDED' && user.suspensionReason && (
          <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2 text-xs text-amber-900">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong>Suspension Justification:</strong> {user.suspensionReason}
            </div>
          </div>
        )}
      </div>

      {/* KPI Cards Row (Tailored to Role) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {isCollector ? (
          <>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Pickups Logged</p>
              <p className="text-xl font-black text-slate-900 mt-1">{stats.pickupCount}</p>
              <p className="text-[10px] text-slate-400">Total requests</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Weight Collected</p>
              <p className="text-xl font-black text-emerald-700 mt-1">
                {(user.metrics.totalCollectedKg || 0).toLocaleString('en-IN')} <span className="text-xs font-bold text-slate-500">kg</span>
              </p>
              <p className="text-[10px] text-slate-400">Total volume</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Reward Points</p>
              <p className="text-xl font-black text-amber-600 mt-1">
                {(user.points || 0).toLocaleString('en-IN')}
              </p>
              <p className="text-[10px] text-slate-400">Incentive wallet</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Contribution Score</p>
              <p className="text-xl font-black text-blue-700 mt-1">
                {user.contributionScore || user.metrics.complianceScore || 90}%
              </p>
              <p className="text-[10px] text-slate-400">Operational score</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Associated Lots</p>
              <p className="text-xl font-black text-slate-900 mt-1">{stats.lotCount}</p>
              <p className="text-[10px] text-slate-400">Batched in depots</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Total Earnings</p>
              <p className="text-xl font-black text-emerald-700 mt-1">
                ₹{(user.metrics.totalEarnings || stats.totalAmountInr).toLocaleString('en-IN')}
              </p>
              <p className="text-[10px] text-slate-400">Disbursed amount</p>
            </div>
          </>
        ) : isAggregator ? (
          <>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Inbound Pickups</p>
              <p className="text-xl font-black text-slate-900 mt-1">{stats.pickupCount}</p>
              <p className="text-[10px] text-slate-400">Received supply</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Lots Dispatched</p>
              <p className="text-xl font-black text-blue-700 mt-1">{stats.lotCount}</p>
              <p className="text-[10px] text-slate-400">Aggregated batches</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Dispatched Volume</p>
              <p className="text-xl font-black text-emerald-700 mt-1">
                {(user.metrics.totalDispatchedKg || 0).toLocaleString('en-IN')} <span className="text-xs font-bold text-slate-500">kg</span>
              </p>
              <p className="text-[10px] text-slate-400">Total tonnage</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Compliance Score</p>
              <p className="text-xl font-black text-slate-900 mt-1">{user.metrics.complianceScore || 92}%</p>
              <p className="text-[10px] text-slate-400">Rating: {user.metrics.rating || 4.7}/5</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Open Complaints</p>
              <p className={`text-xl font-black mt-1 ${stats.complaintCount > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
                {stats.complaintCount}
              </p>
              <p className="text-[10px] text-slate-400">Filed or assigned</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Total Turnover</p>
              <p className="text-xl font-black text-emerald-700 mt-1">
                ₹{(user.metrics.totalEarnings || stats.totalAmountInr).toLocaleString('en-IN')}
              </p>
              <p className="text-[10px] text-slate-400">Settled payments</p>
            </div>
          </>
        ) : isRecycler ? (
          <>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Plant Capacity</p>
              <p className="text-xl font-black text-slate-900 mt-1">
                {user.capacityTonsPerDay || 40} <span className="text-xs font-bold text-slate-500">T/day</span>
              </p>
              <p className="text-[10px] text-slate-400">Authorized intake</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Assigned Lots</p>
              <p className="text-xl font-black text-blue-700 mt-1">{stats.lotCount}</p>
              <p className="text-[10px] text-slate-400">Intake batches</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Recycled Total</p>
              <p className="text-xl font-black text-emerald-700 mt-1">
                {(user.metrics.totalRecycledKg || 0).toLocaleString('en-IN')} <span className="text-xs font-bold text-slate-500">kg</span>
              </p>
              <p className="text-[10px] text-slate-400">Processed material</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">CPCB Verification</p>
              <p className={`text-base font-black mt-2 ${user.verificationStatus === 'VERIFIED' ? 'text-emerald-700' : 'text-amber-600'}`}>
                {user.verificationStatus || 'PENDING'}
              </p>
              <p className="text-[10px] text-slate-400">Regulatory status</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Complaints</p>
              <p className={`text-xl font-black mt-1 ${stats.complaintCount > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
                {stats.complaintCount}
              </p>
              <p className="text-[10px] text-slate-400">Ticket volume</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Disbursed Volume</p>
              <p className="text-xl font-black text-emerald-700 mt-1">
                ₹{(user.metrics.totalEarnings || stats.totalAmountInr).toLocaleString('en-IN')}
              </p>
              <p className="text-[10px] text-slate-400">Settlements</p>
            </div>
          </>
        ) : (
          <>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Admin Role</p>
              <p className="text-xl font-black text-slate-900 mt-1">Full Access</p>
              <p className="text-[10px] text-slate-400">Security Clearance</p>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <p className="text-[11px] font-bold text-slate-500 uppercase">Audit Records</p>
              <p className="text-xl font-black text-blue-700 mt-1">{auditHistory.length}</p>
              <p className="text-[10px] text-slate-400">Logged actions</p>
            </div>
          </>
        )}
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-1 border-b border-slate-200 bg-white px-2 pt-2 rounded-t-xl text-xs font-bold text-slate-600">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2.5 border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'overview'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Profile & Organization</span>
        </button>

        <button
          onClick={() => setActiveTab('operations')}
          className={`px-4 py-2.5 border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'operations'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <Boxes className="w-3.5 h-3.5" />
          <span>Operational Activity ({isCollector ? pickups.length : lots.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('complaints')}
          className={`px-4 py-2.5 border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'complaints'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Complaints & Discrepancies ({complaints.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('payments')}
          className={`px-4 py-2.5 border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'payments'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span>Payments & Settlements ({payments.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`px-4 py-2.5 border-b-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'audit'
              ? 'border-emerald-600 text-emerald-800'
              : 'border-transparent text-slate-500 hover:text-slate-900'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>Audit History ({auditHistory.length})</span>
        </button>
      </div>

      {/* Tab 1: Profile & Organization Information */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white border border-slate-200 rounded-b-2xl p-6">
          {/* Identity & Legal Verification */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Identity & Regulatory Credentials</span>
            </h3>

            <div className="bg-slate-50 rounded-xl p-4 space-y-3 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Legal Entity Name:</span>
                <span className="font-bold text-slate-900">{user.organizationName || user.name}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Authorized Contact:</span>
                <span className="font-medium text-slate-900">{user.name}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Role in RecySetu:</span>
                <span className="font-bold text-slate-900 uppercase">{user.role}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">License / Registration Number:</span>
                <span className="font-mono font-semibold text-slate-900">
                  {user.licenseNumber || 'DOC-REG-VERIFIED'}
                </span>
              </div>
              {isRecycler && (
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-500">Recycler Verification Status:</span>
                  <span
                    className={`font-bold uppercase ${
                      user.verificationStatus === 'VERIFIED'
                        ? 'text-emerald-700'
                        : user.verificationStatus === 'REJECTED'
                        ? 'text-rose-700'
                        : 'text-amber-700'
                    }`}
                  >
                    {user.verificationStatus || 'PENDING'}
                  </span>
                </div>
              )}
              <div className="flex justify-between py-1">
                <span className="text-slate-500">KYC Status:</span>
                <span className={`font-bold ${user.kycVerified ? 'text-emerald-700' : 'text-amber-700'}`}>
                  {user.kycVerified ? 'VERIFIED' : 'PENDING APPROVAL'}
                </span>
              </div>
            </div>

            {/* Service Area */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700">Designated Service Area</label>
              <div className="flex flex-wrap gap-1.5">
                {user.serviceArea && user.serviceArea.length > 0 ? (
                  user.serviceArea.map((area, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 bg-slate-100 border border-slate-200 text-slate-700 rounded-md text-xs font-medium"
                    >
                      {area}
                    </span>
                  ))
                ) : (
                  <span className="px-2.5 py-1 bg-slate-100 text-slate-600 rounded-md text-xs font-medium">
                    {user.location.city}, {user.location.state}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Logistics, Materials & Facility Metrics */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-blue-600" />
              <span>Facility & Material Specifications</span>
            </h3>

            <div className="bg-slate-50 rounded-xl p-4 space-y-3 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Operating Facility Address:</span>
                <span className="font-medium text-slate-900 text-right max-w-xs">
                  {user.location.address || 'Central District Logistics Park'}, {user.location.city}, {user.location.state}
                </span>
              </div>
              {isRecycler && (
                <div className="flex justify-between py-1 border-b border-slate-200/60">
                  <span className="text-slate-500">Daily Processing Capacity:</span>
                  <span className="font-bold text-slate-900">{user.capacityTonsPerDay || 45} Metric Tons / Day</span>
                </div>
              )}
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">Platform Registration Date:</span>
                <span className="font-medium text-slate-900">{new Date(user.createdAt).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Last Active Session:</span>
                <span className="font-medium text-slate-900">
                  {user.lastActiveAt ? new Date(user.lastActiveAt).toLocaleString('en-IN') : 'Recently active'}
                </span>
              </div>
            </div>

            {/* Supported Materials */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700">Authorized / Supported Materials</label>
              <div className="flex flex-wrap gap-1.5">
                {user.supportedMaterials && user.supportedMaterials.length > 0 ? (
                  user.supportedMaterials.map((mat) => (
                    <span
                      key={mat}
                      className="px-2.5 py-1 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-md text-xs font-bold"
                    >
                      {mat}
                    </span>
                  ))
                ) : (
                  <>
                    <span className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-md text-xs font-medium">PLASTIC</span>
                    <span className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-md text-xs font-medium">METAL</span>
                    <span className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-md text-xs font-medium">PAPER</span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Operational Activity (Pickups / Lots) */}
      {activeTab === 'operations' && (
        <div className="bg-white border border-slate-200 rounded-b-2xl p-6">
          {isCollector ? (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-900">Logged Pickup History ({pickups.length})</h3>
              {pickups.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">No pickup records logged yet for this collector.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-600">
                    <thead className="bg-slate-50 text-slate-800 uppercase font-bold text-[10px] border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Tracking Code</th>
                        <th className="py-2.5 px-3">Category</th>
                        <th className="py-2.5 px-3">Est / Actual Wt</th>
                        <th className="py-2.5 px-3">Aggregator</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {pickups.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{p.trackingCode}</td>
                          <td className="py-2.5 px-3 font-semibold text-slate-700">{p.status}</td>
                          <td className="py-2.5 px-3 font-bold text-emerald-700">
                            {p.actualWeightKg ? `${p.actualWeightKg} kg` : `~${p.quantityKg} kg`}
                          </td>
                          <td className="py-2.5 px-3">{p.aggregatorName || 'Pending Allocation'}</td>
                          <td className="py-2.5 px-3">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                              {p.status}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-slate-400">{new Date(p.createdAt).toLocaleDateString('en-IN')}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-900">
                {isRecycler ? 'Assigned Intake Lots' : 'Created & Dispatched Lots'} ({lots.length})
              </h3>
              {lots.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">No associated lots found in the system.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-600">
                    <thead className="bg-slate-50 text-slate-800 uppercase font-bold text-[10px] border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Lot Number</th>
                        <th className="py-2.5 px-3">Category</th>
                        <th className="py-2.5 px-3">Net Weight</th>
                        <th className="py-2.5 px-3">{isRecycler ? 'Source Hub' : 'Destination Recycler'}</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {lots.map((l) => (
                        <tr key={l.id} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{l.lotNumber}</td>
                          <td className="py-2.5 px-3 font-semibold text-slate-700">{l.status}</td>
                          <td className="py-2.5 px-3 font-bold text-emerald-700">{l.totalWeightKg.toLocaleString('en-IN')} kg</td>
                          <td className="py-2.5 px-3">{isRecycler ? l.aggregatorName : (l.recyclerName || 'Unassigned')}</td>
                          <td className="py-2.5 px-3">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                              {l.status}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-slate-400">{new Date(l.createdAt).toLocaleDateString('en-IN')}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Complaints */}
      {activeTab === 'complaints' && (
        <div className="bg-white border border-slate-200 rounded-b-2xl p-6 space-y-3">
          <h3 className="text-sm font-bold text-slate-900">Complaints & Discrepancies Involving Stakeholder ({complaints.length})</h3>
          {complaints.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No open or resolved grievances for this account.</p>
          ) : (
            <div className="space-y-2.5">
              {complaints.map((c) => (
                <div key={c.id} className="p-3.5 border border-slate-200 rounded-xl bg-slate-50 flex items-start justify-between gap-3 text-xs">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900">{c.ticketId}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-700">
                        {c.category.replace(/_/g, ' ')}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        c.priority === 'CRITICAL' || c.priority === 'HIGH' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {c.priority}
                      </span>
                    </div>
                    <p className="text-slate-700">{c.description}</p>
                    <p className="text-[10px] text-slate-400">
                      Filed by {c.filedByName} against {c.againstName} • {new Date(c.createdAt).toLocaleDateString('en-IN')}
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-white border border-slate-200 text-slate-700 shrink-0">
                    {c.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Payments */}
      {activeTab === 'payments' && (
        <div className="bg-white border border-slate-200 rounded-b-2xl p-6 space-y-3">
          <h3 className="text-sm font-bold text-slate-900">Authorized Financial Disbursements ({payments.length})</h3>
          {payments.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No payment transactions recorded for this account.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 text-slate-800 uppercase font-bold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Transaction ID</th>
                    <th className="py-2.5 px-3">Amount</th>
                    <th className="py-2.5 px-3">Payer</th>
                    <th className="py-2.5 px-3">Payee</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {payments.map((pay) => (
                    <tr key={pay.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{pay.transactionId}</td>
                      <td className="py-2.5 px-3 font-bold text-emerald-700">₹{pay.amount.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3">{pay.payerName}</td>
                      <td className="py-2.5 px-3 font-medium text-slate-800">{pay.payeeName}</td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          pay.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {pay.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400">{new Date(pay.timestamp).toLocaleDateString('en-IN')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Tab 5: Immutable Audit History */}
      {activeTab === 'audit' && (
        <div className="bg-white border border-slate-200 rounded-b-2xl p-6 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <History className="w-4 h-4 text-slate-600" />
              <span>Immutable Audit Trail for this Stakeholder</span>
            </h3>
            <span className="text-[11px] text-slate-400 font-medium">Read-only audit record</span>
          </div>

          {auditHistory.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No audit logs recorded for this stakeholder yet.</p>
          ) : (
            <div className="space-y-2">
              {auditHistory.map((a) => (
                <div
                  key={a.id}
                  className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl text-xs space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900">{a.action}</span>
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-200 text-slate-700">
                        Actor: {a.actorName} ({a.actorRole})
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400">
                      {new Date(a.timestamp).toLocaleString('en-IN')}
                    </span>
                  </div>
                  <p className="text-slate-700 text-[11px]">{a.details}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Sensitive Action Confirmation Dialog */}
      <AdminUserActionDialog
        isOpen={!!actionType}
        onClose={() => setActionType(null)}
        user={user}
        actionType={actionType}
        onConfirm={handleExecuteAction}
        isLoading={isActionLoading}
      />
    </div>
  );
};
