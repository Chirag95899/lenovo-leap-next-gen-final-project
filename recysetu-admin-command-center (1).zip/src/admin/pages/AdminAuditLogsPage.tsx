import React from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { AdminSearch } from '../components/AdminSearch';
import { AdminPagination } from '../components/AdminPagination';
import { formatDateTime } from '../utils/formatters';
import { AuditLog } from '../../shared/types/domain';
import { TableColumn } from '../types/admin';
import { Shield, Lock } from 'lucide-react';

interface AdminAuditLogsPageProps {
  logs: AuditLog[];
  total: number;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  search: string;
  setSearch: (s: string) => void;
  isLoading: boolean;
}

export const AdminAuditLogsPage: React.FC<AdminAuditLogsPageProps> = ({
  logs,
  total,
  page,
  totalPages,
  setPage,
  search,
  setSearch,
  isLoading,
}) => {
  const columns: TableColumn<AuditLog>[] = [
    {
      key: 'timestamp',
      header: 'Timestamp',
      render: (l) => (
        <span className="font-mono text-xs text-slate-500 whitespace-nowrap">
          {formatDateTime(l.timestamp)}
        </span>
      ),
    },
    {
      key: 'action',
      header: 'Security Action',
      render: (l) => (
        <span className="font-bold text-xs text-slate-800 font-mono">
          {l.action.replace(/_/g, ' ')}
        </span>
      ),
    },
    {
      key: 'actor',
      header: 'Operator',
      render: (l) => (
        <div className="text-xs">
          <span className="font-semibold text-slate-900">{l.actorName}</span>
          <div className="text-[11px] text-slate-400 font-mono">ID: {l.actorId}</div>
        </div>
      ),
    },
    {
      key: 'target',
      header: 'Target Resource',
      render: (l) => (
        <span className="font-mono text-xs text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
          {l.targetResource}
        </span>
      ),
    },
    {
      key: 'details',
      header: 'Event Log Summary',
      render: (l) => <span className="text-xs text-slate-600">{l.details}</span>,
    },
  ];

  return (
    <div className="space-y-4">
      <AdminPageHeader
        title="Administrative Security Audit Trail"
        description="Immutable compliance journal recording every administrative login, status transition, price update, and security hold."
        badge={
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            <Lock className="w-3.5 h-3.5 text-slate-500" />
            Append-Only Secure Log
          </span>
        }
      />

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200">
          <AdminSearch
            value={search}
            onChange={setSearch}
            placeholder="Search by action, operator name, target ID, or event summary..."
          />
        </div>

        <AdminDataTable
          columns={columns}
          data={logs}
          keyExtractor={(l) => l.id}
          isLoading={isLoading}
          emptyTitle="No audit records found"
        />

        <AdminPagination
          currentPage={page}
          totalPages={totalPages}
          totalItems={total}
          itemsPerPage={15}
          onPageChange={setPage}
        />
      </div>
    </div>
  );
};
