import React, { useState } from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { AdminSearch } from '../components/AdminSearch';
import { AdminPagination } from '../components/AdminPagination';
import { AdminStatusBadge } from '../components/AdminStatusBadge';
import { AdminUserActionDialog, UserActionType } from '../components/AdminUserActionDialog';
import { AdminUserDetailPage } from './AdminUserDetailPage';
import { formatDateTime, formatWeight, formatInr } from '../utils/formatters';
import { User, UserRole, RecyclerVerificationStatus } from '../../shared/types/domain';
import { TableColumn } from '../types/admin';
import {
  ShieldCheck,
  ShieldAlert,
  CheckCircle,
  Ban,
  Eye,
  RotateCcw,
  XCircle,
  Factory,
  Building2,
  Package,
  Users,
  Calendar,
  MapPin,
  Filter,
  X,
  UserCheck,
} from 'lucide-react';

export type UserSectionTab = 'ALL' | 'COLLECTORS' | 'AGGREGATORS' | 'RECYCLERS';

interface AdminUsersPageProps {
  users: User[];
  total: number;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  limit?: number;
  setLimit?: (l: number) => void;
  search: string;
  setSearch: (s: string) => void;
  role: string;
  setRole: (r: string) => void;
  status: string;
  setStatus: (st: string) => void;
  verificationStatus?: string;
  setVerificationStatus?: (v: string) => void;
  location?: string;
  setLocation?: (loc: string) => void;
  startDate?: string;
  setStartDate?: (d: string) => void;
  endDate?: string;
  setEndDate?: (d: string) => void;
  isLoading: boolean;
  onVerifyRecycler?: (id: string, reason?: string) => Promise<void>;
  onRejectRecycler?: (id: string, reason: string) => Promise<void>;
  onSuspendUser?: (id: string, reason: string) => Promise<void>;
  onReactivateUser?: (id: string, reason?: string) => Promise<void>;
  onVerifyKyc?: (id: string, reason?: string) => Promise<void>;
  onChangeUserRole?: (id: string, newRole: UserRole, reason: string) => Promise<void>;
  onUpdateUserStatus?: (id: string, status: User['status'], kycVerified?: boolean) => Promise<void>;
  onSelectUserDetail?: (userId: string) => void;
  selectedUserId?: string | null;
  onClearSelectedUser?: () => void;
}

export const AdminUsersPage: React.FC<AdminUsersPageProps> = ({
  users,
  total,
  page,
  totalPages,
  setPage,
  limit = 25,
  setLimit,
  search,
  setSearch,
  role,
  setRole,
  status,
  setStatus,
  verificationStatus = '',
  setVerificationStatus,
  location = '',
  setLocation,
  startDate = '',
  setStartDate,
  endDate = '',
  setEndDate,
  isLoading,
  onVerifyRecycler,
  onRejectRecycler,
  onSuspendUser,
  onReactivateUser,
  onVerifyKyc,
  onChangeUserRole,
  onSelectUserDetail,
  selectedUserId: externalSelectedUserId,
  onClearSelectedUser,
}) => {
  // Local active user detail ID if not controlled externally
  const [internalSelectedUserId, setInternalSelectedUserId] = useState<string | null>(null);
  const activeDetailUserId = externalSelectedUserId || internalSelectedUserId;

  // Active Navigation Section Tab
  const getInitialTab = (): UserSectionTab => {
    if (role === 'COLLECTOR') return 'COLLECTORS';
    if (role === 'AGGREGATOR') return 'AGGREGATORS';
    if (role === 'RECYCLER') return 'RECYCLERS';
    return 'ALL';
  };
  const [activeTab, setActiveTab] = useState<UserSectionTab>(getInitialTab);

  // Dialog action state
  const [actionTargetUser, setActionTargetUser] = useState<User | null>(null);
  const [actionType, setActionType] = useState<UserActionType | null>(null);
  const [isActionProcessing, setIsActionProcessing] = useState(false);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  // Switch tab and synchronize role filter
  const handleTabChange = (tab: UserSectionTab) => {
    setActiveTab(tab);
    setPage(1);
    if (tab === 'ALL') {
      setRole('');
    } else if (tab === 'COLLECTORS') {
      setRole('COLLECTOR');
    } else if (tab === 'AGGREGATORS') {
      setRole('AGGREGATOR');
    } else if (tab === 'RECYCLERS') {
      setRole('RECYCLER');
    }
  };

  const handleOpenDetail = (userId: string) => {
    if (onSelectUserDetail) {
      onSelectUserDetail(userId);
    } else {
      setInternalSelectedUserId(userId);
    }
  };

  const handleCloseDetail = () => {
    if (onClearSelectedUser) {
      onClearSelectedUser();
    } else {
      setInternalSelectedUserId(null);
    }
  };

  const handleExecuteAction = async (reason: string, targetRole?: UserRole) => {
    if (!actionTargetUser || !actionType) return;
    setIsActionProcessing(true);
    try {
      if (actionType === 'VERIFY_RECYCLER' && onVerifyRecycler) {
        await onVerifyRecycler(actionTargetUser.id, reason);
      } else if (actionType === 'REJECT_RECYCLER' && onRejectRecycler) {
        await onRejectRecycler(actionTargetUser.id, reason);
      } else if (actionType === 'SUSPEND' && onSuspendUser) {
        await onSuspendUser(actionTargetUser.id, reason);
      } else if (actionType === 'REACTIVATE' && onReactivateUser) {
        await onReactivateUser(actionTargetUser.id, reason);
      } else if (actionType === 'VERIFY_KYC' && onVerifyKyc) {
        await onVerifyKyc(actionTargetUser.id, reason);
      } else if (actionType === 'CHANGE_ROLE' && onChangeUserRole && targetRole) {
        await onChangeUserRole(actionTargetUser.id, targetRole, reason);
      }
      setActionTargetUser(null);
      setActionType(null);
    } catch (err: any) {
      alert(err.message || 'Action failed.');
    } finally {
      setIsActionProcessing(false);
    }
  };

  const resetAllFilters = () => {
    setSearch('');
    setStatus('');
    if (setVerificationStatus) setVerificationStatus('');
    if (setLocation) setLocation('');
    if (setStartDate) setStartDate('');
    if (setEndDate) setEndDate('');
    setPage(1);
  };

  // If a user detail page is active, show the full detail dossier
  if (activeDetailUserId) {
    return (
      <AdminUserDetailPage
        userId={activeDetailUserId}
        onBack={handleCloseDetail}
      />
    );
  }

  // User Table Columns
  const columns: TableColumn<User>[] = [
    {
      key: 'name',
      header: 'Stakeholder & Identity',
      render: (u) => (
        <div className="space-y-0.5">
          <div className="font-bold text-slate-900 flex items-center gap-1.5">
            <button
              onClick={() => handleOpenDetail(u.id)}
              className="hover:text-emerald-700 hover:underline text-left font-bold"
            >
              {u.organizationName || u.name}
            </button>
            {u.organizationName && u.name !== u.organizationName && (
              <span className="text-[11px] text-slate-400 font-normal">({u.name})</span>
            )}
          </div>
          <div className="text-xs text-slate-500 font-mono flex items-center gap-2">
            <span>ID: {u.id}</span>
            <span>•</span>
            <span>{u.phone}</span>
          </div>
        </div>
      ),
    },
    {
      key: 'role',
      header: 'Role',
      render: (u) => (
        <span
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider ${
            u.role === 'ADMIN'
              ? 'bg-purple-100 text-purple-800'
              : u.role === 'AGGREGATOR'
              ? 'bg-blue-100 text-blue-800'
              : u.role === 'RECYCLER'
              ? 'bg-emerald-100 text-emerald-800'
              : 'bg-amber-100 text-amber-800'
          }`}
        >
          {u.role === 'RECYCLER' ? (
            <Factory className="w-3 h-3" />
          ) : u.role === 'AGGREGATOR' ? (
            <Building2 className="w-3 h-3" />
          ) : u.role === 'COLLECTOR' ? (
            <Package className="w-3 h-3" />
          ) : (
            <Users className="w-3 h-3" />
          )}
          <span>{u.role}</span>
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Account Status',
      render: (u) => <AdminStatusBadge status={u.status} size="sm" />,
    },
    {
      key: 'verification',
      header: 'Verification Status',
      render: (u) => (
        <div className="space-y-1">
          {u.role === 'RECYCLER' ? (
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                u.verificationStatus === 'VERIFIED'
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : u.verificationStatus === 'REJECTED'
                  ? 'bg-rose-50 text-rose-700 border border-rose-200'
                  : u.verificationStatus === 'SUSPENDED'
                  ? 'bg-amber-50 text-amber-700 border border-amber-200'
                  : 'bg-amber-50 text-amber-700 border border-amber-200 animate-pulse'
              }`}
            >
              <ShieldCheck className="w-3 h-3" />
              <span>Recycler: {u.verificationStatus || 'PENDING'}</span>
            </span>
          ) : (
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                u.kycVerified
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : 'bg-amber-50 text-amber-700 border border-amber-200'
              }`}
            >
              {u.kycVerified ? <ShieldCheck className="w-3 h-3" /> : <ShieldAlert className="w-3 h-3" />}
              <span>KYC: {u.kycVerified ? 'VERIFIED' : 'PENDING'}</span>
            </span>
          )}
        </div>
      ),
    },
    {
      key: 'location',
      header: 'Location',
      render: (u) => (
        <div className="text-xs text-slate-700 flex items-center gap-1">
          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="truncate">{u.location.city}, {u.location.state}</span>
        </div>
      ),
    },
    {
      key: 'registration',
      header: 'Registered',
      render: (u) => (
        <div className="text-xs text-slate-500 flex items-center gap-1">
          <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span>{new Date(u.createdAt).toLocaleDateString('en-IN')}</span>
        </div>
      ),
    },
    {
      key: 'activity',
      header: 'Recent Throughput',
      render: (u) => (
        <div className="text-xs">
          {u.role === 'COLLECTOR' && (
            <div>
              <span className="font-semibold text-slate-900">
                {formatWeight(u.metrics.totalCollectedKg)}
              </span>{' '}
              <span className="text-slate-400">({formatInr(u.metrics.totalEarnings)})</span>
            </div>
          )}
          {u.role === 'AGGREGATOR' && (
            <div>
              <span className="font-semibold text-slate-900">
                {formatWeight(u.metrics.totalDispatchedKg)}
              </span>{' '}
              <span className="text-slate-400">dispatched</span>
            </div>
          )}
          {u.role === 'RECYCLER' && (
            <div>
              <span className="font-semibold text-slate-900">
                {formatWeight(u.metrics.totalRecycledKg)}
              </span>{' '}
              <span className="text-slate-400">recycled</span>
            </div>
          )}
          {u.role === 'ADMIN' && (
            <span className="text-slate-500 font-mono text-[11px]">{u.adminId || 'Super Admin'}</span>
          )}
        </div>
      ),
    },
    {
      key: 'actions',
      header: 'Administrative Actions',
      align: 'right',
      render: (u) => (
        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
          {/* Detail Dossier Button */}
          <button
            onClick={() => handleOpenDetail(u.id)}
            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
            title="Inspect full stakeholder dossier"
          >
            <Eye className="w-4 h-4" />
          </button>

          {/* Quick Recycler Verification Actions */}
          {u.role === 'RECYCLER' && (u.status === 'PENDING_VERIFICATION' || u.verificationStatus === 'PENDING') && (
            <>
              <button
                onClick={() => {
                  setActionTargetUser(u);
                  setActionType('VERIFY_RECYCLER');
                }}
                className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold flex items-center gap-1 shadow-2xs transition-colors"
                title="Review & Verify Industrial Recycler"
              >
                <ShieldCheck className="w-3 h-3" />
                <span>Verify</span>
              </button>
              <button
                onClick={() => {
                  setActionTargetUser(u);
                  setActionType('REJECT_RECYCLER');
                }}
                className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded text-[10px] font-bold flex items-center gap-1 transition-colors"
                title="Reject Recycler Application"
              >
                <XCircle className="w-3 h-3" />
                <span>Reject</span>
              </button>
            </>
          )}

          {/* Re-review for Rejected Recycler */}
          {u.role === 'RECYCLER' && u.verificationStatus === 'REJECTED' && (
            <button
              onClick={() => {
                setActionTargetUser(u);
                setActionType('VERIFY_RECYCLER');
              }}
              className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-300 rounded text-[10px] font-bold flex items-center gap-1 transition-colors"
              title="Re-review & Verify Recycler"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Re-verify</span>
            </button>
          )}

          {/* KYC verification for Collectors/Aggregators */}
          {u.role !== 'RECYCLER' && !u.kycVerified && u.role !== 'ADMIN' && (
            <button
              onClick={() => {
                setActionTargetUser(u);
                setActionType('VERIFY_KYC');
              }}
              className="p-1.5 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors"
              title="Verify KYC Documents"
            >
              <UserCheck className="w-4 h-4" />
            </button>
          )}

          {/* Suspend user */}
          {u.status === 'ACTIVE' && u.role !== 'ADMIN' && (
            <button
              onClick={() => {
                setActionTargetUser(u);
                setActionType('SUSPEND');
              }}
              className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-md transition-colors"
              title="Suspend User Account (Requires reason)"
            >
              <Ban className="w-4 h-4" />
            </button>
          )}

          {/* Reactivate user */}
          {u.status === 'SUSPENDED' && (
            <button
              onClick={() => {
                setActionTargetUser(u);
                setActionType('REACTIVATE');
              }}
              className="p-1.5 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors"
              title="Reactivate User Account"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div id="admin-users-management-view" className="space-y-5">
      <AdminPageHeader
        title="Stakeholder & User Management"
        description="Unified administration directory for informal waste collectors, aggregation hubs, licensed recyclers, and system operators."
      />

      {/* Navigation Sections Tabs: Users, Collectors, Aggregators, Recyclers */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        <button
          id="nav-section-users"
          onClick={() => handleTabChange('ALL')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'ALL'
              ? 'bg-slate-900 text-white shadow-xs'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Users</span>
        </button>

        <button
          id="nav-section-collectors"
          onClick={() => handleTabChange('COLLECTORS')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'COLLECTORS'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>Collectors</span>
        </button>

        <button
          id="nav-section-aggregators"
          onClick={() => handleTabChange('AGGREGATORS')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'AGGREGATORS'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Aggregators</span>
        </button>

        <button
          id="nav-section-recyclers"
          onClick={() => handleTabChange('RECYCLERS')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'RECYCLERS'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Factory className="w-3.5 h-3.5" />
          <span>Recyclers</span>
        </button>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
        {/* Search & Quick Filters Bar */}
        <div className="p-4 flex flex-col md:flex-row items-center justify-between gap-3 border-b border-slate-200">
          <div className="w-full md:max-w-md">
            <AdminSearch
              value={search}
              onChange={setSearch}
              placeholder="Search by name, user ID, mobile, location..."
            />
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
            {/* Account Status Filter */}
            <select
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(1);
              }}
              aria-label="Filter by account status"
              className="text-xs font-medium px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
            >
              <option value="">All Statuses</option>
              <option value="ACTIVE">Active</option>
              <option value="PENDING_VERIFICATION">Pending Verification</option>
              <option value="SUSPENDED">Suspended</option>
              <option value="REJECTED">Rejected</option>
            </select>

            {/* Recycler Verification Status (if tab is Recyclers or All) */}
            {(activeTab === 'RECYCLERS' || activeTab === 'ALL') && setVerificationStatus && (
              <select
                value={verificationStatus}
                onChange={(e) => {
                  setVerificationStatus(e.target.value);
                  setPage(1);
                }}
                aria-label="Filter by verification status"
                className="text-xs font-medium px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              >
                <option value="">All Verification</option>
                <option value="VERIFIED">Verified</option>
                <option value="PENDING">Pending Approval</option>
                <option value="SUSPENDED">Suspended</option>
                <option value="REJECTED">Rejected</option>
              </select>
            )}

            {/* Toggle Advanced Filters (Location & Date) */}
            <button
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className={`inline-flex items-center gap-1.5 px-3 py-2 border rounded-lg text-xs font-semibold transition-colors ${
                showAdvancedFilters || location || startDate || endDate
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Filters</span>
              {(location || startDate || endDate) && (
                <span className="w-2 h-2 rounded-full bg-emerald-600" />
              )}
            </button>

            {(search || status || verificationStatus || location || startDate || endDate) && (
              <button
                onClick={resetAllFilters}
                className="inline-flex items-center gap-1 px-2.5 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                title="Reset all filters"
              >
                <X className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            )}
          </div>
        </div>

        {/* Advanced Filters Expandable Drawer/Bar */}
        {showAdvancedFilters && (
          <div className="p-4 bg-slate-50/80 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Filter by Location
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation && setLocation(e.target.value)}
                placeholder="City or state (e.g. Pune)..."
                className="w-full text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Registration Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate && setStartDate(e.target.value)}
                className="w-full text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Registration End Date
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate && setEndDate(e.target.value)}
                className="w-full text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>
        )}

        {/* Data Table */}
        <AdminDataTable
          columns={columns}
          data={users}
          keyExtractor={(u) => u.id}
          isLoading={isLoading}
          onRowClick={(u) => handleOpenDetail(u.id)}
          emptyTitle="No stakeholders found matching the criteria"
        />

        {/* Pagination: Default 25 records per page, allows 25, 50, 100 */}
        <AdminPagination
          currentPage={page}
          totalPages={totalPages}
          totalItems={total}
          itemsPerPage={limit}
          onPageChange={setPage}
          onItemsPerPageChange={setLimit}
          pageSizeOptions={[25, 50, 100]}
        />
      </div>

      {/* Sensitive Action Confirmation Dialog with Reason Field */}
      <AdminUserActionDialog
        isOpen={!!actionType}
        onClose={() => {
          setActionTargetUser(null);
          setActionType(null);
        }}
        user={actionTargetUser}
        actionType={actionType}
        onConfirm={handleExecuteAction}
        isLoading={isActionProcessing}
      />
    </div>
  );
};
