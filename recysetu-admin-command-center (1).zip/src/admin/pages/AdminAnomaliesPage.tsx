import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Play,
  Sparkles,
  Search,
  ExternalLink,
  Clock,
  FileText,
  UserCheck,
  RotateCcw,
  Eye,
  Building,
  Truck,
  Boxes,
  CreditCard,
  HelpCircle,
} from 'lucide-react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { AdminSearch } from '../components/AdminSearch';
import { AdminFilterBar } from '../components/AdminFilterBar';
import { AdminPagination } from '../components/AdminPagination';
import { AdminStatusBadge } from '../components/AdminStatusBadge';
import { AdminModal } from '../components/AdminModal';
import { formatDateTime } from '../utils/formatters';
import { AnomalyRecord } from '../../shared/types/domain';
import { TableColumn } from '../types/admin';

interface AdminAnomaliesPageProps {
  activeAnomaliesCount?: number;
  criticalAnomaliesCount?: number;
  anomalies: AnomalyRecord[];
  total: number;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  search: string;
  setSearch: (s: string) => void;
  severity: string;
  setSeverity: (s: string) => void;
  status: string;
  setStatus: (st: string) => void;
  entityType?: string;
  setEntityType?: (et: string) => void;
  ruleKey?: string;
  setRuleKey?: (rk: string) => void;
  isLoading: boolean;
  onRunRules?: () => Promise<any>;
  onReviewAnomaly?: (id: string) => Promise<any>;
  onResolveAnomalyWithNotes?: (id: string, resolution: string) => Promise<any>;
  onDismissAnomaly?: (id: string, reason: string) => Promise<any>;
  onInvestigateAnomaly?: (id: string, notes: string) => Promise<any>;
  onExplainAnomalyWithAi?: (id: string) => Promise<any>;
  onResolveAnomaly?: (id: string, status: AnomalyRecord['status']) => Promise<void>;
  onNavigateToEntity?: (entityType: string, entityId: string) => void;
}

export const AdminAnomaliesPage: React.FC<AdminAnomaliesPageProps> = ({
  activeAnomaliesCount = 0,
  criticalAnomaliesCount = 0,
  anomalies,
  total,
  page,
  totalPages,
  setPage,
  search,
  setSearch,
  severity,
  setSeverity,
  status,
  setStatus,
  entityType = '',
  setEntityType,
  ruleKey = '',
  setRuleKey,
  isLoading,
  onRunRules,
  onReviewAnomaly,
  onResolveAnomalyWithNotes,
  onDismissAnomaly,
  onInvestigateAnomaly,
  onExplainAnomalyWithAi,
  onResolveAnomaly,
  onNavigateToEntity,
}) => {
  const [selectedAnomaly, setSelectedAnomaly] = useState<AnomalyRecord | null>(null);
  const [isActionLoading, setIsActionLoading] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [isExplainingAi, setIsExplainingAi] = useState(false);

  // Dialog sub-states for human review workflow
  const [activeActionModal, setActiveActionModal] = useState<
    'NONE' | 'RESOLVE' | 'DISMISS' | 'INVESTIGATE'
  >('NONE');
  const [actionInput, setActionInput] = useState('');
  const [actionError, setActionError] = useState<string | null>(null);

  const handleRunScan = async () => {
    if (!onRunRules) return;
    try {
      setIsScanning(true);
      const res = await onRunRules();
      alert(`Anomaly Engine Scan Complete: ${res.detected?.length || 0} issues detected.`);
    } catch (err: any) {
      alert(`Scan failed: ${err.message}`);
    } finally {
      setIsScanning(false);
    }
  };

  const handleReview = async () => {
    if (!selectedAnomaly || !onReviewAnomaly) return;
    try {
      setIsActionLoading(true);
      const res = await onReviewAnomaly(selectedAnomaly.id);
      setSelectedAnomaly(res.anomaly || { ...selectedAnomaly, status: 'UNDER_REVIEW' });
    } catch (err: any) {
      alert(`Failed to assign review: ${err.message}`);
    } finally {
      setIsActionLoading(false);
    }
  };

  const handleExplainAi = async () => {
    if (!selectedAnomaly || !onExplainAnomalyWithAi) return;
    try {
      setIsExplainingAi(true);
      const res = await onExplainAnomalyWithAi(selectedAnomaly.id);
      if (res.anomaly) {
        setSelectedAnomaly(res.anomaly);
      }
    } catch (err: any) {
      alert(`Advisory explanation failed: ${err.message}`);
    } finally {
      setIsExplainingAi(false);
    }
  };

  const handleExecuteActionModal = async () => {
    if (!selectedAnomaly) return;
    if (!actionInput.trim()) {
      setActionError('Factual justification or operational note is required.');
      return;
    }

    try {
      setIsActionLoading(true);
      setActionError(null);

      if (activeActionModal === 'RESOLVE' && onResolveAnomalyWithNotes) {
        const res = await onResolveAnomalyWithNotes(selectedAnomaly.id, actionInput.trim());
        setSelectedAnomaly(res.anomaly);
      } else if (activeActionModal === 'DISMISS' && onDismissAnomaly) {
        const res = await onDismissAnomaly(selectedAnomaly.id, actionInput.trim());
        setSelectedAnomaly(res.anomaly);
      } else if (activeActionModal === 'INVESTIGATE' && onInvestigateAnomaly) {
        const res = await onInvestigateAnomaly(selectedAnomaly.id, actionInput.trim());
        setSelectedAnomaly(res.anomaly);
      }

      setActiveActionModal('NONE');
      setActionInput('');
    } catch (err: any) {
      setActionError(err.message || 'Operation failed');
    } finally {
      setIsActionLoading(false);
    }
  };

  const columns: TableColumn<AnomalyRecord>[] = [
    {
      key: 'type',
      header: 'Anomaly Type & Operational Context',
      render: (a) => (
        <div>
          <div className="font-bold text-slate-900 flex items-center gap-1.5">
            <span className="font-mono text-slate-900 text-xs">
              {a.title || a.ruleKey.replace(/_/g, ' ')}
            </span>
          </div>
          <div className="text-xs text-slate-600 line-clamp-2 mt-0.5 max-w-md">{a.description}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-2">
            <span>Detected: {formatDateTime(a.detectedAt)}</span>
            <span className="text-slate-300">•</span>
            <span className="font-mono text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
              Rule: {a.ruleKey}
            </span>
          </div>
        </div>
      ),
    },
    {
      key: 'severity',
      header: 'Severity',
      render: (a) => (
        <span
          className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold uppercase ${
            a.severity === 'CRITICAL'
              ? 'bg-rose-100 text-rose-800 border border-rose-300'
              : a.severity === 'HIGH'
              ? 'bg-orange-50 text-orange-700 border border-orange-200'
              : a.severity === 'MEDIUM'
              ? 'bg-amber-50 text-amber-700 border border-amber-200'
              : 'bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          {a.severity}
        </span>
      ),
    },
    {
      key: 'entity',
      header: 'Target Resource',
      render: (a) => (
        <div className="text-xs">
          <span className="font-semibold text-slate-800 flex items-center gap-1">
            {a.entityType === 'LOT' && <Boxes className="w-3.5 h-3.5 text-indigo-600" />}
            {a.entityType === 'PICKUP' && <Truck className="w-3.5 h-3.5 text-emerald-600" />}
            {a.entityType === 'PAYMENT' && <CreditCard className="w-3.5 h-3.5 text-amber-600" />}
            {a.entityType === 'USER' && <Building className="w-3.5 h-3.5 text-purple-600" />}
            {a.entityType}
          </span>
          <div className="font-mono text-[11px] text-slate-500 mt-0.5">{a.entityId}</div>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Review State',
      render: (a) => <AdminStatusBadge status={a.status} size="sm" />,
    },
    {
      key: 'actions',
      header: 'Investigation',
      align: 'right',
      render: (a) => (
        <button
          type="button"
          onClick={() => setSelectedAnomaly(a)}
          className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors inline-flex items-center gap-1"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Inspect</span>
        </button>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      {/* Page Header with Run Anomaly Scan Button */}
      <AdminPageHeader
        title="Fraud & Operational Anomaly Oversight"
        description="Empirical algorithmic checks flagging mass-balance discrepancies, price variations, turnaround outliers, and delivery verification variances without biased labeling."
      />
<div className="mb-6 flex gap-2">

        {onRunRules && (
          <button
            type="button"
            onClick={handleRunScan}
            disabled={isScanning || isLoading}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
          >
            <Play className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
            <span>{isScanning ? 'Evaluating Rules...' : 'Run Operational Scan'}</span>
          </button>
        )}
      
</div>

      {/* Main Table Container */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="w-full sm:w-80">
            <AdminSearch
              value={search}
              onChange={setSearch}
              placeholder="Search by anomaly description, entity ID..."
            />
          </div>

          <div className="text-xs text-slate-500 font-medium">
            Active Discrepancies: <span className="font-mono text-slate-900 font-bold">{total}</span>
          </div>
        </div>

        <AdminFilterBar
          filters={[
            {
              key: 'severity',
              label: 'Severity:',
              currentValue: severity,
              options: [
                { label: 'All Severities', value: '' },
                { label: 'Critical', value: 'CRITICAL' },
                { label: 'High', value: 'HIGH' },
                { label: 'Medium', value: 'MEDIUM' },
                { label: 'Low', value: 'LOW' },
              ],
            },
            {
              key: 'status',
              label: 'Review Status:',
              currentValue: status,
              options: [
                { label: 'All States', value: '' },
                { label: 'Detected (New)', value: 'DETECTED' },
                { label: 'Under Review', value: 'UNDER_REVIEW' },
                { label: 'Resolved', value: 'RESOLVED' },
                { label: 'Dismissed', value: 'DISMISSED' },
              ],
            },
            ...(setEntityType
              ? [
                  {
                    key: 'entityType',
                    label: 'Target Resource:',
                    currentValue: entityType,
                    options: [
                      { label: 'All Entities', value: '' },
                      { label: 'Lots', value: 'LOT' },
                      { label: 'Pickups', value: 'PICKUP' },
                      { label: 'Payments', value: 'PAYMENT' },
                      { label: 'Users', value: 'USER' },
                    ],
                  },
                ]
              : []),
          ]}
          onFilterChange={(key, val) => {
            if (key === 'severity') setSeverity(val);
            if (key === 'status') setStatus(val);
            if (key === 'entityType' && setEntityType) setEntityType(val);
            setPage(1);
          }}
          onReset={() => {
            setSeverity('');
            setStatus('');
            if (setEntityType) setEntityType('');
            if (setRuleKey) setRuleKey('');
            setSearch('');
            setPage(1);
          }}
        />

        <AdminDataTable
          columns={columns}
          data={anomalies}
          keyExtractor={(a) => a.id}
          isLoading={isLoading}
          onRowClick={(a) => setSelectedAnomaly(a)}
          emptyTitle="No operational discrepancies detected in current ledger"
        />

        <AdminPagination
          currentPage={page}
          totalPages={totalPages}
          totalItems={total}
          itemsPerPage={10}
          onPageChange={setPage}
        />
      </div>

      {/* Anomaly Inspection & Human Review Drawer/Modal */}
      <AdminModal
        isOpen={!!selectedAnomaly}
        onClose={() => {
          setSelectedAnomaly(null);
          setActiveActionModal('NONE');
          setActionInput('');
        }}
        title={`Anomaly Investigation: ${selectedAnomaly?.title || selectedAnomaly?.ruleKey.replace(/_/g, ' ')}`}
      >
        
        {selectedAnomaly && (
          <div className="space-y-4 text-xs">
            {/* Objective Trigger Card */}
            <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-amber-900">
              <span className="font-bold flex items-center gap-1.5 mb-1 text-xs">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                Operational Deviation Description:
              </span>
              <p className="leading-relaxed text-slate-800">{selectedAnomaly.description}</p>
            </div>

            {/* Target Resource & Rule Triggered Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block mb-1">Target Resource:</span>
                <span className="font-bold text-slate-900">{selectedAnomaly.entityType}</span>
                <div className="font-mono text-slate-600 block text-[11px] mt-0.5">
                  {selectedAnomaly.entityId}
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block mb-1">Rule Evaluated:</span>
                <span className="font-bold text-slate-900 font-mono text-[11px]">
                  {selectedAnomaly.ruleKey}
                </span>
                <span className="text-slate-500 block text-[11px] mt-0.5">
                  Configured Threshold Check
                </span>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 col-span-2 sm:col-span-1">
                <span className="text-slate-400 block mb-1">Assigned Severity:</span>
                <span
                  className={`font-bold uppercase ${
                    selectedAnomaly.severity === 'CRITICAL'
                      ? 'text-rose-700'
                      : selectedAnomaly.severity === 'HIGH'
                      ? 'text-orange-700'
                      : 'text-amber-700'
                  }`}
                >
                  {selectedAnomaly.severity}
                </span>
                <span className="text-slate-500 block text-[11px] mt-0.5">
                  Algorithmic Score
                </span>
              </div>
            </div>

            {/* Empirical Evidence & Mathematical Payload */}
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-700 font-semibold block mb-1">
                Empirical Telemetry & Deviation Metrics:
              </span>
              <pre className="font-mono text-[11px] text-slate-800 bg-white p-2.5 rounded border border-slate-200 overflow-x-auto max-h-44">
                {JSON.stringify(selectedAnomaly.metrics, null, 2)}
              </pre>
            </div>

            {/* AI Advisory Assessment Checkpoint */}
            <div className="p-3.5 bg-indigo-50/70 rounded-lg border border-indigo-200 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-indigo-900 font-bold">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  <span>AI Compliance & Investigation Advisory</span>
                </div>

                {onExplainAnomalyWithAi && (
                  <button
                    type="button"
                    onClick={handleExplainAi}
                    disabled={isExplainingAi}
                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-indigo-600 text-white hover:bg-indigo-700 rounded font-medium text-[11px] transition-colors"
                  >
                    <RotateCcw className={`w-3 h-3 ${isExplainingAi ? 'animate-spin' : ''}`} />
                    <span>{isExplainingAi ? 'Generating Checkpoints...' : 'Evaluate Checkpoints'}</span>
                  </button>
                )}
              </div>

              {selectedAnomaly.metrics?.aiExplanation ? (
                <div className="bg-white p-3 rounded-md border border-indigo-100 text-slate-800 space-y-2">
                  <p className="font-medium text-slate-900">
                    {selectedAnomaly.metrics.aiExplanation.objectiveSummary}
                  </p>
                  <div>
                    <span className="font-semibold text-slate-700 block mb-1">
                      Required Human Verification Checkpoints:
                    </span>
                    <ul className="list-disc pl-4 space-y-1 text-slate-600">
                      {selectedAnomaly.metrics.aiExplanation.verificationCheckpoints?.map(
                        (cp: string, idx: number) => (
                          <li key={idx}>{cp}</li>
                        )
                      )}
                    </ul>
                  </div>
                  <p className="text-[10px] text-slate-400 italic pt-1 border-t border-slate-100">
                    {selectedAnomaly.metrics.aiExplanation.regulatoryNote ||
                      'AI assessment is advisory only. Decisions must be made by authorized administrators.'}
                  </p>
                </div>
              ) : (
                <p className="text-slate-600 text-[11px]">
                  Click "Evaluate Checkpoints" to review objective AI-assisted audit questions and regulatory verification points.
                </p>
              )}
            </div>

            {/* Resolution History if Present */}
            {selectedAnomaly.resolution && (
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-emerald-900">
                <span className="font-bold block mb-0.5">Resolution Record:</span>
                <p className="text-slate-800">{selectedAnomaly.resolution}</p>
                <div className="text-[11px] text-slate-500 mt-1">
                  Resolved by {selectedAnomaly.assignedAdmin || 'Admin'} at{' '}
                  {selectedAnomaly.resolvedAt ? formatDateTime(selectedAnomaly.resolvedAt) : 'N/A'}
                </div>
              </div>
            )}

            {/* Sub-action input form if an action was clicked */}
            {activeActionModal !== 'NONE' && (
              <div className="p-3.5 bg-slate-100 rounded-lg border border-slate-300 space-y-2">
                <span className="font-bold text-slate-900 block">
                  {activeActionModal === 'RESOLVE' && 'Confirm Resolution Justification:'}
                  {activeActionModal === 'DISMISS' && 'Specify Dismissal / Tolerance Reason:'}
                  {activeActionModal === 'INVESTIGATE' && 'Field Investigation Instructions:'}
                </span>

                <textarea
                  rows={3}
                  value={actionInput}
                  onChange={(e) => setActionInput(e.target.value)}
                  placeholder={
                    activeActionModal === 'RESOLVE'
                      ? 'e.g., Tare tare weight recalibrated; discrepancy confirmed within legal tolerance.'
                      : activeActionModal === 'DISMISS'
                      ? 'e.g., Seasonal humidity adjustment approved; tolerance accepted.'
                      : 'e.g., Dispatch field officer to verify physical scales and inspect lot tags.'
                  }
                  className="w-full bg-white border border-slate-300 rounded p-2 text-slate-800 font-sans text-xs focus:ring-2 focus:ring-slate-400 outline-none"
                />

                {actionError && <p className="text-rose-600 text-xs font-medium">{actionError}</p>}

                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveActionModal('NONE');
                      setActionInput('');
                      setActionError(null);
                    }}
                    className="px-3 py-1 bg-white border border-slate-300 text-slate-700 rounded hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleExecuteActionModal}
                    disabled={isActionLoading}
                    className="px-3 py-1 bg-slate-900 text-white rounded hover:bg-slate-800 font-medium"
                  >
                    {isActionLoading ? 'Saving...' : 'Confirm Action'}
                  </button>
                </div>
              </div>
            )}

            {/* Action Buttons Bar */}
            {activeActionModal === 'NONE' && (
              <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  {onNavigateToEntity && (
                    <button
                      type="button"
                      onClick={() => {
                        onNavigateToEntity(selectedAnomaly.entityType, selectedAnomaly.entityId);
                        setSelectedAnomaly(null);
                      }}
                      className="px-2.5 py-1.5 font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 inline-flex items-center gap-1"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Open {selectedAnomaly.entityType}</span>
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedAnomaly(null)}
                    className="px-3 py-1.5 font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50"
                  >
                    Close
                  </button>

                  {selectedAnomaly.status !== 'RESOLVED' && selectedAnomaly.status !== 'DISMISSED' && (
                    <>
                      {onReviewAnomaly && selectedAnomaly.status !== 'UNDER_REVIEW' && (
                        <button
                          type="button"
                          disabled={isActionLoading}
                          onClick={handleReview}
                          className="px-3 py-1.5 font-semibold text-amber-800 bg-amber-100 hover:bg-amber-200 rounded-lg transition-colors"
                        >
                          Mark Under Review
                        </button>
                      )}

                      {onInvestigateAnomaly && (
                        <button
                          type="button"
                          onClick={() => {
                            setActiveActionModal('INVESTIGATE');
                            setActionInput('');
                          }}
                          className="px-3 py-1.5 font-semibold text-indigo-800 bg-indigo-100 hover:bg-indigo-200 rounded-lg transition-colors"
                        >
                          Flag Investigation
                        </button>
                      )}

                      {onDismissAnomaly && (
                        <button
                          type="button"
                          onClick={() => {
                            setActiveActionModal('DISMISS');
                            setActionInput('');
                          }}
                          className="px-3 py-1.5 font-semibold text-slate-700 bg-slate-200 hover:bg-slate-300 rounded-lg transition-colors"
                        >
                          Dismiss (False Positive)
                        </button>
                      )}

                      {onResolveAnomalyWithNotes && (
                        <button
                          type="button"
                          onClick={() => {
                            setActiveActionModal('RESOLVE');
                            setActionInput('');
                          }}
                          className="px-4 py-1.5 font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors"
                        >
                          Resolve Discrepancy
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </AdminModal>
    </div>
  );
};
