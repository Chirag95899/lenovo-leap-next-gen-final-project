import React, { useState } from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminTimeline } from '../components/AdminTimeline';
import { AdminSearch } from '../components/AdminSearch';
import { AdminFilterBar } from '../components/AdminFilterBar';
import { AdminPagination } from '../components/AdminPagination';
import { AdminModal } from '../components/AdminModal';
import { formatDateTime } from '../utils/formatters';
import { TraceabilityEvent } from '../../shared/types/domain';
import { ShieldCheck, QrCode, Search, Camera } from 'lucide-react';

interface AdminTraceabilityPageProps {
  events: TraceabilityEvent[];
  total: number;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  search: string;
  setSearch: (s: string) => void;
  entityType: string;
  setEntityType: (e: string) => void;
  isLoading: boolean;
  onNavigateToScanner?: () => void;
}

export const AdminTraceabilityPage: React.FC<AdminTraceabilityPageProps> = ({
  events,
  total,
  page,
  totalPages,
  setPage,
  search,
  setSearch,
  entityType,
  setEntityType,
  isLoading,
  onNavigateToScanner,
}) => {
  const [selectedEvent, setSelectedEvent] = useState<TraceabilityEvent | null>(null);

  return (
    <div className="space-y-4">
      
      <AdminPageHeader
        title="Traceability & Digital Chain of Custody"
        description="Immutable event trail from source collection through depot weighment, lot formation, and industrial facility processing."
        badge={
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            100% Cryptographically Sealed
          </span>
        }
        actions={
          onNavigateToScanner && (
          <button
            onClick={onNavigateToScanner}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 shadow-2xs transition-colors"
          >
            <Camera className="w-4 h-4" />
            Scan QR Token
          </button>
        )}
      />


      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200">
          <AdminSearch
            value={search}
            onChange={setSearch}
            placeholder="Search by tracking code, entity ID, hash, or actor..."
          />
        </div>

        <AdminFilterBar
          filters={[
            {
              key: 'entityType',
              label: 'Entity Level:',
              currentValue: entityType,
              options: [
                { label: 'All Entities', value: '' },
                { label: 'Pickup Batches', value: 'PICKUP' },
                { label: 'Aggregated Lots', value: 'LOT' },
              ],
            },
          ]}
          onFilterChange={(key, val) => {
            if (key === 'entityType') setEntityType(val);
            setPage(1);
          }}
          onReset={() => {
            setEntityType('');
            setSearch('');
            setPage(1);
          }}
        />

        <div className="p-6">
          <AdminTimeline
            events={events}
            onSelectEvent={(evt) => setSelectedEvent(evt)}
          />

          {events.length === 0 && !isLoading && (
            <div className="text-center py-12 text-slate-400 text-sm">
              No traceability events matched the query.
            </div>
          )}
        </div>

        <AdminPagination
          currentPage={page}
          totalPages={totalPages}
          totalItems={total}
          itemsPerPage={10}
          onPageChange={setPage}
        />
      </div>

      {/* Event Details Modal */}
      <AdminModal
        isOpen={!!selectedEvent}
        onClose={() => setSelectedEvent(null)}
        title={`Audit Event: ${selectedEvent?.eventType.replace(/_/g, ' ')}`}
        subtitle={`Logged at ${formatDateTime(selectedEvent?.timestamp)}`}
      >
        {selectedEvent && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block mb-1">Actor Identity:</span>
                <span className="font-bold text-slate-900 text-sm">{selectedEvent.actorName}</span>
                <span className="text-[11px] text-slate-500 block">Role: {selectedEvent.actorRole}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-400 block mb-1">Location Coordinates:</span>
                <span className="font-bold text-slate-900 text-sm">{selectedEvent.location}</span>
                <span className="text-[11px] text-slate-500 block">City Zone: {selectedEvent.location}</span>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-400 block mb-1">Tracking Code & Entity:</span>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-emerald-700 text-sm">
                  {selectedEvent.trackingCode}
                </span>
                <span className="px-1.5 py-0.5 bg-slate-200 rounded font-semibold text-[10px]">
                  {selectedEvent.entityType} ({selectedEvent.entityId})
                </span>
              </div>
            </div>

            {selectedEvent.verificationHash && (
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                <span className="text-emerald-800 font-semibold block mb-1">
                  Cryptographic Integrity Seal:
                </span>
                <p className="font-mono text-[11px] text-emerald-900 break-all bg-emerald-100/60 p-2 rounded">
                  {selectedEvent.verificationHash}
                </p>
              </div>
            )}

            {selectedEvent.details && (
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-500 font-semibold block mb-1">Telemetry Payload:</span>
                <pre className="font-mono text-[11px] text-slate-700 bg-white p-2 rounded border border-slate-200 overflow-x-auto">
                  {JSON.stringify(selectedEvent.details, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
      </AdminModal>
    </div>
  );
};
