import React, { useState } from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { AdminSearch } from '../components/AdminSearch';
import { AdminFilterBar } from '../components/AdminFilterBar';
import { AdminPagination } from '../components/AdminPagination';
import { AdminStatusBadge } from '../components/AdminStatusBadge';
import { AdminModal } from '../components/AdminModal';
import { AdminQrCodeView } from '../components/AdminQrCodeView';
import { AdminPickupDetailDrawer } from '../components/AdminPickupDetailDrawer';
import { formatDateTime, formatWeight, formatInr } from '../utils/formatters';
import { PickupRequest, PickupStatus } from '../../shared/types/domain';
import { TableColumn } from '../types/admin';
import {
  QrCode,
  Eye,
  Camera,
  Truck,
  Building2,
  Boxes,
  Scale,
  Calendar,
  Layers,
} from 'lucide-react';

interface AdminPickupsPageProps {
  pickups: PickupRequest[];
  total: number;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  search: string;
  setSearch: (s: string) => void;
  status: string;
  setStatus: (st: string) => void;
  category: string;
  setCategory: (c: string) => void;
  isLoading: boolean;
  onUpdateStatus?: (id: string, status: PickupStatus, reason?: string) => Promise<void>;
  onNavigateToLot?: (lotId: string) => void;
  onNavigateToScanner?: () => void;
}

export const AdminPickupsPage: React.FC<AdminPickupsPageProps> = ({
  pickups,
  total,
  page,
  totalPages,
  setPage,
  search,
  setSearch,
  status,
  setStatus,
  category,
  setCategory,
  isLoading,
  onNavigateToLot,
  onNavigateToScanner,
}) => {
  const [selectedPickupId, setSelectedPickupId] = useState<string | null>(null);
  const [viewQrPickup, setViewQrPickup] = useState<PickupRequest | null>(null);

  const columns: TableColumn<PickupRequest>[] = [
    {
      key: 'trackingCode',
      header: 'Tracking / Request ID',
      render: (p) => (
        <div>
          <div className="flex items-center gap-1.5">
            <span className="font-mono font-bold text-emerald-700">{p.trackingCode}</span>
            {p.lotId && (
              <span className="text-[10px] uppercase font-bold text-purple-700 bg-purple-50 px-1.5 py-0.2 rounded border border-purple-200">
                In Lot
              </span>
            )}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            ID: {p.id} • {formatDateTime(p.createdAt)}
          </div>
        </div>
      ),
    },
    {
      key: 'parties',
      header: 'Chain of Custody',
      render: (p) => (
        <div className="text-xs space-y-0.5">
          <div className="font-semibold text-slate-900 flex items-center gap-1">
            <span className="text-slate-400 text-[10px]">By:</span> {p.collectorName}
          </div>
          <div className="text-slate-600 text-[11px] truncate max-w-[160px] flex items-center gap-1">
            <span className="text-slate-400 text-[10px]">Hub:</span> {p.aggregatorName}
          </div>
          {p.recyclerName && (
            <div className="text-purple-700 text-[11px] truncate max-w-[160px] flex items-center gap-1">
              <span className="text-purple-400 text-[10px]">Recycler:</span> {p.recyclerName}
            </div>
          )}
        </div>
      ),
    },
    {
      key: 'material',
      header: 'Material & Category',
      render: (p) => (
        <div className="text-xs">
          <div className="font-bold text-slate-900">{p.materialName}</div>
          <div className="text-slate-500 text-[11px]">{p.category}</div>
          {p.source && (
            <span className="text-[10px] text-slate-400 bg-slate-100 px-1.5 py-0.2 rounded mt-0.5 inline-block">
              {p.source}
            </span>
          )}
        </div>
      ),
    },
    {
      key: 'weight',
      header: 'Quantity & Weight',
      render: (p) => (
        <div className="text-xs">
          <div className="font-bold text-slate-900">
            {p.quantityKg} {p.unit || 'kg'}
          </div>
          {p.actualWeightKg != null ? (
            <div className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
              <Scale className="w-3 h-3" />
              <span>Verified: {formatWeight(p.actualWeightKg)}</span>
            </div>
          ) : (
            <div className="text-[10px] text-slate-400">Intake pending</div>
          )}
        </div>
      ),
    },
    {
      key: 'location',
      header: 'Location / Schedule',
      render: (p) => (
        <div className="text-xs text-slate-700">
          <div className="font-medium truncate max-w-[140px]">
            {p.location.city}, {p.location.ward}
          </div>
          <div className="text-[11px] text-slate-400">
            {p.preferredDate || 'Immediate'}
          </div>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (p) => <AdminStatusBadge status={p.status} size="sm" />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (p) => (
        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => setViewQrPickup(p)}
            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors"
            title="Inspect physical QR tag"
          >
            <QrCode className="w-4 h-4" />
          </button>
          <button
            onClick={() => setSelectedPickupId(p.id)}
            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
            title="Inspect complete pickup detail & traceability"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div id="admin-pickups-page" className="space-y-4">
      <AdminPageHeader
        title="Pickup Request Ledger"
        description="Unified ledger of waste collections logged by informal collectors, aggregated at neighborhood hubs, and sealed for industrial recycling."
      />
<div className="mb-6 flex gap-2">

        <div className="flex items-center gap-2">
          {onNavigateToScanner && (
            <button
              onClick={onNavigateToScanner}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 shadow-2xs transition-colors"
            >
              <Camera className="w-4 h-4" />
              Launch QR Scanner
            </button>
          )}
        </div>
      
</div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200">
          <AdminSearch
            value={search}
            onChange={setSearch}
            placeholder="Search by request ID, tracking code, collector, aggregator, recycler, or material..."
          />
        </div>

        <AdminFilterBar
          filters={[
            {
              key: 'status',
              label: 'Status:',
              currentValue: status,
              options: [
                { label: 'All Statuses', value: '' },
                { label: 'Requested', value: 'REQUESTED' },
                { label: 'Accepted', value: 'ACCEPTED' },
                { label: 'Scheduled', value: 'SCHEDULED' },
                { label: 'Collector Ready', value: 'COLLECTOR_READY' },
                { label: 'Picked Up', value: 'PICKED_UP' },
                { label: 'Collected', value: 'COLLECTED' },
                { label: 'Aggregated into Lot', value: 'AGGREGATED' },
                { label: 'Completed', value: 'COMPLETED' },
                { label: 'Cancelled', value: 'CANCELLED' },
              ],
            },
            {
              key: 'category',
              label: 'Category:',
              currentValue: category,
              options: [
                { label: 'All Categories', value: '' },
                { label: 'Plastic', value: 'PLASTIC' },
                { label: 'Metal', value: 'METAL' },
                { label: 'Paper', value: 'PAPER' },
                { label: 'E-Waste', value: 'E_WASTE' },
                { label: 'Glass', value: 'GLASS' },
              ],
            },
          ]}
          onFilterChange={(key, val) => {
            if (key === 'status') setStatus(val);
            if (key === 'category') setCategory(val);
            setPage(1);
          }}
          onReset={() => {
            setStatus('');
            setCategory('');
            setSearch('');
            setPage(1);
          }}
        />

        <AdminDataTable
          columns={columns}
          data={pickups}
          keyExtractor={(p) => p.id}
          isLoading={isLoading}
          onRowClick={(p) => setSelectedPickupId(p.id)}
          emptyTitle="No pickup records matching query"
        />

        <AdminPagination
          currentPage={page}
          totalPages={totalPages}
          totalItems={total}
          itemsPerPage={10}
          onPageChange={setPage}
        />
      </div>

      {/* Comprehensive Pickup Detail Drawer */}
      <AdminPickupDetailDrawer
        pickupId={selectedPickupId}
        onClose={() => setSelectedPickupId(null)}
        onNavigateToLot={onNavigateToLot}
      />

      {/* Standalone Quick QR Code Modal */}
      <AdminModal
        isOpen={!!viewQrPickup}
        onClose={() => setViewQrPickup(null)}
        title="Physical Traceability Tag"
        subtitle={`Cryptographic Verification Tag for ${viewQrPickup?.trackingCode}`}
        maxWidth="sm"
      >
        {viewQrPickup && (
          <AdminQrCodeView
            value={viewQrPickup.qrCode || `RECYSETU:PK:${viewQrPickup.id}:${viewQrPickup.trackingCode}`}
            title={viewQrPickup.trackingCode}
            subtitle="Scannable by Aggregators & Destination Recyclers"
            metadata={{
              entityType: 'PICKUP',
              identifier: viewQrPickup.trackingCode,
              material: viewQrPickup.materialName,
              weightKg: viewQrPickup.quantityKg,
              status: viewQrPickup.status,
            }}
            size={190}
          />
        )}
      </AdminModal>
    </div>
  );
};
