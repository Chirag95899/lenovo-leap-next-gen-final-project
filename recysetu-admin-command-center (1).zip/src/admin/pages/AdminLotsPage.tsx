import React, { useState } from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { AdminSearch } from '../components/AdminSearch';
import { AdminFilterBar } from '../components/AdminFilterBar';
import { AdminPagination } from '../components/AdminPagination';
import { AdminStatusBadge } from '../components/AdminStatusBadge';
import { AdminModal } from '../components/AdminModal';
import { AdminQrCodeView } from '../components/AdminQrCodeView';
import { AdminLotDetailDrawer } from '../components/AdminLotDetailDrawer';
import { formatDateTime, formatWeight, formatInr } from '../utils/formatters';
import { AggregatedLot, LotStatus } from '../../shared/types/domain';
import { TableColumn } from '../types/admin';
import {
  Boxes,
  Eye,
  QrCode,
  Camera,
  Scale,
  AlertTriangle,
  CheckCircle2,
  Building2,
  Factory,
} from 'lucide-react';

interface AdminLotsPageProps {
  lots: AggregatedLot[];
  total: number;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  search: string;
  setSearch: (s: string) => void;
  status: string;
  setStatus: (st: string) => void;
  category: string;
  setCategory: (c: string) => void;
  hasDiscrepancy?: boolean;
  setHasDiscrepancy?: (hd: boolean) => void;
  isLoading: boolean;
  onUpdateLotStatus?: (id: string, status: LotStatus, reason?: string) => Promise<void>;
  onNavigateToPickup?: (pickupId: string) => void;
  onNavigateToScanner?: () => void;
}

export const AdminLotsPage: React.FC<AdminLotsPageProps> = ({
  lots,
  total,
  page,
  totalPages,
  setPage,
  search,
  setSearch,
  status,
  setStatus,
  category,
  setCategory,
  hasDiscrepancy = false,
  setHasDiscrepancy,
  isLoading,
  onNavigateToPickup,
  onNavigateToScanner,
}) => {
  const [selectedLotId, setSelectedLotId] = useState<string | null>(null);
  const [viewQrLot, setViewQrLot] = useState<AggregatedLot | null>(null);

  const columns: TableColumn<AggregatedLot>[] = [
    {
      key: 'lotNumber',
      header: 'Lot Identifier',
      render: (l) => (
        <div>
          <div className="flex items-center gap-1.5">
            <span className="font-mono font-bold text-slate-900">{l.lotNumber}</span>
            {l.isDiscrepancyFlagged && (
              <span
                className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200 flex items-center gap-0.5"
                title="Weight Discrepancy > 5% flagged between aggregator and recycler weighbridges"
              >
                <AlertTriangle className="w-3 h-3 text-rose-600" />
                Discrepancy
              </span>
            )}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            ID: {l.id} • {formatDateTime(l.createdAt)}
          </div>
        </div>
      ),
    },
    {
      key: 'participants',
      header: 'Aggregator → Recycler',
      render: (l) => (
        <div className="text-xs space-y-0.5">
          <div className="font-semibold text-slate-900 truncate max-w-[170px] flex items-center gap-1">
            <Building2 className="w-3 h-3 text-blue-600 shrink-0" />
            <span>{l.aggregatorName}</span>
          </div>
          <div className="text-slate-600 text-[11px] truncate max-w-[170px] flex items-center gap-1">
            <Factory className="w-3 h-3 text-purple-600 shrink-0" />
            <span>{l.recyclerName}</span>
          </div>
        </div>
      ),
    },
    {
      key: 'material',
      header: 'Material & Grade',
      render: (l) => (
        <div className="text-xs">
          <div className="font-bold text-slate-900">{l.materialName}</div>
          <div className="flex items-center gap-1 text-[11px] text-slate-500 mt-0.5">
            <span>{l.category}</span>
            <span className="font-semibold px-1.5 py-0.2 bg-slate-100 rounded text-[10px] text-slate-700">
              Grade: {l.qualityGrade}
            </span>
          </div>
        </div>
      ),
    },
    {
      key: 'weightAnalysis',
      header: 'Weight Verification',
      render: (l) => {
        const declared = l.declaredWeightKg || l.totalWeightKg;
        const actual = l.actualWeightKg;
        return (
          <div className="text-xs">
            <div className="flex items-center gap-1 text-slate-900 font-medium">
              <span className="text-slate-400 text-[10px]">Declared:</span>
              <span className="font-bold">{formatWeight(declared)}</span>
            </div>
            {actual != null ? (
              <div className="flex items-center gap-1 text-[11px] mt-0.5">
                <span className="text-slate-400 text-[10px]">Intake:</span>
                <span className={`font-bold ${l.isDiscrepancyFlagged ? 'text-rose-600' : 'text-emerald-700'}`}>
                  {formatWeight(actual)}
                </span>
                {l.weightDiscrepancyKg !== undefined && Math.abs(l.weightDiscrepancyKg) > 0 && (
                  <span className={`text-[10px] font-mono px-1 rounded ${l.isDiscrepancyFlagged ? 'bg-rose-50 text-rose-700' : 'bg-slate-100 text-slate-600'}`}>
                    {l.weightDiscrepancyKg > 0 ? '+' : ''}{l.weightDiscrepancyKg.toFixed(1)}kg
                  </span>
                )}
              </div>
            ) : (
              <div className="text-[10px] text-slate-400 mt-0.5">Weighbridge pending</div>
            )}
          </div>
        );
      },
    },
    {
      key: 'pickupsCount',
      header: 'Consolidated Batches',
      align: 'center',
      render: (l) => (
        <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 font-mono">
          {l.pickupIds?.length || 0} pickups
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (l) => <AdminStatusBadge status={l.status} size="sm" />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (l) => (
        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => setViewQrLot(l)}
            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors"
            title="Inspect batch QR verification tag"
          >
            <QrCode className="w-4 h-4" />
          </button>
          <button
            onClick={() => setSelectedLotId(l.id)}
            className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
            title="Inspect lot details, weight discrepancy & traceability"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div id="admin-lots-page" className="space-y-4">
      <AdminPageHeader
        title="Aggregated Material Lots"
        description="Consolidated industrial consignments generated by aggregators, verified through weighbridge intake, and dispatched to authorized recyclers."
      />
<div className="mb-6 flex gap-2">

        <div className="flex items-center gap-2">
          {onNavigateToScanner && (
            <button
              onClick={onNavigateToScanner}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 shadow-2xs transition-colors"
            >
              <Camera className="w-4 h-4" />
              Launch QR Scanner
            </button>
          )}
        </div>
      
</div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex-1 min-w-[240px]">
            <AdminSearch
              value={search}
              onChange={setSearch}
              placeholder="Search by lot number, aggregator, recycler, material, or quality grade..."
            />
          </div>

          {setHasDiscrepancy && (
            <button
              type="button"
              onClick={() => {
                setHasDiscrepancy(!hasDiscrepancy);
                setPage(1);
              }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold border transition-all ${
                hasDiscrepancy
                  ? 'bg-rose-50 text-rose-800 border-rose-300 shadow-2xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <AlertTriangle className={`w-3.5 h-3.5 ${hasDiscrepancy ? 'text-rose-600' : 'text-slate-400'}`} />
              <span>Weight Discrepancy Flagged</span>
            </button>
          )}
        </div>

        <AdminFilterBar
          filters={[
            {
              key: 'status',
              label: 'Status:',
              currentValue: status,
              options: [
                { label: 'All Statuses', value: '' },
                { label: 'Created / Formed', value: 'CREATED' },
                { label: 'Ready for Pickup', value: 'READY_FOR_PICKUP' },
                { label: 'In Transit', value: 'IN_TRANSIT' },
                { label: 'Delivered to Plant', value: 'DELIVERED' },
                { label: 'Accepted by Recycler', value: 'ACCEPTED' },
                { label: 'Processing at Facility', value: 'PROCESSING' },
                { label: 'Recycling Completed', value: 'COMPLETED' },
                { label: 'Rejected', value: 'REJECTED' },
              ],
            },
            {
              key: 'category',
              label: 'Category:',
              currentValue: category,
              options: [
                { label: 'All Categories', value: '' },
                { label: 'Plastic', value: 'PLASTIC' },
                { label: 'Metal', value: 'METAL' },
                { label: 'Paper', value: 'PAPER' },
                { label: 'E-Waste', value: 'E_WASTE' },
                { label: 'Glass', value: 'GLASS' },
              ],
            },
          ]}
          onFilterChange={(key, val) => {
            if (key === 'status') setStatus(val);
            if (key === 'category') setCategory(val);
            setPage(1);
          }}
          onReset={() => {
            setStatus('');
            setCategory('');
            setSearch('');
            if (setHasDiscrepancy) setHasDiscrepancy(false);
            setPage(1);
          }}
        />

        <AdminDataTable
          columns={columns}
          data={lots}
          keyExtractor={(l) => l.id}
          isLoading={isLoading}
          onRowClick={(l) => setSelectedLotId(l.id)}
          emptyTitle="No aggregated lots matching criteria"
        />

        <AdminPagination
          currentPage={page}
          totalPages={totalPages}
          totalItems={total}
          itemsPerPage={10}
          onPageChange={setPage}
        />
      </div>

      {/* Comprehensive Lot Detail Drawer with Weight Discrepancy UI */}
      <AdminLotDetailDrawer
        lotId={selectedLotId}
        onClose={() => setSelectedLotId(null)}
        onNavigateToPickup={onNavigateToPickup}
      />

      {/* Standalone Quick QR Code Modal */}
      <AdminModal
        isOpen={!!viewQrLot}
        onClose={() => setViewQrLot(null)}
        title="Consignment Batch QR Tag"
        subtitle={`Cryptographic Verification Code for ${viewQrLot?.lotNumber}`}
        maxWidth="sm"
      >
        {viewQrLot && (
          <AdminQrCodeView
            value={viewQrLot.batchQrCode || `RECYSETU:LOT:${viewQrLot.id}:${viewQrLot.lotNumber}`}
            title={viewQrLot.lotNumber}
            subtitle="Industrial Batch Tag for Destination Recycling Intake"
            metadata={{
              entityType: 'LOT',
              identifier: viewQrLot.lotNumber,
              material: `${viewQrLot.materialName} (${viewQrLot.qualityGrade})`,
              weightKg: viewQrLot.actualWeightKg != null ? viewQrLot.actualWeightKg : viewQrLot.totalWeightKg,
              status: viewQrLot.status,
            }}
            size={190}
          />
        )}
      </AdminModal>
    </div>
  );
};
