import React, { useState, useEffect } from 'react';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminDataTable } from '../components/AdminDataTable';
import { AdminSearch } from '../components/AdminSearch';
import { AdminFilterBar } from '../components/AdminFilterBar';
import { AdminPagination } from '../components/AdminPagination';
import { AdminStatusBadge } from '../components/AdminStatusBadge';
import { AdminModal } from '../components/AdminModal';
import { formatDateTime, formatInr } from '../utils/formatters';
import { PaymentRecord, TraceabilityEvent } from '../../shared/types/domain';
import { TableColumn } from '../types/admin';
import { adminApi } from '../services/adminApiService';
import {
  CreditCard,
  ShieldAlert,
  CheckCircle2,
  Lock,
  Unlock,
  AlertTriangle,
  FileText,
  Clock,
  ArrowRight,
  ExternalLink,
  DollarSign,
  Scale,
  RefreshCw,
  XCircle,
  Gavel,
  BellRing,
} from 'lucide-react';

interface AdminPaymentsPageProps {
  payments: PaymentRecord[];
  total: number;
  page: number;
  totalPages: number;
  setPage: (p: number) => void;
  search: string;
  setSearch: (s: string) => void;
  status: string;
  setStatus: (st: string) => void;
  startDate?: string;
  setStartDate?: (d: string) => void;
  endDate?: string;
  setEndDate?: (d: string) => void;
  minAmount?: number;
  setMinAmount?: (a?: number) => void;
  maxAmount?: number;
  setMaxAmount?: (a?: number) => void;
  disputedOnly?: boolean;
  setDisputedOnly?: (d: boolean) => void;
  paymentMethod?: string;
  setPaymentMethod?: (m: string) => void;
  isLoading: boolean;
  onFlagPayment: (id: string, flagged: boolean, reason?: string) => Promise<void>;
  onResolveDispute?: (
    id: string,
    action: 'HOLD_ESCROW' | 'RELEASE_PAYOUT' | 'REFUND_PAYER' | 'ARBITRATE' | 'CLEAR_FLAG',
    reason: string
  ) => Promise<any>;
}

export const AdminPaymentsPage: React.FC<AdminPaymentsPageProps> = ({
  payments,
  total,
  page,
  totalPages,
  setPage,
  search,
  setSearch,
  status,
  setStatus,
  startDate = '',
  setStartDate,
  endDate = '',
  setEndDate,
  minAmount,
  setMinAmount,
  maxAmount,
  setMaxAmount,
  disputedOnly = false,
  setDisputedOnly,
  paymentMethod = '',
  setPaymentMethod,
  isLoading,
  onFlagPayment,
  onResolveDispute,
}) => {
  const [selectedPaymentId, setSelectedPaymentId] = useState<string | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [paymentDetail, setPaymentDetail] = useState<{
    payment: PaymentRecord;
    payer: any;
    payee: any;
    relatedLot: any;
    relatedPickup: any;
    lifecycleEvents: TraceabilityEvent[];
    auditLogs: any[];
    notifications: any[];
  } | null>(null);

  // Dispute Action Modal state
  const [disputeActionTarget, setDisputeActionTarget] = useState<{
    payment: PaymentRecord;
    action: 'HOLD_ESCROW' | 'RELEASE_PAYOUT' | 'REFUND_PAYER' | 'ARBITRATE' | 'CLEAR_FLAG';
  } | null>(null);
  const [disputeReason, setDisputeReason] = useState('');
  const [isProcessingDispute, setIsProcessingDispute] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Local filter inputs for amount & date
  const [tempMinAmount, setTempMinAmount] = useState<string>(minAmount ? minAmount.toString() : '');
  const [tempMaxAmount, setTempMaxAmount] = useState<string>(maxAmount ? maxAmount.toString() : '');
  const [tempStartDate, setTempStartDate] = useState<string>(startDate);
  const [tempEndDate, setTempEndDate] = useState<string>(endDate);

  const fetchDetail = async (id: string) => {
    setDetailLoading(true);
    try {
      const res = await adminApi.getPaymentDetail(id);
      if (res && res.payment) {
        setPaymentDetail(res);
      }
    } catch (err) {
      console.error('Failed to load payment detail:', err);
    } finally {
      setDetailLoading(false);
    }
  };

  useEffect(() => {
    if (selectedPaymentId) {
      fetchDetail(selectedPaymentId);
    } else {
      setPaymentDetail(null);
    }
  }, [selectedPaymentId]);

  const handleApplyRangeFilters = () => {
    if (setMinAmount) {
      const min = tempMinAmount ? parseFloat(tempMinAmount) : undefined;
      setMinAmount(isNaN(min!) ? undefined : min);
    }
    if (setMaxAmount) {
      const max = tempMaxAmount ? parseFloat(tempMaxAmount) : undefined;
      setMaxAmount(isNaN(max!) ? undefined : max);
    }
    if (setStartDate) setStartDate(tempStartDate);
    if (setEndDate) setEndDate(tempEndDate);
    setPage(1);
  };

  const handleClearAllFilters = () => {
    setStatus('');
    setSearch('');
    setTempMinAmount('');
    setTempMaxAmount('');
    setTempStartDate('');
    setTempEndDate('');
    if (setMinAmount) setMinAmount(undefined);
    if (setMaxAmount) setMaxAmount(undefined);
    if (setStartDate) setStartDate('');
    if (setEndDate) setEndDate('');
    if (setDisputedOnly) setDisputedOnly(false);
    if (setPaymentMethod) setPaymentMethod('');
    setPage(1);
  };

  const handleConfirmDisputeAction = async () => {
    if (!disputeActionTarget) return;
    if (!disputeReason.trim() || disputeReason.trim().length < 5) {
      setActionError('Please provide a mandatory justification of at least 5 characters.');
      return;
    }

    setIsProcessingDispute(true);
    setActionError(null);
    try {
      if (onResolveDispute) {
        await onResolveDispute(
          disputeActionTarget.payment.id,
          disputeActionTarget.action,
          disputeReason.trim()
        );
      } else {
        await adminApi.resolvePaymentDispute(
          disputeActionTarget.payment.id,
          disputeActionTarget.action,
          disputeReason.trim()
        );
      }

      if (selectedPaymentId === disputeActionTarget.payment.id) {
        await fetchDetail(disputeActionTarget.payment.id);
      }
      setDisputeActionTarget(null);
      setDisputeReason('');
    } catch (err: any) {
      setActionError(err.message || 'Failed to submit financial arbitration.');
    } finally {
      setIsProcessingDispute(false);
    }
  };

  const columns: TableColumn<PaymentRecord>[] = [
    {
      key: 'id',
      header: 'Payment ID / UPI Ref',
      render: (p) => (
        <div>
          <span className="font-mono font-bold text-slate-900">{p.id}</span>
          <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1 mt-0.5">
            <span>{p.transactionId}</span>
            {p.upiRefNumber && <span className="text-emerald-700 font-semibold">• {p.upiRefNumber}</span>}
          </div>
        </div>
      ),
    },
    {
      key: 'relatedEntity',
      header: 'Related Lot / Pickup',
      render: (p) => (
        <div className="text-xs">
          <span className="font-mono font-semibold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded">
            {p.relatedTrackingCode || p.relatedEntityId}
          </span>
          <div className="text-[11px] text-slate-500 mt-0.5 capitalize">
            Type: {p.relatedEntityType}
          </div>
        </div>
      ),
    },
    {
      key: 'parties',
      header: 'Payer → Payee',
      render: (p) => (
        <div className="text-xs">
          <div className="font-semibold text-slate-900 flex items-center gap-1">
            <span>{p.payerName}</span>
            <span className="text-slate-400 text-[10px]">({p.payerRole})</span>
          </div>
          <div className="text-slate-500 text-[11px] flex items-center gap-1">
            <span>→ {p.payeeName}</span>
            <span className="text-slate-400 text-[10px]">({p.payeeRole})</span>
          </div>
        </div>
      ),
    },
    {
      key: 'amount',
      header: 'Amount',
      render: (p) => (
        <div>
          <div className="font-bold text-slate-900 text-sm font-mono">{formatInr(p.amount)}</div>
          <div className="text-[10px] text-slate-400 uppercase tracking-wide">
            {p.paymentMethod || 'UPI Direct'}
          </div>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (p) => {
        const isDisputed =
          p.status === 'DISPUTED' ||
          p.status === 'FLAGGED' ||
          (p.disputeStatus && p.disputeStatus !== 'NONE');

        return (
          <div className="flex items-center gap-1.5">
            <AdminStatusBadge status={p.status} size="sm" />
            {isDisputed && (
              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-bold rounded bg-amber-100 text-amber-900 border border-amber-300">
                <AlertTriangle className="w-3 h-3 text-amber-700" />
                {p.disputeStatus || 'DISPUTED'}
              </span>
            )}
          </div>
        );
      },
    },
    {
      key: 'createdDate',
      header: 'Created / Updated',
      render: (p) => (
        <div className="text-xs">
          <div className="text-slate-700 font-medium">{formatDateTime(p.createdAt || p.timestamp)}</div>
          {p.updatedAt && p.updatedAt !== (p.createdAt || p.timestamp) && (
            <div className="text-[10px] text-slate-400">Upd: {formatDateTime(p.updatedAt)}</div>
          )}
        </div>
      ),
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (p) => (
        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => setSelectedPaymentId(p.id)}
            className="px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-md transition-colors"
          >
            View Dossier
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <AdminPageHeader
        title="Direct Payments & Escrow Clearing"
        description="Authoritative financial ledger tracking live UPI, bank clearing, escrow holds, and formal dispute arbitrations without simulated records."
      />

      {/* Main Search & Filters Card */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-200 space-y-3">
          <AdminSearch
            value={search}
            onChange={setSearch}
            placeholder="Search Payment ID, Lot ID, Collector, Aggregator, Recycler..."
          />

          {/* Extended Server-side filters: Status, Dates, Amounts */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-2.5 pt-1 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => {
                  setStatus(e.target.value);
                  setPage(1);
                }}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              >
                <option value="">All Statuses</option>
                <option value="PAID">PAID (Completed)</option>
                <option value="PENDING">PENDING</option>
                <option value="PROCESSING">PROCESSING</option>
                <option value="DISPUTED">DISPUTED / Escrow Hold</option>
                <option value="FAILED">FAILED</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Start Date</label>
              <input
                type="date"
                value={tempStartDate}
                onChange={(e) => setTempStartDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">End Date</label>
              <input
                type="date"
                value={tempEndDate}
                onChange={(e) => setTempEndDate(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div className="flex items-end gap-2">
              <div className="flex-1">
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Min ₹</label>
                <input
                  type="number"
                  placeholder="Min"
                  value={tempMinAmount}
                  onChange={(e) => setTempMinAmount(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                />
              </div>
              <div className="flex-1">
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Max ₹</label>
                <input
                  type="number"
                  placeholder="Max"
                  value={tempMaxAmount}
                  onChange={(e) => setTempMaxAmount(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                />
              </div>
              <button
                onClick={handleApplyRangeFilters}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-lg shadow-2xs transition-colors shrink-0"
                title="Apply date and amount filters"
              >
                Apply
              </button>
              <button
                onClick={handleClearAllFilters}
                className="px-2.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition-colors shrink-0"
                title="Reset all filters"
              >
                Reset
              </button>
            </div>
          </div>
        </div>

        <AdminDataTable
          columns={columns}
          data={payments}
          keyExtractor={(p) => p.id}
          isLoading={isLoading}
          onRowClick={(p) => setSelectedPaymentId(p.id)}
          emptyTitle="No payment records match criteria"
        />

        <AdminPagination
          currentPage={page}
          totalPages={totalPages}
          totalItems={total}
          itemsPerPage={10}
          onPageChange={setPage}
        />
      </div>

      {/* Payment Detailed Dossier Modal */}
      <AdminModal
        isOpen={!!selectedPaymentId}
        onClose={() => {
          setSelectedPaymentId(null);
          setPaymentDetail(null);
        }}
        title={`Payment Audit Record: ${selectedPaymentId}`}
        subtitle={
          paymentDetail?.payment.transactionId
            ? `UPI/Bank Txn: ${paymentDetail.payment.transactionId}`
            : 'Authoritative Escrow & Payment Record'
        }
        maxWidth="lg"
      >
        {detailLoading ? (
          <div className="p-8 text-center text-slate-500 text-xs animate-pulse">
            Loading secure payment dossier and blockchain traceability...
          </div>
        ) : paymentDetail ? (
          <div className="space-y-4 text-xs">
            {/* Top Financial Overview Banner */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-4">
              <div>
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide block">
                  Net Settlement Amount
                </span>
                <div className="text-2xl font-black text-emerald-800 font-mono mt-0.5">
                  {formatInr(paymentDetail.payment.amount)}
                </div>
                <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
                  <span>Method: {paymentDetail.payment.paymentMethod || 'UPI Direct Transfer'}</span>
                  <span>•</span>
                  <span>Escrow: <strong className="text-slate-800">{paymentDetail.payment.escrowStatus || 'DIRECT'}</strong></span>
                </div>
              </div>

              <div className="flex flex-col items-end gap-1.5">
                <AdminStatusBadge status={paymentDetail.payment.status} size="md" />
                {paymentDetail.payment.disputeStatus && paymentDetail.payment.disputeStatus !== 'NONE' && (
                  <span className="px-2 py-0.5 text-[11px] font-bold rounded bg-amber-100 text-amber-900 border border-amber-300">
                    Dispute: {paymentDetail.payment.disputeStatus}
                  </span>
                )}
              </div>
            </div>

            {/* Provider and Security Identifiers */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="text-[11px] font-bold uppercase text-slate-500 block mb-1">
                  Provider & Banking Identifiers
                </span>
                <div className="space-y-1 font-mono text-[11px]">
                  <div>
                    <span className="text-slate-400">Payment ID:</span>{' '}
                    <strong className="text-slate-900">{paymentDetail.payment.id}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400">Transaction Ref:</span>{' '}
                    <strong className="text-slate-900">{paymentDetail.payment.transactionId}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400">UPI Ref (RRN):</span>{' '}
                    <strong className="text-slate-900">
                      {paymentDetail.payment.upiRefNumber || 'N/A (Pending Bank Settlement)'}
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400">Provider Ref:</span>{' '}
                    <span className="text-slate-700 font-medium">
                      {paymentDetail.payment.providerRef || 'NPCI_UPI_ROUTER'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="text-[11px] font-bold uppercase text-slate-500 block mb-1">
                  Associated Entity & Traceability
                </span>
                <div className="space-y-1 text-[11px]">
                  <div>
                    <span className="text-slate-400">Entity Type:</span>{' '}
                    <strong className="text-slate-900 uppercase">{paymentDetail.payment.relatedEntityType}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400">Tracking Code:</span>{' '}
                    <strong className="font-mono text-emerald-800">
                      {paymentDetail.payment.relatedTrackingCode || paymentDetail.payment.relatedEntityId}
                    </strong>
                  </div>
                  {paymentDetail.relatedLot && (
                    <div className="text-slate-600 mt-1 pt-1 border-t border-slate-100">
                      Lot Material: <strong>{paymentDetail.relatedLot.materialName}</strong> ({paymentDetail.relatedLot.totalWeightKg} kg)
                      <div className="text-[10px] text-slate-500">
                        Weight Reconciled: Declared {paymentDetail.relatedLot.declaredWeightKg} kg vs Actual{' '}
                        {paymentDetail.relatedLot.actualWeightKg ?? paymentDetail.relatedLot.totalWeightKg} kg
                      </div>
                    </div>
                  )}
                  {paymentDetail.relatedPickup && (
                    <div className="text-slate-600 mt-1 pt-1 border-t border-slate-100">
                      Pickup Request: <strong>{paymentDetail.relatedPickup.materialName}</strong> ({paymentDetail.relatedPickup.quantityKg} kg)
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Payer and Payee Dossiers */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="text-[11px] font-bold uppercase text-slate-500 block mb-1">
                  Payer Party ({paymentDetail.payment.payerRole})
                </span>
                <div className="font-semibold text-slate-900 text-sm">{paymentDetail.payment.payerName}</div>
                {paymentDetail.payer ? (
                  <div className="text-slate-500 text-[11px] mt-0.5 space-y-0.5">
                    <div>Org: {paymentDetail.payer.organizationName || 'Independent'}</div>
                    <div>Location: {paymentDetail.payer.city}</div>
                    <div className="font-mono">Contact: {paymentDetail.payer.phone}</div>
                  </div>
                ) : (
                  <div className="text-slate-400 text-[11px]">System Account</div>
                )}
              </div>

              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="text-[11px] font-bold uppercase text-slate-500 block mb-1">
                  Payee Beneficiary ({paymentDetail.payment.payeeRole})
                </span>
                <div className="font-semibold text-slate-900 text-sm">{paymentDetail.payment.payeeName}</div>
                {paymentDetail.payee ? (
                  <div className="text-slate-500 text-[11px] mt-0.5 space-y-0.5">
                    <div>Org: {paymentDetail.payee.organizationName || 'Independent Waste Collector'}</div>
                    <div>Location: {paymentDetail.payee.city}</div>
                    <div className="font-mono">Beneficiary Mobile: {paymentDetail.payee.phone}</div>
                  </div>
                ) : (
                  <div className="text-slate-400 text-[11px]">Direct Recipient</div>
                )}
              </div>
            </div>

            {/* Dispute Dossier if exists */}
            {(paymentDetail.payment.disputeReason ||
              paymentDetail.payment.status === 'DISPUTED' ||
              paymentDetail.payment.status === 'FLAGGED') && (
              <div className="p-3.5 bg-amber-50 rounded-lg border border-amber-200 text-amber-900">
                <div className="flex items-center gap-1.5 font-bold mb-1">
                  <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>Dispute / Compliance Hold Summary</span>
                </div>
                <div className="text-xs leading-relaxed">
                  Reason: {paymentDetail.payment.disputeReason || paymentDetail.payment.referenceNotes || 'Flagged for admin arbitration.'}
                </div>
                {paymentDetail.payment.disputedAt && (
                  <div className="text-[10px] text-amber-800 mt-1">
                    Filed On: {formatDateTime(paymentDetail.payment.disputedAt)}
                  </div>
                )}
              </div>
            )}

            {/* Sensitive Admin Dispute Actions Bar */}
            <div className="p-3 bg-slate-100 rounded-lg border border-slate-200">
              <span className="text-[11px] font-bold uppercase text-slate-600 block mb-2">
                Authorized Financial Actions
              </span>
              <div className="flex flex-wrap items-center gap-2">
                {paymentDetail.payment.escrowStatus !== 'HELD' && paymentDetail.payment.status !== 'DISPUTED' ? (
                  <button
                    onClick={() =>
                      setDisputeActionTarget({
                        payment: paymentDetail.payment,
                        action: 'HOLD_ESCROW',
                      })
                    }
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg shadow-2xs transition-colors flex items-center gap-1"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    Place Escrow Hold
                  </button>
                ) : (
                  <>
                    <button
                      onClick={() =>
                        setDisputeActionTarget({
                          payment: paymentDetail.payment,
                          action: 'RELEASE_PAYOUT',
                        })
                      }
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg shadow-2xs transition-colors flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Release Payout to Payee
                    </button>
                    <button
                      onClick={() =>
                        setDisputeActionTarget({
                          payment: paymentDetail.payment,
                          action: 'REFUND_PAYER',
                        })
                      }
                      className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold rounded-lg shadow-2xs transition-colors flex items-center gap-1"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Reverse & Refund Payer
                    </button>
                    <button
                      onClick={() =>
                        setDisputeActionTarget({
                          payment: paymentDetail.payment,
                          action: 'ARBITRATE',
                        })
                      }
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow-2xs transition-colors flex items-center gap-1"
                    >
                      <Gavel className="w-3.5 h-3.5" />
                      Escalate to Arbitration
                    </button>
                  </>
                )}

                {paymentDetail.payment.status === 'FLAGGED' && (
                  <button
                    onClick={() =>
                      setDisputeActionTarget({
                        payment: paymentDetail.payment,
                        action: 'CLEAR_FLAG',
                      })
                    }
                    className="px-3 py-1.5 bg-slate-700 hover:bg-slate-800 text-white font-semibold rounded-lg shadow-2xs transition-colors flex items-center gap-1"
                  >
                    <Unlock className="w-3.5 h-3.5" />
                    Clear Security Hold
                  </button>
                )}
              </div>
            </div>

            {/* Lifecycle Traceability & Notifications Log */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold uppercase text-slate-500 block">
                Lifecycle Traceability & Audit Events
              </span>
              <div className="max-h-40 overflow-y-auto space-y-1.5 p-2 bg-slate-50 rounded-lg border border-slate-200">
                {paymentDetail.lifecycleEvents.length === 0 && paymentDetail.auditLogs.length === 0 ? (
                  <div className="text-slate-400 text-center py-2">No previous dispute events logged</div>
                ) : (
                  <>
                    {paymentDetail.lifecycleEvents.map((evt) => (
                      <div key={evt.id} className="p-2 bg-white rounded border border-slate-200 text-[11px]">
                        <div className="flex items-center justify-between">
                          <strong className="text-slate-900 font-mono">{evt.eventType}</strong>
                          <span className="text-slate-400">{formatDateTime(evt.timestamp)}</span>
                        </div>
                        <div className="text-slate-600 mt-0.5">{evt.notes}</div>
                        {evt.verificationHash && (
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">
                            Seal: {evt.verificationHash}
                          </div>
                        )}
                      </div>
                    ))}
                    {paymentDetail.auditLogs.map((log) => (
                      <div key={log.id} className="p-2 bg-white rounded border border-slate-200 text-[11px]">
                        <div className="flex items-center justify-between">
                          <strong className="text-slate-800">{log.action}</strong>
                          <span className="text-slate-400">{formatDateTime(log.timestamp)}</span>
                        </div>
                        <div className="text-slate-600 mt-0.5">{log.details}</div>
                        <div className="text-[10px] text-slate-400">Actor: {log.actorName}</div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </div>

            {/* Notifications Sent */}
            {paymentDetail.notifications && paymentDetail.notifications.length > 0 && (
              <div className="space-y-1">
                <span className="text-[11px] font-bold uppercase text-slate-500 flex items-center gap-1">
                  <BellRing className="w-3 h-3 text-slate-400" />
                  <span>Real Carrier Notification Status</span>
                </span>
                <div className="space-y-1">
                  {paymentDetail.notifications.map((n) => (
                    <div
                      key={n.id}
                      className="p-2 bg-slate-50 rounded border border-slate-200 text-[11px] flex items-center justify-between"
                    >
                      <div>
                        <div className="font-semibold text-slate-800">{n.title}</div>
                        <div className="text-slate-500 text-[10px]">
                          To: {n.recipientName} ({n.recipientRole})
                        </div>
                      </div>
                      <span className="px-1.5 py-0.5 text-[10px] font-mono rounded bg-slate-200 text-slate-700">
                        {n.deliveryStatus}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : null}
      </AdminModal>

      {/* Sensitive Dispute Resolution Modal */}
      <AdminModal
        isOpen={!!disputeActionTarget}
        onClose={() => {
          setDisputeActionTarget(null);
          setDisputeReason('');
          setActionError(null);
        }}
        title={`Confirm Financial Action: ${disputeActionTarget?.action.replace(/_/g, ' ')}`}
        subtitle={`Transaction: ${disputeActionTarget?.payment.transactionId} • ${formatInr(
          disputeActionTarget?.payment.amount || 0
        )}`}
        maxWidth="sm"
      >
        <div className="space-y-3.5 text-xs">
          <p className="text-slate-600 leading-relaxed">
            {disputeActionTarget?.action === 'HOLD_ESCROW' &&
              'Placing this payment on escrow hold will pause automated fund clearance and notify the parties. A mandatory reason is recorded in the permanent audit ledger.'}
            {disputeActionTarget?.action === 'RELEASE_PAYOUT' &&
              'Releasing escrow funds will initiate immediate payout settlement to the payee account and log an unalterable financial authorization event.'}
            {disputeActionTarget?.action === 'REFUND_PAYER' &&
              'Refunding will reverse the transaction and return the escrowed sum back to the original payer depot.'}
            {disputeActionTarget?.action === 'ARBITRATE' &&
              'Escalating to formal arbitration routes this dispute to the Central Quality & Weighment Grievance Board.'}
            {disputeActionTarget?.action === 'CLEAR_FLAG' &&
              'Clearing security hold restores the standard settlement pipeline for this transaction.'}
          </p>

          <div>
            <label className="block text-xs font-semibold uppercase text-slate-700 mb-1">
              Mandatory Justification / Compliance Reason *
            </label>
            <textarea
              value={disputeReason}
              onChange={(e) => setDisputeReason(e.target.value)}
              placeholder="Provide clear justification for this financial administrative action..."
              rows={3}
              className="w-full p-2.5 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-emerald-500 font-medium"
            />
          </div>

          {actionError && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-[11px]">
              {actionError}
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              onClick={() => {
                setDisputeActionTarget(null);
                setDisputeReason('');
                setActionError(null);
              }}
              className="px-3 py-1.5 text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirmDisputeAction}
              disabled={isProcessingDispute}
              className="px-4 py-1.5 text-white font-semibold bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-2xs transition-colors"
            >
              {isProcessingDispute ? 'Recording Audit...' : 'Authorize Action'}
            </button>
          </div>
        </div>
      </AdminModal>
    </div>
  );
};
