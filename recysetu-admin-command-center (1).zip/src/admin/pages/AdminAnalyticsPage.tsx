import React, { useState, useEffect, useCallback } from 'react';
import {
  Calendar,
  Download,
  RefreshCw,
  TrendingUp,
  Recycle,
  Truck,
  IndianRupee,
  AlertTriangle,
  Layers,
  ChevronDown,
} from 'lucide-react';
import { adminApi } from '../services/adminApiService';
import { AnalyticsResponse, AnalyticsRange } from '../../shared/types/analytics';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminLoadingState } from '../components/AdminLoadingState';
import { AdminErrorState } from '../components/AdminErrorState';
import { LotsOverTimeChart } from '../components/charts/LotsOverTimeChart';
import { MaterialCategoryChart } from '../components/charts/MaterialCategoryChart';
import { CollectionVolumeChart } from '../components/charts/CollectionVolumeChart';
import { RecyclingVolumeChart } from '../components/charts/RecyclingVolumeChart';
import { PickupCompletionChart } from '../components/charts/PickupCompletionChart';
import { PaymentAnalyticsChart } from '../components/charts/PaymentAnalyticsChart';
import { RegionalActivityChart } from '../components/charts/RegionalActivityChart';

export const AdminAnalyticsPage: React.FC = () => {
  const [range, setRange] = useState<AnalyticsRange>('7d');
  const [customStart, setCustomStart] = useState<string>('2026-09-01');
  const [customEnd, setCustomEnd] = useState<string>('2026-09-14');
  const [data, setData] = useState<AnalyticsResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [exportDropdownOpen, setExportDropdownOpen] = useState<boolean>(false);
  const [exporting, setExporting] = useState<boolean>(false);

  const fetchAnalytics = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await adminApi.getAnalytics({
        range,
        startDate: range === 'custom' ? customStart : undefined,
        endDate: range === 'custom' ? customEnd : undefined,
      });
      setData(res);
    } catch (err: any) {
      console.error('Failed to fetch analytics:', err);
      setError(err.message || 'Failed to aggregate system analytics.');
    } finally {
      setLoading(false);
    }
  }, [range, customStart, customEnd]);

  useEffect(() => {
    fetchAnalytics();
  }, [fetchAnalytics]);

  const handleExport = async (type: string) => {
    try {
      setExporting(true);
      setExportDropdownOpen(false);
      const res = await adminApi.exportAnalytics({
        type,
        range,
        startDate: range === 'custom' ? customStart : undefined,
        endDate: range === 'custom' ? customEnd : undefined,
      });

      // Trigger browser file download
      const blob = new Blob([res.text], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', res.filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err: any) {
      alert(`Export error: ${err.message}`);
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <AdminPageHeader
        title="Analytics & Operational Intelligence"
        description="Empirical system-wide throughput, material flows, financial disbursements, and regional performance aggregated directly from the central ledger."
      />
<div className="mb-6 flex gap-2">

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={fetchAnalytics}
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-medium rounded-lg shadow-sm transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          {/* Export Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setExportDropdownOpen(!exportDropdownOpen)}
              disabled={exporting}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium rounded-lg shadow-sm transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{exporting ? 'Generating CSV...' : 'Export Audit CSV'}</span>
              <ChevronDown className="w-3.5 h-3.5 ml-0.5" />
            </button>

            {exportDropdownOpen && (
              <div className="absolute right-0 mt-1.5 w-56 bg-white border border-slate-200 rounded-lg shadow-lg z-30 py-1 text-xs">
                <button
                  type="button"
                  onClick={() => handleExport('summary')}
                  className="w-full text-left px-3 py-2 hover:bg-slate-50 text-slate-700 font-medium"
                >
                  Executive Summary Report
                </button>
                <button
                  type="button"
                  onClick={() => handleExport('lots')}
                  className="w-full text-left px-3 py-2 hover:bg-slate-50 text-slate-700"
                >
                  Aggregated Lots Ledger (CSV)
                </button>
                <button
                  type="button"
                  onClick={() => handleExport('pickups')}
                  className="w-full text-left px-3 py-2 hover:bg-slate-50 text-slate-700"
                >
                  Pickups & Collection Log (CSV)
                </button>
                <button
                  type="button"
                  onClick={() => handleExport('payments')}
                  className="w-full text-left px-3 py-2 hover:bg-slate-50 text-slate-700"
                >
                  Disbursement Ledger (CSV)
                </button>
                <button
                  type="button"
                  onClick={() => handleExport('materials')}
                  className="w-full text-left px-3 py-2 hover:bg-slate-50 text-slate-700"
                >
                  Material Categories Matrix (CSV)
                </button>
              </div>
            )}
          </div>
        </div>
      
</div>

      {/* Date Range Selector Filter Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <span className="text-xs font-medium text-slate-500 mr-2 flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5" /> Range:
          </span>
          {(['today', '7d', '30d', '90d', 'custom'] as AnalyticsRange[]).map((r) => {
            const labels: Record<AnalyticsRange, string> = {
              today: 'Today',
              '7d': '7 Days',
              '30d': '30 Days',
              '90d': '90 Days',
              custom: 'Custom Range',
            };
            const active = range === r;
            return (
              <button
                key={r}
                type="button"
                onClick={() => setRange(r)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {labels[r]}
              </button>
            );
          })}
        </div>

        {/* Custom Range Inputs */}
        {range === 'custom' && (
          <div className="flex items-center gap-2 text-xs">
            <input
              type="date"
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              className="border border-slate-300 rounded px-2 py-1 text-slate-700"
            />
            <span className="text-slate-400">to</span>
            <input
              type="date"
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              className="border border-slate-300 rounded px-2 py-1 text-slate-700"
            />
            <button
              type="button"
              onClick={fetchAnalytics}
              className="px-2.5 py-1 bg-slate-800 text-white rounded font-medium hover:bg-slate-900"
            >
              Apply
            </button>
          </div>
        )}

        {data && (
          <div className="text-xs text-slate-500 font-mono">
            Window: <span className="font-medium text-slate-700">{data.dateRange.effectiveLabel}</span>
          </div>
        )}
      </div>

      {/* Loading & Error States */}
      {loading && !data && <AdminLoadingState message="Aggregating records from database..." />}
      {error && <AdminErrorState message={error} onRetry={fetchAnalytics} />}

      {/* Analytics Dashboard Grid */}
      {data && (
        <div className="space-y-6">
          {/* Summary Stat Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 text-xs mb-1 font-medium">
                <span>Collection Volume</span>
                <Truck className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900 font-mono">
                {data.summary.totalCollectionVolumeKg >= 1000
                  ? `${(data.summary.totalCollectionVolumeKg / 1000).toFixed(1)} tons`
                  : `${data.summary.totalCollectionVolumeKg.toLocaleString()} kg`}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                From <span className="font-semibold text-slate-700">{data.summary.totalPickupsCount}</span> pickups
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 text-xs mb-1 font-medium">
                <span>Recycled Volume</span>
                <Recycle className="w-4 h-4 text-teal-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900 font-mono">
                {data.summary.totalRecycledVolumeKg >= 1000
                  ? `${(data.summary.totalRecycledVolumeKg / 1000).toFixed(1)} tons`
                  : `${data.summary.totalRecycledVolumeKg.toLocaleString()} kg`}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Across <span className="font-semibold text-slate-700">{data.summary.totalLotsCount}</span> aggregated lots
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 text-xs mb-1 font-medium">
                <span>Pickup Completion</span>
                <TrendingUp className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900 font-mono">
                {data.summary.pickupCompletionRate}%
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Scheduled vs Completed fulfillment
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 text-xs mb-1 font-medium">
                <span>Funds Disbursed</span>
                <IndianRupee className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-bold text-slate-900 font-mono">
                ₹{data.summary.totalDisbursedInr.toLocaleString()}
              </div>
              <p className="text-[11px] text-amber-600 mt-1 font-medium">
                ₹{data.summary.pendingDisbursementInr.toLocaleString()} pending clearance
              </p>
            </div>
          </div>

          {/* Row 1: Lots Over Time & Material Categories */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">Consignment Lots Over Time</h3>
                  <p className="text-xs text-slate-500">Aggregated vs Recycled mass trends</p>
                </div>
                <span className="text-xs font-mono font-medium px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded border border-emerald-100">
                  {data.summary.totalLotsCount} Lots Recorded
                </span>
              </div>
              <LotsOverTimeChart data={data.lotsOverTime} />
            </div>

            <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">Material Categories</h3>
                  <p className="text-xs text-slate-500">Volume and economic valuation matrix</p>
                </div>
                <Layers className="w-4 h-4 text-slate-400" />
              </div>
              <MaterialCategoryChart data={data.materialCategories} />
            </div>
          </div>

          {/* Row 2: Collection Volume vs Recycling Volume */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">Collection Volume Velocity</h3>
                  <p className="text-xs text-slate-500">Daily intake from field pickups</p>
                </div>
                <Truck className="w-4 h-4 text-emerald-600" />
              </div>
              <CollectionVolumeChart data={data.collectionVolume} />
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">Terminal Recycling Volume</h3>
                  <p className="text-xs text-slate-500">Certified processor batch throughput</p>
                </div>
                <Recycle className="w-4 h-4 text-teal-600" />
              </div>
              <RecyclingVolumeChart data={data.recyclingVolume} />
            </div>
          </div>

          {/* Row 3: Pickup Completion & Payment Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">Pickup Fulfillment & Completion</h3>
                  <p className="text-xs text-slate-500">Status distribution and efficiency rate</p>
                </div>
                <TrendingUp className="w-4 h-4 text-indigo-600" />
              </div>
              <PickupCompletionChart data={data.pickupCompletion} />
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">Payments & Disbursements</h3>
                  <p className="text-xs text-slate-500">Disbursed funds and payout queue timeline</p>
                </div>
                <IndianRupee className="w-4 h-4 text-emerald-600" />
              </div>
              <PaymentAnalyticsChart data={data.payments} />
            </div>
          </div>

          {/* Row 4: Regional Activity & Material Share Table */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">Regional Activity Hubs</h3>
                  <p className="text-xs text-slate-500">Volume and active field participants</p>
                </div>
              </div>
              <RegionalActivityChart data={data.regionalActivity} />
            </div>

            <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">Top Materials Breakdown</h3>
                  <p className="text-xs text-slate-500">Detailed metric ledger</p>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                    <tr>
                      <th className="py-2.5 px-3">Grade</th>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-3 text-right">Collected (kg)</th>
                      <th className="py-2.5 px-3 text-right">Recycled (kg)</th>
                      <th className="py-2.5 px-3 text-right">Value (₹)</th>
                      <th className="py-2.5 px-3 text-right">Share</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {data.topMaterialCategories.map((m) => (
                      <tr key={m.materialId} className="hover:bg-slate-50/70">
                        <td className="py-2.5 px-3 font-sans font-medium text-slate-800">
                          {m.materialName} ({m.code})
                        </td>
                        <td className="py-2.5 px-3 font-sans text-slate-500">{m.category}</td>
                        <td className="py-2.5 px-3 text-right text-emerald-700 font-medium">
                          {m.collectedKg.toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 text-right text-teal-700">
                          {m.recycledKg.toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-700">
                          ₹{m.valueInr.toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-600">
                          {m.percentage}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
