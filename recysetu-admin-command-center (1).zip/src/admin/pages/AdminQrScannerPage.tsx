import React, { useState, useRef, useEffect, useCallback } from 'react';
import jsQR from 'jsqr';
import { adminApi } from '../services/adminApiService';
import { AdminPageHeader } from '../components/AdminPageHeader';
import { AdminStatusBadge } from '../components/AdminStatusBadge';
import { formatDateTime, formatWeight, formatInr } from '../utils/formatters';
import {
  QrCode,
  Camera,
  CameraOff,
  AlertTriangle,
  CheckCircle2,
  Search,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
  Boxes,
  Truck,
  Eye,
  KeyRound,
  ShieldAlert,
} from 'lucide-react';

interface AdminQrScannerPageProps {
  onNavigateToLot?: (lotId: string) => void;
  onNavigateToPickup?: (pickupId: string) => void;
}

export const AdminQrScannerPage: React.FC<AdminQrScannerPageProps> = ({
  onNavigateToLot,
  onNavigateToPickup,
}) => {
  const [cameraActive, setCameraActive] = useState(false);
  const [permissionError, setPermissionError] = useState<string | null>(null);
  const [manualInput, setManualInput] = useState('');
  const [isResolving, setIsResolving] = useState(false);
  const [scanResult, setScanResult] = useState<{
    found: boolean;
    type: 'LOT' | 'PICKUP';
    id: string;
    code: string;
    entity: any;
    summary: Record<string, any>;
  } | null>(null);
  const [resolveError, setResolveError] = useState<string | null>(null);
  const [lastScannedPayload, setLastScannedPayload] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const stopCamera = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  }, []);

  const handleResolvePayload = async (rawPayload: string) => {
    const trimmed = rawPayload.trim();
    if (!trimmed) return;

    setIsResolving(true);
    setResolveError(null);
    setLastScannedPayload(trimmed);

    try {
      // Backend lookup ensures raw client input is never trusted directly
      const result = await adminApi.resolveQrToken(trimmed);
      setScanResult(result);
    } catch (err: any) {
      setScanResult(null);
      setResolveError(err.message || 'No registered Lot or Pickup found matching this QR code.');
    } finally {
      setIsResolving(false);
    }
  };

  const scanFrame = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState !== video.HAVE_ENOUGH_DATA) {
      animationFrameRef.current = requestAnimationFrame(scanFrame);
      return;
    }

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: 'dontInvert',
    });

    if (code && code.data) {
      // QR successfully detected
      stopCamera();
      handleResolvePayload(code.data);
      return;
    }

    animationFrameRef.current = requestAnimationFrame(scanFrame);
  }, [stopCamera]);

  const startCamera = async () => {
    setPermissionError(null);
    setResolveError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        setCameraActive(true);
        animationFrameRef.current = requestAnimationFrame(scanFrame);
      }
    } catch (err: any) {
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setPermissionError('Camera access was denied by your browser. Please grant camera permission in your address bar or browser settings, or use the manual ID fallback below.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setPermissionError('No video camera device was detected on your hardware. Please use the manual Lot or Pickup ID fallback below.');
      } else {
        setPermissionError(`Unable to start camera stream: ${err.message || err.name}. You can use the manual identifier fallback.`);
      }
      setCameraActive(false);
    }
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualInput.trim()) {
      handleResolvePayload(manualInput.trim());
    }
  };

  return (
    <div id="admin-qr-scanner-page" className="space-y-6">
      <AdminPageHeader
        title="Physical Traceability & QR Verification Scanner"
        description="Industrial scan hub verifying cryptographically-sealed batch QR tags against the central RECYSETU custodial ledger."
      />

      {/* Security Banner */}
      <div className="p-4 bg-slate-900 text-slate-100 rounded-xl border border-slate-800 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white flex items-center gap-2">
                RECYSETU Zero-Trust QR Protocol
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 rounded">
                  Enforced
                </span>
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                QR tags contain public batch hashes only. Authentication secrets, passwords, OTPs, and private phone numbers are never stored inside physical tags.
              </p>
            </div>
          </div>
          <div className="text-[11px] font-mono text-slate-400 flex items-center gap-2">
            <KeyRound className="w-3.5 h-3.5 text-amber-400" />
            <span>Backend Lookup & Authorize</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Camera Viewport */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Camera className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-slate-900">Live Optical Scanner</span>
              </div>
              {cameraActive && (
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                  Live Video Stream
                </span>
              )}
            </div>

            <div className="p-4">
              <div className="relative aspect-4/3 w-full bg-slate-950 rounded-xl overflow-hidden flex items-center justify-center">
                {/* Hidden canvas for jsQR frame sampling */}
                <canvas ref={canvasRef} className="hidden" />

                {/* Video feed */}
                <video
                  ref={videoRef}
                  className={`w-full h-full object-cover ${cameraActive ? 'block' : 'hidden'}`}
                />

                {/* Laser animation overlay while camera is active */}
                {cameraActive && (
                  <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
                    {/* Targeting frame corners */}
                    <div className="w-64 h-64 border-2 border-emerald-400/70 rounded-2xl relative">
                      <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-emerald-400" />
                      <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-emerald-400" />
                      <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-emerald-400" />
                      <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-emerald-400" />

                      {/* Laser scanning line */}
                      <div className="absolute inset-x-0 h-0.5 bg-emerald-400 shadow-[0_0_12px_#34d399] animate-[bounce_2s_ease-in-out_infinite]" />
                    </div>
                    <span className="mt-4 text-xs font-semibold text-white/90 bg-slate-900/80 px-3 py-1 rounded-full backdrop-blur-xs">
                      Align QR tag within targeting frame
                    </span>
                  </div>
                )}

                {/* Inactive or error states */}
                {!cameraActive && (
                  <div className="p-6 text-center max-w-sm flex flex-col items-center">
                    {permissionError ? (
                      <>
                        <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center mb-3">
                          <CameraOff className="w-6 h-6" />
                        </div>
                        <h4 className="text-xs font-bold text-white mb-1">Camera Inactive</h4>
                        <p className="text-[11px] text-slate-300 leading-relaxed mb-4">
                          {permissionError}
                        </p>
                        <button
                          type="button"
                          onClick={startCamera}
                          className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 transition-colors"
                        >
                          Retry Camera Permission
                        </button>
                      </>
                    ) : (
                      <>
                        <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mb-3 border border-slate-700">
                          <QrCode className="w-8 h-8" />
                        </div>
                        <h4 className="text-xs font-bold text-white mb-1">Ready to Scan</h4>
                        <p className="text-[11px] text-slate-400 leading-relaxed mb-4">
                          Activate device camera to scan physical QR bags, dispatch manifests, or weighbridge receipts.
                        </p>
                        <button
                          type="button"
                          onClick={startCamera}
                          className="px-5 py-2.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 shadow-md transition-all flex items-center gap-2"
                        >
                          <Camera className="w-4 h-4" />
                          Launch Camera Scanner
                        </button>
                      </>
                    )}
                  </div>
                )}
              </div>

              {cameraActive && (
                <div className="mt-3 flex justify-center">
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="px-4 py-1.5 rounded-lg text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 transition-colors flex items-center gap-1.5"
                  >
                    <CameraOff className="w-3.5 h-3.5" />
                    Turn Off Camera
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Manual Fallback Form */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
            <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5 mb-1">
              <Search className="w-4 h-4 text-slate-600" />
              Manual Identifier Fallback
            </h4>
            <p className="text-[11px] text-slate-500 mb-3">
              If the physical QR label is torn, smudged, or your workstation lacks a webcam, enter the Lot ID, Pickup ID, or QR hash manually.
            </p>

            <form onSubmit={handleManualSubmit} className="flex gap-2">
              <input
                type="text"
                value={manualInput}
                onChange={(e) => setManualInput(e.target.value)}
                placeholder="e.g. LOT-2026-DEL-001 or PK-88219..."
                className="flex-1 px-3 py-2 text-xs rounded-lg border border-slate-300 text-slate-900 font-mono focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
              <button
                type="submit"
                disabled={isResolving || !manualInput.trim()}
                className="px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-lg hover:bg-slate-800 disabled:opacity-50 transition-colors shrink-0"
              >
                {isResolving ? 'Resolving...' : 'Lookup'}
              </button>
            </form>

            {/* Sample Shortcuts */}
            <div className="mt-3 pt-3 border-t border-slate-100">
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block mb-1.5">
                Quick Sample Identifiers from Backend:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { label: 'Lot: LOT-2026-DEL-001 (Flagged)', val: 'LOT-2026-DEL-001' },
                  { label: 'Lot: LOT-2026-CHE-003 (Verified)', val: 'LOT-2026-CHE-003' },
                  { label: 'Pickup: PK-88219 (PET Bottles)', val: 'PK-88219' },
                  { label: 'Pickup: PK-77402 (Cardboard)', val: 'PK-77402' },
                ].map((s) => (
                  <button
                    key={s.val}
                    type="button"
                    onClick={() => {
                      setManualInput(s.val);
                      handleResolvePayload(s.val);
                    }}
                    className="text-[11px] font-mono px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Resolution & Authentication Result */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs min-h-[400px]">
            <h4 className="text-xs font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center justify-between">
              <span>Resolution & Verification Status</span>
              {scanResult && (
                <button
                  onClick={() => {
                    setScanResult(null);
                    setResolveError(null);
                    setLastScannedPayload(null);
                  }}
                  className="text-[11px] text-slate-400 hover:text-slate-600 flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  Clear
                </button>
              )}
            </h4>

            {isResolving && (
              <div className="py-16 text-center space-y-3">
                <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="text-xs font-semibold text-slate-700">Verifying cryptographic hash against backend...</p>
                <p className="text-[11px] text-slate-400">Querying central ledger authorization engine</p>
              </div>
            )}

            {!isResolving && resolveError && (
              <div className="py-10 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto border border-rose-200">
                  <AlertTriangle className="w-6 h-6" />
                </div>
                <h5 className="text-xs font-bold text-rose-800">Lookup Unsuccessful</h5>
                <p className="text-xs text-rose-600 max-w-xs mx-auto leading-relaxed">
                  {resolveError}
                </p>
                {lastScannedPayload && (
                  <div className="text-[11px] font-mono text-slate-500 bg-slate-50 p-2 rounded max-w-xs mx-auto truncate border border-slate-200">
                    Scanned query: {lastScannedPayload}
                  </div>
                )}
              </div>
            )}

            {!isResolving && !resolveError && !scanResult && (
              <div className="py-20 text-center space-y-2 text-slate-400">
                <QrCode className="w-12 h-12 mx-auto stroke-1 text-slate-300" />
                <p className="text-xs font-medium text-slate-600">Awaiting QR scan or manual input</p>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                  Scanned data is authenticated against authorized backend records before rendering details.
                </p>
              </div>
            )}

            {!isResolving && scanResult && (
              <div className="mt-4 space-y-4">
                {/* Status card */}
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs font-bold text-emerald-950 block">
                      Authentic Record Resolved & Verified
                    </span>
                    <span className="text-[11px] text-emerald-800">
                      Entity Type: <strong>{scanResult.type}</strong> • Identifier: <strong>{scanResult.code}</strong>
                    </span>
                  </div>
                </div>

                {/* Entity Details Card */}
                {scanResult.type === 'LOT' && (
                  <div className="space-y-3 text-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Boxes className="w-4 h-4 text-emerald-600" />
                        <span className="font-mono font-bold text-slate-900 text-sm">
                          {scanResult.summary.lotNumber}
                        </span>
                      </div>
                      <AdminStatusBadge status={scanResult.summary.status} size="sm" />
                    </div>

                    <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200 text-[11px]">
                      <div>
                        <span className="text-slate-400 block">Material:</span>
                        <span className="font-semibold text-slate-800">{scanResult.summary.materialName}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Quality Grade:</span>
                        <span className="font-semibold text-slate-800">{scanResult.summary.qualityGrade}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Declared Weight:</span>
                        <span className="font-bold text-slate-900">{formatWeight(scanResult.summary.declaredWeightKg)}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Actual Intake Weight:</span>
                        <span className="font-bold text-emerald-700">
                          {scanResult.summary.actualWeightKg != null ? formatWeight(scanResult.summary.actualWeightKg) : 'Pending Weighment'}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Aggregator Depot:</span>
                        <span className="font-medium text-slate-800 truncate">{scanResult.summary.aggregatorName}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Destination Recycler:</span>
                        <span className="font-medium text-slate-800 truncate">{scanResult.summary.recyclerName}</span>
                      </div>
                    </div>

                    {scanResult.summary.isDiscrepancyFlagged && (
                      <div className="p-2.5 bg-rose-50 rounded-lg border border-rose-200 text-rose-800 text-[11px] flex items-center gap-2">
                        <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                        <span>
                          <strong>Weight Discrepancy Flagged:</strong> Declared vs actual weight differs by {scanResult.summary.weightDiscrepancyKg} kg.
                        </span>
                      </div>
                    )}

                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => onNavigateToLot && onNavigateToLot(scanResult.id)}
                        className="w-full py-2 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-2 shadow-2xs"
                      >
                        <Eye className="w-4 h-4" />
                        Inspect Complete Lot & Discrepancy Ledger
                      </button>
                    </div>
                  </div>
                )}

                {scanResult.type === 'PICKUP' && (
                  <div className="space-y-3 text-xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Truck className="w-4 h-4 text-emerald-600" />
                        <span className="font-mono font-bold text-slate-900 text-sm">
                          {scanResult.summary.trackingCode}
                        </span>
                      </div>
                      <AdminStatusBadge status={scanResult.summary.status} size="sm" />
                    </div>

                    <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200 text-[11px]">
                      <div>
                        <span className="text-slate-400 block">Collector:</span>
                        <span className="font-semibold text-slate-800">{scanResult.summary.collectorName}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Hub / Aggregator:</span>
                        <span className="font-semibold text-slate-800">{scanResult.summary.aggregatorName}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Material:</span>
                        <span className="font-semibold text-slate-800">{scanResult.summary.materialName}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Quantity:</span>
                        <span className="font-bold text-emerald-700">
                          {scanResult.summary.quantityKg} {scanResult.summary.unit}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Valuation:</span>
                        <span className="font-mono font-bold text-slate-900">{formatInr(scanResult.summary.totalPrice)}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Source:</span>
                        <span className="font-semibold text-slate-800">{scanResult.summary.source}</span>
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => onNavigateToPickup && onNavigateToPickup(scanResult.id)}
                        className="w-full py-2 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-2 shadow-2xs"
                      >
                        <Eye className="w-4 h-4" />
                        Inspect Complete Pickup Detail
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
