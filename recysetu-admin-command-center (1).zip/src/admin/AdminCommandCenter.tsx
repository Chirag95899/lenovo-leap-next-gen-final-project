import React, { useState, useEffect } from 'react';
import { useAdminAuth } from './hooks/useAdminAuth';
import { useAdminDashboard } from './hooks/useAdminDashboard';
import {
  useUsersQuery,
  usePickupsQuery,
  useLotsQuery,
  useTraceabilityQuery,
  usePaymentsQuery,
  useComplaintsQuery,
  useAnomaliesQuery,
  useAuditLogsQuery,
  useAiActivityQuery,
  useIvrActivityQuery,
  useSystemNotificationsQuery,

} from './hooks/useAdminDomainQueries';
import { AdminLayout } from './components/AdminLayout';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { AdminUsersPage } from './pages/AdminUsersPage';
import { AdminPickupsPage } from './pages/AdminPickupsPage';
import { AdminLotsPage } from './pages/AdminLotsPage';
import { AdminTraceabilityPage } from './pages/AdminTraceabilityPage';

import { AdminPaymentsPage } from './pages/AdminPaymentsPage';
import { AdminComplaintsPage } from './pages/AdminComplaintsPage';
import { AdminAnomaliesPage } from './pages/AdminAnomaliesPage';
import { AdminAiActivityPage } from './pages/AdminAiActivityPage';
import { AdminIvrActivityPage } from './pages/AdminIvrActivityPage';
import { AdminNotificationsPage } from './pages/AdminNotificationsPage';
import { AdminAuditLogsPage } from './pages/AdminAuditLogsPage';
import { AdminReviewsPage } from './pages/AdminReviewsPage';
import { AdminTrustRewardsPage } from './pages/AdminTrustRewardsPage';

import { AdminStateAnalyticsPage } from './pages/AdminStateAnalyticsPage';
import { AdminAnalyticsPage } from './pages/AdminAnalyticsPage';
import { AdminLoadingState } from './components/AdminLoadingState';
import { AdminView } from './types/admin';

interface AdminCommandCenterProps {
  initialView?: AdminView;
}

export const AdminCommandCenter: React.FC<AdminCommandCenterProps> = ({
  initialView = 'dashboard',
}) => {
  const [activeView, setActiveView] = useState<AdminView>(initialView);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);

  // Authentication hook
  const { user, isAuthenticated, isLoading: authLoading, error: authError, login, logout } =
    useAdminAuth();

  // Dynamic Dashboard Live Telemetry
  const dashboard = useAdminDashboard();

  // Domain queries
  const usersQuery = useUsersQuery();
  const pickupsQuery = usePickupsQuery();
  const lotsQuery = useLotsQuery();
  const traceabilityQuery = useTraceabilityQuery();
  const paymentsQuery = usePaymentsQuery();
  const complaintsQuery = useComplaintsQuery();
  const anomaliesQuery = useAnomaliesQuery();
  const auditLogsQuery = useAuditLogsQuery();

  const aiActivityQuery = useAiActivityQuery();
  const ivrActivityQuery = useIvrActivityQuery();
  const notificationsQuery = useSystemNotificationsQuery();


  // Keep browser URL in sync if appropriate
  useEffect(() => {
    if (window.location.pathname !== '/admin/dashboard' && isAuthenticated) {
      window.history.replaceState(null, '', '/admin/dashboard');
    }
  }, [isAuthenticated]);

  const handleNavigateWithFilters = (view: AdminView, filters?: Record<string, string>) => {
    setActiveView(view);
    if (!filters) return;
    if (view === 'users') {
      if (filters.userId) {
        setSelectedUserId(filters.userId);
      } else {
        setSelectedUserId(null);
      }
      if (filters.role) usersQuery.setRole(filters.role);
      if (filters.status) usersQuery.setStatus(filters.status);
      if (filters.verificationStatus) usersQuery.setVerificationStatus(filters.verificationStatus);
      if (filters.search) usersQuery.setSearch(filters.search);
    } else if (view === 'pickups') {
      setSelectedUserId(null);
      if (filters.status) pickupsQuery.setStatus(filters.status);
      if (filters.category) pickupsQuery.setCategory(filters.category);
      if (filters.search) pickupsQuery.setSearch(filters.search);
    } else if (view === 'lots') {
      setSelectedUserId(null);
      if (filters.status) lotsQuery.setStatus(filters.status);
      if (filters.category) lotsQuery.setCategory(filters.category);
      if (filters.search) lotsQuery.setSearch(filters.search);
    } else if (view === 'payments') {
      setSelectedUserId(null);
      if (filters.status) paymentsQuery.setStatus(filters.status);
      if (filters.search) paymentsQuery.setSearch(filters.search);
    } else if (view === 'complaints') {
      setSelectedUserId(null);
      if (filters.status) complaintsQuery.setStatus(filters.status);
      if (filters.search) complaintsQuery.setSearch(filters.search);
    } else if (view === 'anomalies') {
      setSelectedUserId(null);
      if (filters.severity) anomaliesQuery.setSeverity(filters.severity);
      if (filters.search) anomaliesQuery.setSearch(filters.search);
    } else if (view === 'traceability') {
      setSelectedUserId(null);
      if (filters.entityType) traceabilityQuery.setEntityType(filters.entityType);
      if (filters.search) traceabilityQuery.setSearch(filters.search);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <AdminLoadingState message="Verifying RECYSETU Administrative Credentials..." />
      </div>
    );
  }

  // Not logged in or not admin -> Show Admin Login
  if (!isAuthenticated || !user) {
    return (
      <AdminLoginPage
        onLogin={async (adminId, pass) => {
          await login(adminId, pass);
          await dashboard.refetch();
        }}
        isLoading={authLoading}
        error={authError}
      />
    );
  }

  return (
    <AdminLayout
      adminUser={user}
      activeView={activeView}
      onNavigate={setActiveView}
      onLogout={logout}
      onRefresh={dashboard.refresh}
      isRefreshing={dashboard.isRefreshing}
      anomaliesCount={dashboard.data?.overview?.activeAnomaliesCount || 0}
      complaintsCount={dashboard.data?.overview?.openComplaintsCount || 0}
    >
      {activeView === 'dashboard' && (
        <AdminDashboardPage
          data={dashboard.data}
          isLoading={dashboard.isLoading}
          isRefreshing={dashboard.isRefreshing}
          error={dashboard.error}
                                                                                          onRefresh={dashboard.refresh}
          onNavigateToView={handleNavigateWithFilters}
        />
      )}

      {activeView === 'users' && (
        <AdminUsersPage
          users={usersQuery.users}
          total={usersQuery.total}
          page={usersQuery.page}
          totalPages={usersQuery.totalPages}
          setPage={usersQuery.setPage}
          limit={usersQuery.limit}
          setLimit={usersQuery.setLimit}
          search={usersQuery.search}
          setSearch={usersQuery.setSearch}
          role={usersQuery.role}
          setRole={usersQuery.setRole}
          status={usersQuery.status}
          setStatus={usersQuery.setStatus}
          verificationStatus={usersQuery.verificationStatus}
          setVerificationStatus={usersQuery.setVerificationStatus}
          location={usersQuery.location}
          setLocation={usersQuery.setLocation}
          startDate={usersQuery.startDate}
          setStartDate={usersQuery.setStartDate}
          endDate={usersQuery.endDate}
          setEndDate={usersQuery.setEndDate}
          isLoading={usersQuery.isLoading}
          onVerifyRecycler={usersQuery.verifyRecycler}
          onRejectRecycler={usersQuery.rejectRecycler}
          onSuspendUser={usersQuery.suspendUser}
          onReactivateUser={usersQuery.reactivateUser}
          onVerifyKyc={usersQuery.verifyKyc}
          onChangeUserRole={usersQuery.changeUserRole}
          onUpdateUserStatus={usersQuery.updateUserStatus}
          selectedUserId={selectedUserId}
          onSelectUserDetail={(id) => setSelectedUserId(id)}
          onClearSelectedUser={() => setSelectedUserId(null)}
        />
      )}

      {activeView === 'pickups' && (
        <AdminPickupsPage
          pickups={pickupsQuery.pickups}
          total={pickupsQuery.total}
          page={pickupsQuery.page}
          totalPages={pickupsQuery.totalPages}
          setPage={pickupsQuery.setPage}
          search={pickupsQuery.search}
          setSearch={pickupsQuery.setSearch}
          status={pickupsQuery.status}
          setStatus={pickupsQuery.setStatus}
          category={pickupsQuery.category}
          setCategory={pickupsQuery.setCategory}
          isLoading={pickupsQuery.isLoading}
          onUpdateStatus={pickupsQuery.updateStatus}
          onNavigateToLot={(lotId) => {
            lotsQuery.setSearch(lotId);
            setActiveView('lots');
          }}
          onNavigateToScanner={() => setActiveView('qr-scanner')}
        />
      )}

      {activeView === 'lots' && (
        <AdminLotsPage
          lots={lotsQuery.lots}
          total={lotsQuery.total}
          page={lotsQuery.page}
          totalPages={lotsQuery.totalPages}
          setPage={lotsQuery.setPage}
          search={lotsQuery.search}
          setSearch={lotsQuery.setSearch}
          status={lotsQuery.status}
          setStatus={lotsQuery.setStatus}
          category={lotsQuery.category}
          setCategory={lotsQuery.setCategory}
          hasDiscrepancy={lotsQuery.hasDiscrepancy}
          setHasDiscrepancy={lotsQuery.setHasDiscrepancy}
          isLoading={lotsQuery.isLoading}
          onUpdateLotStatus={lotsQuery.updateLotStatus}
          onNavigateToPickup={(pickupId) => {
            pickupsQuery.setSearch(pickupId);
            setActiveView('pickups');
          }}
          onNavigateToScanner={() => setActiveView('qr-scanner')}
        />
      )}

      

      {activeView === 'traceability' && (
        <AdminTraceabilityPage
          events={traceabilityQuery.events}
          total={traceabilityQuery.total}
          page={traceabilityQuery.page}
          totalPages={traceabilityQuery.totalPages}
          setPage={traceabilityQuery.setPage}
          search={traceabilityQuery.search}
          setSearch={traceabilityQuery.setSearch}
          entityType={traceabilityQuery.entityType}
          setEntityType={traceabilityQuery.setEntityType}
          isLoading={traceabilityQuery.isLoading}
          onNavigateToScanner={() => setActiveView('qr-scanner')}
        />
      )}

      {activeView === 'payments' && (
        <AdminPaymentsPage
          payments={paymentsQuery.payments}
          total={paymentsQuery.total}
          page={paymentsQuery.page}
          totalPages={paymentsQuery.totalPages}
          setPage={paymentsQuery.setPage}
          search={paymentsQuery.search}
          setSearch={paymentsQuery.setSearch}
          status={paymentsQuery.status}
          setStatus={paymentsQuery.setStatus}
          startDate={paymentsQuery.startDate}
          setStartDate={paymentsQuery.setStartDate}
          endDate={paymentsQuery.endDate}
          setEndDate={paymentsQuery.setEndDate}
          minAmount={paymentsQuery.minAmount}
          setMinAmount={paymentsQuery.setMinAmount}
          maxAmount={paymentsQuery.maxAmount}
          setMaxAmount={paymentsQuery.setMaxAmount}
          disputedOnly={paymentsQuery.disputedOnly}
          setDisputedOnly={paymentsQuery.setDisputedOnly}
          paymentMethod={paymentsQuery.paymentMethod}
          setPaymentMethod={paymentsQuery.setPaymentMethod}
          isLoading={paymentsQuery.isLoading}
          onFlagPayment={paymentsQuery.flagPayment}
          onResolveDispute={paymentsQuery.resolveDispute}
        />
      )}

      {activeView === 'complaints' && (
        <AdminComplaintsPage
          complaints={complaintsQuery.complaints}
          total={complaintsQuery.total}
          page={complaintsQuery.page}
          totalPages={complaintsQuery.totalPages}
          setPage={complaintsQuery.setPage}
          search={complaintsQuery.search}
          setSearch={complaintsQuery.setSearch}
          status={complaintsQuery.status}
          setStatus={complaintsQuery.setStatus}
          category={complaintsQuery.category}
          setCategory={complaintsQuery.setCategory}
          priority={complaintsQuery.priority}
          setPriority={complaintsQuery.setPriority}
          startDate={complaintsQuery.startDate}
          setStartDate={complaintsQuery.setStartDate}
          endDate={complaintsQuery.endDate}
          setEndDate={complaintsQuery.setEndDate}
          isLoading={complaintsQuery.isLoading}
          onResolveComplaint={complaintsQuery.resolveComplaint}
          onResolveComplaintAction={complaintsQuery.resolveComplaintAction}
          onAddResponse={complaintsQuery.addComplaintResponse}
        />
      )}

      {activeView === 'geographic' && <AdminStateAnalyticsPage />}
      {activeView === 'analytics' && <AdminAnalyticsPage />}

      {activeView === 'anomalies' && (
        <AdminAnomaliesPage
          activeAnomaliesCount={dashboard.data?.overview?.activeAnomaliesCount || 0}
          criticalAnomaliesCount={dashboard.data?.overview?.criticalAnomaliesCount || 0}
          anomalies={anomaliesQuery.anomalies}
          total={anomaliesQuery.total}
          page={anomaliesQuery.page}
          totalPages={anomaliesQuery.totalPages}
          setPage={anomaliesQuery.setPage}
          search={anomaliesQuery.search}
          setSearch={anomaliesQuery.setSearch}
          severity={anomaliesQuery.severity}
          setSeverity={anomaliesQuery.setSeverity}
          status={anomaliesQuery.status}
          setStatus={anomaliesQuery.setStatus}
          entityType={anomaliesQuery.entityType}
          setEntityType={anomaliesQuery.setEntityType}
          ruleKey={anomaliesQuery.ruleKey}
          setRuleKey={anomaliesQuery.setRuleKey}
          isLoading={anomaliesQuery.isLoading}
          onRunRules={anomaliesQuery.runRules}
          onReviewAnomaly={anomaliesQuery.reviewAnomaly}
          onResolveAnomalyWithNotes={anomaliesQuery.resolveAnomalyWithNotes}
          onDismissAnomaly={anomaliesQuery.dismissAnomaly}
          onInvestigateAnomaly={anomaliesQuery.investigateAnomaly}
          onExplainAnomalyWithAi={anomaliesQuery.explainAnomalyWithAi}
          onResolveAnomaly={anomaliesQuery.resolveAnomaly}
          onNavigateToEntity={(type, id) => {
            if (type === 'LOT') {
              lotsQuery.setSearch(id);
              setActiveView('lots');
            } else if (type === 'PICKUP') {
              pickupsQuery.setSearch(id);
              setActiveView('pickups');
            } else if (type === 'PAYMENT') {
              paymentsQuery.setSearch(id);
              setActiveView('payments');
            } else if (type === 'USER') {
              usersQuery.setSearch(id);
              setActiveView('users');
            }
          }}
        />
      )}

      

      
      {activeView === 'ai-activity' && (
        <AdminAiActivityPage
          data={aiActivityQuery.data}
          total={aiActivityQuery.total}
          page={aiActivityQuery.page}
          totalPages={aiActivityQuery.totalPages}
          setPage={aiActivityQuery.setPage}
          isLoading={aiActivityQuery.isLoading}
        />
      )}
      {activeView === 'ivr' && (
        <AdminIvrActivityPage
          data={ivrActivityQuery.data}
          total={ivrActivityQuery.total}
          page={ivrActivityQuery.page}
          totalPages={ivrActivityQuery.totalPages}
          setPage={ivrActivityQuery.setPage}
          isLoading={ivrActivityQuery.isLoading}
        />
      )}
      {activeView === 'notifications' && (
        <AdminNotificationsPage
          data={notificationsQuery.data}
          total={notificationsQuery.total}
          page={notificationsQuery.page}
          totalPages={notificationsQuery.totalPages}
          setPage={notificationsQuery.setPage}
          isLoading={notificationsQuery.isLoading}
        />
      )}

      {activeView === 'audit' && (
        <AdminAuditLogsPage
          logs={auditLogsQuery.logs}
          total={auditLogsQuery.total}
          page={auditLogsQuery.page}
          totalPages={auditLogsQuery.totalPages}
          setPage={auditLogsQuery.setPage}
          search={auditLogsQuery.search}
          setSearch={auditLogsQuery.setSearch}
          isLoading={auditLogsQuery.isLoading}
        />
      )}
    </AdminLayout>
  );
};
