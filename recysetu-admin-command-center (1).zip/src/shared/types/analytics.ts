export type AnalyticsRange = 'today' | '7d' | '30d' | '90d' | 'custom';

export interface AnalyticsSummary {
  totalCollectionVolumeKg: number;
  totalRecycledVolumeKg: number;
  totalLotsCount: number;
  totalPickupsCount: number;
  pickupCompletionRate: number;
  totalDisbursedInr: number;
  pendingDisbursementInr: number;
  activeAnomaliesCount: number;
}

export interface LotsOverTimePoint {
  date: string;
  label: string;
  count: number;
  totalKg: number;
  aggregatedKg: number;
  recycledKg: number;
}

export interface MaterialCategoryPoint {
  categoryId: string;
  categoryName: string;
  materialId?: string;
  materialName?: string;
  code?: string;
  category?: string;
  collectedKg: number;
  recycledKg: number;
  totalValueInr: number;
  valueInr?: number;
  percentage: number;
  color?: string;
}

export interface CollectionVolumePoint {
  date: string;
  label: string;
  volumeKg: number;
  pickupsCount: number;
}

export interface RecyclingVolumePoint {
  date: string;
  label: string;
  volumeKg: number;
  lotsProcessed: number;
  lotsCount?: number;
}

export interface PickupCompletionPoint {
  date: string;
  label: string;
  completed: number;
  pending: number;
  cancelled: number;
  completionRate: number;
}

export interface PickupCompletionStats {
  total: number;
  completed: number;
  pending: number;
  cancelled: number;
  completionRate: number;
  history: PickupCompletionPoint[];
}

export interface LotsByStatusPoint {
  status: string;
  label: string;
  count: number;
  totalKg: number;
  percentage: number;
}

export interface PaymentStatusPoint {
  status: string;
  label: string;
  count: number;
  amount: number;
  percentage: number;
}

export interface PaymentOverTimePoint {
  date: string;
  label: string;
  disbursedAmount: number;
  count: number;
}

export interface PaymentStats {
  totalDisbursed: number;
  totalPending: number;
  totalDisputed: number;
  totalFailed: number;
  byStatus: PaymentStatusPoint[];
  history: PaymentOverTimePoint[];
}

export interface RegionalActivityPoint {
  region: string;
  state: string;
  city: string;
  ward?: string;
  pickupsCount: number;
  volumeKg: number;
  recycledKg: number;
  collectorsCount: number;
  aggregatorsCount: number;
}

export interface AnalyticsResponse {
  timeRange: {
    range: AnalyticsRange;
    startDate: string;
    endDate: string;
    label: string;
  };
  dateRange?: {
    range: AnalyticsRange;
    startDate: string;
    endDate: string;
    effectiveLabel: string;
  };
  summary: AnalyticsSummary;
  lotsOverTime: LotsOverTimePoint[];
  materialCategories: MaterialCategoryPoint[];
  collectionVolume: CollectionVolumePoint[];
  recyclingVolume: RecyclingVolumePoint[];
  pickupCompletion: PickupCompletionStats;
  lotsByStatus: LotsByStatusPoint[];
  payments: PaymentStats;
  regionalActivity: RegionalActivityPoint[];
  topMaterialCategories: MaterialCategoryPoint[];
  cachedAt: string;
  isRealData: boolean;
}
