import { MaterialCategory, PickupStatus, LotStatus, AnomalySeverity } from './domain';

export interface AdminConfig {
  systemName: string;
  tagline: string;
  organizationName: string;
  version: string;
  maintenanceMode: boolean;
  autoEscalateComplaintsHours: number;
  kycMandatoryForDisbursement: boolean;
  minDisbursementThresholdInr: number;
  qrTraceabilityProtocol: 'RECY-CHAIN-V2' | 'RECY-CHAIN-V3';
}

export interface MaterialPricingConfig {
  code: string;
  name: string;
  category: MaterialCategory;
  standardBasePrice: number;
  minPriceFloor: number;
  maxPriceCeiling: number;
  incentiveBonusPerKg: number;
  co2Factor: number;
}

export interface MaterialConfig {
  activeCategories: MaterialCategory[];
  materials: MaterialPricingConfig[];
  updatedAt: string;
}

export interface StatusTransitionRule {
  from: string;
  allowedTransitions: string[];
  requiredRole: ('ADMIN' | 'COLLECTOR' | 'AGGREGATOR' | 'RECYCLER')[];
  requiresEvidencePhoto?: boolean;
  requiresGeoTag?: boolean;
}

export interface StatusConfig {
  pickupTransitions: Record<PickupStatus, StatusTransitionRule>;
  lotTransitions: Record<LotStatus, StatusTransitionRule>;
}

export interface DashboardMetricTarget {
  key: string;
  label: string;
  monthlyTarget: number;
  unit: string;
  benchmarkGood: number;
}

export interface DashboardConfig {
  refreshIntervalSeconds: number;
  targets: DashboardMetricTarget[];
  featuredAlertThresholdHours: number;
}

export interface AnomalyThresholdRule {
  ruleKey: string;
  name: string;
  description: string;
  defaultSeverity: AnomalySeverity;
  thresholdValue: number;
  unit: string;
  autoFlagTransaction: boolean;
  isEnabled: boolean;
}

export interface AnomalyRuleConfig {
  rules: AnomalyThresholdRule[];
}

export interface NotificationChannelConfig {
  channel: 'SMS' | 'WHATSAPP' | 'IN_APP_PUSH' | 'IVR';
  enabled: boolean;
  urgencyLevel: 'ALL' | 'HIGH_AND_CRITICAL_ONLY';
}

export interface NotificationConfig {
  channels: NotificationChannelConfig[];
  adminAlertEmails: string[];
  dailyDigestEnabled: boolean;
}

export interface AppConfiguration {
  adminConfig: AdminConfig;
  materialConfig: MaterialConfig;
  statusConfig: StatusConfig;
  dashboardConfig: DashboardConfig;
  anomalyRuleConfig: AnomalyRuleConfig;
  notificationConfig: NotificationConfig;
  trustRewardsConfig?: TrustRewardsConfiguration;
}

// --- TRUST & REWARDS CONFIG ---

export interface RewardTierConfig {
  tiers: {
    name: string;
    minScore: number;
    maxScore: number;
    benefits: string[];
    bonusPercentage: number;
  }[];
}

export interface ContributionScoreConfig {
  reviewWeight: number;
  reliabilityWeight: number;
  transactionWeight: number;
  accuracyWeight: number;
  participationWeight: number;
  penaltyRules: Record<string, number>; // e.g. { 'CANCELLATION': -10 }
  maximumScore: number;
  minimumScore: number;
}

export interface TrustScoreConfig {
  reviewQualityWeight: number;
  paymentReliabilityWeight: number;
  transactionReliabilityWeight: number;
  processingReliabilityWeight: number;
  complaintPenaltyWeight: number;
  maximumScore: number;
  minimumScore: number;
}

export interface TrustRewardsConfiguration {
  rewardTiers: RewardTierConfig;
  collectorContribution: ContributionScoreConfig;
  aggregatorTrust: TrustScoreConfig;
  recyclerTrust: TrustScoreConfig;
}
