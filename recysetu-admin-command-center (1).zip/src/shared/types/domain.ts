export type UserRole = 'ADMIN' | 'COLLECTOR' | 'AGGREGATOR' | 'RECYCLER';
export type UserStatus = 'ACTIVE' | 'SUSPENDED' | 'PENDING_VERIFICATION' | 'REJECTED';
export type RecyclerVerificationStatus = 'PENDING' | 'VERIFIED' | 'SUSPENDED' | 'REJECTED';

export interface UserLocation {
  city: string;
  state: string;
  ward?: string;
  lat?: number;
  lng?: number;
  address?: string;
}

export interface UserMetrics {
  totalCollectedKg?: number;
  totalDispatchedKg?: number;
  totalRecycledKg?: number;
  totalEarnings?: number;
  rating?: number;
  complianceScore?: number;
}

export interface User {
  id: string;
  adminId?: string; // e.g. "ADMIN-RECY-01" for admins
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  status: UserStatus;
  kycVerified: boolean;
  location: UserLocation;
  metrics: UserMetrics;
  createdAt: string;
  lastActiveAt?: string;
  // Role-specific extensions
  organizationName?: string;
  serviceArea?: string[];
  supportedMaterials?: MaterialCategory[];
  licenseNumber?: string;
  capacityTonsPerDay?: number;
  verificationStatus?: RecyclerVerificationStatus;
  points?: number;
  contributionScore?: number;
  trustScore?: number;
  rejectionReason?: string;
  suspensionReason?: string;
  contributionPoints?: number;
}

export type MaterialCategory = 'PLASTIC' | 'METAL' | 'PAPER' | 'E_WASTE' | 'GLASS' | 'ORGANIC';

export interface Material {
  id: string;
  name: string;
  code: string;
  category: MaterialCategory;
  standardPricePerKg: number;
  marketRate: number;
  unit: string;
  co2OffsetFactorKg: number;
  minGrade: string;
  isActive: boolean;
}

export type PickupStatus =
  | 'REQUESTED'
  | 'ACCEPTED'
  | 'SCHEDULED'
  | 'COLLECTOR_READY'
  | 'PICKED_UP'
  | 'ASSIGNED'
  | 'COLLECTED'
  | 'AGGREGATED'
  | 'DELIVERED'
  | 'CANCELLED'
  | 'COMPLETED';

export type PickupSource = 'PWA' | 'CHATBOT' | 'VOICE' | 'IVR' | 'DIGITAL_SAATHI';

export interface PickupRequest {
  id: string;
  trackingCode: string;
  collectorId: string;
  collectorName: string;
  aggregatorId: string;
  aggregatorName: string;
  recyclerId?: string;
  recyclerName?: string;
  materialId: string;
  materialName: string;
  category: MaterialCategory;
  quantityKg: number;
  unit?: string;
  actualWeightKg?: number;
  lotId?: string;
  pricePerKg: number;
  totalPrice: number;
  status: PickupStatus;
  source?: PickupSource;
  preferredDate?: string;
  preferredTime?: string;
  location: {
    city: string;
    ward: string;
    address: string;
  };
  qrCode: string;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
  collectedAt?: string;
  aggregatedAt?: string;
  scheduledAt?: string;
}

export type LotStatus = 'FORMED' | 'IN_TRANSIT' | 'RECEIVED' | 'PROCESSED' | 'REJECTED';

export interface AggregatedLot {
  id: string;
  lotNumber: string;
  aggregatorId: string;
  aggregatorName: string;
  recyclerId: string;
  recyclerName: string;
  materialId: string;
  materialName: string;
  category: MaterialCategory;
  totalWeightKg: number;
  declaredWeightKg?: number;
  actualWeightKg?: number;
  weightDiscrepancyKg?: number;
  weightDiscrepancyPercent?: number;
  isDiscrepancyFlagged?: boolean;
  moisturePercent: number;
  contaminationPercent: number;
  qualityGrade: 'GRADE_A' | 'GRADE_B' | 'GRADE_C';
  status: LotStatus;
  batchQrCode: string;
  qrStatus?: 'ACTIVE' | 'SEALED' | 'EXPIRED';
  handoverStatus?: 'PENDING' | 'IN_TRANSIT' | 'RECEIVED' | 'VERIFIED';
  paymentStatus?: PaymentStatus;
  pickupIds: string[];
  createdAt: string;
  updatedAt?: string;
  dispatchedAt?: string;
  receivedAt?: string;
  processedAt?: string;
  totalValue?: number;
  manifestId?: string;
  discrepancyNotes?: string;
}

export interface TraceabilityEvent {
  id: string;
  entityType: 'PICKUP' | 'LOT' | 'PAYMENT' | 'USER';
  entityId: string;
  trackingCode: string;
  eventType: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  location: string;
  timestamp: string;
  verifiedOnChain: boolean;
  verificationHash: string;
  verificationMethod?: string;
  weightKg?: number;
  notes?: string;
  details: Record<string, any>;
}

export type PaymentStatus =
  | 'PENDING'
  | 'PROCESSING'
  | 'PAID'
  | 'COMPLETED'
  | 'FAILED'
  | 'DISPUTED'
  | 'FLAGGED';

export interface PaymentRecord {
  id: string;
  transactionId: string;
  payerId: string;
  payerName: string;
  payerRole: UserRole;
  payeeId: string;
  payeeName: string;
  payeeRole: UserRole;
  amount: number;
  status: PaymentStatus;
  paymentMethod: 'UPI' | 'BANK_TRANSFER' | 'DIRECT_CASH' | 'ESCROW';
  relatedEntityType: 'PICKUP' | 'LOT' | 'SUBSIDY';
  relatedEntityId: string;
  relatedTrackingCode?: string;
  timestamp: string;
  createdAt?: string;
  updatedAt?: string;
  referenceNotes?: string;
  upiRefNumber?: string;
  providerRef?: string;
  failureReason?: string;
  disputeReason?: string;
  disputeStatus?: 'NONE' | 'OPEN' | 'UNDER_REVIEW' | 'ARBITRATION' | 'RESOLVED_REFUND' | 'RESOLVED_RELEASE';
  disputedAt?: string;
  escrowStatus?: 'LOCKED' | 'RELEASED' | 'REFUNDED' | 'HELD';
  breakdown?: { baseAmount: number; bonus: number };
}

export type ComplaintPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type ComplaintStatus =
  | 'OPEN'
  | 'IN_REVIEW'
  | 'IN_INVESTIGATION'
  | 'RESOLVED'
  | 'REJECTED'
  | 'DISMISSED';

export type ComplaintCategory =
  | 'PICKUP_ISSUE'
  | 'WEIGHT_ISSUE'
  | 'WEIGHT_DISCREPANCY'
  | 'PAYMENT_ISSUE'
  | 'PAYMENT_DELAY'
  | 'RECYCLER_ISSUE'
  | 'QUALITY_DISPUTE'
  | 'APP_ISSUE'
  | 'HARASSMENT'
  | 'PRICING_MANIPULATION'
  | 'OTHER';

export interface ComplaintResponse {
  id: string;
  responderId: string;
  responderName: string;
  responderRole: UserRole;
  message: string;
  createdAt: string;
  isInternal?: boolean;
}

export interface ComplaintAttachment {
  id: string;
  fileName: string;
  fileType: string;
  fileSizeKb: number;
  storageKey?: string;
  url?: string;
  uploadedAt: string;
  uploadedBy: string;
}

export interface Complaint {
  id: string;
  ticketId: string;
  filedById: string;
  filedByName: string;
  filedByRole: UserRole;
  againstId: string;
  againstName: string;
  againstRole: UserRole;
  category: ComplaintCategory;
  description: string;
  priority: ComplaintPriority;
  status: ComplaintStatus;
  relatedEntityType?: 'LOT' | 'PICKUP';
  relatedEntityId?: string;
  relatedTrackingCode?: string;
  responses?: ComplaintResponse[];
  attachments?: ComplaintAttachment[];
  resolutionNotes?: string;
  resolvedAt?: string;
  resolvedBy?: string;
  rejectedReason?: string;
  createdAt: string;
  updatedAt: string;
}

export type AnomalySeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type AnomalyStatus =
  | 'NEW'
  | 'UNDER_REVIEW'
  | 'RESOLVED'
  | 'DISMISSED'
  | 'DETECTED'
  | 'FALSE_POSITIVE';

export interface AnomalyAiExplanation {
  summary: string;
  riskFactor: string;
  recommendedAction: string;
  verificationCheckpoints: string[];
  generatedAt: string;
  modelUsed?: string;
}

export interface AnomalyRecord {
  id: string;
  type?: string;
  ruleKey: string;
  ruleId?: string;
  ruleName?: string;
  title: string;
  entityType: 'PICKUP' | 'LOT' | 'USER' | 'PAYMENT';
  entityId: string;
  entityTrackingCode?: string;
  severity: AnomalySeverity;
  status: AnomalyStatus;
  description: string;
  detectedAt: string;
  whatHappened?: string;
  whyFlagged?: string;
  whichRule?: string;
  evidence?: Record<string, any>;
  metrics?: Record<string, any>;
  assignedAdmin?: string;
  resolution?: string;
  resolvedAt?: string;
  resolvedBy?: string;
  investigationNotes?: string;
  aiExplanation?: AnomalyAiExplanation;
}

export type AnomalyFlag = AnomalyRecord;

export interface AuditLog {
  id: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  targetResource: string;
  details: string;
  ipAddress?: string;
  timestamp: string;
  entity?: string;
  entityId?: string;
  result?: 'SUCCESS' | 'FAILURE';
  metadata?: Record<string, any>;
}

export interface PaginationParams {
  page?: number;
  limit?: number;
  search?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface AiActivity {
  id: string;
  conversationId: string;
  userId: string;
  userRole?: UserRole;
  language: string;
  intent: string;
  action: string;
  status: 'SUCCESS' | 'FAILED' | 'PENDING';
  confidenceScore: number;
  timestamp: string;
  metadata?: Record<string, any>;
}

export interface IvrActivity {
  id: string;
  callId: string;
  callerId: string;
  provider: string;
  language: string;
  menuSelections: string[];
  intent: string;
  status: 'COMPLETED' | 'DROPPED' | 'FAILED' | 'IN_PROGRESS';
  smsStatus?: 'SENT' | 'FAILED' | 'PENDING' | 'NOT_APPLICABLE';
  timestamp: string;
  durationSeconds: number;
  requestCreated?: string;
}

export interface SystemNotification {
  id: string;
  recipientId: string;
  type: 'OTP' | 'PICKUP_CREATED' | 'PICKUP_ACCEPTED' | 'PICKUP_SCHEDULED' | 'LOT_CREATED' | 'QR_SCANNED' | 'HANDOVER_COMPLETED' | 'WEIGHT_DISCREPANCY' | 'PAYMENT_UPDATE' | 'COMPLAINT_UPDATE' | 'RECYCLER_VERIFIED' | 'SYSTEM_ALERT';
  channel: 'SMS' | 'WHATSAPP' | 'PUSH' | 'EMAIL' | 'IN_APP';
  status: 'SENT' | 'DELIVERED' | 'READ' | 'FAILED';
  title: string;
  message: string;
  timestamp: string;
  relatedEntityId?: string;
  relatedEntityType?: string;
}

export interface SystemConfig {
  id: string;
  key: string;
  value: any;
  category: 'MATERIALS' | 'PRICING' | 'THRESHOLDS' | 'ANOMALIES' | 'NOTIFICATIONS' | 'LANGUAGES' | 'FEATURE_FLAGS';
  description?: string;
  updatedAt: string;
  updatedBy: string;
}

// --- TRUST & REWARDS DOMAIN ---

export type ReviewStatus = 'PENDING' | 'PROCESSED' | 'FLAGGED' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED';

export interface ReviewCriteria {
  pickupCoordination?: number;
  communication?: number;
  fairness?: number;
  paymentReliability?: number;
  professionalism?: number;
  weighingTransparency?: number;
  punctuality?: number;
  materialAccuracy?: number;
  acceptanceReliability?: number;
  lotCoordination?: number;
  documentation?: number;
}

export interface MutualReview {
  id: string;
  reviewerId: string;
  reviewerName: string;
  reviewerRole: UserRole;
  reviewedId: string;
  reviewedName: string;
  reviewedRole: UserRole;
  transactionId: string; // Lot ID or Pickup ID
  transactionType: 'PICKUP' | 'LOT';
  rating: number; // 1-5
  criteria: ReviewCriteria;
  comment?: string;
  status: ReviewStatus;
  scoreImpact?: number;
  createdAt: string;
  processedAt?: string;
}

export interface ScoreHistoryRecord {
  id: string;
  userId: string;
  userRole: UserRole;
  scoreType: 'CONTRIBUTION_POINTS' | 'TRUST_SCORE';
  previousValue: number;
  changeValue: number;
  newValue: number;
  reason: string;
  source: 'REVIEW' | 'TRANSACTION' | 'ADMIN_OVERRIDE' | 'COMPLAINT';
  relatedEntityId?: string;
  timestamp: string;
}

export interface ContributionTier {
  name: string;
  minPoints: number;
  maxPoints: number;
  bonusPercentage: number;
  benefits: string[];
}
