const fs = require('fs');
let content = fs.readFileSync('src/admin/components/AdminTimeline.tsx', 'utf8');

content = content.replace(/text-blue-600/g, 'text-emerald-600');
content = content.replace(/text-rose-600/g, 'text-amber-600');
content = content.replace(/text-slate-600/g, 'text-slate-500');
content = content.replace(/shadow-2xs/g, 'shadow-[0_1px_4px_0_rgba(0,0,0,0.02)]');
content = content.replace(/rounded-lg/g, 'rounded-xl');

fs.writeFileSync('src/admin/components/AdminTimeline.tsx', content);
