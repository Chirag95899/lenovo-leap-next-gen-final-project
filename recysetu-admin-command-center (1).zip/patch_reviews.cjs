const fs = require('fs');

const file = 'src/admin/pages/AdminReviewsPage.tsx';
let code = fs.readFileSync(file, 'utf8');

// Replace GET
code = code.replace(/const res = await fetch\(\`\/api\/admin\/reviews\?search=\$\{search\}\`, \{[\s\S]*?\}\);/, "const res = await adminApi.getReviews({ search, limit: 50 });");
code = code.replace(/if \(!res\.ok\) throw new Error\('Failed to fetch'\);/g, "");
code = code.replace(/const data = await res\.json\(\);/, "const data = res;");
code = code.replace(/setReviews\(data\);/, "setReviews(data.data || []);");

// Replace POST
code = code.replace(/const res = await fetch\(\`\/api\/admin\/reviews\/\$\{selectedReview\.id\}\/process\`, \{[\s\S]*?\}\);/, "const res = await adminApi.processReview(selectedReview.id, { action: reviewAction, notes: reviewNotes });");
code = code.replace(/const data = await res\.json\(\);/, "const data = res;");
code = code.replace(/setReviews\(reviews\.map\(\(r\) => \(r\.id === data\.review\.id \? data\.review : r\)\)\);/, "setReviews(reviews.map((r) => (r.id === data.review.id ? data.review : r)));");

fs.writeFileSync(file, code);

