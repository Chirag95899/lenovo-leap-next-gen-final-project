const fs = require('fs');

const content = `
import React from 'react';

interface AdminPageHeaderProps {
  id?: string;
  title: string;
  description?: string;
  badge?: React.ReactNode;
  actions?: React.ReactNode;
}

export const AdminPageHeader: React.FC<AdminPageHeaderProps> = ({
  id = 'admin-page-header',
  title,
  description,
  badge,
  actions,
}) => {
  return (
    <div
      id={id}
      className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8"
    >
      <div>
        <div className="flex items-center gap-3">
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">{title}</h1>
          {badge}
        </div>
        {description && <p className="text-sm text-slate-500 mt-1.5 max-w-3xl font-medium">{description}</p>}
      </div>
      {actions && <div className="flex items-center gap-2.5 shrink-0">{actions}</div>}
    </div>
  );
};
`;

fs.writeFileSync('src/admin/components/AdminPageHeader.tsx', content);
