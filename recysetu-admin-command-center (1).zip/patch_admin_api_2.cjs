const fs = require('fs');
let code = fs.readFileSync('src/admin/services/adminApiService.ts', 'utf8');

const newMethods = `
  public async getStateAnalytics(): Promise<any> {
    return this.request('/api/admin/state-analytics');
  }

  public async generateStateAnalyticsReport(): Promise<{ report: string }> {
    return this.request('/api/admin/state-analytics/report', { method: 'POST' });
  }

  // --- Config ---
`;

code = code.replace('  // --- Config ---', newMethods);
fs.writeFileSync('src/admin/services/adminApiService.ts', code);
