const fs = require('fs');
let content = fs.readFileSync('src/admin/components/AdminSidebar.tsx', 'utf8');

content = content.replace(
  /\{ view: 'qr-scanner', label: 'QR Scanner', icon: Camera \},?\n?\s*/g,
  ""
);

fs.writeFileSync('src/admin/components/AdminSidebar.tsx', content);
