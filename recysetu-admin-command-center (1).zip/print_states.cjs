const fs = require('fs');
const geo = JSON.parse(fs.readFileSync('public/india-states.geojson'));
const names = geo.features.map(f => f.properties.NAME_1);
console.log(names);
