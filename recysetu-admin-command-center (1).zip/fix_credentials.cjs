const fs = require('fs');
let code = fs.readFileSync('server/db/database.ts', 'utf-8');

// Replace the credentials map and validPasswords checks to use process.env.ADMIN_PASSWORD
code = code.replace(
  /private credentials: Map<string, string\[\]> = new Map\(\[\s*\[.*?\]\s*\]\);/s,
  `// Admin password checking uses process.env.ADMIN_PASSWORD (defaulting to a securely documented env var)
  private getValidPasswords(): string[] {
    const envPass = process.env.ADMIN_PASSWORD;
    if (envPass) return [envPass];
    console.warn('WARNING: ADMIN_PASSWORD environment variable is not set. Using default development password. DO NOT USE IN PRODUCTION.');
    return ['admin123']; // Only for fallback/dev, will warn in logs
  }`
);

code = code.replace(
  /const validPasswords = this\.credentials\.get\(cleanId\) \|\| \[\s*'RecySetuAdmin2026!',\s*'Admin@RecySetu2025',\s*'admin123',\s*\];/s,
  `const validPasswords = this.getValidPasswords();`
);

fs.writeFileSync('server/db/database.ts', code);
