const fs = require('fs');
let content = fs.readFileSync('src/admin/components/AdminSidebar.tsx', 'utf8');

// Add Lucide imports
content = content.replace(
  'History,\n  Recycle,',
  'History,\n  Recycle,\n  Star,\n  Award,'
);

// Add to navigationItems array
const newItems = `
    { view: 'trust-rewards', label: 'Trust & Rewards', icon: Award },
    { view: 'reviews', label: 'Tri-Party Reviews', icon: Star },
    { view: 'complaints',`;

content = content.replace(
  '{ view: \'complaints\',',
  newItems
);

fs.writeFileSync('src/admin/components/AdminSidebar.tsx', content);
