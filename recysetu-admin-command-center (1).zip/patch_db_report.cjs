const fs = require('fs');
let content = fs.readFileSync('server/db/database.ts', 'utf8');

const reportMethod = `
  public async generateStateAnalyticsReport(): Promise<string> {
    const states = this.getStateAnalytics();
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is missing');
    }
    const ai = new GoogleGenAI({ apiKey });
    const prompt = \`
      You are an expert Data Analyst and Operations Director for RECYSETU, a national e-waste recycling platform in India.
      Generate a professional, structured Executive Progress Report based strictly on the following state-wise analytics data.

      DATA:
      \${JSON.stringify(states, null, 2)}

      Requirements:
      - Include an Executive Summary.
      - Detail the Geographic Coverage (active states vs coming soon).
      - Detail the Stakeholder Network (Total Collectors, Aggregators, Recyclers).
      - Detail Collection Performance & Environmental Impact (Waste collected, processed, recycled in kg or Tonnes).
      - Highlight Areas Requiring Attention if any.
      - Do NOT hallucinate data, numbers, or percentages not provided in the data. If data is zero, state it.
      - Do not include financial data if it is not in the JSON.
      - Format as clean Markdown.
    \`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    if (response.text) {
      return response.text;
    } else {
      throw new Error('Failed to generate report text');
    }
  }
`;

content = content.replace(
  /public getStateAnalytics/,
  reportMethod + '\n  public getStateAnalytics'
);

fs.writeFileSync('server/db/database.ts', content);
