const fs = require('fs');
let code = fs.readFileSync('src/admin/services/adminApiService.ts', 'utf8');

const newMethods = `
  public async getAiActivity(page: number): Promise<any> {
    return this.request(\`/api/admin/ai-activity?page=\${page}&limit=15\`);
  }

  public async getIvrActivity(page: number): Promise<any> {
    return this.request(\`/api/admin/ivr-activity?page=\${page}&limit=15\`);
  }

  public async getNotifications(page: number): Promise<any> {
    return this.request(\`/api/admin/notifications?page=\${page}&limit=15\`);
  }

  // --- Config ---
`;

code = code.replace('  // --- Config ---', newMethods);
fs.writeFileSync('src/admin/services/adminApiService.ts', code);
