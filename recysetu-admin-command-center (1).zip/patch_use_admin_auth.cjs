const fs = require('fs');
let code = fs.readFileSync('src/admin/hooks/useAdminAuth.ts', 'utf8');

const replacement = `
  useEffect(() => {
    checkSession();
  }, [checkSession]);

  useEffect(() => {
    const handleExpired = () => {
      adminApi.setToken(null);
      setUser(null);
      setError('Admin session has expired. Please log in again.');
    };
    window.addEventListener('admin-auth-expired', handleExpired);
    return () => window.removeEventListener('admin-auth-expired', handleExpired);
  }, []);
`;

code = code.replace(`  useEffect(() => {
    checkSession();
  }, [checkSession]);`, replacement);

fs.writeFileSync('src/admin/hooks/useAdminAuth.ts', code);
