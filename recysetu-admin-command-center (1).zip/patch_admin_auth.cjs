const fs = require('fs');

function patchFile(filepath) {
  if (!fs.existsSync(filepath)) return;
  let content = fs.readFileSync(filepath, 'utf8');
  content = content.replace(/localStorage\.getItem\('admin_token'\)/g, "adminApi.getToken()");
  
  if (content.includes('adminApi.getToken()') && !content.includes("import { adminApi }")) {
    // Add import to top
    if (content.includes("import React")) {
        content = content.replace("import React", "import { adminApi } from '../services/adminApiService';\nimport React");
    } else {
        content = "import { adminApi } from '../services/adminApiService';\n" + content;
    }
  }
  fs.writeFileSync(filepath, content);
}

patchFile('src/admin/pages/AdminStateAnalyticsPage.tsx');
patchFile('src/admin/pages/AdminReviewsPage.tsx');
patchFile('src/admin/pages/AdminTrustRewardsPage.tsx');
patchFile('src/admin/hooks/useAdminDomainQueries.ts');

