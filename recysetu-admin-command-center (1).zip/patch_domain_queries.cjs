const fs = require('fs');
let code = fs.readFileSync('src/admin/hooks/useAdminDomainQueries.ts', 'utf8');

// Patch AI Activity
code = code.replace(
  /const res = await fetch\(`\/api\/admin\/ai-activity\?page=\$\{p\}&limit=15`, \{\s*headers: \{ Authorization: `Bearer \$\{adminApi\.getToken\(\)\}` \},\s*\}\);\s*const data = await res\.json\(\);\s*if \(!res\.ok\) throw new Error\('Failed to load AI activity'\);/,
  "const data = await adminApi.getAiActivity(p);"
);

// Patch IVR Activity
code = code.replace(
  /const res = await fetch\(`\/api\/admin\/ivr-activity\?page=\$\{p\}&limit=15`, \{\s*headers: \{ Authorization: `Bearer \$\{adminApi\.getToken\(\)\}` \},\s*\}\);\s*const data = await res\.json\(\);\s*if \(!res\.ok\) throw new Error\('Failed to load IVR activity'\);/,
  "const data = await adminApi.getIvrActivity(p);"
);

// Patch Notifications
code = code.replace(
  /const res = await fetch\(`\/api\/admin\/notifications\?page=\$\{p\}&limit=15`, \{\s*headers: \{ Authorization: `Bearer \$\{adminApi\.getToken\(\)\}` \},\s*\}\);\s*const data = await res\.json\(\);\s*if \(!res\.ok\) throw new Error\('Failed to load notifications'\);/,
  "const data = await adminApi.getNotifications(p);"
);

fs.writeFileSync('src/admin/hooks/useAdminDomainQueries.ts', code);
