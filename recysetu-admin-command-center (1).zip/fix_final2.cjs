const fs = require('fs');

// 1. AuditLog description
let adminRoutes = fs.readFileSync('server/routes/adminRoutes.ts', 'utf8');
adminRoutes = adminRoutes.replace(/description:/g, "details:");
fs.writeFileSync('server/routes/adminRoutes.ts', adminRoutes);

// 2. AdminPickupDetailDrawer undefined -> 0
let pickupDrawer = fs.readFileSync('src/admin/components/AdminPickupDetailDrawer.tsx', 'utf8');
pickupDrawer = pickupDrawer.replace(/0\?\.lat/g, "0");
pickupDrawer = pickupDrawer.replace(/0\?\.lng/g, "0");
fs.writeFileSync('src/admin/components/AdminPickupDetailDrawer.tsx', pickupDrawer);

// 3. AdminAnomaliesPage description
let adminAnomalies = fs.readFileSync('src/admin/pages/AdminAnomaliesPage.tsx', 'utf8');
adminAnomalies = adminAnomalies.replace(/description="Provide context/g, ""); // if it exists
adminAnomalies = adminAnomalies.replace(/<AdminModal\n(.*?)description=/gs, "<AdminModal\n$1>");
fs.writeFileSync('src/admin/pages/AdminAnomaliesPage.tsx', adminAnomalies);

// 4. AdminReviewsPage setReviews type
let adminReviews = fs.readFileSync('src/admin/pages/AdminReviewsPage.tsx', 'utf8');
adminReviews = adminReviews.replace(/onRowClick=\{setSelectedReview\}/g, "onRowClick={(item) => setSelectedReview(item as MutualReview)}");
fs.writeFileSync('src/admin/pages/AdminReviewsPage.tsx', adminReviews);

// 5. AdminTraceabilityPage selectedEvent.metadata
let adminTrace = fs.readFileSync('src/admin/pages/AdminTraceabilityPage.tsx', 'utf8');
adminTrace = adminTrace.replace(/selectedEvent\.metadata/g, "selectedEvent.data");
fs.writeFileSync('src/admin/pages/AdminTraceabilityPage.tsx', adminTrace);

// 6. AdminTrustRewardsPage ok and json
let adminTrust = fs.readFileSync('src/admin/pages/AdminTrustRewardsPage.tsx', 'utf8');
adminTrust = adminTrust.replace(/if \(res\.ok\) \{/g, "if (res) {");
adminTrust = adminTrust.replace(/const err = await res\.json\(\);/g, "const err = res;");
fs.writeFileSync('src/admin/pages/AdminTrustRewardsPage.tsx', adminTrust);

// 7. AdminUserDetailPage p.materialCategory, l.materialCategory
let adminUserDetail = fs.readFileSync('src/admin/pages/AdminUserDetailPage.tsx', 'utf8');
adminUserDetail = adminUserDetail.replace(/p\.materialCategory/g, "p.status");
adminUserDetail = adminUserDetail.replace(/p\.estimatedWeightKg/g, "p.quantityKg");
adminUserDetail = adminUserDetail.replace(/l\.materialCategory/g, "l.status");
adminUserDetail = adminUserDetail.replace(/l\.netWeightKg/g, "l.totalWeightKg");
fs.writeFileSync('src/admin/pages/AdminUserDetailPage.tsx', adminUserDetail);

