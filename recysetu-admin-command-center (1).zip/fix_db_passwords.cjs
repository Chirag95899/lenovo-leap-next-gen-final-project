const fs = require('fs');
let code = fs.readFileSync('server/db/database.ts', 'utf-8');

// The replacement was put inside the class but before constructor probably.
// Let's check where it put it and make sure the function is correctly typed and accessible via this.

// A safer way is to just replace this.getValidPasswords() with the logic directly if it's struggling.
code = code.replace(
  /const validPasswords = this\.getValidPasswords\(\);/s,
  `const getValidPasswords = () => {
      const envPass = process.env.ADMIN_PASSWORD;
      if (envPass) return [envPass];
      console.warn('WARNING: ADMIN_PASSWORD environment variable is not set. Using default development password. DO NOT USE IN PRODUCTION.');
      return ['admin123'];
    };
    const validPasswords = getValidPasswords();`
);

// We need to also remove the injected private getValidPasswords method if it caused the error.
// We'll just run sed to remove the class method.
fs.writeFileSync('server/db/database.ts', code);
