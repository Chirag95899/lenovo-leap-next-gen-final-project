const fs = require('fs');
let code = fs.readFileSync('server/db/database.ts', 'utf8');

const targetStr = `    }

    // PRIMARY KPI COUNTS:`;

const replacement = `    }

    // --- APPLY DATE FILTERS TO ARRAYS ---
    const isWithinRange = (dateStr?: string) => {
      if (!dateStr) return false;
      const t = new Date(dateStr).getTime();
      return t >= rangeStart && t <= rangeEnd;
    };

    const periodPickups = allPickups.filter(p => isWithinRange(p.scheduledDate || p.createdAt));
    const periodLots = allLots.filter(l => isWithinRange(l.createdAt));
    const periodPayments = allPayments.filter(p => isWithinRange(p.createdAt || p.timestamp));
    const periodComplaints = allComplaints.filter(c => isWithinRange(c.createdAt));
    
    // PRIMARY KPI COUNTS:`;

code = code.replace(targetStr, replacement);
fs.writeFileSync('server/db/database.ts', code);
