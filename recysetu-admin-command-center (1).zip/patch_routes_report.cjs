const fs = require('fs');
let content = fs.readFileSync('server/routes/adminRoutes.ts', 'utf8');

const newRoute = `
adminRouter.post('/state-analytics/report', async (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const reportText = await db.generateStateAnalyticsReport();
    res.json({ report: reportText });
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_STATE_REPORT', message: err.message });
  }
});
`;

content = content.replace(
  /adminRouter\.get\(\['\/dashboard-stats'/,
  newRoute + "\nadminRouter.get(['/dashboard-stats'"
);

fs.writeFileSync('server/routes/adminRoutes.ts', content);
