const fs = require('fs');

const file = 'src/admin/pages/AdminTrustRewardsPage.tsx';
let code = fs.readFileSync(file, 'utf8');

code = code.replace(/const res = await fetch.*?\{[\s\S]*?\}\);/g, "const res = await adminApi.getUsers({ search, limit: 50 });");
code = code.replace(/if \(!res\.ok\) throw new Error\('Failed to fetch'\);/g, "");
code = code.replace(/const data = await res\.json\(\);/g, "const data = res;");
code = code.replace(/const overrideRes = await fetch.*?\{[\s\S]*?\}\);/g, "const overrideRes = await adminApi.overrideTrustScore(selectedUser.id, overrideScore, overrideReason);");
code = code.replace(/if \(!overrideRes\.ok\) throw new Error\('Failed to override score'\);/g, "");

fs.writeFileSync(file, code);

