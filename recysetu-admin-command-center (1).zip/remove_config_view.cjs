const fs = require('fs');
let code = fs.readFileSync('src/admin/AdminCommandCenter.tsx', 'utf8');

// Also remove `useAdminConfig` from imports if needed, but not strictly required to avoid breaking things, we can just remove the rendering.
// Find the block:
//      {activeView === 'config' && (
//        <AdminConfigPage
//          config={configQuery.config}
//          isLoading={configQuery.isLoading}
//          isSaving={configQuery.isSaving}
//          onUpdateSection={configQuery.updateSection}
//        />
//      )}
code = code.replace(/\{activeView === 'config' && \([\s\S]*?<AdminConfigPage[\s\S]*?\/>\s*\)\}/g, '');

// Save it back
fs.writeFileSync('src/admin/AdminCommandCenter.tsx', code);
