const fs = require('fs');
let content = fs.readFileSync('src/admin/components/AdminActivityFeed.tsx', 'utf8');

content = content.replace(/text-blue-600/g, 'text-emerald-700');
content = content.replace(/text-rose-600/g, 'text-amber-600');
content = content.replace(/text-slate-600/g, 'text-slate-500');

fs.writeFileSync('src/admin/components/AdminActivityFeed.tsx', content);
