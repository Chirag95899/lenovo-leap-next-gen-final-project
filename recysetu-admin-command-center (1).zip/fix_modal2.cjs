const fs = require('fs');
let file = fs.readFileSync('src/admin/pages/AdminAnomaliesPage.tsx', 'utf8');

file = file.replace(/\{\/\* `Flagged on \$\{formatDateTime\(selectedAnomaly\?\.detectedAt\)\} • Status: \$\{selectedAnomaly\?\.status\}`\}\n\s*>/g, "");

fs.writeFileSync('src/admin/pages/AdminAnomaliesPage.tsx', file);
