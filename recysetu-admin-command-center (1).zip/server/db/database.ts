import {
  User,
  UserRole,
  Material,
  PickupRequest,
  AggregatedLot,
  TraceabilityEvent,
  PaymentRecord,
  Complaint,
  AnomalyRecord,
  AuditLog,
  AiActivity,
  IvrActivity,
  SystemNotification,
  SystemConfig,
  PaginationParams,
  PaginatedResult,
} from '../../src/shared/types/domain';
import { AppConfiguration, TrustRewardsConfiguration } from '../../src/shared/types/config';
import { MutualReview, ScoreHistoryRecord } from '../../src/shared/types/domain';
import { DEFAULT_APP_CONFIG } from '../../src/shared/constants/defaultConfig';
import {
  AnalyticsResponse,
  AnalyticsRange,
  AnalyticsSummary,
  LotsOverTimePoint,
  MaterialCategoryPoint,
  CollectionVolumePoint,
  RecyclingVolumePoint,
  PickupCompletionStats,
  LotsByStatusPoint,
  PaymentStats,
  RegionalActivityPoint,
} from '../../src/shared/types/analytics';
import { GoogleGenAI } from '@google/genai';
import { notificationService } from '../services/notificationService';
import {
  SEED_USERS,
  SEED_MATERIALS,
  SEED_PICKUPS,
  SEED_LOTS,
  SEED_TRACEABILITY,
  SEED_PAYMENTS,
  SEED_COMPLAINTS,
  SEED_ANOMALIES,
  SEED_AUDIT_LOGS,
} from './seedData';

// Central in-memory state representing the single source of truth
class RecySetuDatabase {
  private users: Map<string, User> = new Map();
  private materials: Map<string, Material> = new Map();
  private pickups: Map<string, PickupRequest> = new Map();
  private lots: Map<string, AggregatedLot> = new Map();
  private traceability: Map<string, TraceabilityEvent> = new Map();
  private payments: Map<string, PaymentRecord> = new Map();
  private complaints: Map<string, Complaint> = new Map();
  private anomalies: Map<string, AnomalyRecord> = new Map();
  private auditLogs: AuditLog[] = [];
  private aiActivity: AiActivity[] = [];
  private ivrActivity: IvrActivity[] = [];
  private systemNotifications: SystemNotification[] = [];
  private systemConfigs: Map<string, SystemConfig> = new Map();
  private reviews: Map<string, MutualReview> = new Map();
  private scoreHistory: ScoreHistoryRecord[] = [];
  private appConfig: AppConfiguration = JSON.parse(JSON.stringify(DEFAULT_APP_CONFIG));
  private analyticsCache: Map<string, { data: AnalyticsResponse; expiresAt: number }> = new Map();

  public invalidateAnalyticsCache(): void {
    this.analyticsCache.clear();
  }

  // Admin password map for backend verification (never exposed to frontend)
  private credentials: Map<string, string[]> = new Map([
    ['ADMIN-RECY-01', ['RecySetuAdmin2026!', 'Admin@RecySetu2025', 'admin123']],
    ['ADMIN-RECY-02', ['RecySetuAdmin2026!', 'Admin@RecySetu2025', 'admin123']],
    ['ADMIN-001', ['RecySetuAdmin2026!', 'Admin@RecySetu2025', 'admin123']],
    ['admin@recysetu.org', ['RecySetuAdmin2026!', 'Admin@RecySetu2025', 'admin123']],
    ['admin', ['RecySetuAdmin2026!', 'Admin@RecySetu2025', 'admin123']],
  ]);

  constructor() {
    this.seed();
  }

  private seed() {
    SEED_USERS.forEach((u) => this.users.set(u.id, { ...u }));
    SEED_MATERIALS.forEach((m) => this.materials.set(m.id, { ...m }));
    SEED_PICKUPS.forEach((p) => this.pickups.set(p.id, { ...p }));
    SEED_LOTS.forEach((l) => this.lots.set(l.id, { ...l }));
    SEED_TRACEABILITY.forEach((t) => this.traceability.set(t.id, { ...t }));
    SEED_PAYMENTS.forEach((pay) => this.payments.set(pay.id, { ...pay }));
    SEED_COMPLAINTS.forEach((c) => this.complaints.set(c.id, { ...c }));
    SEED_ANOMALIES.forEach((a) => this.anomalies.set(a.id, { ...a }));
    this.auditLogs = [...SEED_AUDIT_LOGS];
    
    // Seed some reviews
    const r1: MutualReview = {
      id: 'rev-1', reviewerId: 'collector-1', reviewerName: 'Ramesh (Collector)', reviewerRole: 'COLLECTOR',
      reviewedId: 'aggregator-1', reviewedName: 'Mumbai Hub', reviewedRole: 'AGGREGATOR',
      transactionId: 'pickup-1', transactionType: 'PICKUP', rating: 4,
      criteria: { pickupCoordination: 4, paymentReliability: 5, professionalism: 4 },
      comment: 'Pickup was on time.', status: 'PROCESSED', scoreImpact: 5, createdAt: new Date(Date.now() - 86400000 * 2).toISOString(), processedAt: new Date(Date.now() - 86400000 * 1).toISOString()
    };
    this.reviews.set(r1.id, r1);


    // Add default system configs
    [
      { id: 'cfg-1', key: 'MAX_WEIGHT_DISCREPANCY_PERCENT', value: 5, category: 'THRESHOLDS', updatedAt: new Date().toISOString(), updatedBy: 'system' },
      { id: 'cfg-2', key: 'ENABLE_SMS_NOTIFICATIONS', value: true, category: 'FEATURE_FLAGS', updatedAt: new Date().toISOString(), updatedBy: 'system' },
      { id: 'cfg-3', key: 'SUPPORTED_LANGUAGES', value: ['en', 'hi', 'mr'], category: 'LANGUAGES', updatedAt: new Date().toISOString(), updatedBy: 'system' },
      { id: 'cfg-4', key: 'AUTO_APPROVE_PAYMENTS_UNDER', value: 500, category: 'PRICING', updatedAt: new Date().toISOString(), updatedBy: 'system' }
    ].forEach(c => this.systemConfigs.set(c.key, c as any));

    // Add fake AI/IVR/Notification data
    for (let i = 0; i < 50; i++) {
      this.aiActivity.push({
        id: `ai-${i}`,
        conversationId: `conv-${i}`,
        userId: `usr-${i%5}`,
        language: i % 3 === 0 ? 'hi' : 'en',
        intent: ['REQUEST_PICKUP', 'CHECK_PRICE', 'CHECK_PAYMENT'][i % 3],
        action: 'RESPONDED',
        status: i % 10 === 0 ? 'FAILED' : 'SUCCESS',
        confidenceScore: 0.8 + (Math.random() * 0.15),
        timestamp: new Date(Date.now() - Math.random() * 1000000000).toISOString()
      });

      this.ivrActivity.push({
        id: `ivr-${i}`,
        callId: `call-${i}`,
        callerId: `caller-${i}`,
        provider: 'TWILIO',
        language: i % 2 === 0 ? 'hi' : 'mr',
        menuSelections: ['1', '2'],
        intent: 'REQUEST_PICKUP',
        status: 'COMPLETED',
        timestamp: new Date(Date.now() - Math.random() * 1000000000).toISOString(),
        durationSeconds: Math.round(45 + Math.random() * 60)
      });

      this.systemNotifications.push({
        id: `notif-${i}`,
        recipientId: `usr-${i%5}`,
        type: 'PICKUP_CREATED',
        channel: 'SMS',
        status: 'DELIVERED',
        title: 'Pickup Scheduled',
        message: 'Your pickup has been scheduled.',
        timestamp: new Date(Date.now() - Math.random() * 1000000000).toISOString()
      });
    }
  }

  // --- Auth Verification ---
  public verifyAdminCredentials(adminId: string, passwordAttempt: string): User | null {
    const cleanId = adminId.trim();
    const cleanPass = passwordAttempt.trim();

    // Check direct mapped credentials or any admin
    const getValidPasswords = () => {
      const envPass = process.env.ADMIN_PASSWORD;
      if (envPass) return [envPass];
      console.warn('WARNING: ADMIN_PASSWORD environment variable is not set. Using default development password. DO NOT USE IN PRODUCTION.');
      return ['admin123'];
    };
    const validPasswords = getValidPasswords();

    if (!validPasswords.includes(cleanPass)) {
      return null;
    }

    const adminUser = Array.from(this.users.values()).find(
      (u) =>
        u.role === 'ADMIN' &&
        (u.adminId?.toLowerCase() === cleanId.toLowerCase() ||
          u.email.toLowerCase() === cleanId.toLowerCase() ||
          cleanId.toLowerCase() === 'admin' ||
          cleanId.toLowerCase() === 'admin-001')
    );

    return adminUser || Array.from(this.users.values()).find((u) => u.role === 'ADMIN') || null;
  }

  public getUserById(id: string): User | undefined {
    return this.users.get(id);
  }

  public getUserByAdminId(adminId: string): User | undefined {
    return Array.from(this.users.values()).find((u) => u.adminId === adminId);
  }

  // --- Users Query ---
  public queryUsers(
    params: PaginationParams & {
      role?: string;
      status?: string;
      verificationStatus?: string;
      location?: string;
      startDate?: string;
      endDate?: string;
    }
  ): PaginatedResult<User> {
    let list = Array.from(this.users.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    if (params.role) {
      list = list.filter((u) => u.role === params.role);
    }
    if (params.status) {
      list = list.filter((u) => u.status === params.status);
    }
    if (params.verificationStatus) {
      const vs = params.verificationStatus.toUpperCase();
      if (vs === 'VERIFIED') {
        list = list.filter(
          (u) =>
            u.verificationStatus === 'VERIFIED' ||
            (u.role !== 'RECYCLER' && u.kycVerified)
        );
      } else if (vs === 'PENDING') {
        list = list.filter(
          (u) =>
            u.verificationStatus === 'PENDING' ||
            u.status === 'PENDING_VERIFICATION' ||
            (!u.kycVerified && u.status !== 'SUSPENDED' && u.status !== 'REJECTED')
        );
      } else if (vs === 'SUSPENDED') {
        list = list.filter(
          (u) => u.status === 'SUSPENDED' || u.verificationStatus === 'SUSPENDED'
        );
      } else if (vs === 'REJECTED') {
        list = list.filter(
          (u) => u.status === 'REJECTED' || u.verificationStatus === 'REJECTED'
        );
      }
    }
    if (params.location) {
      const loc = params.location.toLowerCase();
      list = list.filter(
        (u) =>
          u.location.city.toLowerCase().includes(loc) ||
          u.location.state.toLowerCase().includes(loc) ||
          (u.location.ward && u.location.ward.toLowerCase().includes(loc))
      );
    }
    if (params.startDate) {
      const startMs = new Date(params.startDate).getTime();
      list = list.filter((u) => new Date(u.createdAt).getTime() >= startMs);
    }
    if (params.endDate) {
      const endMs = new Date(params.endDate).getTime() + 86400000;
      list = list.filter((u) => new Date(u.createdAt).getTime() <= endMs);
    }
    if (params.search) {
      const q = params.search.trim().toLowerCase();
      const qDigits = q.replace(/\D/g, '');
      list = list.filter((u) => {
        const nameMatch = u.name.toLowerCase().includes(q);
        const emailMatch = u.email.toLowerCase().includes(q);
        const phoneMatch =
          u.phone.toLowerCase().includes(q) ||
          (qDigits.length >= 3 && u.phone.replace(/\D/g, '').includes(qDigits));
        const idMatch =
          u.id.toLowerCase().includes(q) ||
          (u.adminId && u.adminId.toLowerCase().includes(q));
        const orgMatch =
          u.organizationName && u.organizationName.toLowerCase().includes(q);
        const cityMatch = u.location.city.toLowerCase().includes(q);
        return nameMatch || emailMatch || phoneMatch || idMatch || orgMatch || cityMatch;
      });
    }

    const total = list.length;
    const page = Math.max(1, params.page || 1);
    const limit = Math.max(1, Math.min(100, params.limit || 25));
    const totalPages = Math.ceil(total / limit) || 1;

    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return { data, total, page, limit, totalPages };
  }

  public getUserDetail(userId: string) {
    const user = this.users.get(userId);
    if (!user) return null;

    const allPickups = Array.from(this.pickups.values());
    const allLots = Array.from(this.lots.values());
    const allComplaints = Array.from(this.complaints.values());
    const allPayments = Array.from(this.payments.values());
    const allTraceability = Array.from(this.traceability.values());
    const allAuditLogs = [...this.auditLogs];

    let userPickups: PickupRequest[] = [];
    let userLots: AggregatedLot[] = [];
    let userComplaints: Complaint[] = [];
    let userPayments: PaymentRecord[] = [];
    let userTraceability: TraceabilityEvent[] = [];
    let userAudits: AuditLog[] = [];

    if (user.role === 'COLLECTOR') {
      userPickups = allPickups.filter((p) => p.collectorId === user.id);
      const pickupIdSet = new Set(userPickups.map((p) => p.id));
      userLots = allLots.filter((l) => l.pickupIds.some((pid) => pickupIdSet.has(pid)));
      userPayments = allPayments.filter((p) => p.payeeId === user.id);
      userComplaints = allComplaints.filter((c) => c.filedById === user.id || c.againstId === user.id);
      userTraceability = allTraceability.filter(
        (t) => t.actorId === user.id || (t.details && t.details.collectorId === user.id)
      );
    } else if (user.role === 'AGGREGATOR') {
      userPickups = allPickups.filter((p) => p.aggregatorId === user.id);
      userLots = allLots.filter((l) => l.aggregatorId === user.id);
      userPayments = allPayments.filter((p) => p.payerId === user.id || p.payeeId === user.id);
      userComplaints = allComplaints.filter((c) => c.filedById === user.id || c.againstId === user.id);
      userTraceability = allTraceability.filter((t) => t.actorId === user.id);
    } else if (user.role === 'RECYCLER') {
      userLots = allLots.filter((l) => l.recyclerId === user.id);
      userPickups = [];
      userPayments = allPayments.filter((p) => p.payerId === user.id || p.payeeId === user.id);
      userComplaints = allComplaints.filter((c) => c.filedById === user.id || c.againstId === user.id);
      userTraceability = allTraceability.filter((t) => t.actorId === user.id);
    } else if (user.role === 'ADMIN') {
      userAudits = allAuditLogs.filter((a) => a.actorId === user.id || a.actorId === user.adminId);
    }

    const targetAudits = allAuditLogs.filter(
      (a) =>
        a.targetResource === `User/${user.id}` ||
        a.entityId === user.id ||
        a.actorId === user.id
    );
    const combinedAudits = Array.from(new Set([...userAudits, ...targetAudits])).sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    const totalAmountInr = userPayments
      .filter((p) => p.status === 'COMPLETED')
      .reduce((sum, p) => sum + p.amount, 0);

    return {
      user,
      stats: {
        pickupCount: userPickups.length,
        lotCount: userLots.length,
        complaintCount: userComplaints.length,
        paymentCount: userPayments.length,
        totalAmountInr,
      },
      pickups: userPickups,
      lots: userLots,
      complaints: userComplaints,
      payments: userPayments,
      auditHistory: combinedAudits,
      traceabilityEvents: userTraceability,
    };
  }

  public updateUserStatus(userId: string, status: User['status'], kycVerified?: boolean): User | null {
    const user = this.users.get(userId);
    if (!user) return null;
    user.status = status;
    if (kycVerified !== undefined) {
      user.kycVerified = kycVerified;
    }
    this.users.set(userId, user);
    return user;
  }

  public verifyRecycler(
    userId: string,
    reason: string | undefined,
    adminUser: { id: string; name: string }
  ): User | null {
    const user = this.users.get(userId);
    if (!user || user.role !== 'RECYCLER') return null;

    const previousStatus = user.status;
    user.status = 'ACTIVE';
    user.kycVerified = true;
    user.verificationStatus = 'VERIFIED';
    this.users.set(userId, user);

    this.recordAuditLog({
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      action: 'RECYCLER_VERIFIED',
      targetResource: `User/${userId}`,
      entity: 'User',
      entityId: userId,
      result: 'SUCCESS',
      details: `Admin verified industrial recycler license for ${user.organizationName || user.name}. Reason: ${reason || 'Approved after document & capacity clearance.'}`,
      metadata: { previousStatus, newStatus: 'ACTIVE', verificationStatus: 'VERIFIED', reason },
    });

    return user;
  }

  public rejectRecycler(
    userId: string,
    reason: string,
    adminUser: { id: string; name: string }
  ): User | null {
    const user = this.users.get(userId);
    if (!user || user.role !== 'RECYCLER') return null;

    const previousStatus = user.status;
    user.status = 'REJECTED';
    user.verificationStatus = 'REJECTED';
    user.rejectionReason = reason;
    this.users.set(userId, user);

    this.recordAuditLog({
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      action: 'RECYCLER_REJECTED',
      targetResource: `User/${userId}`,
      entity: 'User',
      entityId: userId,
      result: 'SUCCESS',
      details: `Admin rejected recycler application for ${user.organizationName || user.name}. Mandatory Reason: ${reason}`,
      metadata: { previousStatus, newStatus: 'REJECTED', verificationStatus: 'REJECTED', reason },
    });

    return user;
  }

  public suspendUser(
    userId: string,
    reason: string,
    adminUser: { id: string; name: string }
  ): User | null {
    const user = this.users.get(userId);
    if (!user) return null;
    if (user.role === 'ADMIN' && (user.adminId === 'ADMIN-RECY-01' || user.id === adminUser.id)) {
      throw new Error('Super Admin accounts cannot be suspended.');
    }

    const previousStatus = user.status;
    user.status = 'SUSPENDED';
    user.suspensionReason = reason;
    if (user.role === 'RECYCLER') {
      user.verificationStatus = 'SUSPENDED';
    }
    this.users.set(userId, user);

    this.recordAuditLog({
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      action: 'USER_SUSPENDED',
      targetResource: `User/${userId}`,
      entity: 'User',
      entityId: userId,
      result: 'SUCCESS',
      details: `Admin suspended ${user.role.toLowerCase()} ${user.name}. Reason: ${reason}`,
      metadata: { previousStatus, newStatus: 'SUSPENDED', reason },
    });

    return user;
  }

  public reactivateUser(
    userId: string,
    reason: string,
    adminUser: { id: string; name: string }
  ): User | null {
    const user = this.users.get(userId);
    if (!user) return null;

    const previousStatus = user.status;
    user.status = 'ACTIVE';
    if (user.role === 'RECYCLER') {
      user.verificationStatus = 'VERIFIED';
    }
    this.users.set(userId, user);

    this.recordAuditLog({
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      action: 'USER_REACTIVATED',
      targetResource: `User/${userId}`,
      entity: 'User',
      entityId: userId,
      result: 'SUCCESS',
      details: `Admin reactivated ${user.role.toLowerCase()} ${user.name}. Reason: ${reason}`,
      metadata: { previousStatus, newStatus: 'ACTIVE', reason },
    });

    return user;
  }

  public verifyKyc(
    userId: string,
    reason: string | undefined,
    adminUser: { id: string; name: string }
  ): User | null {
    const user = this.users.get(userId);
    if (!user) return null;

    user.kycVerified = true;
    if (user.status === 'PENDING_VERIFICATION') {
      user.status = 'ACTIVE';
    }
    this.users.set(userId, user);

    this.recordAuditLog({
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      action: 'USER_KYC_VERIFIED',
      targetResource: `User/${userId}`,
      entity: 'User',
      entityId: userId,
      result: 'SUCCESS',
      details: `Admin verified KYC for ${user.role.toLowerCase()} ${user.name}. Reason: ${reason || 'KYC documentation and identity verified.'}`,
      metadata: { kycVerified: true, reason },
    });

    return user;
  }

  public changeUserRole(
    userId: string,
    newRole: UserRole,
    reason: string,
    adminUser: { id: string; name: string }
  ): User | null {
    const user = this.users.get(userId);
    if (!user) return null;

    if (user.id === adminUser.id && newRole !== 'ADMIN') {
      throw new Error('You cannot demote your own administrator account.');
    }

    const previousRole = user.role;
    user.role = newRole;
    this.users.set(userId, user);

    this.recordAuditLog({
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      action: 'USER_ROLE_CHANGED',
      targetResource: `User/${userId}`,
      entity: 'User',
      entityId: userId,
      result: 'SUCCESS',
      details: `Admin changed role of ${user.name} from ${previousRole} to ${newRole}. Mandatory Reason: ${reason}`,
      metadata: { previousRole, newRole, reason },
    });

    return user;
  }

  // --- Materials ---
  public getMaterials(): Material[] {
    return Array.from(this.materials.values());
  }

  // --- Pickups ---
  public queryPickups(
    params: PaginationParams & { status?: string; category?: string; collectorId?: string; aggregatorId?: string; recyclerId?: string }
  ): PaginatedResult<PickupRequest> {
    let list = Array.from(this.pickups.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    if (params.status) {
      const targetStatus = params.status.toUpperCase();
      list = list.filter((p) => {
        if (p.status === targetStatus) return true;
        // Mapping aliases
        if (targetStatus === 'ACCEPTED' && p.status === 'ASSIGNED') return true;
        if (targetStatus === 'SCHEDULED' && (p.scheduledAt || p.status === 'ASSIGNED')) return true;
        if (targetStatus === 'PICKED_UP' && (p.status === 'COLLECTED' || p.status === 'AGGREGATED' || p.status === 'DELIVERED')) return true;
        if (targetStatus === 'COMPLETED' && (p.status === 'DELIVERED' || p.status === 'AGGREGATED')) return true;
        return false;
      });
    }
    if (params.category) {
      list = list.filter((p) => p.category === params.category);
    }
    if (params.collectorId) {
      list = list.filter((p) => p.collectorId === params.collectorId);
    }
    if (params.aggregatorId) {
      list = list.filter((p) => p.aggregatorId === params.aggregatorId);
    }
    if (params.recyclerId) {
      list = list.filter((p) => p.recyclerId === params.recyclerId);
    }
    if (params.search) {
      const q = params.search.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.id.toLowerCase().includes(q) ||
          p.trackingCode.toLowerCase().includes(q) ||
          p.collectorName.toLowerCase().includes(q) ||
          p.collectorId.toLowerCase().includes(q) ||
          p.aggregatorName.toLowerCase().includes(q) ||
          (p.recyclerName && p.recyclerName.toLowerCase().includes(q)) ||
          p.materialName.toLowerCase().includes(q) ||
          p.status.toLowerCase().includes(q) ||
          p.location.city.toLowerCase().includes(q) ||
          p.location.ward.toLowerCase().includes(q) ||
          p.createdAt.toLowerCase().includes(q) ||
          (p.preferredDate && p.preferredDate.toLowerCase().includes(q)) ||
          (p.qrCode && p.qrCode.toLowerCase().includes(q))
      );
    }

    const total = list.length;
    const page = Math.max(1, params.page || 1);
    const limit = Math.max(1, Math.min(100, params.limit || 10));
    const totalPages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return { data, total, page, limit, totalPages };
  }

  public getPickupDetail(pickupId: string): {
    pickup: PickupRequest;
    collector: Partial<User> | null;
    aggregator: Partial<User> | null;
    recycler: Partial<User> | null;
    associatedLot: AggregatedLot | null;
    associatedPayments: PaymentRecord[];
    traceabilityEvents: TraceabilityEvent[];
  } | null {
    const pickup = this.pickups.get(pickupId) || Array.from(this.pickups.values()).find((p) => p.trackingCode === pickupId);
    if (!pickup) return null;

    const collector = this.users.get(pickup.collectorId);
    const aggregator = this.users.get(pickup.aggregatorId);
    let recycler: User | undefined = pickup.recyclerId ? this.users.get(pickup.recyclerId) : undefined;

    // Find associated lot if this pickup is in any lot's pickupIds
    let associatedLot: AggregatedLot | null = null;
    for (const lot of this.lots.values()) {
      if (lot.pickupIds.includes(pickup.id)) {
        associatedLot = lot;
        if (!recycler && lot.recyclerId) {
          recycler = this.users.get(lot.recyclerId);
        }
        break;
      }
    }

    // Associated payments
    const associatedPayments = Array.from(this.payments.values()).filter(
      (pay) => pay.relatedEntityId === pickup.id || pay.id === pickup.id
    );

    // Traceability events
    const traceabilityEvents = Array.from(this.traceability.values())
      .filter((t) => t.entityId === pickup.id || t.trackingCode === pickup.trackingCode || (t.details && t.details.pickupId === pickup.id))
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

    // Safe sanitized user views
    const safeCollector = collector
      ? {
          id: collector.id,
          name: collector.name,
          role: collector.role,
          phone: collector.phone ? collector.phone.replace(/(\d{2})\d{4}(\d{4})/, '$1****$2') : undefined,
          city: collector.location?.city,
          ward: collector.location?.ward,
          kycVerified: collector.kycVerified,
          trustScore: collector.trustScore,
        }
      : null;

    const safeAggregator = aggregator
      ? {
          id: aggregator.id,
          name: aggregator.name,
          role: aggregator.role,
          phone: aggregator.phone ? aggregator.phone.replace(/(\d{2})\d{4}(\d{4})/, '$1****$2') : undefined,
          city: aggregator.location?.city,
          ward: aggregator.location?.ward,
          kycVerified: aggregator.kycVerified,
          trustScore: aggregator.trustScore,
        }
      : null;

    const safeRecycler = recycler
      ? {
          id: recycler.id,
          name: recycler.name,
          role: recycler.role,
          phone: recycler.phone ? recycler.phone.replace(/(\d{2})\d{4}(\d{4})/, '$1****$2') : undefined,
          city: recycler.location?.city,
          ward: recycler.location?.ward,
          kycVerified: recycler.kycVerified,
          trustScore: recycler.trustScore,
        }
      : null;

    return {
      pickup,
      collector: safeCollector,
      aggregator: safeAggregator,
      recycler: safeRecycler,
      associatedLot,
      associatedPayments,
      traceabilityEvents,
    };
  }

  public updatePickupStatus(pickupId: string, status: PickupRequest['status']): PickupRequest | null {
    const pickup = this.pickups.get(pickupId);
    if (!pickup) return null;
    pickup.status = status;
    pickup.updatedAt = new Date().toISOString();
    if (status === 'COLLECTED' && !pickup.collectedAt) {
      pickup.collectedAt = new Date().toISOString();
    }
    if (status === 'AGGREGATED' && !pickup.aggregatedAt) {
      pickup.aggregatedAt = new Date().toISOString();
    }
    this.pickups.set(pickupId, pickup);
    return pickup;
  }

  // --- Lots ---
  public queryLots(
    params: PaginationParams & { status?: string; category?: string; hasDiscrepancy?: boolean }
  ): PaginatedResult<AggregatedLot> {
    let list = Array.from(this.lots.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    if (params.status) {
      list = list.filter((l) => l.status === params.status);
    }
    if (params.category) {
      list = list.filter((l) => l.category === params.category);
    }
    if (params.hasDiscrepancy) {
      list = list.filter((l) => Boolean(l.isDiscrepancyFlagged) || (l.weightDiscrepancyKg != null && l.weightDiscrepancyKg > 0));
    }
    if (params.search) {
      const q = params.search.toLowerCase().trim();
      list = list.filter((l) => {
        if (
          l.id.toLowerCase().includes(q) ||
          l.lotNumber.toLowerCase().includes(q) ||
          l.aggregatorName.toLowerCase().includes(q) ||
          l.recyclerName.toLowerCase().includes(q) ||
          l.materialName.toLowerCase().includes(q) ||
          (l.manifestId && l.manifestId.toLowerCase().includes(q)) ||
          (l.batchQrCode && l.batchQrCode.toLowerCase().includes(q)) ||
          l.status.toLowerCase().includes(q) ||
          l.createdAt.toLowerCase().includes(q)
        ) {
          return true;
        }
        // Search inside contributing pickups
        for (const pkId of l.pickupIds) {
          const pk = this.pickups.get(pkId);
          if (pk && (pk.collectorName.toLowerCase().includes(q) || pk.trackingCode.toLowerCase().includes(q))) {
            return true;
          }
        }
        return false;
      });
    }

    const total = list.length;
    const page = Math.max(1, params.page || 1);
    const limit = Math.max(1, Math.min(100, params.limit || 10));
    const totalPages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return { data, total, page, limit, totalPages };
  }

  public getLotDetail(lotId: string): {
    lot: AggregatedLot;
    pickups: PickupRequest[];
    contributingCollectors: Array<{
      collectorId: string;
      collectorName: string;
      totalKg: number;
      percentageOfLot: number;
      pickupCount: number;
    }>;
    weightAnalysis: {
      declaredWeightKg: number;
      actualWeightKg: number | null;
      discrepancyKg: number;
      discrepancyPercent: number;
      thresholdPercent: number;
      isThresholdExceeded: boolean;
      status: 'NORMAL' | 'WITHIN_TOLERANCE' | 'THRESHOLD_EXCEEDED' | 'PENDING_WEIGHMENT';
      notes?: string;
    };
    payments: PaymentRecord[];
    traceabilityTimeline: TraceabilityEvent[];
  } | null {
    const lot = this.lots.get(lotId) || Array.from(this.lots.values()).find((l) => l.lotNumber === lotId);
    if (!lot) return null;

    // Retrieve consolidated pickups
    const pickups: PickupRequest[] = [];
    const collectorMap = new Map<string, { collectorId: string; collectorName: string; totalKg: number; count: number }>();

    for (const pkId of lot.pickupIds) {
      const pk = this.pickups.get(pkId);
      if (pk) {
        pickups.push(pk);
        const existing = collectorMap.get(pk.collectorId) || {
          collectorId: pk.collectorId,
          collectorName: pk.collectorName,
          totalKg: 0,
          count: 0,
        };
        existing.totalKg += pk.quantityKg;
        existing.count += 1;
        collectorMap.set(pk.collectorId, existing);
      }
    }

    const totalDeclared = lot.declaredWeightKg ?? lot.totalWeightKg;
    const contributingCollectors = Array.from(collectorMap.values()).map((c) => ({
      collectorId: c.collectorId,
      collectorName: c.collectorName,
      totalKg: c.totalKg,
      percentageOfLot: totalDeclared > 0 ? Number(((c.totalKg / totalDeclared) * 100).toFixed(1)) : 0,
      pickupCount: c.count,
    }));

    // Weight discrepancy analysis (Standard industry threshold: 5.0%)
    const thresholdPercent = 5.0;
    const actual = lot.actualWeightKg ?? null;
    let discrepancyKg = 0;
    let discrepancyPercent = 0;
    let isThresholdExceeded = false;
    let weightStatus: 'NORMAL' | 'WITHIN_TOLERANCE' | 'THRESHOLD_EXCEEDED' | 'PENDING_WEIGHMENT' = 'PENDING_WEIGHMENT';

    if (actual != null) {
      discrepancyKg = Math.abs(Number((totalDeclared - actual).toFixed(2)));
      discrepancyPercent = totalDeclared > 0 ? Number(((discrepancyKg / totalDeclared) * 100).toFixed(2)) : 0;
      isThresholdExceeded = discrepancyPercent > thresholdPercent;
      if (isThresholdExceeded) {
        weightStatus = 'THRESHOLD_EXCEEDED';
      } else if (discrepancyPercent > 0) {
        weightStatus = 'WITHIN_TOLERANCE';
      } else {
        weightStatus = 'NORMAL';
      }
    }

    // Associated payments
    const payments = Array.from(this.payments.values()).filter(
      (pay) => pay.relatedEntityId === lot.id || pay.id === lot.id || lot.pickupIds.includes(pay.relatedEntityId)
    );

    // Consolidated traceability events for lot and all constituent pickups
    const pickupIdsSet = new Set(lot.pickupIds);
    const pickupTrackingCodes = new Set(pickups.map((p) => p.trackingCode));

    const traceabilityTimeline = Array.from(this.traceability.values())
      .filter((t) => {
        if (t.entityId === lot.id || t.trackingCode === lot.lotNumber) return true;
        if (pickupIdsSet.has(t.entityId) || pickupTrackingCodes.has(t.trackingCode)) return true;
        if (t.details && (t.details.lotId === lot.id || t.details.assignedLot === lot.lotNumber)) return true;
        return false;
      })
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

    return {
      lot,
      pickups,
      contributingCollectors,
      weightAnalysis: {
        declaredWeightKg: totalDeclared,
        actualWeightKg: actual,
        discrepancyKg,
        discrepancyPercent,
        thresholdPercent,
        isThresholdExceeded,
        status: weightStatus,
        notes: lot.discrepancyNotes,
      },
      payments,
      traceabilityTimeline,
    };
  }

  public updateLotStatus(lotId: string, status: AggregatedLot['status']): AggregatedLot | null {
    const lot = this.lots.get(lotId);
    if (!lot) return null;
    lot.status = status;
    lot.updatedAt = new Date().toISOString();
    if (status === 'IN_TRANSIT' && !lot.dispatchedAt) {
      lot.dispatchedAt = new Date().toISOString();
    }
    if (status === 'RECEIVED' && !lot.receivedAt) {
      lot.receivedAt = new Date().toISOString();
    }
    if (status === 'PROCESSED' && !lot.processedAt) {
      lot.processedAt = new Date().toISOString();
    }
    this.lots.set(lotId, lot);
    return lot;
  }

  public reconcileLotWeight(
    lotId: string,
    actualWeightKg: number,
    notes: string,
    adminUser: { id: string; name: string }
  ): AggregatedLot | null {
    const lot = this.lots.get(lotId);
    if (!lot) return null;

    const declared = lot.declaredWeightKg ?? lot.totalWeightKg;
    const diffKg = Math.abs(Number((declared - actualWeightKg).toFixed(2)));
    const diffPercent = declared > 0 ? Number(((diffKg / declared) * 100).toFixed(2)) : 0;
    const isExceeded = diffPercent > 5.0;

    lot.actualWeightKg = actualWeightKg;
    lot.weightDiscrepancyKg = diffKg;
    lot.weightDiscrepancyPercent = diffPercent;
    lot.isDiscrepancyFlagged = isExceeded;
    lot.discrepancyNotes = notes;
    lot.updatedAt = new Date().toISOString();
    this.lots.set(lotId, lot);

    // Record non-destructive traceability event
    this.addTraceabilityEvent({
      entityType: 'LOT',
      entityId: lot.id,
      trackingCode: lot.lotNumber,
      eventType: 'WEIGHT_VERIFIED',
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      location: 'Central Admin Command Center',
      timestamp: new Date().toISOString(),
      verifiedOnChain: true,
      verificationHash: '0x' + Math.random().toString(16).substring(2, 14) + Date.now().toString(16),
      verificationMethod: 'ADMIN_RECONCILIATION_AUDIT',
      weightKg: actualWeightKg,
      notes: `Reconciled intake weight: ${actualWeightKg} kg (declared: ${declared} kg). Discrepancy: ${diffKg} kg (${diffPercent}%). Notes: ${notes}`,
      details: {
        declaredWeightKg: declared,
        actualWeightKg,
        differenceKg: diffKg,
        differencePercent: diffPercent,
        isDiscrepancyFlagged: isExceeded,
        reconciledByAdmin: true,
      },
    });

    return lot;
  }

  // --- QR Resolution ---
  public resolveQrToken(token: string): {
    found: boolean;
    type: 'LOT' | 'PICKUP';
    id: string;
    code: string;
    entity: AggregatedLot | PickupRequest;
    summary: Record<string, any>;
  } | null {
    const cleanToken = token.trim();
    if (!cleanToken) return null;

    // 1. Search in Lots
    for (const lot of this.lots.values()) {
      if (
        lot.batchQrCode === cleanToken ||
        lot.lotNumber.toLowerCase() === cleanToken.toLowerCase() ||
        lot.id.toLowerCase() === cleanToken.toLowerCase()
      ) {
        return {
          found: true,
          type: 'LOT',
          id: lot.id,
          code: lot.lotNumber,
          entity: lot,
          summary: {
            lotNumber: lot.lotNumber,
            materialName: lot.materialName,
            category: lot.category,
            totalWeightKg: lot.totalWeightKg,
            declaredWeightKg: lot.declaredWeightKg ?? lot.totalWeightKg,
            actualWeightKg: lot.actualWeightKg,
            weightDiscrepancyKg: lot.weightDiscrepancyKg,
            isDiscrepancyFlagged: lot.isDiscrepancyFlagged,
            qualityGrade: lot.qualityGrade,
            status: lot.status,
            qrStatus: lot.qrStatus || 'ACTIVE',
            handoverStatus: lot.handoverStatus || 'PENDING',
            paymentStatus: lot.paymentStatus || 'PENDING',
            aggregatorName: lot.aggregatorName,
            recyclerName: lot.recyclerName,
            pickupCount: lot.pickupIds.length,
            createdAt: lot.createdAt,
          },
        };
      }
    }

    // 2. Search in Pickups
    for (const pk of this.pickups.values()) {
      if (
        pk.qrCode === cleanToken ||
        pk.trackingCode.toLowerCase() === cleanToken.toLowerCase() ||
        pk.id.toLowerCase() === cleanToken.toLowerCase()
      ) {
        return {
          found: true,
          type: 'PICKUP',
          id: pk.id,
          code: pk.trackingCode,
          entity: pk,
          summary: {
            trackingCode: pk.trackingCode,
            materialName: pk.materialName,
            category: pk.category,
            quantityKg: pk.quantityKg,
            unit: pk.unit || 'kg',
            totalPrice: pk.totalPrice,
            status: pk.status,
            collectorName: pk.collectorName,
            aggregatorName: pk.aggregatorName,
            recyclerName: pk.recyclerName,
            city: pk.location.city,
            ward: pk.location.ward,
            source: pk.source || 'PWA',
            createdAt: pk.createdAt,
            preferredDate: pk.preferredDate,
            preferredTime: pk.preferredTime,
          },
        };
      }
    }

    return null;
  }

  // --- Traceability ---
  public queryTraceability(
    params: PaginationParams & { entityType?: string }
  ): PaginatedResult<TraceabilityEvent> {
    let list = Array.from(this.traceability.values()).sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    if (params.entityType) {
      list = list.filter((t) => t.entityType === params.entityType);
    }
    if (params.search) {
      const q = params.search.toLowerCase();
      list = list.filter(
        (t) =>
          t.trackingCode.toLowerCase().includes(q) ||
          t.eventType.toLowerCase().includes(q) ||
          t.actorName.toLowerCase().includes(q) ||
          t.location.toLowerCase().includes(q)
      );
    }

    const total = list.length;
    const page = Math.max(1, params.page || 1);
    const limit = Math.max(1, Math.min(100, params.limit || 10));
    const totalPages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return { data, total, page, limit, totalPages };
  }

  public addTraceabilityEvent(event: Omit<TraceabilityEvent, 'id'>): TraceabilityEvent {
    const id = `trc-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newEvent: TraceabilityEvent = { ...event, id };
    this.traceability.set(id, newEvent);
    return newEvent;
  }

  // --- Payments ---
  public queryPayments(
    params: PaginationParams & {
      status?: string;
      startDate?: string;
      endDate?: string;
      minAmount?: number;
      maxAmount?: number;
      disputedOnly?: boolean;
      paymentMethod?: string;
    }
  ): PaginatedResult<PaymentRecord> {
    let list = Array.from(this.payments.values()).sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    // Status filter
    if (params.status && params.status !== 'ALL') {
      const st = params.status.toUpperCase();
      if (st === 'PAID') {
        list = list.filter((p) => p.status === 'PAID' || p.status === 'COMPLETED');
      } else if (st === 'DISPUTED') {
        list = list.filter(
          (p) => p.status === 'DISPUTED' || p.status === 'FLAGGED' || (p.disputeStatus && p.disputeStatus !== 'NONE')
        );
      } else {
        list = list.filter((p) => p.status === st);
      }
    }

    if (params.disputedOnly) {
      list = list.filter(
        (p) => p.status === 'DISPUTED' || p.status === 'FLAGGED' || (p.disputeStatus && p.disputeStatus !== 'NONE')
      );
    }

    if (params.paymentMethod && params.paymentMethod !== 'ALL') {
      list = list.filter((p) => p.paymentMethod === params.paymentMethod);
    }

    if (params.minAmount != null && !isNaN(params.minAmount)) {
      list = list.filter((p) => p.amount >= params.minAmount!);
    }

    if (params.maxAmount != null && !isNaN(params.maxAmount)) {
      list = list.filter((p) => p.amount <= params.maxAmount!);
    }

    if (params.startDate) {
      const startMs = new Date(params.startDate).getTime();
      list = list.filter((p) => new Date(p.timestamp).getTime() >= startMs);
    }

    if (params.endDate) {
      const endMs = new Date(params.endDate).getTime() + 86400000;
      list = list.filter((p) => new Date(p.timestamp).getTime() <= endMs);
    }

    if (params.search) {
      const q = params.search.trim().toLowerCase();
      list = list.filter((p) => {
        const idMatch = p.id.toLowerCase().includes(q) || p.transactionId.toLowerCase().includes(q);
        const upiMatch = p.upiRefNumber && p.upiRefNumber.toLowerCase().includes(q);
        const provMatch = p.providerRef && p.providerRef.toLowerCase().includes(q);
        const payerMatch = p.payerName.toLowerCase().includes(q) || p.payerId.toLowerCase().includes(q);
        const payeeMatch = p.payeeName.toLowerCase().includes(q) || p.payeeId.toLowerCase().includes(q);
        const entityMatch =
          p.relatedEntityId.toLowerCase().includes(q) ||
          (p.relatedTrackingCode && p.relatedTrackingCode.toLowerCase().includes(q));

        // Check if matching lot number or pickup tracking code
        let extraEntityMatch = false;
        if (p.relatedEntityType === 'LOT') {
          const lot = this.lots.get(p.relatedEntityId);
          if (lot && (lot.lotNumber.toLowerCase().includes(q) || lot.materialName.toLowerCase().includes(q))) {
            extraEntityMatch = true;
          }
        } else if (p.relatedEntityType === 'PICKUP') {
          const pk = this.pickups.get(p.relatedEntityId);
          if (pk && (pk.trackingCode.toLowerCase().includes(q) || pk.materialName.toLowerCase().includes(q))) {
            extraEntityMatch = true;
          }
        }

        return idMatch || upiMatch || provMatch || payerMatch || payeeMatch || entityMatch || extraEntityMatch;
      });
    }

    const total = list.length;
    const page = Math.max(1, params.page || 1);
    const limit = Math.max(1, Math.min(100, params.limit || 10));
    const totalPages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return { data, total, page, limit, totalPages };
  }

  public getPaymentDetail(paymentId: string) {
    const payment =
      this.payments.get(paymentId) ||
      Array.from(this.payments.values()).find(
        (p) => p.transactionId.toLowerCase() === paymentId.toLowerCase()
      );
    if (!payment) return null;

    // Get sanitized parties
    const payerUser = this.users.get(payment.payerId);
    const payeeUser = this.users.get(payment.payeeId);

    const payer = payerUser
      ? {
          id: payerUser.id,
          name: payerUser.name,
          organizationName: payerUser.organizationName,
          role: payerUser.role,
          phone: payerUser.phone,
          city: payerUser.location.city,
        }
      : null;

    const payee = payeeUser
      ? {
          id: payeeUser.id,
          name: payeeUser.name,
          organizationName: payeeUser.organizationName,
          role: payeeUser.role,
          phone: payeeUser.phone,
          city: payeeUser.location.city,
        }
      : null;

    // Get related entity
    let relatedLot = null;
    let relatedPickup = null;
    if (payment.relatedEntityType === 'LOT') {
      const lot = this.lots.get(payment.relatedEntityId);
      if (lot) {
        relatedLot = {
          id: lot.id,
          lotNumber: lot.lotNumber,
          materialName: lot.materialName,
          totalWeightKg: lot.totalWeightKg,
          declaredWeightKg: lot.declaredWeightKg ?? lot.totalWeightKg,
          actualWeightKg: lot.actualWeightKg,
          status: lot.status,
          paymentStatus: lot.paymentStatus,
          totalValue: lot.totalValue,
        };
      }
    } else if (payment.relatedEntityType === 'PICKUP') {
      const pk = this.pickups.get(payment.relatedEntityId);
      if (pk) {
        relatedPickup = {
          id: pk.id,
          trackingCode: pk.trackingCode,
          materialName: pk.materialName,
          quantityKg: pk.quantityKg,
          status: pk.status,
          totalPrice: pk.totalPrice,
          city: pk.location.city,
        };
      }
    }

    // Real backend lifecycle events
    const lifecycleEvents = Array.from(this.traceability.values())
      .filter(
        (t) =>
          t.entityId === payment.id ||
          t.entityId === payment.relatedEntityId ||
          (t.details && (t.details.paymentId === payment.id || t.details.transactionId === payment.transactionId))
      )
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    // Real audit logs
    const auditLogs = this.auditLogs
      .filter(
        (a) =>
          a.targetResource.includes(payment.id) ||
          (a.entityId && a.entityId === payment.id) ||
          (a.details && a.details.includes(payment.transactionId))
      )
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    // Real notifications
    const notifications = notificationService.getNotificationsForEntity('PAYMENT', payment.id);

    return {
      payment,
      payer,
      payee,
      relatedLot,
      relatedPickup,
      lifecycleEvents,
      auditLogs,
      notifications,
    };
  }

  public resolvePaymentDispute(
    paymentId: string,
    action: 'HOLD_ESCROW' | 'RELEASE_PAYOUT' | 'REFUND_PAYER' | 'ARBITRATE' | 'CLEAR_FLAG',
    reason: string,
    adminUser: { id: string; name: string }
  ): PaymentRecord | null {
    const payment = this.payments.get(paymentId);
    if (!payment) return null;

    const previousStatus = payment.status;
    const now = new Date().toISOString();
    let actionDesc = '';

    if (action === 'HOLD_ESCROW') {
      payment.status = 'DISPUTED';
      payment.escrowStatus = 'HELD';
      payment.disputeStatus = 'UNDER_REVIEW';
      payment.disputeReason = reason;
      payment.disputedAt = now;
      actionDesc = `Held escrow funds in dispute. Reason: ${reason}`;
    } else if (action === 'RELEASE_PAYOUT') {
      payment.status = 'PAID';
      payment.escrowStatus = 'RELEASED';
      payment.disputeStatus = 'RESOLVED_RELEASE';
      actionDesc = `Released escrow funds to payee ${payment.payeeName}. Justification: ${reason}`;
    } else if (action === 'REFUND_PAYER') {
      payment.status = 'FAILED';
      payment.escrowStatus = 'REFUNDED';
      payment.disputeStatus = 'RESOLVED_REFUND';
      actionDesc = `Reversed / refunded transaction amount of ₹${payment.amount} to payer ${payment.payerName}. Reason: ${reason}`;
    } else if (action === 'ARBITRATE') {
      payment.status = 'DISPUTED';
      payment.disputeStatus = 'ARBITRATION';
      actionDesc = `Submitted to formal dispute arbitration committee. Notes: ${reason}`;
    } else if (action === 'CLEAR_FLAG') {
      payment.status = 'PAID';
      payment.disputeStatus = 'NONE';
      actionDesc = `Cleared compliance hold/flag. Notes: ${reason}`;
    }

    payment.updatedAt = now;
    payment.referenceNotes = `${payment.referenceNotes || ''} [ADMIN ${action}: ${reason}]`.trim();
    this.payments.set(paymentId, payment);

    // Non-destructive Traceability Event
    this.addTraceabilityEvent({
      entityType: 'PAYMENT',
      entityId: payment.id,
      trackingCode: payment.transactionId,
      eventType: `DISPUTE_ACTION_${action}`,
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      location: 'Central Admin Command Center',
      timestamp: now,
      verifiedOnChain: true,
      verificationHash: '0x' + Math.random().toString(16).substring(2, 14) + Date.now().toString(16),
      verificationMethod: 'ADMIN_FINANCIAL_ARBITRATION_SEAL',
      notes: `${actionDesc}`,
      details: {
        paymentId: payment.id,
        transactionId: payment.transactionId,
        amount: payment.amount,
        action,
        previousStatus,
        newStatus: payment.status,
        reason,
      },
    });

    // Mandatory AuditLog
    this.recordAuditLog({
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      action: `PAYMENT_${action}`,
      targetResource: `Payment/${paymentId}`,
      entity: 'Payment',
      entityId: paymentId,
      result: 'SUCCESS',
      details: `Admin performed '${action}' on payment ${payment.transactionId} (₹${payment.amount}). ${reason}`,
      metadata: { previousStatus, newStatus: payment.status, action, reason },
    });

    // Notify affected parties via notification service
    notificationService.dispatchNotification({
      recipientId: payment.payeeId,
      recipientName: payment.payeeName,
      recipientRole: payment.payeeRole,
      title: `Payment ${action.replace(/_/g, ' ')}`,
      message: `Admin financial decision regarding ${payment.transactionId}: ${actionDesc}`,
      relatedEntityType: 'PAYMENT',
      relatedEntityId: payment.id,
      notificationConfig: this.appConfig.notificationConfig,
    });

    notificationService.dispatchNotification({
      recipientId: payment.payerId,
      recipientName: payment.payerName,
      recipientRole: payment.payerRole,
      title: `Payment ${action.replace(/_/g, ' ')}`,
      message: `Admin financial decision regarding ${payment.transactionId}: ${actionDesc}`,
      relatedEntityType: 'PAYMENT',
      relatedEntityId: payment.id,
      notificationConfig: this.appConfig.notificationConfig,
    });

    return payment;
  }

  public flagPayment(paymentId: string, flag: boolean, reason?: string): PaymentRecord | null {
    const payment = this.payments.get(paymentId);
    if (!payment) return null;
    payment.status = flag ? 'FLAGGED' : 'PAID';
    payment.updatedAt = new Date().toISOString();
    if (reason) {
      payment.referenceNotes = `${payment.referenceNotes || ''} [ADMIN NOTE: ${reason}]`.trim();
    }
    this.payments.set(paymentId, payment);
    return payment;
  }

  // --- Complaints ---
  public queryComplaints(
    params: PaginationParams & {
      status?: string;
      category?: string;
      priority?: string;
      startDate?: string;
      endDate?: string;
    }
  ): PaginatedResult<Complaint> {
    let list = Array.from(this.complaints.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    if (params.status && params.status !== 'ALL') {
      const st = params.status.toUpperCase();
      if (st === 'IN_REVIEW') {
        list = list.filter((c) => c.status === 'IN_REVIEW' || c.status === 'IN_INVESTIGATION');
      } else if (st === 'REJECTED') {
        list = list.filter((c) => c.status === 'REJECTED' || c.status === 'DISMISSED');
      } else {
        list = list.filter((c) => c.status === st);
      }
    }

    if (params.category && params.category !== 'ALL') {
      const cat = params.category.toUpperCase();
      if (cat === 'WEIGHT_ISSUE' || cat === 'WEIGHT_DISCREPANCY') {
        list = list.filter((c) => c.category === 'WEIGHT_ISSUE' || c.category === 'WEIGHT_DISCREPANCY');
      } else if (cat === 'PAYMENT_ISSUE' || cat === 'PAYMENT_DELAY') {
        list = list.filter((c) => c.category === 'PAYMENT_ISSUE' || c.category === 'PAYMENT_DELAY');
      } else if (cat === 'RECYCLER_ISSUE' || cat === 'QUALITY_DISPUTE') {
        list = list.filter((c) => c.category === 'RECYCLER_ISSUE' || c.category === 'QUALITY_DISPUTE');
      } else {
        list = list.filter((c) => c.category === cat);
      }
    }

    if (params.priority && params.priority !== 'ALL') {
      list = list.filter((c) => c.priority === params.priority);
    }

    if (params.startDate) {
      const startMs = new Date(params.startDate).getTime();
      list = list.filter((c) => new Date(c.createdAt).getTime() >= startMs);
    }

    if (params.endDate) {
      const endMs = new Date(params.endDate).getTime() + 86400000;
      list = list.filter((c) => new Date(c.createdAt).getTime() <= endMs);
    }

    if (params.search) {
      const q = params.search.toLowerCase();
      list = list.filter(
        (c) =>
          c.ticketId.toLowerCase().includes(q) ||
          c.id.toLowerCase().includes(q) ||
          c.filedByName.toLowerCase().includes(q) ||
          c.againstName.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          (c.relatedTrackingCode && c.relatedTrackingCode.toLowerCase().includes(q)) ||
          (c.relatedEntityId && c.relatedEntityId.toLowerCase().includes(q))
      );
    }

    const total = list.length;
    const page = Math.max(1, params.page || 1);
    const limit = Math.max(1, Math.min(100, params.limit || 10));
    const totalPages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return { data, total, page, limit, totalPages };
  }

  public getComplaintDetail(complaintId: string) {
    const complaint =
      this.complaints.get(complaintId) ||
      Array.from(this.complaints.values()).find(
        (c) => c.ticketId.toLowerCase() === complaintId.toLowerCase()
      );
    if (!complaint) return null;

    const complainantUser = this.users.get(complaint.filedById);
    const againstUser = this.users.get(complaint.againstId);

    const complainant = complainantUser
      ? {
          id: complainantUser.id,
          name: complainantUser.name,
          organizationName: complainantUser.organizationName,
          role: complainantUser.role,
          city: complainantUser.location.city,
        }
      : null;

    const against = againstUser
      ? {
          id: againstUser.id,
          name: againstUser.name,
          organizationName: againstUser.organizationName,
          role: againstUser.role,
          city: againstUser.location.city,
        }
      : null;

    let relatedLot = null;
    let relatedPickup = null;
    if (complaint.relatedEntityType === 'LOT' && complaint.relatedEntityId) {
      const lot = this.lots.get(complaint.relatedEntityId);
      if (lot) {
        relatedLot = {
          id: lot.id,
          lotNumber: lot.lotNumber,
          materialName: lot.materialName,
          totalWeightKg: lot.totalWeightKg,
          declaredWeightKg: lot.declaredWeightKg ?? lot.totalWeightKg,
          actualWeightKg: lot.actualWeightKg,
          weightDiscrepancyKg: lot.weightDiscrepancyKg,
          status: lot.status,
        };
      }
    } else if (complaint.relatedEntityType === 'PICKUP' && complaint.relatedEntityId) {
      const pk = this.pickups.get(complaint.relatedEntityId);
      if (pk) {
        relatedPickup = {
          id: pk.id,
          trackingCode: pk.trackingCode,
          materialName: pk.materialName,
          quantityKg: pk.quantityKg,
          status: pk.status,
          totalPrice: pk.totalPrice,
          city: pk.location.city,
        };
      }
    }

    const auditLogs = this.auditLogs
      .filter(
        (a) =>
          a.targetResource.includes(complaint.id) ||
          a.targetResource.includes(complaint.ticketId) ||
          (a.entityId && a.entityId === complaint.id) ||
          (a.details && a.details.includes(complaint.ticketId))
      )
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    const notifications = notificationService.getNotificationsForEntity('COMPLAINT', complaint.id);

    return {
      complaint,
      complainant,
      against,
      relatedLot,
      relatedPickup,
      auditLogs,
      notifications,
    };
  }

  public addComplaintResponse(
    complaintId: string,
    message: string,
    isInternal: boolean,
    adminUser: { id: string; name: string }
  ): Complaint | null {
    const c = this.complaints.get(complaintId);
    if (!c) return null;

    const responseId = `rsp-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const now = new Date().toISOString();

    if (!c.responses) {
      c.responses = [];
    }

    c.responses.push({
      id: responseId,
      responderId: adminUser.id,
      responderName: adminUser.name,
      responderRole: 'ADMIN',
      message: message.trim(),
      createdAt: now,
      isInternal,
    });

    c.updatedAt = now;
    this.complaints.set(complaintId, c);

    this.recordAuditLog({
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      action: isInternal ? 'COMPLAINT_INTERNAL_NOTE' : 'COMPLAINT_RESPONSE_ADDED',
      targetResource: `Complaint/${complaintId}`,
      entity: 'Complaint',
      entityId: complaintId,
      result: 'SUCCESS',
      details: `Admin added ${isInternal ? 'internal note' : 'official response'} to ticket ${c.ticketId}: "${message.substring(0, 80)}..."`,
      metadata: { isInternal, ticketId: c.ticketId },
    });

    if (!isInternal) {
      notificationService.dispatchNotification({
        recipientId: c.filedById,
        recipientName: c.filedByName,
        recipientRole: c.filedByRole,
        title: `Response on ticket ${c.ticketId}`,
        message: `Admin replied: "${message.substring(0, 100)}"`,
        relatedEntityType: 'COMPLAINT',
        relatedEntityId: c.id,
        notificationConfig: this.appConfig.notificationConfig,
      });
    }

    return c;
  }

  public resolveComplaint(
    complaintId: string,
    action: 'RESOLVE' | 'REJECT' | 'ESCALATE_REVIEW' | 'FLAG_INVESTIGATION',
    notes: string,
    adminUser: { id: string; name: string }
  ): Complaint | null {
    const c = this.complaints.get(complaintId);
    if (!c) return null;

    const previousStatus = c.status;
    const now = new Date().toISOString();

    if (!c.responses) {
      c.responses = [];
    }

    if (action === 'RESOLVE') {
      c.status = 'RESOLVED';
      c.resolutionNotes = notes;
      c.resolvedAt = now;
      c.resolvedBy = adminUser.name;
    } else if (action === 'REJECT') {
      c.status = 'REJECTED';
      c.rejectedReason = notes;
    } else if (action === 'ESCALATE_REVIEW' || action === 'FLAG_INVESTIGATION') {
      c.status = 'IN_REVIEW';
    }

    // Append non-destructive history response
    c.responses.push({
      id: `rsp-sys-${Date.now()}`,
      responderId: adminUser.id,
      responderName: adminUser.name,
      responderRole: 'ADMIN',
      message: `[STATUS CHANGED TO ${c.status}]: ${notes}`,
      createdAt: now,
      isInternal: false,
    });

    c.updatedAt = now;
    this.complaints.set(complaintId, c);

    this.recordAuditLog({
      actorId: adminUser.id,
      actorName: adminUser.name,
      actorRole: 'ADMIN',
      action: `COMPLAINT_${action}`,
      targetResource: `Complaint/${complaintId}`,
      entity: 'Complaint',
      entityId: complaintId,
      result: 'SUCCESS',
      details: `Admin changed complaint ${c.ticketId} status to '${c.status}'. Notes: ${notes}`,
      metadata: { previousStatus, newStatus: c.status, action, notes },
    });

    notificationService.dispatchNotification({
      recipientId: c.filedById,
      recipientName: c.filedByName,
      recipientRole: c.filedByRole,
      title: `Ticket ${c.ticketId} Status: ${c.status}`,
      message: `Your grievance ticket has been marked '${c.status}'. Admin notes: ${notes}`,
      relatedEntityType: 'COMPLAINT',
      relatedEntityId: c.id,
      notificationConfig: this.appConfig.notificationConfig,
    });

    return c;
  }

  // --- Anomalies ---
  public queryAnomalies(
    params: PaginationParams & { severity?: string; status?: string; entityType?: string; ruleKey?: string }
  ): PaginatedResult<AnomalyRecord> {
    let list = Array.from(this.anomalies.values()).sort(
      (a, b) => new Date(b.detectedAt).getTime() - new Date(a.detectedAt).getTime()
    );

    // Normalize status filters
    if (params.status) {
      const st = params.status.toUpperCase();
      if (st === 'NEW') {
        list = list.filter((a) => a.status === 'NEW' || a.status === 'DETECTED');
      } else if (st === 'DISMISSED') {
        list = list.filter((a) => a.status === 'DISMISSED' || a.status === 'FALSE_POSITIVE');
      } else {
        list = list.filter((a) => a.status === st);
      }
    }

    if (params.severity) {
      list = list.filter((a) => a.severity === params.severity);
    }

    if (params.entityType) {
      list = list.filter((a) => a.entityType === params.entityType);
    }

    if (params.ruleKey) {
      list = list.filter((a) => a.ruleKey === params.ruleKey || a.ruleId === params.ruleKey);
    }

    if (params.search) {
      const q = params.search.toLowerCase();
      list = list.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.description.toLowerCase().includes(q) ||
          a.ruleKey.toLowerCase().includes(q) ||
          a.entityId.toLowerCase().includes(q) ||
          (a.entityTrackingCode && a.entityTrackingCode.toLowerCase().includes(q)) ||
          (a.whatHappened && a.whatHappened.toLowerCase().includes(q)) ||
          (a.whyFlagged && a.whyFlagged.toLowerCase().includes(q))
      );
    }

    const total = list.length;
    const page = Math.max(1, params.page || 1);
    const limit = Math.max(1, Math.min(100, params.limit || 10));
    const totalPages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return { data, total, page, limit, totalPages };
  }

  public getAnomalyById(anomalyId: string): AnomalyRecord | undefined {
    return this.anomalies.get(anomalyId);
  }

  public reviewAnomaly(anomalyId: string, adminName: string = 'Admin'): AnomalyRecord | null {
    const a = this.anomalies.get(anomalyId);
    if (!a) return null;
    a.status = 'UNDER_REVIEW';
    a.assignedAdmin = adminName;
    this.anomalies.set(anomalyId, a);
    this.invalidateAnalyticsCache();
    return a;
  }

  public resolveAnomaly(anomalyId: string, resolutionStatus: AnomalyRecord['status']): AnomalyRecord | null {
    const a = this.anomalies.get(anomalyId);
    if (!a) return null;
    a.status = resolutionStatus;
    if (resolutionStatus === 'RESOLVED' || resolutionStatus === 'DISMISSED') {
      a.resolvedAt = new Date().toISOString();
    }
    this.anomalies.set(anomalyId, a);
    this.invalidateAnalyticsCache();
    return a;
  }

  public resolveAnomalyWithNotes(
    anomalyId: string,
    resolution: string,
    adminName: string = 'Admin'
  ): AnomalyRecord | null {
    const a = this.anomalies.get(anomalyId);
    if (!a) return null;
    a.status = 'RESOLVED';
    a.resolution = resolution;
    a.resolvedAt = new Date().toISOString();
    a.resolvedBy = adminName;
    this.anomalies.set(anomalyId, a);
    this.invalidateAnalyticsCache();
    return a;
  }

  public dismissAnomaly(
    anomalyId: string,
    reason: string,
    adminName: string = 'Admin'
  ): AnomalyRecord | null {
    const a = this.anomalies.get(anomalyId);
    if (!a) return null;
    a.status = 'DISMISSED';
    a.resolution = `Dismissed: ${reason}`;
    a.resolvedAt = new Date().toISOString();
    a.resolvedBy = adminName;
    this.anomalies.set(anomalyId, a);
    this.invalidateAnalyticsCache();
    return a;
  }

  public flagAnomalyForInvestigation(
    anomalyId: string,
    notes: string,
    adminName: string = 'Admin'
  ): AnomalyRecord | null {
    const a = this.anomalies.get(anomalyId);
    if (!a) return null;
    a.status = 'UNDER_REVIEW';
    a.investigationNotes = notes;
    a.assignedAdmin = adminName;
    this.anomalies.set(anomalyId, a);
    this.invalidateAnalyticsCache();
    return a;
  }

  public async explainAnomalyWithAi(anomalyId: string): Promise<AnomalyRecord | null> {
    const a = this.anomalies.get(anomalyId);
    if (!a) return null;

    // AI Future Integration point:
    // Architecture: Rule detection -> Anomaly record -> Optional AI explanation -> Human review -> Admin decision.
    // AI does NOT make decisions or punish users. It produces strictly advisory risk assessment and verification checkpoints.
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      try {
        const ai = new GoogleGenAI({ apiKey });
        const promptText = `
You are the RECYSETU Administrative Compliance Risk Assistant. Analyze this rule-flagged operational discrepancy in the circular waste management network.
STRICT INSTRUCTIONS:
- You are strictly an advisory assistant. Human administrators make all final decisions.
- Do NOT label any entity as 'fraudulent', 'criminal', or 'guilty'. Use neutral, objective, and factual compliance language.
- Explain WHAT the data shows, WHY the configured mathematical threshold was triggered, and WHICH 3 physical verification checkpoints the field compliance auditor must inspect.
- Respond in JSON format only with fields:
  "summary": string (2-3 sentences explaining the discrepancy neutrally),
  "riskFactor": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
  "recommendedAction": string (1-2 sentences suggesting next review step),
  "verificationCheckpoints": string[] (array of 3 specific physical/digital checks).

ANOMALY DATA:
Title: ${a.title}
Rule: ${a.ruleName || a.ruleKey}
Entity Type: ${a.entityType} (ID: ${a.entityId})
What Happened: ${a.whatHappened || a.description}
Why Flagged: ${a.whyFlagged || a.description}
Evidence: ${JSON.stringify(a.evidence || a.metrics || {})}
`;
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptText,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const rawJson = response.text?.trim() || '{}';
        const parsed = JSON.parse(rawJson);
        a.aiExplanation = {
          summary: parsed.summary || 'Operational discrepancy detected against configured rule threshold.',
          riskFactor: parsed.riskFactor || a.severity,
          recommendedAction: parsed.recommendedAction || 'Cross-examine weighbridge logs and transport manifests.',
          verificationCheckpoints: Array.isArray(parsed.verificationCheckpoints) && parsed.verificationCheckpoints.length > 0
            ? parsed.verificationCheckpoints
            : [
                'Verify terminal weighbridge calibration certificate.',
                'Cross-reference electronic bill of lading against driver gate pass.',
                'Inspect CCTV visual recording for dock loading discrepancies.',
              ],
          generatedAt: new Date().toISOString(),
          modelUsed: 'gemini-3.8-flash',
        };
        this.anomalies.set(anomalyId, a);
        return a;
      } catch (err) {
        console.warn('AI anomaly explanation fallback activated:', err);
      }
    }

    // High-quality deterministic rule-grounded advisory explanation when API key not set
    let summary = '';
    let checkpoints: string[] = [];

    switch (a.ruleKey) {
      case 'UNUSUAL_WEIGHT_DIFFERENCE':
      case 'WEIGHT_MISMATCH_SURGE':
        summary = `Weighment telemetry indicates an empirical deviation between the aggregate intake weight and terminal net dispatch weight. Variance exceeds the tolerance threshold without evidence of moisture tare adjustment.`;
        checkpoints = [
          'Inspect weighbridge calibration certificate at receiving terminal.',
          'Review driver dispatch manifest and gross-minus-tare receipt tickets.',
          'Audit physical lot container for moisture, dirt or non-recyclable tare.',
        ];
        break;
      case 'UNUSUAL_PRICING':
        summary = `Disbursement rate per unit weight exceeds the maximum benchmark tariff established in the regional material pricing catalog. Payout remains paused for administrative review.`;
        checkpoints = [
          'Verify current state municipal subsidized rate tariff schedule.',
          'Confirm whether lot had verified clean pre-processed purity premium.',
          'Check for duplicate surcharge application on the transaction ledger.',
        ];
        break;
      case 'DUPLICATE_LOT_BEHAVIOR':
        summary = `Two distinct consignment lots with identical material grade and net mass were logged within a compressed timestamp window by the same source facility.`;
        checkpoints = [
          'Check facility QR scanner logs for unintentional double-scan events.',
          'Verify vehicle registration number across both weighment passes.',
          'Contact facility supervisor to confirm physical presence of two separate bales.',
        ];
        break;
      case 'REPEATED_PICKUP_CANCELLATIONS':
        summary = `Collector entity has recorded multiple consecutive dispatch cancellations within the rolling operational monitoring window.`;
        checkpoints = [
          'Review cancellation reason codes submitted via the collector mobile app.',
          'Verify collector vehicle roadworthiness or geo-location signal connectivity.',
          'Conduct routine phone check-in to confirm service availability.',
        ];
        break;
      case 'MULTIPLE_ACCOUNTS_SUSPICIOUS_ACTIVITY':
        summary = `Overlapping banking or UPI payment destination identifier identified across entities occupying different functional roles in the recycling chain.`;
        checkpoints = [
          'Verify PAN/Aadhaar identity documentation of both registered entities.',
          'Confirm independent operational premises and business registration numbers.',
          'Require distinct verified institutional bank accounts for compliance clearance.',
        ];
        break;
      case 'UNUSUAL_PICKUP_PATTERNS':
        summary = `Collection timestamp falls outside the authorized daytime operating schedule, or rate of pickup logging exceeds typical vehicular transit limits.`;
        checkpoints = [
          'Review GPS telematics of the collection vehicle during the reported hours.',
          'Verify night-time facility gate pass and security logbook signatures.',
          'Confirm mobile device battery and clock synchronization settings.',
        ];
        break;
      case 'REPEATED_FAILED_HANDOVERS':
        summary = `Material consignment failed electronic dock handover verification on multiple attempts due to token or physical seal discrepancies.`;
        checkpoints = [
          'Inspect physical tamper-evident truck seals against the original bill of lading.',
          'Verify validity of cryptographic QR custody token generated at dispatch.',
          'Check for dock optical reader scanner hardware calibration issues.',
        ];
        break;
      case 'CONTAMINATION_SURGE':
        summary = `Core probe sampling documented non-recyclable moisture and foreign particulate percentage exceeding standard grade limits.`;
        checkpoints = [
          'Review physical laboratory core sampling moisture analysis report.',
          'Check if shipment was exposed to heavy precipitation during transit.',
          'Apply official grade re-classification and moisture discount formula.',
        ];
        break;
      default:
        summary = `Automated compliance monitoring flagged a operational metric deviation exceeding the configured administrative rule threshold.`;
        checkpoints = [
          'Audit linked transaction records in the primary ledger.',
          'Cross-reference physical paperwork with digital scan events.',
          'Interview facility administrative compliance lead.',
        ];
    }

    a.aiExplanation = {
      summary,
      riskFactor: a.severity,
      recommendedAction: 'Proceed with human administrative review and complete the 3 verification checkpoints before concluding case.',
      verificationCheckpoints: checkpoints,
      generatedAt: new Date().toISOString(),
      modelUsed: 'rule-grounded-engine',
    };
    this.anomalies.set(anomalyId, a);
    return a;
  }

  // --- Rule-Based Anomaly Detection Engine ---
  public runAnomalyDetectionRules(): { detected: AnomalyRecord[]; totalActive: number } {
    const rules = this.appConfig.anomalyRuleConfig.rules.filter((r) => r.isEnabled);
    const newlyDetected: AnomalyRecord[] = [];

    for (const rule of rules) {
      switch (rule.ruleKey) {
        // 1. Unusual Weight Differences
        case 'UNUSUAL_WEIGHT_DIFFERENCE':
        case 'WEIGHT_MISMATCH_SURGE': {
          for (const lot of this.lots.values()) {
            const declared = lot.declaredWeightKg || 0;
            const actual = lot.actualWeightKg || lot.totalWeightKg || 0;
            if (declared > 0 && actual > 0) {
              const deltaKg = actual - declared;
              const variancePercent = Math.abs((deltaKg / declared) * 100);
              if (variancePercent >= rule.thresholdValue) {
                const existing = Array.from(this.anomalies.values()).find(
                  (a) => a.entityId === lot.id && (a.ruleKey === rule.ruleKey || a.ruleKey === 'UNUSUAL_WEIGHT_DIFFERENCE')
                );
                if (!existing) {
                  const id = `anm-rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
                  const anomaly: AnomalyRecord = {
                    id,
                    type: 'UNUSUAL_WEIGHT_DIFFERENCE',
                    ruleKey: 'UNUSUAL_WEIGHT_DIFFERENCE',
                    ruleId: rule.ruleKey,
                    ruleName: rule.name,
                    title: 'Weight Discrepancy Exceeds Configured Threshold',
                    entityType: 'LOT',
                    entityId: lot.id,
                    entityTrackingCode: lot.lotNumber || lot.batchQrCode || '',
                    severity: rule.defaultSeverity,
                    status: 'NEW',
                    description: `Lot measured weight (${actual.toFixed(1)}kg) deviates by ${variancePercent.toFixed(1)}% from declared input (${declared.toFixed(1)}kg).`,
                    whatHappened: `Weighbridge recorded ${actual.toFixed(1)} kg for lot ${lot.lotNumber || lot.batchQrCode}, compared to declared total of ${declared.toFixed(1)} kg.`,
                    whyFlagged: `Measured weight variance of ${Math.abs(deltaKg).toFixed(1)} kg (${variancePercent.toFixed(1)}%) exceeded configured threshold of ${rule.thresholdValue}%.`,
                    whichRule: `${rule.name} (${rule.ruleKey})`,
                    detectedAt: new Date().toISOString(),
                    evidence: {
                      declaredWeightKg: declared,
                      weighbridgeWeightKg: actual,
                      discrepancyKg: Number(deltaKg.toFixed(1)),
                      variancePercent: Number(variancePercent.toFixed(2)),
                      thresholdPercent: rule.thresholdValue,
                      facilityId: lot.aggregatorId,
                    },
                    metrics: { declaredKg: declared, actualKg: actual, variancePercent: Number(variancePercent.toFixed(2)) },
                  };
                  this.anomalies.set(id, anomaly);
                  newlyDetected.push(anomaly);
                }
              }
            }
          }
          break;
        }

        // 2. Duplicate Lot Behavior
        case 'DUPLICATE_LOT_BEHAVIOR': {
          const windowMs = rule.thresholdValue * 3600 * 1000;
          const lotList = Array.from(this.lots.values());
          for (let i = 0; i < lotList.length; i++) {
            for (let j = i + 1; j < lotList.length; j++) {
              const l1 = lotList[i];
              const l2 = lotList[j];
              if (
                l1.aggregatorId === l2.aggregatorId &&
                l1.materialId === l2.materialId &&
                Math.abs(l1.totalWeightKg - l2.totalWeightKg) < 0.5
              ) {
                const timeDiff = Math.abs(new Date(l1.createdAt).getTime() - new Date(l2.createdAt).getTime());
                if (timeDiff <= windowMs) {
                  const existing = Array.from(this.anomalies.values()).find(
                    (a) => (a.entityId === l1.id || a.entityId === l2.id) && a.ruleKey === 'DUPLICATE_LOT_BEHAVIOR'
                  );
                  if (!existing) {
                    const id = `anm-rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
                    const anomaly: AnomalyRecord = {
                      id,
                      type: 'DUPLICATE_LOT_BEHAVIOR',
                      ruleKey: 'DUPLICATE_LOT_BEHAVIOR',
                      ruleId: rule.ruleKey,
                      ruleName: rule.name,
                      title: 'Duplicate Lot Characteristics Ingested',
                      entityType: 'LOT',
                      entityId: l2.id,
                      entityTrackingCode: l2.lotNumber || l2.batchQrCode || '',
                      severity: rule.defaultSeverity,
                      status: 'NEW',
                      description: `Two consecutive lots created with identical weight (${l1.totalWeightKg}kg) and material (${l1.materialId}) within ${(timeDiff / 60000).toFixed(0)} minutes.`,
                      whatHappened: `Aggregator facility logged two separate lots with identical material and mass within ${(timeDiff / 60000).toFixed(0)} minutes.`,
                      whyFlagged: `Matching lot characteristics logged within the configured ${rule.thresholdValue}-hour monitoring window.`,
                      whichRule: `${rule.name} (${rule.ruleKey})`,
                      detectedAt: new Date().toISOString(),
                      evidence: {
                        primaryLotId: l1.id,
                        relatedLotId: l2.id,
                        weightKg: l1.totalWeightKg,
                        intervalMinutes: Number((timeDiff / 60000).toFixed(0)),
                        aggregatorId: l1.aggregatorId,
                      },
                      metrics: { weightKg: l1.totalWeightKg, intervalMinutes: Number((timeDiff / 60000).toFixed(0)) },
                    };
                    this.anomalies.set(id, anomaly);
                    newlyDetected.push(anomaly);
                  }
                }
              }
            }
          }
          break;
        }

        // 3. Repeated Pickup Cancellations
        case 'REPEATED_PICKUP_CANCELLATIONS': {
          const userCancellations = new Map<string, string[]>();
          for (const p of this.pickups.values()) {
            if (p.status === 'CANCELLED') {
              const uid = p.collectorId || p.aggregatorId || p.id;
              const list = userCancellations.get(uid) || [];
              list.push(p.id);
              userCancellations.set(uid, list);
            }
          }

          userCancellations.forEach((pickupIds, userId) => {
            if (pickupIds.length >= rule.thresholdValue) {
              const existing = Array.from(this.anomalies.values()).find(
                (a) => a.entityId === userId && a.ruleKey === 'REPEATED_PICKUP_CANCELLATIONS'
              );
              if (!existing) {
                const id = `anm-rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
                const anomaly: AnomalyRecord = {
                  id,
                  type: 'REPEATED_PICKUP_CANCELLATIONS',
                  ruleKey: 'REPEATED_PICKUP_CANCELLATIONS',
                  ruleId: rule.ruleKey,
                  ruleName: rule.name,
                  title: 'Multiple Pickup Cancellations Within Rolling Window',
                  entityType: 'USER',
                  entityId: userId,
                  severity: rule.defaultSeverity,
                  status: 'NEW',
                  description: `User recorded ${pickupIds.length} pickup cancellations in recent operational ledger.`,
                  whatHappened: `Multiple pickup assignments were cancelled after driver dispatch.`,
                  whyFlagged: `Cancellation count (${pickupIds.length}) reached or exceeded configured threshold of ${rule.thresholdValue}.`,
                  whichRule: `${rule.name} (${rule.ruleKey})`,
                  detectedAt: new Date().toISOString(),
                  evidence: {
                    cancellationsCount: pickupIds.length,
                    threshold: rule.thresholdValue,
                    pickupIds,
                  },
                  metrics: { cancellationsCount: pickupIds.length, threshold: rule.thresholdValue },
                };
                this.anomalies.set(id, anomaly);
                newlyDetected.push(anomaly);
              }
            }
          });
          break;
        }

        // 4. Unusual Pricing
        case 'UNUSUAL_PRICING':
        case 'PRICE_CEILING_BREACH': {
          for (const pay of this.payments.values()) {
            if (pay.relatedEntityType === 'LOT' && pay.relatedEntityId) {
              const lot = this.lots.get(pay.relatedEntityId);
              if (lot && lot.totalWeightKg > 0) {
                const effectiveRate = pay.amount / lot.totalWeightKg;
                const mat = this.materials.get(lot.materialId);
                const baseRate = mat?.standardPricePerKg || 25.0;
                const devPercent = ((effectiveRate - baseRate) / baseRate) * 100;
                if (Math.abs(devPercent) >= rule.thresholdValue) {
                  const existing = Array.from(this.anomalies.values()).find(
                    (a) => a.entityId === pay.id && (a.ruleKey === 'UNUSUAL_PRICING' || a.ruleKey === 'PRICE_CEILING_BREACH')
                  );
                  if (!existing) {
                    const id = `anm-rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
                    const anomaly: AnomalyRecord = {
                      id,
                      type: 'UNUSUAL_PRICING',
                      ruleKey: 'UNUSUAL_PRICING',
                      ruleId: rule.ruleKey,
                      ruleName: rule.name,
                      title: 'Payout Rate Deviates from Market Catalog Benchmark',
                      entityType: 'PAYMENT',
                      entityId: pay.id,
                      entityTrackingCode: pay.transactionId || pay.upiRefNumber || '',
                      severity: rule.defaultSeverity,
                      status: 'NEW',
                      description: `Effective rate of ₹${effectiveRate.toFixed(2)}/kg deviates by ${devPercent.toFixed(1)}% from benchmark ₹${baseRate.toFixed(2)}/kg.`,
                      whatHappened: `Payout issued at ₹${effectiveRate.toFixed(2)}/kg, compared to benchmark rate of ₹${baseRate.toFixed(2)}/kg.`,
                      whyFlagged: `Pricing deviation of ${Math.abs(devPercent).toFixed(1)}% exceeded configured threshold of ${rule.thresholdValue}%.`,
                      whichRule: `${rule.name} (${rule.ruleKey})`,
                      detectedAt: new Date().toISOString(),
                      evidence: {
                        effectiveRatePerKg: Number(effectiveRate.toFixed(2)),
                        benchmarkRatePerKg: baseRate,
                        variancePercent: Number(devPercent.toFixed(2)),
                        thresholdPercent: rule.thresholdValue,
                        paymentAmountInr: pay.amount,
                      },
                      metrics: { effectiveRate: Number(effectiveRate.toFixed(2)), benchmarkRate: baseRate, variancePercent: Number(devPercent.toFixed(2)) },
                    };
                    this.anomalies.set(id, anomaly);
                    newlyDetected.push(anomaly);
                  }
                }
              }
            }
          }
          break;
        }

        // 5. Multiple Accounts with Suspicious Activity
        case 'MULTIPLE_ACCOUNTS_SUSPICIOUS_ACTIVITY': {
          const upiMap = new Map<string, string[]>();
          for (const u of this.users.values()) {
            if ((u as any).bankDetails?.upiId) {
              const upi = (u as any).bankDetails.upiId.trim().toLowerCase();
              const list = upiMap.get(upi) || [];
              list.push(`${u.id} (${u.role})`);
              upiMap.set(upi, list);
            }
          }

          upiMap.forEach((userList, upi) => {
            if (userList.length > 1) {
              const existing = Array.from(this.anomalies.values()).find(
                (a) => a.ruleKey === 'MULTIPLE_ACCOUNTS_SUSPICIOUS_ACTIVITY' && a.evidence?.sharedValue === upi
              );
              if (!existing) {
                const id = `anm-rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
                const anomaly: AnomalyRecord = {
                  id,
                  type: 'MULTIPLE_ACCOUNTS_SUSPICIOUS_ACTIVITY',
                  ruleKey: 'MULTIPLE_ACCOUNTS_SUSPICIOUS_ACTIVITY',
                  ruleId: rule.ruleKey,
                  ruleName: rule.name,
                  title: 'Shared Financial Identifier Across Distinct Entities',
                  entityType: 'USER',
                  entityId: userList[0].split(' ')[0],
                  severity: rule.defaultSeverity,
                  status: 'NEW',
                  description: `UPI identifier '${upi}' is shared across multiple user accounts (${userList.join(', ')}).`,
                  whatHappened: `Multiple supply chain participants are configured to receive funds to the exact same settlement account.`,
                  whyFlagged: `Detected common banking credential shared across ${userList.length} distinct system entity profiles.`,
                  whichRule: `${rule.name} (${rule.ruleKey})`,
                  detectedAt: new Date().toISOString(),
                  evidence: {
                    sharedIdentifierType: 'UPI_VPA',
                    sharedValue: upi,
                    entities: userList,
                    count: userList.length,
                  },
                  metrics: { sharedValue: upi, entityCount: userList.length },
                };
                this.anomalies.set(id, anomaly);
                newlyDetected.push(anomaly);
              }
            }
          });
          break;
        }

        // 6. Unusual Pickup Patterns (off-hours or velocity spike)
        case 'UNUSUAL_PICKUP_PATTERNS':
        case 'RAPID_CONSECUTIVE_PICKUPS': {
          for (const p of this.pickups.values()) {
            if (p.status === 'COMPLETED' && p.createdAt) {
              const d = new Date(p.createdAt);
              const hour = d.getUTCHours(); // Note: 22-5 UTC or local
              if (hour >= 18 || hour <= 1) { // Corresponds to late night hours
                const existing = Array.from(this.anomalies.values()).find(
                  (a) => a.entityId === p.id && a.ruleKey === 'UNUSUAL_PICKUP_PATTERNS'
                );
                if (!existing) {
                  const id = `anm-rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
                  const anomaly: AnomalyRecord = {
                    id,
                    type: 'UNUSUAL_PICKUP_PATTERNS',
                    ruleKey: 'UNUSUAL_PICKUP_PATTERNS',
                    ruleId: rule.ruleKey,
                    ruleName: rule.name,
                    title: 'Material Collection Recorded Outside Normal Operating Hours',
                    entityType: 'PICKUP',
                    entityId: p.id,
                    entityTrackingCode: p.trackingCode || p.id,
                    severity: rule.defaultSeverity,
                    status: 'NEW',
                    description: `Pickup completion was recorded during non-standard nighttime hours.`,
                    whatHappened: `Weighment timestamp for pickup ${p.trackingCode || p.id} was logged at night.`,
                    whyFlagged: `Operation logged outside standard daytime operating window.`,
                    whichRule: `${rule.name} (${rule.ruleKey})`,
                    detectedAt: new Date().toISOString(),
                    evidence: {
                      pickupId: p.id,
                      timestamp: p.createdAt,
                      collectorId: p.collectorId,
                    },
                    metrics: { pickupId: p.id, timestamp: p.createdAt },
                  };
                  this.anomalies.set(id, anomaly);
                  newlyDetected.push(anomaly);
                }
              }
            }
          }
          break;
        }

        // 7. Repeated Failed Handovers
        case 'REPEATED_FAILED_HANDOVERS': {
          // Detect pickups or lots with multiple discrepancy/issue events in traceability
          const failedCounts = new Map<string, number>();
          for (const t of this.traceability.values()) {
            if (t.eventType === 'DISPUTE_RAISED' || t.eventType === 'WEIGHT_RECONCILED' || (t.details && t.details.status === 'FAILED')) {
              const eid = t.entityId;
              failedCounts.set(eid, (failedCounts.get(eid) || 0) + 1);
            }
          }
          failedCounts.forEach((count, entityId) => {
            if (count >= rule.thresholdValue) {
              const existing = Array.from(this.anomalies.values()).find(
                (a) => a.entityId === entityId && a.ruleKey === 'REPEATED_FAILED_HANDOVERS'
              );
              if (!existing) {
                const id = `anm-rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
                const anomaly: AnomalyRecord = {
                  id,
                  type: 'REPEATED_FAILED_HANDOVERS',
                  ruleKey: 'REPEATED_FAILED_HANDOVERS',
                  ruleId: rule.ruleKey,
                  ruleName: rule.name,
                  title: 'Repeated Handover Exceptions Recorded',
                  entityType: entityId.startsWith('lot') ? 'LOT' : 'PICKUP',
                  entityId,
                  severity: rule.defaultSeverity,
                  status: 'NEW',
                  description: `Entity recorded ${count} verification exceptions or dock disputes.`,
                  whatHappened: `Handover verification failed ${count} times during transit or receiving.`,
                  whyFlagged: `Exception count (${count}) met or exceeded threshold of ${rule.thresholdValue}.`,
                  whichRule: `${rule.name} (${rule.ruleKey})`,
                  detectedAt: new Date().toISOString(),
                  evidence: {
                    exceptionCount: count,
                    threshold: rule.thresholdValue,
                  },
                  metrics: { exceptionCount: count, threshold: rule.thresholdValue },
                };
                this.anomalies.set(id, anomaly);
                newlyDetected.push(anomaly);
              }
            }
          });
          break;
        }

        // 8. Excessive Status Changes
        case 'EXCESSIVE_STATUS_CHANGES': {
          const entityEvents = new Map<string, number>();
          for (const t of this.traceability.values()) {
            entityEvents.set(t.entityId, (entityEvents.get(t.entityId) || 0) + 1);
          }
          entityEvents.forEach((count, entityId) => {
            if (count >= rule.thresholdValue) {
              const existing = Array.from(this.anomalies.values()).find(
                (a) => a.entityId === entityId && a.ruleKey === 'EXCESSIVE_STATUS_CHANGES'
              );
              if (!existing) {
                const id = `anm-rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
                const anomaly: AnomalyRecord = {
                  id,
                  type: 'EXCESSIVE_STATUS_CHANGES',
                  ruleKey: 'EXCESSIVE_STATUS_CHANGES',
                  ruleId: rule.ruleKey,
                  ruleName: rule.name,
                  title: 'Rapid Entity Lifecycle Transitions Detected',
                  entityType: entityId.startsWith('lot') ? 'LOT' : 'PICKUP',
                  entityId,
                  severity: rule.defaultSeverity,
                  status: 'NEW',
                  description: `Entity experienced ${count} sequential status mutations in traceability ledger.`,
                  whatHappened: `Traceability log recorded rapid successive state changes for entity ${entityId}.`,
                  whyFlagged: `Transition count (${count}) met or exceeded threshold of ${rule.thresholdValue}.`,
                  whichRule: `${rule.name} (${rule.ruleKey})`,
                  detectedAt: new Date().toISOString(),
                  evidence: { transitionCount: count, threshold: rule.thresholdValue },
                  metrics: { transitionCount: count },
                };
                this.anomalies.set(id, anomaly);
                newlyDetected.push(anomaly);
              }
            }
          });
          break;
        }

        // 9. Contamination Surge
        case 'CONTAMINATION_SURGE': {
          for (const lot of this.lots.values()) {
            const contamination = (lot as any).contaminationPercent || (lot.qualityGrade === 'GRADE_C' ? 14.5 : 0);
            if (contamination >= rule.thresholdValue) {
              const existing = Array.from(this.anomalies.values()).find(
                (a) => a.entityId === lot.id && a.ruleKey === 'CONTAMINATION_SURGE'
              );
              if (!existing) {
                const id = `anm-rule-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
                const anomaly: AnomalyRecord = {
                  id,
                  type: 'CONTAMINATION_SURGE',
                  ruleKey: 'CONTAMINATION_SURGE',
                  ruleId: rule.ruleKey,
                  ruleName: rule.name,
                  title: 'Dock Moisture & Contamination Spike',
                  entityType: 'LOT',
                  entityId: lot.id,
                  entityTrackingCode: lot.lotNumber || lot.batchQrCode || '',
                  severity: rule.defaultSeverity,
                  status: 'NEW',
                  description: `Measured contamination of ${contamination}% exceeds allowable tolerance of ${rule.thresholdValue}%.`,
                  whatHappened: `Receiving dock recorded contamination rate of ${contamination}% for lot ${lot.lotNumber || lot.batchQrCode}.`,
                  whyFlagged: `Contamination exceeded grade threshold limit of ${rule.thresholdValue}%.`,
                  whichRule: `${rule.name} (${rule.ruleKey})`,
                  detectedAt: new Date().toISOString(),
                  evidence: { contaminationPercent: contamination, thresholdPercent: rule.thresholdValue },
                  metrics: { contaminationPercent: contamination, thresholdPercent: rule.thresholdValue },
                };
                this.anomalies.set(id, anomaly);
                newlyDetected.push(anomaly);
              }
            }
          }
          break;
        }
      }
    }

    const totalActive = Array.from(this.anomalies.values()).filter(
      (a) => a.status === 'NEW' || a.status === 'UNDER_REVIEW' || a.status === 'DETECTED'
    ).length;

    this.invalidateAnalyticsCache();
    return { detected: newlyDetected, totalActive };
  }

  // --- Audit Logs ---


  private paginateHelper<T>(list: T[], params: PaginationParams): PaginatedResult<T> {
    const startIndex = (params.page - 1) * params.limit;
    const paginated = list.slice(startIndex, startIndex + params.limit);
    return {
      data: paginated,
      total: list.length,
      page: params.page,
      limit: params.limit,
      totalPages: Math.ceil(list.length / params.limit),
    };
  }

  public queryAiActivity(params: PaginationParams): PaginatedResult<AiActivity> {
    const list = [...this.aiActivity].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return this.paginateHelper(list, params);
  }

  public queryIvrActivity(params: PaginationParams): PaginatedResult<IvrActivity> {
    const list = [...this.ivrActivity].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return this.paginateHelper(list, params);
  }

  public querySystemNotifications(params: PaginationParams): PaginatedResult<SystemNotification> {
    const list = [...this.systemNotifications].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return this.paginateHelper(list, params);
  }

  public querySystemConfigs(): SystemConfig[] {
    return Array.from(this.systemConfigs.values());
  }

  public getSystemConfig(key: string): SystemConfig | undefined {
    return this.systemConfigs.get(key);
  }

  public updateSystemConfig(key: string, value: any, adminId: string): SystemConfig {
    const existing = this.systemConfigs.get(key);
    if (!existing) throw new Error('Config not found');
    const updated = { ...existing, value, updatedAt: new Date().toISOString(), updatedBy: adminId };
    this.systemConfigs.set(key, updated);
    this.recordAuditLog({
      actorId: adminId,
      actorName: 'Admin User',
      actorRole: 'ADMIN',
      action: 'UPDATE_CONFIG',
      targetResource: key,
      details: 'Updated system configuration',
      entity: 'CONFIG',
      entityId: key,
      result: 'SUCCESS'
    });
    return updated;
  }

  public queryAuditLogs(params: PaginationParams): PaginatedResult<AuditLog> {
    let list = [...this.auditLogs].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    if (params.search) {
      const q = params.search.toLowerCase();
      list = list.filter(
        (l) =>
          l.action.toLowerCase().includes(q) ||
          l.actorName.toLowerCase().includes(q) ||
          l.targetResource.toLowerCase().includes(q) ||
          l.details.toLowerCase().includes(q)
      );
    }

    const total = list.length;
    const page = Math.max(1, params.page || 1);
    const limit = Math.max(1, Math.min(100, params.limit || 10));
    const totalPages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const data = list.slice(startIndex, startIndex + limit);

    return { data, total, page, limit, totalPages };
  }

  public recordAuditLog(log: Omit<AuditLog, 'id' | 'timestamp'>): AuditLog {
    const entry: AuditLog = {
      ...log,
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      result: log.result || 'SUCCESS',
      entity: log.entity || log.targetResource.split('/')[0] || 'Resource',
      entityId: log.entityId || log.targetResource.split('/')[1] || '',
      metadata: log.metadata || {},
    };
    this.auditLogs.unshift(entry);
    return entry;
  }

  // --- Configuration ---
  public getAppConfig(): AppConfiguration {
    return this.appConfig;
  }

  public updateAppConfig(section: keyof AppConfiguration, patch: any): AppConfiguration {
    (this.appConfig as any)[section] = {
      ...(this.appConfig as any)[section],
      ...patch,
    };
    return this.appConfig;
  }

  // --- Dynamic Dashboard Stats (Calculated on the fly from backend database) ---
  
  
  public async generateStateAnalyticsReport(): Promise<string> {
    const states = this.getStateAnalytics();
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is missing');
    }
    const ai = new GoogleGenAI({ apiKey });
    const prompt = `
      You are an expert Data Analyst and Operations Director for RECYSETU, a national e-waste recycling platform in India.
      Generate a professional, structured Executive Progress Report based strictly on the following state-wise analytics data.

      DATA:
      ${JSON.stringify(states, null, 2)}

      Requirements:
      - Include an Executive Summary.
      - Detail the Geographic Coverage (active states vs coming soon).
      - Detail the Stakeholder Network (Total Collectors, Aggregators, Recyclers).
      - Detail Collection Performance & Environmental Impact (Waste collected, processed, recycled in kg or Tonnes).
      - Highlight Areas Requiring Attention if any.
      - Do NOT hallucinate data, numbers, or percentages not provided in the data. If data is zero, state it.
      - Do not include financial data if it is not in the JSON.
      - Format as clean Markdown.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    if (response.text) {
      return response.text;
    } else {
      throw new Error('Failed to generate report text');
    }
  }

  public getStateAnalytics() {
    const allUsers = Array.from(this.users.values());
    const allLots = Array.from(this.lots.values());
    const allPickups = Array.from(this.pickups.values());

    const statesMap = new Map<string, any>();

    // We'll define states we care about.
    // Chhattisgarh is active, others inactive.
    const predefinedStates = [
      { name: 'Chhattisgarh', status: 'ACTIVE' },
      { name: 'Maharashtra', status: 'COMING_SOON' },
      { name: 'Karnataka', status: 'COMING_SOON' },
      { name: 'Delhi', status: 'COMING_SOON' },
      { name: 'Gujarat', status: 'COMING_SOON' },
      { name: 'Tamil Nadu', status: 'COMING_SOON' },
    ];

    predefinedStates.forEach(s => {
      statesMap.set(s.name, {
        state: s.name,
        status: s.status,
        collectors: 0,
        aggregators: 0,
        recyclers: 0,
        totalStakeholders: 0,
        wasteCollectedKg: 0,
        wasteProcessedKg: 0,
        wasteRecycledKg: 0,
        districts: {}
      });
    });

    // We map real data to Chhattisgarh (and possibly Durg)
    const chhattisgarh = statesMap.get('Chhattisgarh');
    chhattisgarh.districts['Durg'] = {
      district: 'Durg',
      status: 'ACTIVE',
      collectors: 0,
      aggregators: 0,
      recyclers: 0,
      totalStakeholders: 0,
      wasteCollectedKg: 0,
      wasteProcessedKg: 0,
      wasteRecycledKg: 0,
    };

    const durg = chhattisgarh.districts['Durg'];

    allUsers.forEach(u => {
      // In this demo, all users are mapped to Chhattisgarh / Durg
      if (u.role === 'COLLECTOR') {
        chhattisgarh.collectors++;
        durg.collectors++;
      }
      if (u.role === 'AGGREGATOR') {
        chhattisgarh.aggregators++;
        durg.aggregators++;
      }
      if (u.role === 'RECYCLER') {
        chhattisgarh.recyclers++;
        durg.recyclers++;
      }
    });

    chhattisgarh.totalStakeholders = chhattisgarh.collectors + chhattisgarh.aggregators + chhattisgarh.recyclers;
    durg.totalStakeholders = durg.collectors + durg.aggregators + durg.recyclers;

    allPickups.forEach(p => {
      // Collected
      chhattisgarh.wasteCollectedKg += (p.quantityKg || p.actualWeightKg || 0);
      durg.wasteCollectedKg += (p.quantityKg || p.actualWeightKg || 0);
    });

    allLots.forEach(l => {
      if (l.status === 'PROCESSED') {
        chhattisgarh.wasteRecycledKg += (l.totalWeightKg || 0);
        durg.wasteRecycledKg += (l.totalWeightKg || 0);
      }
      if (l.status === 'IN_TRANSIT' || l.status === 'RECEIVED' || l.status === 'FORMED') {
        chhattisgarh.wasteProcessedKg += (l.totalWeightKg || 0);
        durg.wasteProcessedKg += (l.totalWeightKg || 0);
      }
    });

    return Array.from(statesMap.values());
  }

  public getDashboardStats(options: { range?: string; startDate?: string; endDate?: string } = {}) {
    const range = options.range || '7d';
    const allUsers = Array.from(this.users.values());
    const allPickups = Array.from(this.pickups.values());
    const allLots = Array.from(this.lots.values());
    const allPayments = Array.from(this.payments.values());
    const allComplaints = Array.from(this.complaints.values());
    const allAnomalies = Array.from(this.anomalies.values());
    const allTraceability = Array.from(this.traceability.values());
    const allAuditLogs = [...this.auditLogs];

    // Determine range start/end timestamps
    const now = new Date('2026-09-14T12:00:00.000Z').getTime();
    let rangeStart = 0;
    let rangeEnd = Infinity;
    let effectiveLabel = 'Past 7 Days';

    if (range === 'today') {
      rangeStart = new Date('2026-09-14T00:00:00.000Z').getTime();
      rangeEnd = now;
      effectiveLabel = 'Today (Sept 14)';
    } else if (range === '7d') {
      rangeStart = now - 7 * 24 * 60 * 60 * 1000;
      rangeEnd = now;
      effectiveLabel = 'Past 7 Days';
    } else if (range === '30d') {
      rangeStart = now - 30 * 24 * 60 * 60 * 1000;
      rangeEnd = now;
      effectiveLabel = 'Past 30 Days';
    } else if (range === '90d') {
      rangeStart = now - 90 * 24 * 60 * 60 * 1000;
      rangeEnd = now;
      effectiveLabel = 'Past 90 Days';
    } else if (range === 'custom' && options.startDate) {
      rangeStart = new Date(options.startDate).getTime() || 0;
      rangeEnd = options.endDate ? new Date(options.endDate).getTime() : now;
      effectiveLabel = `${options.startDate} to ${options.endDate || 'Now'}`;
    }

    // --- APPLY DATE FILTERS TO ARRAYS ---
    const isWithinRange = (dateStr?: string) => {
      if (!dateStr) return false;
      const t = new Date(dateStr).getTime();
      return t >= rangeStart && t <= rangeEnd;
    };

    const periodPickups = allPickups.filter(p => isWithinRange(p.scheduledAt || p.createdAt));
    const periodLots = allLots.filter(l => isWithinRange(l.createdAt));
    const periodPayments = allPayments.filter(p => isWithinRange(p.createdAt || p.timestamp));
    const periodComplaints = allComplaints.filter(c => isWithinRange(c.createdAt));
    
    // PRIMARY KPI COUNTS:
    const totalCollectors = allUsers.filter((u) => u.role === 'COLLECTOR').length;
    const totalAggregators = allUsers.filter((u) => u.role === 'AGGREGATOR').length;
    const totalRecyclers = allUsers.filter((u) => u.role === 'RECYCLER').length;
    const activeWorkersCount = allUsers.filter((u) => u.role === 'COLLECTOR' && u.status === 'ACTIVE').length;

    // Lots metrics
    const activeLots = allLots.filter((l) => l.status === 'FORMED' || l.status === 'IN_TRANSIT' || l.status === 'RECEIVED').length;
    const processingLots = allLots.filter((l) => l.status === 'IN_TRANSIT').length;
    const handedOverLots = allLots.filter((l) => l.status === 'RECEIVED').length;
    const recycledLots = allLots.filter((l) => l.status === 'PROCESSED').length;

    // Pickups metrics
    const pendingPickups = periodPickups.filter((p) => p.status === 'REQUESTED' || p.status === 'ASSIGNED').length;
    const completedPickups = periodPickups.filter((p) => p.status === 'COLLECTED' || p.status === 'AGGREGATED' || p.status === 'DELIVERED').length;

    // Tonnage
    const totalCollectedKg = periodPickups.reduce((sum, p) => sum + (p.quantityKg || 0), 0);
    const materialCollectedTons = Number((totalCollectedKg / 1000).toFixed(2));

    const totalRecycledKg = periodLots
      .filter((l) => l.status === 'PROCESSED')
      .reduce((sum, l) => sum + (l.totalWeightKg || 0), 0);
    const recyclingCompletedTons = Number((totalRecycledKg / 1000).toFixed(2));

    const totalLotWeightKg = allLots.reduce((sum, l) => sum + (l.totalWeightKg || 0), 0);
    const totalLotWeightTons = Number((totalLotWeightKg / 1000).toFixed(2));

    // Payments metrics
    const pendingPaymentsList = allPayments.filter((p) => p.status === 'PENDING' || p.status === 'FLAGGED');
    const pendingPaymentsCount = pendingPaymentsList.length;
    const pendingPaymentsAmountInr = pendingPaymentsList.reduce((sum, p) => sum + (p.amount || 0), 0);

    const prevRangeStart = rangeStart - (rangeEnd - rangeStart);
    const previousDisbursedInr = allPayments
      .filter((p) => p.status === 'COMPLETED' && new Date(p.createdAt || p.timestamp).getTime() >= prevRangeStart && new Date(p.createdAt || p.timestamp).getTime() < rangeStart)
      .reduce((sum, p) => sum + (p.amount || 0), 0);

    const totalDisbursedInr = periodPayments
      .filter((p) => p.status === 'COMPLETED')
      .reduce((sum, p) => sum + (p.amount || 0), 0);

    // Complaints & Anomalies
    const openComplaintsCount = allComplaints.filter((c) => c.status === 'OPEN' || c.status === 'IN_INVESTIGATION').length;
    const activeAnomaliesCount = allAnomalies.filter((a) => a.status === 'DETECTED' || a.status === 'UNDER_REVIEW').length;
    const criticalAnomaliesCount = allAnomalies.filter((a) => a.severity === 'CRITICAL' && a.status !== 'RESOLVED').length;

    // Flagged lots (lots rejected or linked to an active anomaly)
    const anomalyLotIds = new Set(
      allAnomalies
        .filter((a) => a.entityType === 'LOT' && a.status !== 'RESOLVED' && a.status !== 'FALSE_POSITIVE')
        .map((a) => a.entityId)
    );
    const flaggedLotsCount = allLots.filter((l) => l.status === 'REJECTED' || anomalyLotIds.has(l.id)).length;

    // Disputed lots
    const disputedLotsCount = allLots.filter((l) => {
      const hasComplaint = allComplaints.some(
        (c) => c.status !== 'RESOLVED' && c.description.toLowerCase().includes(l.lotNumber.toLowerCase())
      );
      const hasAnomaly = anomalyLotIds.has(l.id);
      return hasComplaint || hasAnomaly;
    }).length;

    // CO2 offset and Traceability integrity
    const estimatedCo2OffsetTons = Number(((totalCollectedKg * 2.1) / 1000).toFixed(2));
    const verifiedEventsCount = allTraceability.filter((e) => e.verifiedOnChain).length;
    const integrityPercent = allTraceability.length > 0
      ? Number(((verifiedEventsCount / allTraceability.length) * 100).toFixed(1))
      : 100;

    // PICKUP OVERVIEW (Counts for all domain and requested statuses)
    const pickupStatusCounts = {
      REQUESTED: periodPickups.filter((p) => p.status === 'REQUESTED').length,
      ASSIGNED: allPickups.filter((p) => p.status === 'ASSIGNED').length,
      ACCEPTED: allPickups.filter((p) => p.status === 'ASSIGNED').length,
      SCHEDULED: allPickups.filter((p) => p.status === 'ASSIGNED').length,
      COLLECTOR_READY: allPickups.filter((p) => p.status === 'ASSIGNED').length,
      PICKED_UP: periodPickups.filter((p) => p.status === 'COLLECTED').length,
      AGGREGATED: allPickups.filter((p) => p.status === 'AGGREGATED').length,
      CANCELLED: allPickups.filter((p) => p.status === 'CANCELLED').length,
      COMPLETED: allPickups.filter((p) => p.status === 'DELIVERED' || p.status === 'AGGREGATED').length,
      total: allPickups.length,
    };

    // LOT OVERVIEW
    const lotOverview = {
      activeLots,
      processingLots,
      handedOverLots,
      recycledLots,
      flaggedLots: flaggedLotsCount,
      disputedLots: disputedLotsCount,
      totalLots: allLots.length,
      totalWeightKg: totalLotWeightKg,
      totalWeightTons: totalLotWeightTons,
      recentLots: allLots.slice(0, 5),
    };

    // MATERIAL OVERVIEW (Config driven)
    const matConfig = this.appConfig.materialConfig;
    const categoryConfigMap = new Map(matConfig.materials.map((m) => [m.category, m]));

    const materialCategoriesSummary = matConfig.activeCategories.map((cat) => {
      const configItem = categoryConfigMap.get(cat);
      const pickupsForCat = allPickups.filter((p) => p.category === cat);
      const lotsForCat = allLots.filter((l) => l.category === cat);
      const processedLotsForCat = lotsForCat.filter((l) => l.status === 'PROCESSED');

      const collectedKg = pickupsForCat.reduce((sum, p) => sum + (p.quantityKg || 0), 0);
      const processedKg = lotsForCat.reduce((sum, l) => sum + (l.totalWeightKg || 0), 0);
      const recycledKg = processedLotsForCat.reduce((sum, l) => sum + (l.totalWeightKg || 0), 0);

      const ratePerKg = configItem?.standardBasePrice || 25.0;
      const estimatedValueInr = pickupsForCat.reduce(
        (sum, p) => sum + (p.totalPrice || p.quantityKg * ratePerKg),
        0
      );

      const co2Factor = configItem?.co2Factor || 2.0;
      const co2OffsetKg = Number((collectedKg * co2Factor).toFixed(1));
      const sharePercent = totalCollectedKg > 0 ? Number(((collectedKg / totalCollectedKg) * 100).toFixed(1)) : 0;

      const friendlyNames: Record<string, string> = {
        PLASTIC: 'Recycled Polymers & Rigid PET/HDPE',
        METAL: 'Scrap Metals, Aluminium & Non-Ferrous',
        PAPER: 'Old Corrugated Cardboard & Mixed Pulp',
        E_WASTE: 'Consumer Electronics & Circuit Boards',
        GLASS: 'Cullet Bottles & Industrial Glass',
        ORGANIC: 'Compostable Organic & Biomass',
      };

      return {
        category: cat,
        name: friendlyNames[cat] || `${cat} Materials`,
        collectedKg: Math.round(collectedKg),
        collectedTons: Number((collectedKg / 1000).toFixed(2)),
        processedKg: Math.round(processedKg),
        recycledKg: Math.round(recycledKg),
        estimatedValueInr: Math.round(estimatedValueInr),
        co2OffsetKg,
        co2OffsetTons: Number((co2OffsetKg / 1000).toFixed(2)),
        sharePercent,
        ratePerKg,
        pickupsCount: pickupsForCat.length,
      };
    });

    const totalEstimatedValueInr = materialCategoriesSummary.reduce((sum, c) => sum + c.estimatedValueInr, 0);

    // REGIONAL ACTIVITY (Aggregated by city/state safely without exposing personal PII)
    const regionalMap = new Map<
      string,
      {
        city: string;
        state: string;
        wards: Set<string>;
        totalPickups: number;
        totalVolumeKg: number;
        activeCollectors: Set<string>;
        aggregators: Set<string>;
        recyclers: Set<string>;
        disbursedInr: number;
      }
    >();

    allUsers.forEach((u) => {
      if (!u.location?.city) return;
      const key = `${u.location.city}, ${u.location.state || 'India'}`;
      if (!regionalMap.has(key)) {
        regionalMap.set(key, {
          city: u.location.city,
          state: u.location.state || 'India',
          wards: new Set(),
          totalPickups: 0,
          totalVolumeKg: 0,
          activeCollectors: new Set(),
          aggregators: new Set(),
          recyclers: new Set(),
          disbursedInr: 0,
        });
      }
      const entry = regionalMap.get(key)!;
      if (u.location.ward) entry.wards.add(u.location.ward);
      if (u.role === 'COLLECTOR' && u.status === 'ACTIVE') entry.activeCollectors.add(u.id);
      if (u.role === 'AGGREGATOR') entry.aggregators.add(u.id);
      if (u.role === 'RECYCLER') entry.recyclers.add(u.id);
    });

    allPickups.forEach((p) => {
      if (!p.location?.city) return;
      const key = `${p.location.city}, ${allUsers.find((u) => u.id === p.collectorId)?.location.state || 'Delhi'}`;
      if (!regionalMap.has(key)) {
        regionalMap.set(key, {
          city: p.location.city,
          state: 'NCR',
          wards: new Set(),
          totalPickups: 0,
          totalVolumeKg: 0,
          activeCollectors: new Set(),
          aggregators: new Set(),
          recyclers: new Set(),
          disbursedInr: 0,
        });
      }
      const entry = regionalMap.get(key)!;
      entry.totalPickups += 1;
      entry.totalVolumeKg += p.quantityKg || 0;
      if (p.location.ward) entry.wards.add(p.location.ward);
      if (p.status === 'DELIVERED' || p.status === 'AGGREGATED' || p.status === 'COLLECTED') {
        entry.disbursedInr += p.totalPrice || 0;
      }
    });

    const regionalActivity = Array.from(regionalMap.entries())
      .map(([key, data]) => ({
        regionKey: key,
        city: data.city,
        state: data.state,
        wards: Array.from(data.wards).slice(0, 4),
        totalPickups: data.totalPickups,
        totalVolumeKg: Math.round(data.totalVolumeKg),
        totalVolumeTons: Number((data.totalVolumeKg / 1000).toFixed(2)),
        activeCollectors: data.activeCollectors.size,
        aggregatorsCount: data.aggregators.size,
        recyclersCount: data.recyclers.size,
        disbursedInr: Math.round(data.disbursedInr),
      }))
      .sort((a, b) => b.totalVolumeKg - a.totalVolumeKg);

    // PAYMENT SNAPSHOT
    const paymentSnapshot = {
      PENDING: {
        count: allPayments.filter((p) => p.status === 'PENDING' && p.paymentMethod !== 'ESCROW').length,
        amountInr: allPayments
          .filter((p) => p.status === 'PENDING' && p.paymentMethod !== 'ESCROW')
          .reduce((sum, p) => sum + (p.amount || 0), 0),
      },
      PROCESSING: {
        count: allPayments.filter((p) => p.status === 'PENDING' && p.paymentMethod === 'ESCROW').length,
        amountInr: allPayments
          .filter((p) => p.status === 'PENDING' && p.paymentMethod === 'ESCROW')
          .reduce((sum, p) => sum + (p.amount || 0), 0),
      },
      PAID: {
        count: allPayments.filter((p) => p.status === 'COMPLETED').length,
        amountInr: allPayments
          .filter((p) => p.status === 'COMPLETED')
          .reduce((sum, p) => sum + (p.amount || 0), 0),
      },
      FAILED: {
        count: allPayments.filter((p) => p.status === 'FAILED').length,
        amountInr: allPayments
          .filter((p) => p.status === 'FAILED')
          .reduce((sum, p) => sum + (p.amount || 0), 0),
      },
      DISPUTED: {
        count: allPayments.filter((p) => p.status === 'FLAGGED').length,
        amountInr: allPayments
          .filter((p) => p.status === 'FLAGGED')
          .reduce((sum, p) => sum + (p.amount || 0), 0),
      },
      totalCount: allPayments.length,
      totalDisbursedInr,
        previousDisbursedInr,
      totalPendingInr: pendingPaymentsAmountInr,
      recentPayments: allPayments.slice(0, 5),
    };

    // COMPLAINT SNAPSHOT
    const complaintCategoryCounts: Record<string, number> = {};
    allComplaints.forEach((c) => {
      complaintCategoryCounts[c.category] = (complaintCategoryCounts[c.category] || 0) + 1;
    });

    const complaintSnapshot = {
      OPEN: allComplaints.filter((c) => c.status === 'OPEN').length,
      IN_REVIEW: allComplaints.filter((c) => c.status === 'IN_INVESTIGATION').length,
      RESOLVED: allComplaints.filter((c) => c.status === 'RESOLVED').length,
      REJECTED: allComplaints.filter((c) => c.status === 'DISMISSED').length,
      total: allComplaints.length,
      categoryBreakdown: complaintCategoryCounts,
      recentComplaints: allComplaints.slice(0, 4),
    };

    // FLAGGED / ATTENTION REQUIRED
    const flaggedAttentionItems: any[] = [];

    // 1. Anomalies
    for (const anm of allAnomalies.filter((a) => a.status !== 'RESOLVED' && a.status !== 'FALSE_POSITIVE')) {
      flaggedAttentionItems.push({
        id: `att-${anm.id}`,
        type: anm.ruleKey.includes('WEIGHT') ? 'WEIGHT_DISCREPANCY' : 'SUSPICIOUS_ANOMALY',
        title: anm.title,
        description: anm.description,
        severity: anm.severity,
        entityType: anm.entityType,
        entityId: anm.entityId,
        actionLabel: 'Review Anomaly',
        targetView: 'anomalies',
        filterPayload: { search: anm.ruleKey },
        timestamp: anm.detectedAt,
      });
    }

    // 2. Disputed Payments on Hold
    for (const pay of allPayments.filter((p) => p.status === 'FLAGGED')) {
      flaggedAttentionItems.push({
        id: `att-${pay.id}`,
        type: 'DISPUTED_PAYMENT',
        title: `Payment ${pay.transactionId} on Security Hold`,
        description: pay.referenceNotes || `Flagged ₹${pay.amount.toLocaleString('en-IN')} payment between ${pay.payerName} and ${pay.payeeName}`,
        severity: 'HIGH',
        entityType: 'PAYMENT',
        entityId: pay.id,
        actionLabel: 'Inspect Disbursement',
        targetView: 'payments',
        filterPayload: { status: 'FLAGGED' },
        timestamp: pay.timestamp,
      });
    }

    // 3. Open High/Critical Complaints
    for (const cmp of allComplaints.filter((c) => c.status === 'OPEN' || c.status === 'IN_INVESTIGATION')) {
      if (cmp.priority === 'HIGH' || cmp.priority === 'CRITICAL' || cmp.category === 'WEIGHT_DISCREPANCY') {
        flaggedAttentionItems.push({
          id: `att-${cmp.id}`,
          type: cmp.category === 'WEIGHT_DISCREPANCY' ? 'WEIGHT_DISCREPANCY' : 'UNRESOLVED_COMPLAINT',
          title: `Ticket ${cmp.ticketId}: ${cmp.category.replace(/_/g, ' ')}`,
          description: cmp.description,
          severity: cmp.priority,
          entityType: 'COMPLAINT',
          entityId: cmp.id,
          actionLabel: 'Investigate Ticket',
          targetView: 'complaints',
          filterPayload: { status: cmp.status },
          timestamp: cmp.createdAt,
        });
      }
    }

    // 4. Pending KYC / Verification Users
    for (const usr of allUsers.filter((u) => u.status === 'PENDING_VERIFICATION' || !u.kycVerified)) {
      if (usr.role !== 'ADMIN') {
        flaggedAttentionItems.push({
          id: `att-${usr.id}`,
          type: 'PENDING_VERIFICATION',
          title: `KYC Pending: ${usr.name} (${usr.role})`,
          description: `User account awaiting document verification and clearance in ${usr.location.city}.`,
          severity: 'MEDIUM',
          entityType: 'USER',
          entityId: usr.id,
          actionLabel: 'Verify Worker',
          targetView: 'users',
          filterPayload: { role: usr.role, status: 'PENDING_VERIFICATION' },
          timestamp: usr.createdAt,
        });
      }
    }

    // 5. Rejected Lots
    for (const lot of allLots.filter((l) => l.status === 'REJECTED')) {
      flaggedAttentionItems.push({
        id: `att-${lot.id}`,
        type: 'LOT_REJECTED',
        title: `Batch Rejected: ${lot.lotNumber}`,
        description: `Lot failed recycler intake QA (Moisture ${lot.moisturePercent}%, Contamination ${lot.contaminationPercent}%).`,
        severity: 'HIGH',
        entityType: 'LOT',
        entityId: lot.id,
        actionLabel: 'Inspect Batch',
        targetView: 'lots',
        filterPayload: { status: 'REJECTED' },
        timestamp: lot.createdAt,
      });
    }

    const severityRank: Record<string, number> = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
    flaggedAttentionItems.sort((a, b) => (severityRank[b.severity] || 0) - (severityRank[a.severity] || 0));

    // SYSTEM RECENT ACTIVITY (Unified real events)
    const systemRecentActivity: any[] = [];

    for (const trc of allTraceability) {
      const typeMap: Record<string, string> = {
        DISPATCHED_TO_RECYCLER: 'lot created / dispatched',
        CONSOLIDATED_INTO_LOT: 'lot consolidation',
        RECEIVED_AT_FACILITY: 'handover completed',
        WEIGHED_AND_COLLECTED: 'QR scanned & weighed',
      };
      systemRecentActivity.push({
        id: `act-trc-${trc.id}`,
        eventType: trc.eventType,
        title: typeMap[trc.eventType] || trc.eventType.replace(/_/g, ' ').toLowerCase(),
        description: `${trc.trackingCode} at ${trc.location}`,
        timestamp: trc.timestamp,
        actor: { name: trc.actorName, role: trc.actorRole },
        entityType: trc.entityType,
        entityId: trc.entityId,
        badgeVariant: trc.eventType.includes('RECEIVED') ? 'emerald' : 'blue',
        verifiedOnChain: trc.verifiedOnChain,
        targetView: trc.entityType === 'LOT' ? 'lots' : 'pickups',
      });
    }

    for (const aud of allAuditLogs) {
      systemRecentActivity.push({
        id: `act-aud-${aud.id}`,
        eventType: aud.action,
        title: aud.action.replace(/_/g, ' ').toLowerCase(),
        description: `${aud.details} (${aud.targetResource})`,
        timestamp: aud.timestamp,
        actor: { name: aud.actorName, role: aud.actorRole },
        entityType: 'CONFIG',
        entityId: aud.id,
        badgeVariant: aud.action.includes('FLAG') ? 'rose' : aud.action.includes('RESOLVE') ? 'emerald' : 'amber',
        targetView: 'audit',
      });
    }

    for (const p of allPickups) {
      systemRecentActivity.push({
        id: `act-pk-${p.id}`,
        eventType: `PICKUP_${p.status}`,
        title: p.status === 'REQUESTED' ? 'pickup created' : p.status === 'ASSIGNED' ? 'pickup accepted' : `pickup ${p.status.toLowerCase()}`,
        description: `${p.collectorName} → ${p.aggregatorName} (${p.quantityKg}kg ${p.materialName})`,
        timestamp: p.createdAt,
        actor: { name: p.collectorName, role: 'COLLECTOR' },
        entityType: 'PICKUP',
        entityId: p.id,
        badgeVariant: p.status === 'DELIVERED' || p.status === 'COLLECTED' ? 'emerald' : 'blue',
        targetView: 'pickups',
      });
    }

    for (const c of allComplaints) {
      systemRecentActivity.push({
        id: `act-cmp-${c.id}`,
        eventType: `COMPLAINT_${c.status}`,
        title: c.status === 'RESOLVED' ? 'complaint resolved' : 'complaint created',
        description: `${c.ticketId}: ${c.description.slice(0, 60)}...`,
        timestamp: c.status === 'RESOLVED' ? c.updatedAt : c.createdAt,
        actor: { name: c.filedByName, role: c.filedByRole },
        entityType: 'COMPLAINT',
        entityId: c.id,
        badgeVariant: c.status === 'RESOLVED' ? 'emerald' : 'rose',
        targetView: 'complaints',
      });
    }

    for (const u of allUsers) {
      if (u.role !== 'ADMIN') {
        systemRecentActivity.push({
          id: `act-usr-${u.id}`,
          eventType: 'NEW_REGISTRATION',
          title: `new ${u.role.toLowerCase()} registration`,
          description: `${u.name} registered in ${u.location.city}${u.kycVerified ? ' (KYC verified)' : ' (verification pending)'}`,
          timestamp: u.createdAt,
          actor: { name: u.name, role: u.role },
          entityType: 'USER',
          entityId: u.id,
          badgeVariant: u.kycVerified ? 'emerald' : 'amber',
          targetView: 'users',
        });
      }
    }

    // Sort events chronologically descending
    systemRecentActivity.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    // THROUGHPUT TIMELINE (Adapting to date range)
    let throughputTimeline: { label: string; collectedKg: number; recycledKg: number; disbursedInr: number }[] = [];

    if (range === 'today') {
      throughputTimeline = [
        { label: '06:00', collectedKg: 280, recycledKg: 0, disbursedInr: 7800 },
        { label: '08:00', collectedKg: 420, recycledKg: 1200, disbursedInr: 12600 },
        { label: '10:00', collectedKg: 680, recycledKg: 1850, disbursedInr: 21400 },
        { label: '12:00', collectedKg: 540, recycledKg: 900, disbursedInr: 16500 },
        { label: '14:00', collectedKg: 790, recycledKg: 2100, disbursedInr: 24800 },
        { label: '16:00', collectedKg: 610, recycledKg: 1400, disbursedInr: 18900 },
        { label: '18:00', collectedKg: 350, recycledKg: 800, disbursedInr: 9500 },
      ];
    } else if (range === '30d') {
      throughputTimeline = [
        { label: 'Week 1', collectedKg: 14200, recycledKg: 12800, disbursedInr: 420000 },
        { label: 'Week 2', collectedKg: 18600, recycledKg: 16400, disbursedInr: 580000 },
        { label: 'Week 3', collectedKg: 21400, recycledKg: 19800, disbursedInr: 660000 },
        { label: 'Week 4', collectedKg: 24900, recycledKg: 23100, disbursedInr: 780000 },
      ];
    } else if (range === '90d') {
      throughputTimeline = [
        { label: 'Month -2', collectedKg: 64000, recycledKg: 58000, disbursedInr: 1940000 },
        { label: 'Month -1', collectedKg: 78500, recycledKg: 72100, disbursedInr: 2410000 },
        { label: 'Current Mo.', collectedKg: 86200, recycledKg: 79800, disbursedInr: 2680000 },
      ];
    } else {
      throughputTimeline = [
        { label: 'Mon', collectedKg: 2450, recycledKg: 1980, disbursedInr: 74200 },
        { label: 'Tue', collectedKg: 3100, recycledKg: 2840, disbursedInr: 96500 },
        { label: 'Wed', collectedKg: 2900, recycledKg: 2700, disbursedInr: 88400 },
        { label: 'Thu', collectedKg: 4200, recycledKg: 3950, disbursedInr: 132000 },
        { label: 'Fri', collectedKg: 3800, recycledKg: 3600, disbursedInr: 118000 },
        { label: 'Sat', collectedKg: 5100, recycledKg: 4800, disbursedInr: 159000 },
        { label: 'Sun (Today)', collectedKg: Math.round(totalCollectedKg), recycledKg: Math.round(totalRecycledKg), disbursedInr: totalDisbursedInr },
      ];
    }

    const materialBreakdown: Record<string, { weightKg: number; count: number }> = {};
    allPickups.forEach((p) => {
      const cat = p.category || 'OTHER';
      if (!materialBreakdown[cat]) {
        materialBreakdown[cat] = { weightKg: 0, count: 0 };
      }
      materialBreakdown[cat].weightKg += p.quantityKg;
      materialBreakdown[cat].count += 1;
    });

    return {
      overview: {
        totalCollectors,
        totalAggregators,
        totalRecyclers,
        activeLots,
        pendingPickups,
        completedPickups,
        materialCollectedKg: Math.round(totalCollectedKg),
        materialCollectedTons,
        recyclingCompletedKg: Math.round(totalRecycledKg),
        recyclingCompletedTons,
        pendingPaymentsCount,
        pendingPaymentsAmountInr,
        openComplaintsCount,
        flaggedLotsCount,
        activeAnomaliesCount,
        criticalAnomaliesCount,
        totalDisbursedInr,
        co2OffsetTons: estimatedCo2OffsetTons,
        traceabilityIntegrityPercent: integrityPercent,
        activeWorkersCount,
        // Backward compatibility
        totalCollectedTons: materialCollectedTons,
        totalRecycledTons: recyclingCompletedTons,
        totalLotWeightTons,
        informalWorkersCount: totalCollectors,
        pendingDisbursementsInr: pendingPaymentsAmountInr,
      },
      pickupOverview: pickupStatusCounts,
      lotOverview,
      materialOverview: {
        categories: materialCategoriesSummary,
        totalEstimatedValueInr,
        totalCo2OffsetTons: estimatedCo2OffsetTons,
        totalCollectedKg: Math.round(totalCollectedKg),
        totalRecycledKg: Math.round(totalRecycledKg),
      },
      regionalActivity,
      paymentSnapshot,
      complaintSnapshot,
      flaggedAttentionItems: flaggedAttentionItems.slice(0, 8),
      systemRecentActivity: systemRecentActivity.slice(0, 15),
      throughputTimeline,
      throughputDays: throughputTimeline.map((t) => ({ day: t.label, collectedKg: t.collectedKg, recycledKg: t.recycledKg })),
      materialBreakdown,
      recentPickups: allPickups.slice(0, 5),
      recentLots: allLots.slice(0, 5),
      recentAnomalies: allAnomalies.slice(0, 3),
      recentComplaints: allComplaints.slice(0, 3),
      dateRange: {
        range: range as any,
        startDate: options.startDate,
        endDate: options.endDate,
        effectiveLabel,
      },
      systemStatus: {
        backendService: 'HEALTHY',
        databaseEngine: 'IN_MEMORY_PERSISTED',
        qrProtocol: this.appConfig.adminConfig.qrTraceabilityProtocol,
        version: this.appConfig.adminConfig.version,
        lastSyncedAt: new Date().toISOString(),
      },
    };
  }

  // --- Real-Database Aggregated Analytics Engine (Phase 6) ---
  public getAnalytics(options: { range?: string; startDate?: string; endDate?: string } = {}): AnalyticsResponse {
    const range = (options.range || '7d') as AnalyticsRange;
    const now = new Date('2026-09-14T12:00:00.000Z').getTime();
    let rangeStart = 0;
    let rangeEnd = now;
    let effectiveLabel = 'Past 7 Days';

    if (range === 'today') {
      rangeStart = new Date('2026-09-14T00:00:00.000Z').getTime();
      rangeEnd = now;
      effectiveLabel = 'Today (Sept 14, 2026)';
    } else if (range === '7d') {
      rangeStart = now - 7 * 24 * 60 * 60 * 1000;
      rangeEnd = now;
      effectiveLabel = 'Past 7 Days';
    } else if (range === '30d') {
      rangeStart = now - 30 * 24 * 60 * 60 * 1000;
      rangeEnd = now;
      effectiveLabel = 'Past 30 Days';
    } else if (range === '90d') {
      rangeStart = now - 90 * 24 * 60 * 60 * 1000;
      rangeEnd = now;
      effectiveLabel = 'Past 90 Days';
    } else if (range === 'custom') {
      rangeStart = options.startDate ? new Date(options.startDate).getTime() : now - 30 * 24 * 60 * 60 * 1000;
      rangeEnd = options.endDate ? new Date(options.endDate).getTime() : now;
      effectiveLabel = `${options.startDate || 'Start'} to ${options.endDate || 'Now'}`;
    }

    // Bounded caching (60 seconds) with explicit invalidation on mutation
    const cacheKey = `${range}_${rangeStart}_${rangeEnd}`;
    const cached = this.analyticsCache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.data;
    }

    // 1. Fetch raw underlying records
    const allLots = Array.from(this.lots.values());
    const allPickups = Array.from(this.pickups.values());
    const allPayments = Array.from(this.payments.values());
    const allAnomalies = Array.from(this.anomalies.values());
    const allMaterials = Array.from(this.materials.values());
    const allUsers = Array.from(this.users.values());

    // Filter records by operational date bounds
    const inRangeLots = allLots.filter((l) => {
      const t = new Date(l.createdAt).getTime();
      return t >= rangeStart && t <= rangeEnd;
    });

    const inRangePickups = allPickups.filter((p) => {
      const t = new Date(p.createdAt).getTime();
      return t >= rangeStart && t <= rangeEnd;
    });

    const inRangePayments = allPayments.filter((pay) => {
      const t = new Date(pay.createdAt).getTime();
      return t >= rangeStart && t <= rangeEnd;
    });

    // 2. Aggregate Summary Metrics
    const totalCollectionVolumeKg = inRangePickups
      .filter((p) => p.status === 'COMPLETED' || p.status === 'DELIVERED')
      .reduce((sum, p) => sum + (p.actualWeightKg || p.quantityKg || 0), 0);

    const totalRecycledVolumeKg = inRangeLots
      .filter((l) => l.status === 'PROCESSED' || l.status === 'RECEIVED')
      .reduce((sum, l) => sum + (l.actualWeightKg || l.totalWeightKg || 0), 0);

    const totalLotsCount = inRangeLots.length;
    const totalPickupsCount = inRangePickups.length;

    const completedPickupsCount = inRangePickups.filter((p) => p.status === 'COMPLETED').length;
    const pendingPickupsCount = inRangePickups.filter(
      (p) =>
        p.status === 'REQUESTED' ||
        p.status === 'ACCEPTED' ||
        p.status === 'SCHEDULED' ||
        p.status === 'ASSIGNED' ||
        p.status === 'COLLECTED'
    ).length;
    const cancelledPickupsCount = inRangePickups.filter((p) => p.status === 'CANCELLED').length;
    const pickupCompletionRate = totalPickupsCount > 0
      ? Number(((completedPickupsCount / totalPickupsCount) * 100).toFixed(1))
      : 100;

    const totalDisbursedInr = inRangePayments
      .filter((p) => p.status === 'PAID')
      .reduce((sum, p) => sum + p.amount, 0);

    const pendingDisbursementInr = inRangePayments
      .filter((p) => p.status === 'PENDING' || p.status === 'PROCESSING')
      .reduce((sum, p) => sum + p.amount, 0);

    const activeAnomaliesCount = allAnomalies.filter(
      (a) => a.status === 'NEW' || a.status === 'UNDER_REVIEW' || a.status === 'DETECTED'
    ).length;

    const summary: AnalyticsSummary = {
      totalCollectionVolumeKg: Math.round(totalCollectionVolumeKg),
      totalRecycledVolumeKg: Math.round(totalRecycledVolumeKg),
      totalLotsCount,
      totalPickupsCount,
      pickupCompletionRate,
      totalDisbursedInr,
      pendingDisbursementInr,
      activeAnomaliesCount,
    };

    // 3. Time Series Generator Helper (generates daily interval buckets)
    const numDays = Math.max(1, Math.ceil((rangeEnd - rangeStart) / (24 * 60 * 60 * 1000)));
    const daysList: { dateStr: string; label: string; startMs: number; endMs: number }[] = [];

    for (let i = 0; i < numDays; i++) {
      const dayStartMs = rangeStart + i * 24 * 60 * 60 * 1000;
      const dayEndMs = Math.min(rangeEnd, dayStartMs + 24 * 60 * 60 * 1000);
      const dObj = new Date(dayStartMs);
      const dateStr = dObj.toISOString().split('T')[0];
      const label = dObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      daysList.push({ dateStr, label, startMs: dayStartMs, endMs: dayEndMs });
    }

    // 4. Lots Over Time
    const lotsOverTime: LotsOverTimePoint[] = daysList.map((d) => {
      const dayLots = allLots.filter((l) => {
        const t = new Date(l.createdAt).getTime();
        return t >= d.startMs && t < d.endMs;
      });

      const totalKg = dayLots.reduce((s, l) => s + (l.totalWeightKg || 0), 0);
      const aggregatedKg = dayLots
        .filter((l) => l.status === 'FORMED' || l.status === 'IN_TRANSIT')
        .reduce((s, l) => s + (l.totalWeightKg || 0), 0);
      const recycledKg = dayLots
        .filter((l) => l.status === 'PROCESSED' || l.status === 'RECEIVED')
        .reduce((s, l) => s + (l.actualWeightKg || l.totalWeightKg || 0), 0);

      return {
        date: d.dateStr,
        label: d.label,
        count: dayLots.length,
        totalKg: Math.round(totalKg),
        aggregatedKg: Math.round(aggregatedKg),
        recycledKg: Math.round(recycledKg),
      };
    });

    // 5. Collection Volume Over Time
    const collectionVolume: CollectionVolumePoint[] = daysList.map((d) => {
      const dayPickups = allPickups.filter((p) => {
        const t = new Date(p.createdAt).getTime();
        return t >= d.startMs && t < d.endMs && p.status === 'COMPLETED';
      });
      const vol = dayPickups.reduce((s, p) => s + (p.actualWeightKg || p.quantityKg || 0), 0);
      return {
        date: d.dateStr,
        label: d.label,
        volumeKg: Math.round(vol),
        pickupsCount: dayPickups.length,
      };
    });

    // 6. Recycling Volume Over Time
    const recyclingVolume: RecyclingVolumePoint[] = daysList.map((d) => {
      const dayRecycledLots = allLots.filter((l) => {
        const t = new Date(l.createdAt).getTime();
        return t >= d.startMs && t < d.endMs && (l.status === 'PROCESSED' || l.status === 'RECEIVED');
      });
      const vol = dayRecycledLots.reduce((s, l) => s + (l.actualWeightKg || l.totalWeightKg || 0), 0);
      return {
        date: d.dateStr,
        label: d.label,
        volumeKg: Math.round(vol),
        lotsProcessed: dayRecycledLots.length,
        lotsCount: dayRecycledLots.length,
      };
    });

    // 7. Pickup Completion Stats
    const pickupCompletionHistory = daysList.map((d) => {
      const dayPickups = allPickups.filter((p) => {
        const t = new Date(p.createdAt).getTime();
        return t >= d.startMs && t < d.endMs;
      });
      const comp = dayPickups.filter((p) => p.status === 'COMPLETED').length;
      const pend = dayPickups.filter(
        (p) =>
          p.status === 'REQUESTED' ||
          p.status === 'ACCEPTED' ||
          p.status === 'SCHEDULED' ||
          p.status === 'ASSIGNED' ||
          p.status === 'COLLECTED'
      ).length;
      const canc = dayPickups.filter((p) => p.status === 'CANCELLED').length;
      const total = dayPickups.length;
      const rate = total > 0 ? Number(((comp / total) * 100).toFixed(1)) : 100;
      return {
        date: d.dateStr,
        label: d.label,
        completed: comp,
        pending: pend,
        cancelled: canc,
        completionRate: rate,
      };
    });

    const pickupCompletion: PickupCompletionStats = {
      total: totalPickupsCount,
      completed: completedPickupsCount,
      pending: pendingPickupsCount,
      cancelled: cancelledPickupsCount,
      completionRate: pickupCompletionRate,
      history: pickupCompletionHistory,
    };

    // 8. Material Categories
    const materialCategoryMap = new Map<string, { collectedKg: number; recycledKg: number; valueInr: number }>();
    allMaterials.forEach((m) => {
      materialCategoryMap.set(m.id, { collectedKg: 0, recycledKg: 0, valueInr: 0 });
    });

    inRangePickups.forEach((p) => {
      if (p.status === 'COMPLETED' || p.status === 'DELIVERED') {
        const entry = materialCategoryMap.get(p.materialId) || { collectedKg: 0, recycledKg: 0, valueInr: 0 };
        const kg = p.actualWeightKg || p.quantityKg || 0;
        const mat = this.materials.get(p.materialId);
        const rate = mat?.standardPricePerKg || 25;
        entry.collectedKg += kg;
        entry.valueInr += kg * rate;
        materialCategoryMap.set(p.materialId, entry);
      }
    });

    inRangeLots.forEach((l) => {
      if (l.status === 'PROCESSED' || l.status === 'RECEIVED') {
        const entry = materialCategoryMap.get(l.materialId) || { collectedKg: 0, recycledKg: 0, valueInr: 0 };
        const kg = l.actualWeightKg || l.totalWeightKg || 0;
        entry.recycledKg += kg;
        materialCategoryMap.set(l.materialId, entry);
      }
    });

    const totalMatKg = Array.from(materialCategoryMap.values()).reduce((s, v) => s + v.collectedKg, 0) || 1;
    const materialCategories: MaterialCategoryPoint[] = allMaterials.map((m) => {
      const stats = materialCategoryMap.get(m.id) || { collectedKg: 0, recycledKg: 0, valueInr: 0 };
      const pct = Number(((stats.collectedKg / totalMatKg) * 100).toFixed(1));
      return {
        categoryId: m.category,
        categoryName: m.name,
        materialId: m.id,
        materialName: m.name,
        category: m.category,
        code: m.code,
        collectedKg: Math.round(stats.collectedKg),
        recycledKg: Math.round(stats.recycledKg),
        totalValueInr: Math.round(stats.valueInr),
        valueInr: Math.round(stats.valueInr),
        percentage: pct,
      };
    });

    // Top materials sorted by volume
    const topMaterialCategories = [...materialCategories].sort((a, b) => b.collectedKg - a.collectedKg);

    // 9. Lots by Status
    const statusLabels: Record<AggregatedLot['status'], string> = {
      FORMED: 'Aggregated & Stored',
      IN_TRANSIT: 'In Transit to Processor',
      RECEIVED: 'Received at Facility',
      PROCESSED: 'Recycled & Certified',
      REJECTED: 'Quality Rejected',
    };

    const statusCounts: Record<string, { count: number; totalKg: number }> = {};
    Object.keys(statusLabels).forEach((st) => {
      statusCounts[st] = { count: 0, totalKg: 0 };
    });

    inRangeLots.forEach((l) => {
      if (!statusCounts[l.status]) {
        statusCounts[l.status] = { count: 0, totalKg: 0 };
      }
      statusCounts[l.status].count += 1;
      statusCounts[l.status].totalKg += l.actualWeightKg || l.totalWeightKg || 0;
    });

    const totalLotKgAll = Object.values(statusCounts).reduce((s, v) => s + v.totalKg, 0) || 1;
    const lotsByStatus: LotsByStatusPoint[] = Object.entries(statusCounts).map(([st, data]) => ({
      status: st,
      label: statusLabels[st as AggregatedLot['status']] || st,
      count: data.count,
      totalKg: Math.round(data.totalKg),
      percentage: Number(((data.totalKg / totalLotKgAll) * 100).toFixed(1)),
    }));

    // 10. Payment Breakdown and History
    const paymentStatusLabels: Record<PaymentRecord['status'], string> = {
      PAID: 'Disbursed / Paid',
      COMPLETED: 'Completed Settlement',
      PENDING: 'Pending Processing',
      PROCESSING: 'In Processing Window',
      DISPUTED: 'Dispute / Hold',
      FAILED: 'Transaction Failed',
      FLAGGED: 'Flagged by Compliance',
    };

    const payStatusMap: Record<PaymentRecord['status'], { count: number; amount: number }> = {
      PAID: { count: 0, amount: 0 },
      COMPLETED: { count: 0, amount: 0 },
      PENDING: { count: 0, amount: 0 },
      PROCESSING: { count: 0, amount: 0 },
      DISPUTED: { count: 0, amount: 0 },
      FAILED: { count: 0, amount: 0 },
      FLAGGED: { count: 0, amount: 0 },
    };

    inRangePayments.forEach((p) => {
      if (!payStatusMap[p.status]) {
        payStatusMap[p.status] = { count: 0, amount: 0 };
      }
      payStatusMap[p.status].count += 1;
      payStatusMap[p.status].amount += p.amount;
    });

    const totalPaySum = Object.values(payStatusMap).reduce((s, v) => s + v.amount, 0) || 1;
    const byStatus = Object.entries(payStatusMap).map(([st, data]) => ({
      status: st,
      label: paymentStatusLabels[st as PaymentRecord['status']] || st,
      count: data.count,
      amount: data.amount,
      percentage: Number(((data.amount / totalPaySum) * 100).toFixed(1)),
    }));

    const paymentHistory = daysList.map((d) => {
      const dayPaid = inRangePayments.filter((p) => {
        const t = new Date(p.createdAt || p.timestamp).getTime();
        return t >= d.startMs && t < d.endMs && (p.status === 'PAID' || p.status === 'COMPLETED');
      });
      const amount = dayPaid.reduce((s, p) => s + p.amount, 0);
      return {
        date: d.dateStr,
        label: d.label,
        disbursedAmount: amount,
        count: dayPaid.length,
      };
    });

    const totalDisputedInr = payStatusMap['DISPUTED']?.amount || 0;
    const totalFailedInr = payStatusMap['FAILED']?.amount || 0;

    const payments: PaymentStats = {
      totalDisbursed: totalDisbursedInr,
      totalPending: pendingDisbursementInr,
      totalDisputed: totalDisputedInr,
      totalFailed: totalFailedInr,
      byStatus,
      history: paymentHistory,
    };

    // 11. Regional Activity (Grounded from actual user locations, pickups, lots)
    const regionalMap = new Map<string, {
      region: string;
      state: string;
      city: string;
      pickupsCount: number;
      volumeKg: number;
      recycledKg: number;
      collectors: Set<string>;
      aggregators: Set<string>;
    }>();

    // Seed regions based on locations in pickups
    inRangePickups.forEach((p) => {
      const city = p.location?.city || 'Delhi NCR';
      const state = (p.location as any)?.state || 'Delhi';
      const region = `${city} Hub`;
      const key = `${city}_${state}`;

      if (!regionalMap.has(key)) {
        regionalMap.set(key, {
          region,
          state,
          city,
          pickupsCount: 0,
          volumeKg: 0,
          recycledKg: 0,
          collectors: new Set(),
          aggregators: new Set(),
        });
      }

      const item = regionalMap.get(key)!;
      item.pickupsCount += 1;
      const kg = p.actualWeightKg || p.quantityKg || 0;
      item.volumeKg += kg;
      if (p.collectorId) item.collectors.add(p.collectorId);
      if (p.aggregatorId) item.aggregators.add(p.aggregatorId);
    });

    inRangeLots.forEach((l) => {
      // Find aggregator or default
      const key = 'Delhi_Delhi';
      const item = regionalMap.get(key);
      if (item && (l.status === 'PROCESSED' || l.status === 'RECEIVED')) {
        item.recycledKg += l.actualWeightKg || l.totalWeightKg || 0;
      }
    });

    const regionalActivity: RegionalActivityPoint[] = Array.from(regionalMap.values()).map((r) => ({
      region: r.region,
      state: r.state,
      city: r.city,
      pickupsCount: r.pickupsCount,
      volumeKg: Math.round(r.volumeKg),
      recycledKg: Math.round(r.recycledKg),
      collectorsCount: r.collectors.size,
      aggregatorsCount: r.aggregators.size,
    }));

    // Ensure at least Delhi and Gurugram hubs are represented from seed data
    if (regionalActivity.length === 0) {
      regionalActivity.push({
        region: 'Delhi NCR Hub',
        state: 'Delhi',
        city: 'New Delhi',
        pickupsCount: inRangePickups.length,
        volumeKg: Math.round(totalCollectionVolumeKg),
        recycledKg: Math.round(totalRecycledVolumeKg),
        collectorsCount: allUsers.filter((u) => u.role === 'COLLECTOR').length,
        aggregatorsCount: allUsers.filter((u) => u.role === 'AGGREGATOR').length,
      });
    }

    const response: AnalyticsResponse = {
      summary,
      lotsOverTime,
      materialCategories,
      collectionVolume,
      recyclingVolume,
      pickupCompletion,
      lotsByStatus,
      payments,
      regionalActivity,
      topMaterialCategories,
      timeRange: {
        range,
        startDate: options.startDate,
        endDate: options.endDate,
        label: effectiveLabel,
      },
      dateRange: {
        range,
        startDate: options.startDate,
        endDate: options.endDate,
        effectiveLabel,
      },
      cachedAt: new Date().toISOString(),
      isRealData: true,
    };

    this.analyticsCache.set(cacheKey, { data: response, expiresAt: Date.now() + 60000 });
    return response;
  }

  // --- On-Demand Analytics Export Engine (CSV generation from database) ---
  
  // --- TRUST & REVIEWS ---
  public queryReviews(params: PaginationParams): PaginatedResult<MutualReview> {
    let result = Array.from(this.reviews.values());
    if (params.search) {
      const q = params.search.toLowerCase();
      result = result.filter(
        (r) =>
          r.reviewerName.toLowerCase().includes(q) ||
          r.reviewedName.toLowerCase().includes(q) ||
          r.transactionId.toLowerCase().includes(q)
      );
    }
    result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    const page = params.page || 1;
    const limit = params.limit || 10;
    const startIndex = (page - 1) * limit;
    const paginated = result.slice(startIndex, startIndex + limit);

    return {
      data: paginated,
      total: result.length,
      page,
      limit,
      totalPages: Math.ceil(result.length / limit),
    };
  }

  public getReviewById(id: string): MutualReview | undefined {
    return this.reviews.get(id);
  }

  public processReview(id: string, adminId: string, action: 'APPROVE' | 'REJECT' | 'FLAG', scoreImpact: number = 0): MutualReview | null {
    const review = this.reviews.get(id);
    if (!review) return null;
    
    if (action === 'APPROVE') {
      review.status = 'PROCESSED';
      review.scoreImpact = scoreImpact;
      
      // Update user score
      const user = this.users.get(review.reviewedId);
      if (user) {
        let prevScore = 0;
        let newScore = 0;
        if (user.role === 'COLLECTOR') {
          prevScore = user.contributionPoints || 0;
          newScore = prevScore + scoreImpact;
          user.contributionPoints = newScore;
        } else {
          prevScore = user.trustScore || 0;
          newScore = Math.min(100, Math.max(0, prevScore + scoreImpact));
          user.trustScore = newScore;
        }
        
        this.scoreHistory.unshift({
          id: `sh-${Date.now()}`,
          userId: user.id,
          userRole: user.role,
          scoreType: user.role === 'COLLECTOR' ? 'CONTRIBUTION_POINTS' : 'TRUST_SCORE',
          previousValue: prevScore,
          changeValue: newScore - prevScore,
          newValue: newScore,
          reason: `Review Processed: ${review.id}`,
          source: 'REVIEW',
          relatedEntityId: review.id,
          timestamp: new Date().toISOString()
        });
      }
    } else if (action === 'REJECT') {
      review.status = 'REJECTED';
    } else if (action === 'FLAG') {
      review.status = 'FLAGGED';
    }
    
    review.processedAt = new Date().toISOString();
    
    this.recordAuditLog({
      actorId: adminId,
      actorName: 'System Admin',
      actorRole: 'ADMIN',
      action: `REVIEW_${action}`,
      targetResource: `Review ${id}`,
      details: `Admin ${action.toLowerCase()}ed review ${id} with impact ${scoreImpact}`,
      entity: 'REVIEW',
      entityId: id,
      result: 'SUCCESS'
    });
    
    return review;
  }

  public queryScoreHistory(userId: string): ScoreHistoryRecord[] {
    return this.scoreHistory.filter(h => h.userId === userId).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  public overrideScore(userId: string, newScore: number, reason: string, adminId: string): User | null {
    const user = this.users.get(userId);
    if (!user) return null;
    
    let prevScore = 0;
    if (user.role === 'COLLECTOR') {
      prevScore = user.contributionPoints || 0;
      user.contributionPoints = newScore;
    } else {
      prevScore = user.trustScore || 0;
      user.trustScore = newScore;
    }
    
    this.scoreHistory.unshift({
      id: `sh-${Date.now()}`,
      userId: user.id,
      userRole: user.role,
      scoreType: user.role === 'COLLECTOR' ? 'CONTRIBUTION_POINTS' : 'TRUST_SCORE',
      previousValue: prevScore,
      changeValue: newScore - prevScore,
      newValue: newScore,
      reason: `Admin Override: ${reason}`,
      source: 'ADMIN_OVERRIDE',
      timestamp: new Date().toISOString()
    });
    
    this.recordAuditLog({
      actorId: adminId,
      actorName: 'System Admin',
      actorRole: 'ADMIN',
      action: 'SCORE_OVERRIDE',
      targetResource: `User ${userId}`,
      details: `Score overridden from ${prevScore} to ${newScore}. Reason: ${reason}`,
      entity: 'USER',
      entityId: userId,
      result: 'SUCCESS'
    });
    
    return user;
  }

  public generateAnalyticsExport(
    type: string,
    range: string = '7d',
    startDate?: string,
    endDate?: string
  ): { filename: string; contentType: string; data: string } {
    const analytics = this.getAnalytics({ range, startDate, endDate });
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');

    if (type === 'lots') {
      const allLots = Array.from(this.lots.values());
      const headers = ['Lot ID', 'Batch Number', 'Material ID', 'Aggregator ID', 'Recycler ID', 'Total Weight (kg)', 'Status', 'Created Date'];
      const rows = allLots.map((l) => [
        `"${l.id}"`,
        `"${l.lotNumber || l.batchQrCode}"`,
        `"${l.materialId}"`,
        `"${l.aggregatorId}"`,
        `"${l.recyclerId || 'Unassigned'}"`,
        (l.actualWeightKg || l.totalWeightKg || 0).toFixed(1),
        `"${l.status}"`,
        `"${l.createdAt}"`,
      ]);
      const data = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      return {
        filename: `recysetu-lots-export-${timestamp}.csv`,
        contentType: 'text/csv',
        data,
      };
    }

    if (type === 'pickups') {
      const allPickups = Array.from(this.pickups.values());
      const headers = ['Pickup ID', 'Tracking Code', 'Material ID', 'Collector ID', 'Aggregator ID', 'Weight (kg)', 'Status', 'Scheduled Date', 'Created Date'];
      const rows = allPickups.map((p) => [
        `"${p.id}"`,
        `"${p.trackingCode}"`,
        `"${p.materialId}"`,
        `"${p.collectorId}"`,
        `"${p.aggregatorId || 'N/A'}"`,
        (p.actualWeightKg || p.quantityKg || 0).toFixed(1),
        `"${p.status}"`,
        `"${p.scheduledAt || p.preferredDate || 'N/A'}"`,
        `"${p.createdAt}"`,
      ]);
      const data = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      return {
        filename: `recysetu-pickups-export-${timestamp}.csv`,
        contentType: 'text/csv',
        data,
      };
    }

    if (type === 'payments') {
      const allPayments = Array.from(this.payments.values());
      const headers = ['Payment ID', 'Transaction ID', 'Related Resource', 'Payer ID', 'Payee ID', 'Amount (INR)', 'Status', 'Payment Method', 'Created Date'];
      const rows = allPayments.map((p) => [
        `"${p.id}"`,
        `"${p.transactionId || p.upiRefNumber || 'N/A'}"`,
        `"${p.relatedEntityType}: ${p.relatedEntityId}"`,
        `"${p.payerId}"`,
        `"${p.payeeId}"`,
        p.amount.toFixed(2),
        `"${p.status}"`,
        `"${p.paymentMethod || 'UPI'}"`,
        `"${p.createdAt || p.timestamp}"`,
      ]);
      const data = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      return {
        filename: `recysetu-payments-export-${timestamp}.csv`,
        contentType: 'text/csv',
        data,
      };
    }

    if (type === 'materials') {
      const headers = ['Code', 'Material Name', 'Category', 'Collected Volume (kg)', 'Recycled Volume (kg)', 'Estimated Value (INR)', 'Share (%)'];
      const rows = analytics.materialCategories.map((m) => [
        `"${m.code || m.categoryId}"`,
        `"${m.materialName || m.categoryName}"`,
        `"${m.category || m.categoryId}"`,
        m.collectedKg,
        m.recycledKg,
        m.totalValueInr || m.valueInr || 0,
        m.percentage,
      ]);
      const data = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      return {
        filename: `recysetu-materials-summary-${timestamp}.csv`,
        contentType: 'text/csv',
        data,
      };
    }

    // Default: Executive Summary Report
    const effectiveLabel = analytics.dateRange?.effectiveLabel || analytics.timeRange.label;
    const headers = ['Metric', 'Value', 'Unit', 'Time Window'];
    const rows = [
      ['Total Material Collected', analytics.summary.totalCollectionVolumeKg, 'kg', effectiveLabel],
      ['Total Material Recycled', analytics.summary.totalRecycledVolumeKg, 'kg', effectiveLabel],
      ['Total Aggregated Lots', analytics.summary.totalLotsCount, 'lots', effectiveLabel],
      ['Total Pickup Requests', analytics.summary.totalPickupsCount, 'pickups', effectiveLabel],
      ['Pickup Completion Rate', analytics.summary.pickupCompletionRate, '%', effectiveLabel],
      ['Total Disbursed Funds', analytics.summary.totalDisbursedInr, 'INR (₹)', effectiveLabel],
      ['Pending Disbursements', analytics.summary.pendingDisbursementInr, 'INR (₹)', effectiveLabel],
      ['Active System Anomalies', analytics.summary.activeAnomaliesCount, 'count', 'Current'],
    ];
    const data = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    return {
      filename: `recysetu-executive-summary-${timestamp}.csv`,
      contentType: 'text/csv',
      data,
    };
  }
}

// Singleton database instance
export const db = new RecySetuDatabase();
