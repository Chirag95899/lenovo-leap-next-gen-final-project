import { Request, Response, NextFunction } from 'express';
import { db } from '../db/database';
import { User } from '../../src/shared/types/domain';

export interface AuthenticatedAdminRequest extends Request {
  adminUser?: User;
}

interface ActiveSession {
  token: string;
  userId: string;
  adminId: string;
  createdAt: number;
  expiresAt: number;
}

// In-memory backend session repository
const activeSessions: Map<string, ActiveSession> = new Map();

// Helper to generate cryptographically safe pseudorandom session tokens
export function createAdminSession(user: User): { token: string; expiresAt: string } {
  const randomPart = Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2);
  const token = `rcy-adm-${user.adminId || user.id}-${Date.now()}-${randomPart}`;
  const now = Date.now();
  const expiresAtMs = now + 12 * 60 * 60 * 1000; // 12 hours validity

  activeSessions.set(token, {
    token,
    userId: user.id,
    adminId: user.adminId || user.id,
    createdAt: now,
    expiresAt: expiresAtMs,
  });

  return {
    token,
    expiresAt: new Date(expiresAtMs).toISOString(),
  };
}

export function revokeAdminSession(token: string): boolean {
  return activeSessions.delete(token);
}

export function requireAdminAuth(req: AuthenticatedAdminRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization || (req.headers['x-admin-token'] as string);

  if (!authHeader) {
    res.status(401).json({
      error: 'UNAUTHORIZED',
      message: 'Admin authorization token required. Please sign in with Admin ID and Password.',
    });
    return;
  }

  const token = authHeader.startsWith('Bearer ') ? authHeader.substring(7).trim() : authHeader.trim();
  const session = activeSessions.get(token);

  if (!session) {
    res.status(401).json({
      error: 'INVALID_TOKEN',
      message: 'Admin session is invalid or has expired. Please re-authenticate.',
    });
    return;
  }

  if (Date.now() > session.expiresAt) {
    activeSessions.delete(token);
    res.status(401).json({
      error: 'SESSION_EXPIRED',
      message: 'Admin session has expired. Please log in again.',
    });
    return;
  }

  const user = db.getUserById(session.userId);
  if (!user) {
    res.status(401).json({
      error: 'USER_NOT_FOUND',
      message: 'Associated admin user account not found in system directory.',
    });
    return;
  }

  // Backend validation: STRICTLY verify ADMIN role
  if (user.role !== 'ADMIN') {
    res.status(403).json({
      error: 'FORBIDDEN',
      message: 'Access denied. Account lacks administrative clearance.',
    });
    return;
  }

  // Attach verified user to request context
  req.adminUser = user;
  next();
}
