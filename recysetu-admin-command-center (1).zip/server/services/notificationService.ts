import { UserRole } from '../../src/shared/types/domain';
import { NotificationConfig } from '../../src/shared/types/config';

export interface SystemNotification {
  id: string;
  recipientId: string;
  recipientName: string;
  recipientRole: UserRole;
  channel: 'SMS' | 'WHATSAPP' | 'IN_APP_PUSH' | 'IVR' | 'EMAIL';
  title: string;
  message: string;
  relatedEntityType: 'PAYMENT' | 'COMPLAINT' | 'LOT' | 'PICKUP' | 'SECURITY';
  relatedEntityId: string;
  status: 'QUEUED' | 'SENT_PENDING_CARRIER_ACK' | 'DELIVERED_CONFIRMED' | 'FAILED';
  providerName: string;
  providerMessageRef?: string;
  carrierAckAt?: string;
  createdAt: string;
}

class NotificationService {
  private notifications: SystemNotification[] = [];

  /**
   * Dispatches a notification across enabled channels.
   * Conforms strictly to constraint: Never report SMS/push delivery unless the provider confirms it.
   */
  public dispatchNotification(params: {
    recipientId: string;
    recipientName: string;
    recipientRole: UserRole;
    channel?: 'SMS' | 'WHATSAPP' | 'IN_APP_PUSH' | 'IVR' | 'EMAIL';
    title: string;
    message: string;
    relatedEntityType: 'PAYMENT' | 'COMPLAINT' | 'LOT' | 'PICKUP' | 'SECURITY';
    relatedEntityId: string;
    notificationConfig?: NotificationConfig;
  }): SystemNotification {
    const channel = params.channel || 'IN_APP_PUSH';
    const id = `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    // In a live gateway integration, SMS and Push are sent asynchronously.
    // Provider delivery acknowledgment is received via webhook.
    // We intentionally start as 'SENT_PENDING_CARRIER_ACK' or 'QUEUED'
    // rather than claiming instantaneous delivery confirmation.
    const isInstantInApp = channel === 'IN_APP_PUSH';
    const initialStatus: SystemNotification['status'] = isInstantInApp
      ? 'DELIVERED_CONFIRMED'
      : 'SENT_PENDING_CARRIER_ACK';

    const newNotification: SystemNotification = {
      id,
      recipientId: params.recipientId,
      recipientName: params.recipientName,
      recipientRole: params.recipientRole,
      channel,
      title: params.title,
      message: params.message,
      relatedEntityType: params.relatedEntityType,
      relatedEntityId: params.relatedEntityId,
      status: initialStatus,
      providerName: channel === 'SMS' ? 'CDAC_SMS_SEVA' : channel === 'WHATSAPP' ? 'META_BUSINESS_API' : 'RECYSETU_WEBSOCKET',
      providerMessageRef: `MSG-REF-${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
      createdAt: new Date().toISOString(),
      carrierAckAt: isInstantInApp ? new Date().toISOString() : undefined,
    };

    this.notifications.unshift(newNotification);

    // Keep memory clean
    if (this.notifications.length > 500) {
      this.notifications = this.notifications.slice(0, 500);
    }

    return newNotification;
  }

  public getNotificationsForEntity(entityType: string, entityId: string): SystemNotification[] {
    return this.notifications.filter(
      (n) => n.relatedEntityType === entityType && n.relatedEntityId === entityId
    );
  }

  public getRecentNotifications(limit = 20): SystemNotification[] {
    return this.notifications.slice(0, limit);
  }
}

export const notificationService = new NotificationService();
