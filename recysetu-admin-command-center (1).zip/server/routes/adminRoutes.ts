import { Router, Response } from 'express';
import { db } from '../db/database';
import { requireAdminAuth, AuthenticatedAdminRequest } from '../middleware/authMiddleware';

export const adminRouter = Router();
// Keep existing routes

// Apply requireAdminAuth middleware to ALL admin routes!
adminRouter.use(requireAdminAuth);

// --- 1. Dynamic Dashboard Stats ---

adminRouter.get('/state-analytics', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const stats = db.getStateAnalytics();
    res.json(stats);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_STATE_ANALYTICS', message: err.message });
  }
});


adminRouter.post('/state-analytics/report', async (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const reportText = await db.generateStateAnalyticsReport();
    res.json({ report: reportText });
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_STATE_REPORT', message: err.message });
  }
});

adminRouter.get(['/dashboard-stats', '/dashboard/overview'], (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const { range, startDate, endDate } = req.query;
    const stats = db.getDashboardStats({
      range: range as string,
      startDate: startDate as string,
      endDate: endDate as string,
    });
    res.json(stats);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_DASHBOARD_STATS', message: err.message });
  }
});

// --- 2. System Configuration ---
adminRouter.get('/config', (_req: AuthenticatedAdminRequest, res: Response) => {
  res.json(db.getAppConfig());
});

adminRouter.put('/config/:section', (req: AuthenticatedAdminRequest, res: Response) => {
  const { section } = req.params;
  const validSections = [
    'adminConfig',
    'materialConfig',
    'statusConfig',
    'dashboardConfig',
    'anomalyRuleConfig',
    'notificationConfig',
  ];

  if (!validSections.includes(section)) {
    res.status(400).json({ error: 'INVALID_SECTION', message: `Section '${section}' does not exist.` });
    return;
  }

  const updatedConfig = db.updateAppConfig(section as any, req.body);

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'UPDATE_CONFIG',
    targetResource: `Config/${section}`,
    details: `Admin updated configuration parameters for section '${section}'.`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, config: updatedConfig });
});

// --- 3. User Management ---
adminRouter.get('/users', (req: AuthenticatedAdminRequest, res: Response) => {
  const { page, limit, search, role, status, verificationStatus, location, startDate, endDate, sortBy, sortOrder } = req.query;
  const result = db.queryUsers({
    page: page ? parseInt(page as string, 10) : 1,
    limit: limit ? parseInt(limit as string, 10) : 25,
    search: search as string,
    role: role as string,
    status: status as string,
    verificationStatus: verificationStatus as string,
    location: location as string,
    startDate: startDate as string,
    endDate: endDate as string,
    sortBy: sortBy as string,
    sortOrder: (sortOrder as 'asc' | 'desc') || 'desc',
  });
  res.json(result);
});


adminRouter.post('/users/:id/override-trust', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { score, reason } = req.body;
  
  const user = db.getUserById(id);
  if (!user) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'User not found' });
    return;
  }
  
  const oldScore = user.role === 'COLLECTOR' ? user.contributionPoints : user.trustScore;
  
  if (user.role === 'COLLECTOR') {
    user.contributionPoints = score;
  } else {
    user.trustScore = score;
  }
  
  db.recordAuditLog({
    action: 'TRUST_SCORE_OVERRIDE',
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
targetResource: user.id,
        details: `${user.role} score overridden from ${oldScore || 0} to ${score}. Reason: ${reason}`,
        ipAddress: req.ip || '0.0.0.0'
  });
  
  res.json({ success: true, user });
});


adminRouter.get('/users/:id', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const dossier = db.getUserDetail(id);
  if (!dossier) {
    res.status(404).json({ error: 'USER_NOT_FOUND', message: 'User record not found.' });
    return;
  }
  res.json(dossier);
});

adminRouter.post('/users/:id/verify-recycler', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { reason } = req.body;
  const updatedUser = db.verifyRecycler(id, reason, {
    id: req.adminUser!.id,
    name: req.adminUser!.name,
  });

  if (!updatedUser) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Recycler not found or user is not a recycler.' });
    return;
  }

  res.json({ success: true, user: updatedUser });
});

adminRouter.post('/users/:id/reject-recycler', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { reason } = req.body;
  if (!reason || typeof reason !== 'string' || reason.trim().length < 5) {
    res.status(400).json({ error: 'REASON_REQUIRED', message: 'A specific reason (min 5 characters) is required to reject a recycler.' });
    return;
  }

  const updatedUser = db.rejectRecycler(id, reason.trim(), {
    id: req.adminUser!.id,
    name: req.adminUser!.name,
  });

  if (!updatedUser) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Recycler not found or user is not a recycler.' });
    return;
  }

  res.json({ success: true, user: updatedUser });
});

adminRouter.post('/users/:id/suspend', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { reason } = req.body;
  if (!reason || typeof reason !== 'string' || reason.trim().length < 5) {
    res.status(400).json({ error: 'REASON_REQUIRED', message: 'A specific reason (min 5 characters) is required to suspend an account.' });
    return;
  }

  try {
    const updatedUser = db.suspendUser(id, reason.trim(), {
      id: req.adminUser!.id,
      name: req.adminUser!.name,
    });

    if (!updatedUser) {
      res.status(404).json({ error: 'NOT_FOUND', message: 'User not found.' });
      return;
    }

    res.json({ success: true, user: updatedUser });
  } catch (err: any) {
    res.status(403).json({ error: 'FORBIDDEN', message: err.message });
  }
});

adminRouter.post('/users/:id/reactivate', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { reason } = req.body;
  const updatedUser = db.reactivateUser(id, reason || 'Reactivated by system administrator.', {
    id: req.adminUser!.id,
    name: req.adminUser!.name,
  });

  if (!updatedUser) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'User not found.' });
    return;
  }

  res.json({ success: true, user: updatedUser });
});

adminRouter.post('/users/:id/verify-kyc', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { reason } = req.body;
  const updatedUser = db.verifyKyc(id, reason, {
    id: req.adminUser!.id,
    name: req.adminUser!.name,
  });

  if (!updatedUser) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'User not found.' });
    return;
  }

  res.json({ success: true, user: updatedUser });
});

adminRouter.post('/users/:id/change-role', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { newRole, reason } = req.body;

  if (!['ADMIN', 'COLLECTOR', 'AGGREGATOR', 'RECYCLER'].includes(newRole)) {
    res.status(400).json({ error: 'INVALID_ROLE', message: 'Target role is invalid.' });
    return;
  }

  if (!reason || typeof reason !== 'string' || reason.trim().length < 5) {
    res.status(400).json({ error: 'REASON_REQUIRED', message: 'A specific reason is required to change user role.' });
    return;
  }

  try {
    const updatedUser = db.changeUserRole(id, newRole, reason.trim(), {
      id: req.adminUser!.id,
      name: req.adminUser!.name,
    });

    if (!updatedUser) {
      res.status(404).json({ error: 'NOT_FOUND', message: 'User not found.' });
      return;
    }

    res.json({ success: true, user: updatedUser });
  } catch (err: any) {
    res.status(403).json({ error: 'FORBIDDEN', message: err.message });
  }
});

adminRouter.patch('/users/:id/status', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { status, kycVerified } = req.body;

  const updatedUser = db.updateUserStatus(id, status, kycVerified);
  if (!updatedUser) {
    res.status(404).json({ error: 'USER_NOT_FOUND', message: 'User does not exist.' });
    return;
  }

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'USER_STATUS_CHANGE',
    targetResource: `User/${id}`,
    entity: 'User',
    entityId: id,
    result: 'SUCCESS',
    details: `Changed status of ${updatedUser.name} (${updatedUser.role}) to '${status}' (KYC: ${kycVerified ? 'VERIFIED' : 'UNVERIFIED'}).`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, user: updatedUser });
});

// --- 4. Pickups Management ---
adminRouter.get('/pickups', (req: AuthenticatedAdminRequest, res: Response) => {
  const { page, limit, search, status, category, collectorId, aggregatorId, recyclerId } = req.query;
  const result = db.queryPickups({
    page: page ? parseInt(page as string, 10) : 1,
    limit: limit ? parseInt(limit as string, 10) : 10,
    search: search as string,
    status: status as string,
    category: category as string,
    collectorId: collectorId as string,
    aggregatorId: aggregatorId as string,
    recyclerId: recyclerId as string,
  });
  res.json(result);
});

adminRouter.get('/pickups/:id', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const detail = db.getPickupDetail(id);
  if (!detail) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Pickup request not found.' });
    return;
  }
  res.json(detail);
});

adminRouter.post('/pickups/:id/audit-event', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { eventType, notes, weightKg, location, details } = req.body;

  const detail = db.getPickupDetail(id);
  if (!detail) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Pickup request not found.' });
    return;
  }

  const newEvent = db.addTraceabilityEvent({
    entityType: 'PICKUP',
    entityId: detail.pickup.id,
    trackingCode: detail.pickup.trackingCode,
    eventType: eventType || 'AUDIT_CORRECTION_RECORDED',
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    location: location || 'Central Admin Command Center',
    timestamp: new Date().toISOString(),
    verifiedOnChain: true,
    verificationHash: '0x' + Math.random().toString(16).substring(2, 14) + Date.now().toString(16),
    verificationMethod: 'ADMIN_MANUAL_AUDIT_LOG',
    weightKg: weightKg ? Number(weightKg) : undefined,
    notes: notes || 'Admin recorded an audit verification event.',
    details: details || {},
  });

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'PICKUP_AUDIT_EVENT_CREATED',
    targetResource: `Pickup/${id}`,
    details: `Added audit event ${newEvent.eventType} to pickup ${detail.pickup.trackingCode}. Note: ${notes || 'N/A'}`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, event: newEvent });
});

adminRouter.patch('/pickups/:id/status', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { status, reason } = req.body;

  const updated = db.updatePickupStatus(id, status);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Pickup request not found.' });
    return;
  }

  // Create non-destructive traceability event
  db.addTraceabilityEvent({
    entityType: 'PICKUP',
    entityId: updated.id,
    trackingCode: updated.trackingCode,
    eventType: `STATUS_CHANGED_TO_${status}`,
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    location: 'Central Admin Command Center',
    timestamp: new Date().toISOString(),
    verifiedOnChain: true,
    verificationHash: '0x' + Math.random().toString(16).substring(2, 14) + Date.now().toString(16),
    verificationMethod: 'ADMIN_AUTHORIZED_ACTION',
    notes: reason || `Admin authorized status transition to ${status}`,
    details: { previousStatus: updated.status, newStatus: status, overrideByAdmin: true, reason },
  });

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'PICKUP_STATUS_OVERRIDE',
    targetResource: `Pickup/${id}`,
    details: `Updated status of pickup ${updated.trackingCode} to '${status}'. Reason: ${reason || 'Admin override'}`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, pickup: updated });
});

// --- 5. Aggregated Lots Management ---
adminRouter.get('/lots', (req: AuthenticatedAdminRequest, res: Response) => {
  const { page, limit, search, status, category, hasDiscrepancy } = req.query;
  const result = db.queryLots({
    page: page ? parseInt(page as string, 10) : 1,
    limit: limit ? parseInt(limit as string, 10) : 10,
    search: search as string,
    status: status as string,
    category: category as string,
    hasDiscrepancy: hasDiscrepancy === 'true',
  });
  res.json(result);
});

adminRouter.get('/lots/:id', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const detail = db.getLotDetail(id);
  if (!detail) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Aggregated lot not found.' });
    return;
  }
  res.json(detail);
});

adminRouter.post('/lots/:id/reconcile-weight', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { actualWeightKg, notes } = req.body;

  if (actualWeightKg == null || isNaN(Number(actualWeightKg)) || Number(actualWeightKg) < 0) {
    res.status(400).json({ error: 'INVALID_WEIGHT', message: 'A valid actual weight in kg is required.' });
    return;
  }

  const updatedLot = db.reconcileLotWeight(id, Number(actualWeightKg), notes || 'Weight verified by weighbridge reconciliation.', {
    id: req.adminUser!.id,
    name: req.adminUser!.name,
  });

  if (!updatedLot) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Aggregated lot not found.' });
    return;
  }

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'LOT_WEIGHT_RECONCILED',
    targetResource: `Lot/${id}`,
    details: `Reconciled lot ${updatedLot.lotNumber} weight to ${actualWeightKg} kg. Discrepancy: ${updatedLot.weightDiscrepancyKg} kg (${updatedLot.weightDiscrepancyPercent}%).`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, lot: updatedLot, detail: db.getLotDetail(id) });
});

adminRouter.post('/lots/:id/audit-event', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { eventType, notes, weightKg, location, details } = req.body;

  const lotDetail = db.getLotDetail(id);
  if (!lotDetail) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Aggregated lot not found.' });
    return;
  }

  const newEvent = db.addTraceabilityEvent({
    entityType: 'LOT',
    entityId: lotDetail.lot.id,
    trackingCode: lotDetail.lot.lotNumber,
    eventType: eventType || 'AUDIT_CORRECTION_RECORDED',
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    location: location || 'Central Admin Command Center',
    timestamp: new Date().toISOString(),
    verifiedOnChain: true,
    verificationHash: '0x' + Math.random().toString(16).substring(2, 14) + Date.now().toString(16),
    verificationMethod: 'ADMIN_MANUAL_AUDIT_LOG',
    weightKg: weightKg ? Number(weightKg) : undefined,
    notes: notes || 'Admin recorded an audit verification event for lot.',
    details: details || {},
  });

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'LOT_AUDIT_EVENT_CREATED',
    targetResource: `Lot/${id}`,
    details: `Added audit event ${newEvent.eventType} to lot ${lotDetail.lot.lotNumber}. Notes: ${notes || 'N/A'}`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, event: newEvent });
});

adminRouter.patch('/lots/:id/status', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { status, reason } = req.body;

  const updated = db.updateLotStatus(id, status);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Aggregated lot not found.' });
    return;
  }

  db.addTraceabilityEvent({
    entityType: 'LOT',
    entityId: updated.id,
    trackingCode: updated.lotNumber,
    eventType: `LOT_STATUS_${status}`,
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    location: 'Central Admin Command Center',
    timestamp: new Date().toISOString(),
    verifiedOnChain: true,
    verificationHash: '0x' + Math.random().toString(16).substring(2, 14) + Date.now().toString(16),
    verificationMethod: 'ADMIN_AUTHORIZED_ACTION',
    notes: reason || `Admin updated status to ${status}`,
    details: { lotNumber: updated.lotNumber, newStatus: status, reason },
  });

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'LOT_STATUS_OVERRIDE',
    targetResource: `Lot/${id}`,
    details: `Updated lot ${updated.lotNumber} status to '${status}'. Reason: ${reason || 'N/A'}`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, lot: updated });
});

// --- QR Code Resolution & Verification ---
adminRouter.post('/qr/resolve', (req: AuthenticatedAdminRequest, res: Response) => {
  const { token } = req.body;
  if (!token || typeof token !== 'string' || !token.trim()) {
    res.status(400).json({ error: 'TOKEN_REQUIRED', message: 'QR token or identifier string is required.' });
    return;
  }

  const resolved = db.resolveQrToken(token.trim());
  if (!resolved) {
    res.status(404).json({
      found: false,
      message: 'No registered Lot or Pickup was found matching the scanned QR code or identifier.',
      token: token.trim(),
    });
    return;
  }

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'QR_LOOKUP_RESOLVED',
    targetResource: `${resolved.type}/${resolved.id}`,
    details: `Resolved QR token to ${resolved.type} [${resolved.code}].`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json(resolved);
});

// --- 6. End-to-End Traceability Events ---
adminRouter.get('/traceability', (req: AuthenticatedAdminRequest, res: Response) => {
  const { page, limit, search, entityType } = req.query;
  const result = db.queryTraceability({
    page: page ? parseInt(page as string, 10) : 1,
    limit: limit ? parseInt(limit as string, 10) : 10,
    search: search as string,
    entityType: entityType as string,
  });
  res.json(result);
});

// --- 7. Payment Monitoring, Detail & Dispute Management ---
adminRouter.get('/payments', (req: AuthenticatedAdminRequest, res: Response) => {
  const {
    page,
    limit,
    search,
    status,
    startDate,
    endDate,
    minAmount,
    maxAmount,
    disputedOnly,
    paymentMethod,
  } = req.query;

  const result = db.queryPayments({
    page: page ? parseInt(page as string, 10) : 1,
    limit: limit ? parseInt(limit as string, 10) : 10,
    search: search as string,
    status: status as string,
    startDate: startDate as string,
    endDate: endDate as string,
    minAmount: minAmount ? parseFloat(minAmount as string) : undefined,
    maxAmount: maxAmount ? parseFloat(maxAmount as string) : undefined,
    disputedOnly: disputedOnly === 'true' || disputedOnly === '1',
    paymentMethod: paymentMethod as string,
  });
  res.json(result);
});

adminRouter.get('/payments/:id', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const detail = db.getPaymentDetail(id);
  if (!detail) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Payment record not found.' });
    return;
  }
  res.json({ success: true, ...detail });
});

adminRouter.post('/payments/:id/dispute', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { action, reason } = req.body;

  if (!action || !['HOLD_ESCROW', 'RELEASE_PAYOUT', 'REFUND_PAYER', 'ARBITRATE', 'CLEAR_FLAG'].includes(action)) {
    res.status(400).json({ error: 'BAD_REQUEST', message: 'Invalid or missing dispute resolution action.' });
    return;
  }

  if (!reason || typeof reason !== 'string' || reason.trim().length < 5) {
    res.status(400).json({ error: 'BAD_REQUEST', message: 'Mandatory justification reason required (min 5 characters).' });
    return;
  }

  const updated = db.resolvePaymentDispute(id, action, reason.trim(), req.adminUser!);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Payment record not found.' });
    return;
  }

  const detail = db.getPaymentDetail(id);
  res.json({ success: true, payment: updated, detail });
});

adminRouter.patch('/payments/:id/flag', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { flag, reason } = req.body;

  const updated = db.flagPayment(id, Boolean(flag), reason);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Payment record not found.' });
    return;
  }

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: flag ? 'PAYMENT_SECURITY_HOLD' : 'PAYMENT_RELEASE',
    targetResource: `Payment/${id}`,
    details: `${flag ? 'Placed security hold on' : 'Cleared hold for'} txn ${updated.transactionId}. Reason: ${reason || 'Admin review'}.`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, payment: updated });
});

// --- 8. Grievance / Complaints Resolution & Dispute Threading ---
adminRouter.get('/complaints', (req: AuthenticatedAdminRequest, res: Response) => {
  const { page, limit, search, status, category, priority, startDate, endDate } = req.query;
  const result = db.queryComplaints({
    page: page ? parseInt(page as string, 10) : 1,
    limit: limit ? parseInt(limit as string, 10) : 10,
    search: search as string,
    status: status as string,
    category: category as string,
    priority: priority as string,
    startDate: startDate as string,
    endDate: endDate as string,
  });
  res.json(result);
});

adminRouter.get('/complaints/:id', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const detail = db.getComplaintDetail(id);
  if (!detail) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Complaint ticket not found.' });
    return;
  }
  res.json({ success: true, ...detail });
});

adminRouter.post('/complaints/:id/respond', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { message, isInternal } = req.body;

  if (!message || typeof message !== 'string' || message.trim().length < 2) {
    res.status(400).json({ error: 'BAD_REQUEST', message: 'Message content is required.' });
    return;
  }

  const updated = db.addComplaintResponse(id, message.trim(), Boolean(isInternal), req.adminUser!);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Complaint ticket not found.' });
    return;
  }

  const detail = db.getComplaintDetail(id);
  res.json({ success: true, complaint: updated, detail });
});

adminRouter.post('/complaints/:id/resolve', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { action, notes } = req.body;

  if (!action || !['RESOLVE', 'REJECT', 'ESCALATE_REVIEW', 'FLAG_INVESTIGATION'].includes(action)) {
    res.status(400).json({ error: 'BAD_REQUEST', message: 'Invalid complaint resolution action.' });
    return;
  }

  if (!notes || typeof notes !== 'string' || notes.trim().length < 3) {
    res.status(400).json({ error: 'BAD_REQUEST', message: 'Resolution notes are required.' });
    return;
  }

  const updated = db.resolveComplaint(id, action, notes.trim(), req.adminUser!);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Complaint ticket not found.' });
    return;
  }

  const detail = db.getComplaintDetail(id);
  res.json({ success: true, complaint: updated, detail });
});

adminRouter.patch('/complaints/:id/resolve', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { status, resolutionNotes } = req.body;

  let action: 'RESOLVE' | 'REJECT' | 'ESCALATE_REVIEW' = 'RESOLVE';
  if (status === 'REJECTED' || status === 'DISMISSED') action = 'REJECT';
  else if (status === 'IN_REVIEW' || status === 'IN_INVESTIGATION') action = 'ESCALATE_REVIEW';

  const updated = db.resolveComplaint(id, action, resolutionNotes || 'Updated via admin console', req.adminUser!);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Complaint ticket not found.' });
    return;
  }

  res.json({ success: true, complaint: updated });
});

// --- 9. Analytics & Reporting (Phase 6) ---
adminRouter.get('/analytics', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const { range, startDate, endDate } = req.query;
    const analytics = db.getAnalytics({
      range: range as string,
      startDate: startDate as string,
      endDate: endDate as string,
    });
    res.json(analytics);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_ANALYTICS_AGGREGATION', message: err.message });
  }
});

adminRouter.get('/analytics/export', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const { type, range, startDate, endDate } = req.query;
    const exportFile = db.generateAnalyticsExport(
      (type as string) || 'summary',
      (range as string) || '7d',
      startDate as string,
      endDate as string
    );

    res.setHeader('Content-Type', exportFile.contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${exportFile.filename}"`);
    res.send(exportFile.data);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_ANALYTICS_EXPORT', message: err.message });
  }
});

// --- 10. Anomaly Intelligence & Human Review (Phase 6) ---
adminRouter.get('/anomalies', (req: AuthenticatedAdminRequest, res: Response) => {
  const { page, limit, search, severity, status, entityType, ruleKey } = req.query;
  const result = db.queryAnomalies({
    page: page ? parseInt(page as string, 10) : 1,
    limit: limit ? parseInt(limit as string, 10) : 10,
    search: search as string,
    severity: severity as string,
    status: status as string,
    entityType: entityType as string,
    ruleKey: ruleKey as string,
  });
  res.json(result);
});

adminRouter.get('/anomalies/:id', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const anomaly = db.getAnomalyById(id);
  if (!anomaly) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Anomaly record not found.' });
    return;
  }
  res.json(anomaly);
});

adminRouter.post('/anomalies/run-rules', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const scanResult = db.runAnomalyDetectionRules();
    db.recordAuditLog({
      actorId: req.adminUser!.id,
      actorName: req.adminUser!.name,
      actorRole: 'ADMIN',
      action: 'RUN_ANOMALY_RULES',
      targetResource: 'Anomalies/Engine',
      details: `Admin initiated automated anomaly rule scan. Detected ${scanResult.detected.length} new operational issues. Total active: ${scanResult.totalActive}.`,
      ipAddress: req.ip || req.socket.remoteAddress,
    });
    res.json({ success: true, ...scanResult });
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_ANOMALY_SCAN', message: err.message });
  }
});

adminRouter.post('/anomalies/:id/review', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const updated = db.reviewAnomaly(id, req.adminUser!.name);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Anomaly record not found.' });
    return;
  }

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'ANOMALY_ASSIGNED_REVIEW',
    targetResource: `Anomaly/${id}`,
    details: `Admin assigned anomaly '${updated.title}' for compliance review.`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, anomaly: updated });
});

adminRouter.post('/anomalies/:id/resolve', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { resolution } = req.body;

  if (!resolution || !resolution.trim()) {
    res.status(400).json({ error: 'RESOLUTION_REQUIRED', message: 'Resolution justification is mandatory.' });
    return;
  }

  const updated = db.resolveAnomalyWithNotes(id, resolution.trim(), req.adminUser!.name);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Anomaly record not found.' });
    return;
  }

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'ANOMALY_RESOLVED',
    targetResource: `Anomaly/${id}`,
    details: `Admin resolved anomaly '${updated.title}'. Notes: ${resolution}`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, anomaly: updated });
});

adminRouter.post('/anomalies/:id/dismiss', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { reason } = req.body;

  if (!reason || !reason.trim()) {
    res.status(400).json({ error: 'REASON_REQUIRED', message: 'Dismissal reason is required.' });
    return;
  }

  const updated = db.dismissAnomaly(id, reason.trim(), req.adminUser!.name);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Anomaly record not found.' });
    return;
  }

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'ANOMALY_DISMISSED',
    targetResource: `Anomaly/${id}`,
    details: `Admin dismissed anomaly '${updated.title}'. Reason: ${reason}`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, anomaly: updated });
});

adminRouter.post('/anomalies/:id/investigate', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { notes } = req.body;

  const updated = db.flagAnomalyForInvestigation(id, notes || 'Field investigation assigned', req.adminUser!.name);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Anomaly record not found.' });
    return;
  }

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'ANOMALY_INVESTIGATION_FLAGGED',
    targetResource: `Anomaly/${id}`,
    details: `Admin marked anomaly '${updated.title}' for investigation: ${notes || 'Field check required'}`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, anomaly: updated });
});

adminRouter.post('/anomalies/:id/explain-ai', async (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const updated = await db.explainAnomalyWithAi(id);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Anomaly record not found.' });
    return;
  }

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'ANOMALY_AI_EXPLANATION_REQUESTED',
    targetResource: `Anomaly/${id}`,
    details: `Generated advisory AI compliance checkpoints for anomaly '${updated.title}'.`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, anomaly: updated });
});

// Backward-compatible patch
adminRouter.patch('/anomalies/:id/resolve', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;

  const updated = db.resolveAnomaly(id, status);
  if (!updated) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'Anomaly record not found.' });
    return;
  }

  db.recordAuditLog({
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    actorRole: 'ADMIN',
    action: 'ANOMALY_STATUS_UPDATE',
    targetResource: `Anomaly/${id}`,
    details: `Anomaly '${updated.title}' status updated to '${status}'.`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  res.json({ success: true, anomaly: updated });
});

// --- 11. Audit Logs ---
adminRouter.get('/audit-logs', (req: AuthenticatedAdminRequest, res: Response) => {
  const { page, limit, search } = req.query;
  const result = db.queryAuditLogs({
    page: page ? parseInt(page as string, 10) : 1,
    limit: limit ? parseInt(limit as string, 10) : 15,
    search: search as string,
  });
  res.json(result);
});

// --- 12. Materials Catalog ---
adminRouter.get('/materials', (_req: AuthenticatedAdminRequest, res: Response) => {
  res.json({ materials: db.getMaterials() });
});


// --- TRUST & REWARDS ROUTES ---
adminRouter.get('/reviews', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const search = req.query.search as string;
    
    const result = db.queryReviews({ page, limit, search });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_REVIEWS', message: err.message });
  }
});

adminRouter.post('/reviews/:id/process', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { action, scoreImpact } = req.body;
    
    const adminUser = req.adminUser;
    if (!adminUser) return res.status(401).json({ error: 'UNAUTHORIZED' });
    
    const review = db.processReview(id, adminUser.id, action, scoreImpact);
    if (!review) return res.status(404).json({ error: 'NOT_FOUND', message: 'Review not found' });
    
    res.json(review);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_PROCESS_REVIEW', message: err.message });
  }
});

adminRouter.post('/users/:id/override-score', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { newScore, reason } = req.body;
    
    const adminUser = req.adminUser;
    if (!adminUser) return res.status(401).json({ error: 'UNAUTHORIZED' });
    
    if (!reason || reason.trim().length < 5) {
      return res.status(400).json({ error: 'BAD_REQUEST', message: 'Reason must be at least 5 characters' });
    }
    
    const user = db.overrideScore(id, newScore, reason, adminUser.id);
    if (!user) return res.status(404).json({ error: 'NOT_FOUND', message: 'User not found' });
    
    res.json(user);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_SCORE_OVERRIDE', message: err.message });
  }
});

adminRouter.get('/users/:id/score-history', (req: AuthenticatedAdminRequest, res: Response) => {
  try {
    const { id } = req.params;
    const history = db.queryScoreHistory(id);
    res.json(history);
  } catch (err: any) {
    res.status(500).json({ error: 'FAILED_SCORE_HISTORY', message: err.message });
  }
});
