import { Router, Request, Response } from 'express';
import { db } from '../db/database';
import { PickupRequest, AggregatedLot } from '../../src/shared/types/domain';

export const sharedRouter = Router();

// GET /api/shared/health
sharedRouter.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'HEALTHY',
    service: 'RECYSETU Unified Backend Core',
    timestamp: new Date().toISOString(),
  });
});

// GET /api/shared/materials
sharedRouter.get('/materials', (_req: Request, res: Response) => {
  res.json({ materials: db.getMaterials() });
});

// GET /api/shared/pickups - Used by Collector and Aggregator apps
sharedRouter.get('/pickups', (req: Request, res: Response) => {
  const { page, limit, search, status, category } = req.query;
  const result = db.queryPickups({
    page: page ? parseInt(page as string, 10) : 1,
    limit: limit ? parseInt(limit as string, 10) : 10,
    search: search as string,
    status: status as string,
    category: category as string,
  });
  res.json(result);
});

// POST /api/shared/pickups - Collector creates a pickup request
sharedRouter.post('/pickups', (req: Request, res: Response) => {
  const { collectorId, collectorName, aggregatorId, aggregatorName, materialId, materialName, category, quantityKg, pricePerKg, location, notes } = req.body;

  if (!collectorId || !materialId || !quantityKg) {
    res.status(400).json({ error: 'MISSING_FIELDS', message: 'collectorId, materialId and quantityKg are required' });
    return;
  }

  const pickupId = `pk-${Date.now()}`;
  const trackingCode = `RCY-PK-${Date.now().toString().slice(-4)}`;
  const totalPrice = Number((Number(quantityKg) * Number(pricePerKg || 25)).toFixed(2));

  const newPickup: PickupRequest = {
    id: pickupId,
    trackingCode,
    collectorId,
    collectorName: collectorName || 'Unknown Collector',
    aggregatorId: aggregatorId || 'usr-agg-01',
    aggregatorName: aggregatorName || 'Pragati Waste Aggregation Hub',
    materialId,
    materialName: materialName || 'Recyclable Plastic',
    category: category || 'PLASTIC',
    quantityKg: Number(quantityKg),
    pricePerKg: Number(pricePerKg || 25),
    totalPrice,
    status: 'REQUESTED',
    location: location || { city: 'New Delhi', ward: 'Zone 1', address: 'Collection Point' },
    qrCode: `RECY-QR-${trackingCode}`,
    notes,
    createdAt: new Date().toISOString(),
  };

  // Saved directly into the same database!
  // In our db, we can add a method or query
  (db as any).pickups.set(pickupId, newPickup);

  // Add traceability event
  db.addTraceabilityEvent({
    entityType: 'PICKUP',
    entityId: newPickup.id,
    trackingCode: newPickup.trackingCode,
    eventType: 'PICKUP_REQUEST_CREATED',
    actorId: collectorId,
    actorName: collectorName || 'Collector',
    actorRole: 'COLLECTOR',
    location: newPickup.location.city,
    timestamp: newPickup.createdAt,
    verifiedOnChain: true,
    verificationHash: '0x' + Math.random().toString(16).substring(2, 14),
    details: { quantityKg: newPickup.quantityKg, material: newPickup.materialName },
  });

  res.status(201).json({ success: true, pickup: newPickup });
});

// GET /api/shared/lots - Aggregator and Recycler lot feed
sharedRouter.get('/lots', (req: Request, res: Response) => {
  const { page, limit, search, status, category } = req.query;
  const result = db.queryLots({
    page: page ? parseInt(page as string, 10) : 1,
    limit: limit ? parseInt(limit as string, 10) : 10,
    search: search as string,
    status: status as string,
    category: category as string,
  });
  res.json(result);
});
