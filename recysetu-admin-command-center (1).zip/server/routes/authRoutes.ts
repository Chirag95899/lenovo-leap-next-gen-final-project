import { Router, Request, Response } from 'express';
import { db } from '../db/database';
import { createAdminSession, revokeAdminSession, requireAdminAuth, AuthenticatedAdminRequest } from '../middleware/authMiddleware';

export const authRouter = Router();

// POST /api/auth/login
// Authenticates using Admin ID and Password. Returns session token + user profile.
authRouter.post('/login', (req: Request, res: Response) => {
  const adminId = req.body.adminId || req.body.identifier;
  const password = req.body.password;

  if (!adminId || !password) {
    res.status(400).json({
      error: 'MISSING_CREDENTIALS',
      message: 'Both Admin ID and Password are required.',
    });
    return;
  }

  const user = db.verifyAdminCredentials(adminId, password);

  if (!user) {
    res.status(401).json({
      error: 'INVALID_CREDENTIALS',
      message: 'Invalid Admin ID or password. Please verify your administrative credentials.',
    });
    return;
  }

  // Security check: Must have ADMIN role
  if (user.role !== 'ADMIN') {
    res.status(403).json({
      error: 'UNAUTHORIZED_ROLE',
      message: 'This portal is restricted to authorized RECYSETU administrators.',
    });
    return;
  }

  const session = createAdminSession(user);

  db.recordAuditLog({
    actorId: user.id,
    actorName: user.name,
    actorRole: 'ADMIN',
    action: 'ADMIN_LOGIN',
    targetResource: 'Session',
    details: `Admin ${user.adminId} logged in successfully.`,
    ipAddress: req.ip || req.socket.remoteAddress,
  });

  // Never return passwords or secret keys
  res.json({
    token: session.token,
    expiresAt: session.expiresAt,
    user: {
      id: user.id,
      adminId: user.adminId,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      status: user.status,
      kycVerified: user.kycVerified,
      location: user.location,
      metrics: user.metrics,
      createdAt: user.createdAt,
      lastActiveAt: user.lastActiveAt,
    },
  });
});

// GET /api/auth/me
// Validates token and returns current authenticated admin profile
authRouter.get('/me', requireAdminAuth, (req: AuthenticatedAdminRequest, res: Response) => {
  res.json({ user: req.adminUser });
});

// POST /api/auth/logout
authRouter.post('/logout', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization || (req.headers['x-admin-token'] as string);
  if (authHeader) {
    const token = authHeader.startsWith('Bearer ') ? authHeader.substring(7).trim() : authHeader.trim();
    revokeAdminSession(token);
  }
  res.json({ success: true, message: 'Logged out successfully.' });
});
