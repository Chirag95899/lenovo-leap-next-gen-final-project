const fs = require('fs');
let code = fs.readFileSync('src/admin/AdminCommandCenter.tsx', 'utf8');

if (!code.includes("import { AdminAnalyticsPage }")) {
  code = code.replace("import { AdminStateAnalyticsPage } from './pages/AdminStateAnalyticsPage';", "import { AdminStateAnalyticsPage } from './pages/AdminStateAnalyticsPage';\nimport { AdminAnalyticsPage } from './pages/AdminAnalyticsPage';");
  fs.writeFileSync('src/admin/AdminCommandCenter.tsx', code);
}
