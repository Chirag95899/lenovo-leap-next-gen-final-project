const india = require('@react-map/india').default;
console.log(typeof india);
console.log(Object.keys(india || {}));
