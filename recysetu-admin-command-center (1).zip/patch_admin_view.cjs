const fs = require('fs');
let content = fs.readFileSync('src/admin/types/admin.ts', 'utf8');

content = content.replace(
  "| 'notifications';",
  "| 'notifications'\n  | 'reviews'\n  | 'trust-rewards';"
);

fs.writeFileSync('src/admin/types/admin.ts', content);
