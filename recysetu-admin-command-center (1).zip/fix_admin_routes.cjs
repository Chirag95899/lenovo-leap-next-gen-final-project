const fs = require('fs');
let code = fs.readFileSync('server/routes/adminRoutes.ts', 'utf8');
code = code.replace(/ user\.name,\n/g, "");
fs.writeFileSync('server/routes/adminRoutes.ts', code);
