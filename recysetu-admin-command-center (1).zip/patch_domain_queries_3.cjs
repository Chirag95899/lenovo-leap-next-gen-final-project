const fs = require('fs');
let code = fs.readFileSync('src/admin/hooks/useAdminDomainQueries.ts', 'utf8');

function cleanFunction(name, method) {
  const regex = new RegExp(
    "const fetch" + name + " = async \\(p: number = page\\) => \\{\\s*try \\{\\s*setIsLoading\\(true\\);\\s*setError\\(null\\);[\\s\\S]*?setData\\(json\\.data\\);\\s*setTotal\\(json\\.total\\);\\s*setTotalPages\\(json\\.totalPages\\);\\s*\\} catch \\(err: any\\) \\{", 
    'g'
  );
  const replacement = "const fetch" + name + " = async (p: number = page) => {\n    try {\n      setIsLoading(true);\n      setError(null);\n      const data = await adminApi." + method + "(p);\n      setData(data.data);\n      setTotal(data.total);\n      setTotalPages(data.totalPages);\n    } catch (err: any) {";
  code = code.replace(regex, replacement);
}

cleanFunction('AiActivity', 'getAiActivity');
cleanFunction('IvrActivity', 'getIvrActivity');
cleanFunction('Notifications', 'getNotifications');

fs.writeFileSync('src/admin/hooks/useAdminDomainQueries.ts', code);
