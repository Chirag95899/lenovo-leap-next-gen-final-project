const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

// Replace direct import with lazy loading
code = code.replace(
  "import { AdminCommandCenter } from './admin/AdminCommandCenter';",
  "import { Suspense, lazy } from 'react';\nconst AdminCommandCenter = lazy(() => import('./admin/AdminCommandCenter').then(module => ({ default: module.AdminCommandCenter })));"
);

// Add Suspense around AdminCommandCenter
code = code.replace(
  "return <AdminCommandCenter />;",
  "return (\n      <Suspense fallback={<div className=\"flex items-center justify-center min-h-screen\"><div className=\"animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600\"></div></div>}>\n        <AdminCommandCenter />\n      </Suspense>\n    );"
);

fs.writeFileSync('src/App.tsx', code);
