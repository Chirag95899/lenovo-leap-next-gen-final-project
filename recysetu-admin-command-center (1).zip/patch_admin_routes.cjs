const fs = require('fs');

let code = fs.readFileSync('server/routes/adminRoutes.ts', 'utf8');
const routeToAdd = `
adminRouter.post('/users/:id/override-trust', (req: AuthenticatedAdminRequest, res: Response) => {
  const { id } = req.params;
  const { score, reason } = req.body;
  
  const user = db.getUserById(id);
  if (!user) {
    res.status(404).json({ error: 'NOT_FOUND', message: 'User not found' });
    return;
  }
  
  const oldScore = user.role === 'COLLECTOR' ? user.contributionPoints : user.trustScore;
  
  if (user.role === 'COLLECTOR') {
    user.contributionPoints = score;
  } else {
    user.trustScore = score;
  }
  
  db.recordAuditLog({
    actionType: 'TRUST_SCORE_OVERRIDE',
    actorId: req.adminUser!.id,
    actorName: req.adminUser!.name,
    targetId: user.id,
    targetName: user.name,
    description: \`\${user.role} score overridden from \${oldScore || 0} to \${score}. Reason: \${reason}\`,
    severity: 'WARNING',
    ipAddress: req.ip || '0.0.0.0'
  });
  
  res.json({ success: true, user });
});
`;

if (!code.includes("override-trust")) {
  code = code.replace(/adminRouter\.get\('\/users\/:id',/g, routeToAdd + "\n\nadminRouter.get('/users/:id',");
  fs.writeFileSync('server/routes/adminRoutes.ts', code);
}
