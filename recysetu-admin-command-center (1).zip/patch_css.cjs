const fs = require('fs');
let css = fs.readFileSync('src/index.css', 'utf8');
if (!css.includes('font-family: "Inter"')) {
  css += `
@layer base {
  body {
    font-family: "Inter", sans-serif;
  }
}
  `;
  fs.writeFileSync('src/index.css', css);
}
