const fs = require('fs');

const content = `
import React from 'react';
import { TableColumn } from '../types/admin';
import { AdminLoadingState } from './AdminLoadingState';
import { AdminEmptyState } from './AdminEmptyState';

interface AdminDataTableProps<T> {
  id?: string;
  columns: TableColumn<T>[];
  data: T[];
  keyExtractor: (item: T) => string;
  isLoading?: boolean;
  emptyTitle?: string;
  emptyDescription?: string;
  onRowClick?: (item: T) => void;
}

export function AdminDataTable<T>({
  id = 'admin-data-table',
  columns,
  data,
  keyExtractor,
  isLoading = false,
  emptyTitle = 'No data matching current criteria',
  emptyDescription = 'Try adjusting your filters or search terms.',
  onRowClick,
}: AdminDataTableProps<T>) {
  if (isLoading) {
    return <AdminLoadingState rows={6} />;
  }

  if (!data || data.length === 0) {
    return <AdminEmptyState title={emptyTitle} description={emptyDescription} />;
  }

  return (
    <div id={id} className="w-full overflow-hidden border border-slate-200 rounded-[14px] bg-white shadow-[0_2px_10px_-3px_rgba(0,0,0,0.02)]">
      <div className="w-full overflow-x-auto">
        <table className="w-full text-left text-sm text-slate-700">
          <thead className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold uppercase tracking-wider text-slate-500">
            <tr>
              {columns.map((col) => (
                <th
                  key={col.key}
                  scope="col"
                  style={{ width: col.width }}
                  className={\`px-5 py-4 whitespace-nowrap \${
                    col.align === 'right'
                      ? 'text-right'
                      : col.align === 'center'
                      ? 'text-center'
                      : 'text-left'
                  }\`}
                >
                  {col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {data.map((item, idx) => {
              const key = keyExtractor(item);
              return (
                <tr
                  key={key}
                  id={\`table-row-\${idx}\`}
                  onClick={() => onRowClick && onRowClick(item)}
                  className={\`transition-colors \${
                    onRowClick ? 'cursor-pointer hover:bg-slate-50/60' : 'hover:bg-slate-50/40'
                  }\`}
                >
                  {columns.map((col) => (
                    <td
                      key={\`\${key}-\${col.key}\`}
                      className={\`px-5 py-3.5 text-xs sm:text-sm text-slate-800 \${
                        col.align === 'right'
                          ? 'text-right'
                          : col.align === 'center'
                          ? 'text-center'
                          : 'text-left'
                      }\`}
                    >
                      {col.render ? col.render(item) : (item as any)[col.key] ?? '—'}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
`;

fs.writeFileSync('src/admin/components/AdminDataTable.tsx', content);
