const fs = require('fs');

let code = fs.readFileSync('src/admin/services/adminApiService.ts', 'utf8');
const methodToAdd = `
  public async overrideTrustScore(
    userId: string,
    score: number,
    reason: string
  ): Promise<{ success: boolean; user: any }> {
    return this.request<{ success: boolean; user: any }>(\`/api/admin/users/\${userId}/override-trust\`, {
      method: 'POST',
      body: JSON.stringify({ score, reason }),
    });
  }
`;

if (!code.includes("overrideTrustScore(")) {
  code = code.replace(/public async getSystemNotifications/g, methodToAdd + "\n  public async getSystemNotifications");
  fs.writeFileSync('src/admin/services/adminApiService.ts', code);
}
