const fs = require('fs');
let content = fs.readFileSync('src/shared/types/config.ts', 'utf8');

content = content.replace(
  'notificationConfig: NotificationConfig;',
  'notificationConfig: NotificationConfig;\n  trustRewardsConfig?: TrustRewardsConfiguration;'
);

fs.writeFileSync('src/shared/types/config.ts', content);
