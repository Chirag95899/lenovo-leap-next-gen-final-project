const fs = require('fs');
let content = fs.readFileSync('src/admin/components/charts/MaterialCategoryChart.tsx', 'utf8');

content = content.replace(
  'className="bg-slate-900 border border-slate-700/80 p-3 rounded-lg shadow-xl text-xs space-y-1.5 min-w-48"',
  'className="bg-white border border-slate-200 p-3 rounded-lg shadow-lg text-xs space-y-1.5 min-w-48"'
);
content = content.replace(/border-slate-800/g, 'border-slate-100');
content = content.replace(/text-slate-300/g, 'text-slate-600');
content = content.replace(/text-slate-500 pt-1/g, 'text-slate-400 pt-1');
content = content.replace(/text-teal-400/g, 'text-emerald-600');
content = content.replace(/text-amber-400/g, 'text-emerald-800');
content = content.replace(/'#0ea5e9'/g, "'#22c55e'"); // blue to green-500
content = content.replace(/'#15803D'/g, "'#16a34a'"); // purple to green-600
content = content.replace(/'#047857'/g, "'#15803d'"); // amber to green-700
content = content.replace(/'#84cc16'/g, "'#14532d'"); // lime to green-900
content = content.replace(/'#16A34A'/g, "'#86efac'"); // emerald to green-300
content = content.replace(/bg-emerald-600/g, 'bg-emerald-600');

fs.writeFileSync('src/admin/components/charts/MaterialCategoryChart.tsx', content);
