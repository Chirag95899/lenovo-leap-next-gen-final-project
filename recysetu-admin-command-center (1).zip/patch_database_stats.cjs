const fs = require('fs');
let content = fs.readFileSync('server/db/database.ts', 'utf8');

// Find the calculation of totalDisbursedInr
content = content.replace(
  "const totalDisbursedInr = allPayments",
  "const prevRangeStart = rangeStart - (rangeEnd - rangeStart);\n    const previousDisbursedInr = allPayments\n      .filter((p) => p.status === 'COMPLETED' && new Date(p.createdAt || p.timestamp).getTime() >= prevRangeStart && new Date(p.createdAt || p.timestamp).getTime() < rangeStart)\n      .reduce((sum, p) => sum + (p.amount || 0), 0);\n\n    const totalDisbursedInr = allPayments"
);

// Add to overview return
content = content.replace(
  "totalDisbursedInr,",
  "totalDisbursedInr,\n        previousDisbursedInr,"
);

fs.writeFileSync('server/db/database.ts', content);
