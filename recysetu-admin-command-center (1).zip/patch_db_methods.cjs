const fs = require('fs');
let content = fs.readFileSync('server/db/database.ts', 'utf8');

const newMethods = `
  // --- TRUST & REVIEWS ---
  public queryReviews(params: PaginationParams): PaginatedResult<MutualReview> {
    let result = Array.from(this.reviews.values());
    if (params.search) {
      const q = params.search.toLowerCase();
      result = result.filter(
        (r) =>
          r.reviewerName.toLowerCase().includes(q) ||
          r.reviewedName.toLowerCase().includes(q) ||
          r.transactionId.toLowerCase().includes(q)
      );
    }
    result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    const page = params.page || 1;
    const limit = params.limit || 10;
    const startIndex = (page - 1) * limit;
    const paginated = result.slice(startIndex, startIndex + limit);

    return {
      data: paginated,
      total: result.length,
      page,
      limit,
      totalPages: Math.ceil(result.length / limit),
    };
  }

  public getReviewById(id: string): MutualReview | undefined {
    return this.reviews.get(id);
  }

  public processReview(id: string, adminId: string, action: 'APPROVE' | 'REJECT' | 'FLAG', scoreImpact: number = 0): MutualReview | null {
    const review = this.reviews.get(id);
    if (!review) return null;
    
    if (action === 'APPROVE') {
      review.status = 'PROCESSED';
      review.scoreImpact = scoreImpact;
      
      // Update user score
      const user = this.users.get(review.reviewedId);
      if (user) {
        let prevScore = 0;
        let newScore = 0;
        if (user.role === 'COLLECTOR') {
          prevScore = user.contributionPoints || 0;
          newScore = prevScore + scoreImpact;
          user.contributionPoints = newScore;
        } else {
          prevScore = user.trustScore || 0;
          newScore = Math.min(100, Math.max(0, prevScore + scoreImpact));
          user.trustScore = newScore;
        }
        
        this.scoreHistory.unshift({
          id: \`sh-\${Date.now()}\`,
          userId: user.id,
          userRole: user.role,
          scoreType: user.role === 'COLLECTOR' ? 'CONTRIBUTION_POINTS' : 'TRUST_SCORE',
          previousValue: prevScore,
          changeValue: newScore - prevScore,
          newValue: newScore,
          reason: \`Review Processed: \${review.id}\`,
          source: 'REVIEW',
          relatedEntityId: review.id,
          timestamp: new Date().toISOString()
        });
      }
    } else if (action === 'REJECT') {
      review.status = 'REJECTED';
    } else if (action === 'FLAG') {
      review.status = 'FLAGGED';
    }
    
    review.processedAt = new Date().toISOString();
    
    this.recordAuditLog({
      actorId: adminId,
      actorName: 'System Admin',
      actorRole: 'ADMIN',
      action: \`REVIEW_\${action}\`,
      targetResource: \`Review \${id}\`,
      details: \`Admin \${action.toLowerCase()}ed review \${id} with impact \${scoreImpact}\`,
      entity: 'REVIEW',
      entityId: id,
      result: 'SUCCESS'
    });
    
    return review;
  }

  public queryScoreHistory(userId: string): ScoreHistoryRecord[] {
    return this.scoreHistory.filter(h => h.userId === userId).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  public overrideScore(userId: string, newScore: number, reason: string, adminId: string): User | null {
    const user = this.users.get(userId);
    if (!user) return null;
    
    let prevScore = 0;
    if (user.role === 'COLLECTOR') {
      prevScore = user.contributionPoints || 0;
      user.contributionPoints = newScore;
    } else {
      prevScore = user.trustScore || 0;
      user.trustScore = newScore;
    }
    
    this.scoreHistory.unshift({
      id: \`sh-\${Date.now()}\`,
      userId: user.id,
      userRole: user.role,
      scoreType: user.role === 'COLLECTOR' ? 'CONTRIBUTION_POINTS' : 'TRUST_SCORE',
      previousValue: prevScore,
      changeValue: newScore - prevScore,
      newValue: newScore,
      reason: \`Admin Override: \${reason}\`,
      source: 'ADMIN_OVERRIDE',
      timestamp: new Date().toISOString()
    });
    
    this.recordAuditLog({
      actorId: adminId,
      actorName: 'System Admin',
      actorRole: 'ADMIN',
      action: 'SCORE_OVERRIDE',
      targetResource: \`User \${userId}\`,
      details: \`Score overridden from \${prevScore} to \${newScore}. Reason: \${reason}\`,
      entity: 'USER',
      entityId: userId,
      result: 'SUCCESS'
    });
    
    return user;
  }
`;

content = content.replace(
  'public generateAnalyticsExport',
  newMethods + '\n  public generateAnalyticsExport'
);

fs.writeFileSync('server/db/database.ts', content);
