const fs = require('fs');
let code = fs.readFileSync('src/admin/components/AdminSidebar.tsx', 'utf8');

if (!code.includes('MapPin,')) {
  code = code.replace("LayoutDashboard,", "LayoutDashboard,\n  MapPin,");
  fs.writeFileSync('src/admin/components/AdminSidebar.tsx', code);
}
