const india = require('@react-map/india');
console.log(india);
