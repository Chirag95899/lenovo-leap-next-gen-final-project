const fs = require('fs');
let content = fs.readFileSync('src/admin/pages/AdminStateAnalyticsPage.tsx', 'utf8');

// Add import
content = content.replace(
  /import \{ AdminErrorState \} from '\.\.\/components\/AdminErrorState';/,
  "import { AdminErrorState } from '../components/AdminErrorState';\nimport { IndiaMap } from '../components/IndiaMap';"
);

// Remove the renderAbstractMap function
content = content.replace(
  /const renderAbstractMap = \(\) => \{[\s\S]*?return \([\s\S]*?\}\);[\s\S]*?\};/,
  ""
);

// Replace {renderAbstractMap()} with <IndiaMap data={data} selectedState={selectedState} onSelectState={setSelectedState} />
content = content.replace(
  /\{renderAbstractMap\(\)\}/,
  "<IndiaMap data={data} selectedState={selectedState} onSelectState={setSelectedState} />"
);

fs.writeFileSync('src/admin/pages/AdminStateAnalyticsPage.tsx', content);
