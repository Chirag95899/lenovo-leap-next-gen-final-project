const fs = require('fs');

// 1. AuditLog severity
let adminRoutes = fs.readFileSync('server/routes/adminRoutes.ts', 'utf8');
adminRoutes = adminRoutes.replace(/severity: 'WARNING',\n/g, "");
fs.writeFileSync('server/routes/adminRoutes.ts', adminRoutes);

// 2. AdminCommandCenter.tsx autoRefresh props
let adminCenter = fs.readFileSync('src/admin/AdminCommandCenter.tsx', 'utf8');
adminCenter = adminCenter.replace(/autoRefresh=\{autoRefresh\}\n/g, "");
adminCenter = adminCenter.replace(/onToggleAutoRefresh=\{setAutoRefresh\}\n/g, "");
fs.writeFileSync('src/admin/AdminCommandCenter.tsx', adminCenter);

// 3. AdminTraceabilityPage data -> details
let adminTrace = fs.readFileSync('src/admin/pages/AdminTraceabilityPage.tsx', 'utf8');
adminTrace = adminTrace.replace(/selectedEvent\.data/g, "selectedEvent.details");
fs.writeFileSync('src/admin/pages/AdminTraceabilityPage.tsx', adminTrace);

// 4. AdminTrustRewardsPage err.message -> any
let adminTrust = fs.readFileSync('src/admin/pages/AdminTrustRewardsPage.tsx', 'utf8');
adminTrust = adminTrust.replace(/const err = res;/g, "const err: any = res;");
fs.writeFileSync('src/admin/pages/AdminTrustRewardsPage.tsx', adminTrust);

