const fs = require('fs');

let centerCode = fs.readFileSync('src/admin/AdminCommandCenter.tsx', 'utf8');
centerCode = centerCode.replace(/<AdminAnomaliesPage\n/g, "<AdminAnomaliesPage\n          activeAnomaliesCount={dashboard.data?.overview?.activeAnomaliesCount || 0}\n          criticalAnomaliesCount={dashboard.data?.overview?.criticalAnomaliesCount || 0}\n");
fs.writeFileSync('src/admin/AdminCommandCenter.tsx', centerCode);

let pageCode = fs.readFileSync('src/admin/pages/AdminAnomaliesPage.tsx', 'utf8');
const interfaceRegex = /interface AdminAnomaliesPageProps \{/;
pageCode = pageCode.replace(interfaceRegex, "interface AdminAnomaliesPageProps {\n  activeAnomaliesCount?: number;\n  criticalAnomaliesCount?: number;");

const componentRegex = /export const AdminAnomaliesPage: React\.FC<AdminAnomaliesPageProps> = \(\{\n  anomalies,/;
pageCode = pageCode.replace(componentRegex, "export const AdminAnomaliesPage: React.FC<AdminAnomaliesPageProps> = ({\n  activeAnomaliesCount = 0,\n  criticalAnomaliesCount = 0,\n  anomalies,");

const renderRegex = /<AdminPageHeader\n        title="Anomaly Engine & Fraud Detection"/;
const statsHtml = `
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Total Active</p>
            <p className="text-2xl font-black text-slate-900">{activeAnomaliesCount}</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-600">
            <ShieldAlert className="w-5 h-5" />
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-rose-500 uppercase tracking-wider mb-1">Critical / High</p>
            <p className="text-2xl font-black text-rose-600">{criticalAnomaliesCount}</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center text-rose-600">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-emerald-500 uppercase tracking-wider mb-1">Resolved</p>
            <p className="text-2xl font-black text-emerald-600">--</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Dismissed</p>
            <p className="text-2xl font-black text-slate-900">--</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-600">
            <XCircle className="w-5 h-5" />
          </div>
        </div>
      </div>
      <AdminPageHeader
        title="Anomaly Engine & Fraud Detection"`;

pageCode = pageCode.replace(renderRegex, statsHtml);

fs.writeFileSync('src/admin/pages/AdminAnomaliesPage.tsx', pageCode);

