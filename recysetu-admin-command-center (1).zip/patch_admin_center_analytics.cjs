const fs = require('fs');
let content = fs.readFileSync('src/admin/AdminCommandCenter.tsx', 'utf8');

content = content.replace(
  /import \{ AdminAnalyticsPage \} from '.\/pages\/AdminAnalyticsPage';/,
  "import { AdminStateAnalyticsPage } from './pages/AdminStateAnalyticsPage';"
);

content = content.replace(
  /\{activeView === 'analytics' && <AdminAnalyticsPage \/>\}/,
  "{activeView === 'analytics' && <AdminStateAnalyticsPage />}"
);

fs.writeFileSync('src/admin/AdminCommandCenter.tsx', content);
