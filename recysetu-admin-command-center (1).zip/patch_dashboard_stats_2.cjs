const fs = require('fs');
let code = fs.readFileSync('server/db/database.ts', 'utf8');

// Replace allPickups -> periodPickups for volume and completions
code = code.replace(/allPickups\.filter\(\(p\) => p\.status === 'REQUESTED'/g, "periodPickups.filter((p) => p.status === 'REQUESTED'");
code = code.replace(/allPickups\.filter\(\(p\) => p\.status === 'COLLECTED'/g, "periodPickups.filter((p) => p.status === 'COLLECTED'");
code = code.replace(/allPickups\.reduce\(\(sum, p\) => sum \+ \(p\.quantityKg \|\| 0\), 0\)/g, "periodPickups.reduce((sum, p) => sum + (p.quantityKg || 0), 0)");

// Replace allLots -> periodLots for recycled amounts
code = code.replace(/allLots\n      \.filter\(\(l\) => l\.status === 'PROCESSED'\)/g, "periodLots\n      .filter((l) => l.status === 'PROCESSED')");

// For totalDisbursedInr:
code = code.replace(/const totalDisbursedInr = allPayments\n      \.filter\(\(p\) => p\.status === 'COMPLETED'\)/g, "const totalDisbursedInr = periodPayments\n      .filter((p) => p.status === 'COMPLETED')");

fs.writeFileSync('server/db/database.ts', code);
