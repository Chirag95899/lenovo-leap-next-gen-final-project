const fs = require('fs');
let typesCode = fs.readFileSync('src/admin/types/admin.ts', 'utf8');
if (!typesCode.includes("'geographic'")) {
  typesCode = typesCode.replace("'analytics'", "'analytics'\n  | 'geographic'");
  fs.writeFileSync('src/admin/types/admin.ts', typesCode);
}

let centerCode = fs.readFileSync('src/admin/AdminCommandCenter.tsx', 'utf8');
centerCode = centerCode.replace(/\{activeView === 'analytics' && <AdminStateAnalyticsPage \/>\}/g, "{activeView === 'geographic' && <AdminStateAnalyticsPage />}\n      {activeView === 'analytics' && <AdminAnalyticsPage data={dashboard.data} isLoading={dashboard.isLoading} />}");

// Also add import for AdminAnalyticsPage
if (!centerCode.includes('AdminAnalyticsPage')) {
  centerCode = centerCode.replace("import { AdminStateAnalyticsPage } from './pages/AdminStateAnalyticsPage';", "import { AdminStateAnalyticsPage } from './pages/AdminStateAnalyticsPage';\nimport { AdminAnalyticsPage } from './pages/AdminAnalyticsPage';");
}
fs.writeFileSync('src/admin/AdminCommandCenter.tsx', centerCode);

let sidebarCode = fs.readFileSync('src/admin/components/AdminSidebar.tsx', 'utf8');
sidebarCode = sidebarCode.replace("{ view: 'analytics', label: 'State Analytics', icon: BarChart3 },", "{ view: 'geographic', label: 'Geographic Data', icon: MapPin },\n    { view: 'analytics', label: 'Platform Analytics', icon: BarChart3 },");
fs.writeFileSync('src/admin/components/AdminSidebar.tsx', sidebarCode);

