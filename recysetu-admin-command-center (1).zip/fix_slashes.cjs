const fs = require('fs');

function fixFile(path) {
  let content = fs.readFileSync(path, 'utf8');
  content = content.replace(/\\\`/g, '`');
  content = content.replace(/\\\$/g, '$');
  fs.writeFileSync(path, content);
}

fixFile('src/admin/pages/AdminReviewsPage.tsx');
fixFile('src/admin/pages/AdminTrustRewardsPage.tsx');
