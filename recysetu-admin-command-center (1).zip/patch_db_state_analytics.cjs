const fs = require('fs');
let content = fs.readFileSync('server/db/database.ts', 'utf8');

const stateAnalyticsMethod = `
  public getStateAnalytics() {
    const allUsers = Array.from(this.users.values());
    const allLots = Array.from(this.lots.values());
    const allPickups = Array.from(this.pickups.values());

    const statesMap = new Map<string, any>();

    // We'll define states we care about.
    // Chhattisgarh is active, others inactive.
    const predefinedStates = [
      { name: 'Chhattisgarh', status: 'ACTIVE' },
      { name: 'Maharashtra', status: 'COMING_SOON' },
      { name: 'Karnataka', status: 'COMING_SOON' },
      { name: 'Delhi', status: 'COMING_SOON' },
      { name: 'Gujarat', status: 'COMING_SOON' },
      { name: 'Tamil Nadu', status: 'COMING_SOON' },
    ];

    predefinedStates.forEach(s => {
      statesMap.set(s.name, {
        state: s.name,
        status: s.status,
        collectors: 0,
        aggregators: 0,
        recyclers: 0,
        totalStakeholders: 0,
        wasteCollectedKg: 0,
        wasteProcessedKg: 0,
        wasteRecycledKg: 0,
        districts: {}
      });
    });

    // We map real data to Chhattisgarh (and possibly Durg)
    const chhattisgarh = statesMap.get('Chhattisgarh');
    chhattisgarh.districts['Durg'] = {
      district: 'Durg',
      status: 'ACTIVE',
      collectors: 0,
      aggregators: 0,
      recyclers: 0,
      totalStakeholders: 0,
      wasteCollectedKg: 0,
      wasteProcessedKg: 0,
      wasteRecycledKg: 0,
    };

    const durg = chhattisgarh.districts['Durg'];

    allUsers.forEach(u => {
      // In this demo, all users are mapped to Chhattisgarh / Durg
      if (u.role === 'COLLECTOR') {
        chhattisgarh.collectors++;
        durg.collectors++;
      }
      if (u.role === 'AGGREGATOR') {
        chhattisgarh.aggregators++;
        durg.aggregators++;
      }
      if (u.role === 'RECYCLER') {
        chhattisgarh.recyclers++;
        durg.recyclers++;
      }
    });

    chhattisgarh.totalStakeholders = chhattisgarh.collectors + chhattisgarh.aggregators + chhattisgarh.recyclers;
    durg.totalStakeholders = durg.collectors + durg.aggregators + durg.recyclers;

    allPickups.forEach(p => {
      // Collected
      chhattisgarh.wasteCollectedKg += (p.quantityKg || p.actualWeightKg || 0);
      durg.wasteCollectedKg += (p.quantityKg || p.actualWeightKg || 0);
    });

    allLots.forEach(l => {
      if (l.status === 'PROCESSED') {
        chhattisgarh.wasteRecycledKg += (l.totalWeightKg || 0);
        durg.wasteRecycledKg += (l.totalWeightKg || 0);
      }
      if (l.status === 'IN_TRANSIT' || l.status === 'RECEIVED' || l.status === 'FORMED') {
        chhattisgarh.wasteProcessedKg += (l.totalWeightKg || 0);
        durg.wasteProcessedKg += (l.totalWeightKg || 0);
      }
    });

    return Array.from(statesMap.values());
  }
`;

content = content.replace(
  /public getDashboardStats\(/,
  stateAnalyticsMethod + '\n  public getDashboardStats('
);

fs.writeFileSync('server/db/database.ts', content);
