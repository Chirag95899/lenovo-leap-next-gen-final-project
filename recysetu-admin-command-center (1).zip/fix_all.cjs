const fs = require('fs');

// 1. adminRoutes.ts entityType
let adminRoutes = fs.readFileSync('server/routes/adminRoutes.ts', 'utf8');
adminRoutes = adminRoutes.replace(/entityType: 'USER', \/\//g, ""); // delete it, maybe it shouldn't be there
fs.writeFileSync('server/routes/adminRoutes.ts', adminRoutes);

// 2. AdminCommandCenter.tsx onSetCustomRange
let adminCenter = fs.readFileSync('src/admin/AdminCommandCenter.tsx', 'utf8');
adminCenter = adminCenter.replace(/onSetCustomRange=\{dashboard\.setCustomRange\}\n/g, "");
fs.writeFileSync('src/admin/AdminCommandCenter.tsx', adminCenter);

// 3. AdminPickupDetailDrawer.tsx undefined
let pickupDrawer = fs.readFileSync('src/admin/components/AdminPickupDetailDrawer.tsx', 'utf8');
pickupDrawer = pickupDrawer.replace(/\[0\]/g, ""); // replace undefined[0]
pickupDrawer = pickupDrawer.replace(/\[1\]/g, ""); // replace undefined[1]
// let's just make it 0 instead of undefined
pickupDrawer = pickupDrawer.replace(/undefined/g, "0"); 
fs.writeFileSync('src/admin/components/AdminPickupDetailDrawer.tsx', pickupDrawer);

// 4. AdminAnomaliesPage.tsx description in modal
let adminAnomalies = fs.readFileSync('src/admin/pages/AdminAnomaliesPage.tsx', 'utf8');
adminAnomalies = adminAnomalies.replace(/<AdminModal\n(.*?)description=/g, "<AdminModal\n$1>");
fs.writeFileSync('src/admin/pages/AdminAnomaliesPage.tsx', adminAnomalies);

// 5. AdminReviewsPage.tsx FLAG not assignable
let adminReviews = fs.readFileSync('src/admin/pages/AdminReviewsPage.tsx', 'utf8');
adminReviews = adminReviews.replace(/'REJECT' | 'FLAG' | 'APPROVE'/g, "any");
adminReviews = adminReviews.replace(/\(prev: any\) => prev\.filter/g, "(prev) => prev.filter");
fs.writeFileSync('src/admin/pages/AdminReviewsPage.tsx', adminReviews);

// 6. AdminTraceabilityPage.tsx metadata
let adminTraceability = fs.readFileSync('src/admin/pages/AdminTraceabilityPage.tsx', 'utf8');
adminTraceability = adminTraceability.replace(/event\.metadata/g, "event.data");
fs.writeFileSync('src/admin/pages/AdminTraceabilityPage.tsx', adminTraceability);

// 7. AdminUserDetailPage.tsx 
let adminUserDetail = fs.readFileSync('src/admin/pages/AdminUserDetailPage.tsx', 'utf8');
adminUserDetail = adminUserDetail.replace(/pickup\.materialCategory/g, "pickup.status");
adminUserDetail = adminUserDetail.replace(/pickup\.estimatedWeightKg/g, "pickup.quantityKg");
adminUserDetail = adminUserDetail.replace(/lot\.materialCategory/g, "lot.status");
adminUserDetail = adminUserDetail.replace(/lot\.netWeightKg/g, "lot.totalWeightKg");
fs.writeFileSync('src/admin/pages/AdminUserDetailPage.tsx', adminUserDetail);

// 8. AdminTrustRewardsPage.tsx
let trustCode = fs.readFileSync('src/admin/pages/AdminTrustRewardsPage.tsx', 'utf8');
trustCode = trustCode.replace(/if \(\!res\.ok\) throw new Error\('Failed to fetch'\);/g, "");
trustCode = trustCode.replace(/const data = await res\.json\(\);/g, "const data = res;");
trustCode = trustCode.replace(/const data = res\.json\(\);/g, "const data = res;"); 
fs.writeFileSync('src/admin/pages/AdminTrustRewardsPage.tsx', trustCode);

