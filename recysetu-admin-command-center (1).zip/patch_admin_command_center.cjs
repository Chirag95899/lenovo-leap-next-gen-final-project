const fs = require('fs');
let content = fs.readFileSync('src/admin/AdminCommandCenter.tsx', 'utf8');

content = content.replace(
  /\{activeView === 'qr-scanner' && \([\s\S]*?\}\)[\s\S]*?\}\)/g,
  ""
);

content = content.replace(
  /import \{ AdminQrScannerPage \} from '.\/pages\/AdminQrScannerPage';/g,
  ""
);

fs.writeFileSync('src/admin/AdminCommandCenter.tsx', content);
